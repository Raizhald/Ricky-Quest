//The counter with pizzas in the shop building: leave pizzas there and pick them up again.
//The player carries three at most (the lineup), storage has no limit.
class StorageMenu extends PanelMenu {
  constructor({ onComplete }) {
    super({ title: "Úložiště", onComplete });
    this.note = "";
  }

  getListMarkup(title, ids) {
    const rows = ids.map(id => {
      const pizza = playerState.pizzas[id];
      return (`
        <div class="PauseMenu_row PauseMenu_row--wideLabel">
          <span class="PauseMenu_label">${PlayerState.nameOf(pizza)}</span>
          <span class="PauseMenu_value">${PanelMenu.getPizzaSummary(pizza)}</span>
        </div>
      `)
    }).join("");
    return (`
      <h3>${title}</h3>
      ${rows || `<p class="PauseMenu_note">Nic tu není.</p>`}
    `)
  }

  showOverviewPanel() {
    const stored = playerState.storage;
    this.showPanel(`
      <h2>Úložiště pizz a burgerů</h2>
      ${this.note ? `<p class="PauseMenu_note">${this.note}</p>` : ""}
      ${this.getListMarkup(`U sebe (${playerState.getCarriedIds().length}/3)`, playerState.getCarriedIds())}
      ${this.getListMarkup(`V úložišti (${stored.length})`, stored.slice(0, 8))}
      ${stored.length > 8 ? `<p class="PauseMenu_note">a ${stored.length - 8} dalších</p>` : ""}
    `);
  }

  getPizzaOption(id, description, isDisabled, handler) {
    const pizza = playerState.pizzas[id];
    return {
      label: PlayerState.nameOf(pizza),
      description,
      disabled: isDisabled,
      right: () => PanelMenu.getPizzaSummary(pizza),
      onFocus: () => this.showPanel(PanelMenu.getPizzaMarkup(pizza)),
      handler
    }
  }

  getOptions(pageKey) {
    const back = {
      label: "Zpět",
      description: "Zpět na přehled",
      onFocus: () => this.showOverviewPanel(),
      handler: () => {
        this.showPage("root");
      }
    };

    if (pageKey === "store") {
      const entries = playerState.getCarriedIds().map(id => {
        const isLast = playerState.isLastOfLineup(id);
        const leave = PlayerState.word(playerState.pizzas[id], "Nechat tuhle pizzu v úložišti", "Nechat tenhle burger v úložišti");
        return this.getPizzaOption(id, isLast ? "Menu nesmí zůstat prázdné" : leave, isLast, () => {
          playerState.storePizza(id);
          this.note = `${PlayerState.nameOf(playerState.pizzas[id])} zůstává v úložišti.`;
          this.showPage("root");
        })
      })
      return this.getPagedOptions(entries, back, () => this.showPage("store"));
    }

    if (pageKey === "withdraw") {
      const entries = playerState.storage.map(id => {
        return this.getPizzaOption(id, PlayerState.word(playerState.pizzas[id], "Vzít si tuhle pizzu s sebou", "Vzít si tenhle burger s sebou"), false, () => {
          if (playerState.withdrawPizza(id)) {
            this.note = `${PlayerState.nameOf(playerState.pizzas[id])} jde s tebou.`;
          } else {
            this.note = "U sebe můžeš mít jen tři. Nejdřív někoho uschovej.";
          }
          this.showPage("root");
        })
      })
      return this.getPagedOptions(entries, back, () => this.showPage("withdraw"));
    }

    //Any pizza can be renamed, carried or stored
    if (pageKey === "rename") {
      const entries = [...playerState.getCarriedIds(), ...playerState.storage].map(id => {
        return this.getPizzaOption(id, PlayerState.word(playerState.pizzas[id], "Dát téhle pizze nové jméno", "Dát tomuhle burgeru nové jméno"), false, () => {
          this.chosen = id;
          this.showPage("renameInput");
        })
      })
      return this.getPagedOptions(entries, back, () => this.showPage("rename"));
    }

    //The name itself is typed into a text field in the right panel: Enter confirms, Esc cancels.
    //These two options do the same for the mouse.
    if (pageKey === "renameInput") {
      return [
        {
          label: "Potvrdit (Enter)",
          description: "Napiš jméno a potvrď klávesou Enter",
          handler: () => {
            this.confirmRename();
          }
        },
        {
          label: "Zrušit (Esc)",
          description: "Nechat jméno, jak je",
          handler: () => {
            this.showPage("rename");
          }
        }
      ];
    }

    //Order of attacks: pick a pizza, pick one of its attacks, then move it up or down a slot
    if (pageKey === "order") {
      const entries = [...playerState.getCarriedIds(), ...playerState.storage].map(id => {
        return this.getPizzaOption(id, PlayerState.word(playerState.pizzas[id], "Změnit pořadí útoků téhle pizzy", "Změnit pořadí útoků tohohle burgeru"), false, () => {
          this.chosen = id;
          this.chosenSlot = 0;
          this.showPage("orderPick");
        })
      })
      return this.getPagedOptions(entries, back, () => this.showPage("order"));
    }

    if (pageKey === "orderPick") {
      const order = PlayerState.actionsOf(playerState.pizzas[this.chosen]);
      const onlyOne = PlayerState.word(playerState.pizzas[this.chosen], "Tahle pizza umí jen jeden útok", "Tenhle burger umí jen jeden útok");
      return [
        ...order.map((key, index) => {
          return {
            label: `${index + 1}. ${Actions[key].name}`,
            description: order.length > 1 ? "Vyber útok, který chceš posunout" : onlyOne,
            onFocus: () => this.showOrderPanel(index),
            handler: () => {
              if (order.length < 2) {
                return;
              }
              this.chosenSlot = index;
              this.showPage("orderMove");
            }
          }
        }),
        {
          label: "Zpět",
          description: "Zpět na seznam",
          onFocus: () => this.showOrderPanel(-1),
          handler: () => {
            this.showPage("order");
          }
        }
      ];
    }

    if (pageKey === "orderMove") {
      const order = PlayerState.actionsOf(playerState.pizzas[this.chosen]);
      const name = Actions[order[this.chosenSlot]].name;
      const move = (step, buttonIndex) => {
        this.chosenSlot = playerState.moveAction(this.chosen, this.chosenSlot, step);
        this.showPage("orderMove", buttonIndex); //stay on the same button, so it can be pressed again
      };
      return [
        {
          label: "Posunout nahoru",
          description: this.chosenSlot === 0 ? `${name} už je úplně nahoře` : `${name} půjde o místo výš`,
          disabled: this.chosenSlot === 0,
          handler: () => move(-1, 0)
        },
        {
          label: "Posunout dolů",
          description: this.chosenSlot === order.length - 1 ? `${name} už je úplně dole` : `${name} půjde o místo níž`,
          disabled: this.chosenSlot === order.length - 1,
          handler: () => move(1, 1)
        },
        {
          label: "Hotovo",
          description: "Zpět na seznam útoků",
          handler: () => {
            this.showPage("orderPick", this.chosenSlot);
          }
        }
      ];
    }

    return [
      {
        label: "Uschovat", //not "Uložit": that is saving the game in the pause menu, and the two are different words in English
        description: "Nech tu pizzu nebo burger, které zrovna nepotřebuješ",
        onFocus: () => this.showOverviewPanel(),
        handler: () => {
          this.showPage("store");
        }
      },
      {
        label: "Vyzvednout",
        description: playerState.storage.length ? "Vezmi si zpátky něco z toho, co tu máš uložené" : "V úložišti zatím nic není",
        disabled: playerState.storage.length === 0,
        onFocus: () => this.showOverviewPanel(),
        handler: () => {
          this.showPage("withdraw");
        }
      },
      {
        label: "Přejmenovat",
        description: "Dej pizze nebo burgeru vlastní jméno",
        onFocus: () => this.showOverviewPanel(),
        handler: () => {
          this.showPage("rename");
        }
      },
      {
        label: "Pořadí útoků",
        description: "Urči, v jakém pořadí se útoky nabízejí v souboji",
        onFocus: () => this.showOverviewPanel(),
        handler: () => {
          this.showPage("order");
        }
      },
      {
        label: "Zavřít",
        description: "Odejít od pultu",
        onFocus: () => this.showOverviewPanel(),
        handler: () => {
          this.close();
        }
      }
    ];
  }

  showRenamePanel() {
    const pizza = playerState.pizzas[this.chosen];
    const kindName = Pizzas[pizza.pizzaId].name;
    this.showPanel(`
      <h2>Nové jméno</h2>
      <p class="PauseMenu_note">Jak se má jmenovat ${PlayerState.nameOf(pizza)}?</p>
      <input class="PauseMenu_input" type="text" maxlength="18" value="${PlayerState.nameOf(pizza)}" />
      <p class="PauseMenu_note">Nejvýš 18 znaků. Enter potvrdí, Esc zruší.</p>
      <p class="PauseMenu_note">Když pole necháš prázdné, vrátí se původní jméno: ${kindName}.</p>
    `);
    const input = this.panelElement.querySelector(".PauseMenu_input");
    input.addEventListener("keydown", event => {
      if (event.key === "Enter") {
        event.preventDefault();
        this.confirmRename();
      }
      if (event.key === "Escape") {
        event.preventDefault();
        this.showPage("rename");
      }
    })
    //The option list grabs the focus right after it is drawn, so take it back a moment later
    setTimeout(() => {
      input.focus();
      input.select();
    }, 60)
  }

  confirmRename() {
    const input = this.panelElement.querySelector(".PauseMenu_input");
    if (!input) {
      return;
    }
    const oldName = PlayerState.nameOf(playerState.pizzas[this.chosen]);
    const newName = playerState.renamePizza(this.chosen, input.value);
    this.note = newName === oldName ? "Jméno zůstalo stejné." : `${oldName} se teď jmenuje ${newName}.`;
    this.showPage("root");
  }

  //The attacks of the chosen pizza, slot by slot, the way the fight will offer them. "picked" is the slot to highlight.
  showOrderPanel(picked) {
    const pizza = playerState.pizzas[this.chosen];
    const order = PlayerState.actionsOf(pizza);
    const rows = order.map((key, index) => (`
      <div class="PauseMenu_row PauseMenu_row--slot ${index === picked ? "PauseMenu_row--picked" : ""}">
        <span class="PauseMenu_label">${index + 1}.</span>
        <span class="PauseMenu_value">${Actions[key].name}</span>
      </div>
    `)).join("");
    this.showPanel(`
      <h2>Pořadí útoků</h2>
      <p class="PauseMenu_note">${PlayerState.nameOf(pizza)}: v tomhle pořadí se útoky nabízejí v souboji.</p>
      ${rows}
      <p class="PauseMenu_note">${order.length > 1
        ? "Vyber útok a posuň ho nahoru nebo dolů. Pořadí zůstane uložené."
        : "Jen jeden útok, není co přehazovat."}</p>
    `);
  }

  //focusIndex: which option of the new page gets the highlight (see KeyboardMenu.setOptions)
  showPage(pageKey, focusIndex = null) {
    //Going back and forth between the pages of "Pořadí útoků" keeps the page of the pizza list
    const orderPages = ["order", "orderPick", "orderMove"];
    const staysInOrder = orderPages.includes(pageKey) && orderPages.includes(this.pageKey);
    if (pageKey !== this.pageKey && !staysInOrder) {
      this.listPage = 0;
    }
    this.pageKey = pageKey;
    if (pageKey === "root") {
      this.showOverviewPanel();
    } else {
      this.note = "";
    }
    this.setOptions(this.getOptions(pageKey), focusIndex);
    if (pageKey === "renameInput") {
      this.showRenamePanel();
    }
    if (pageKey === "orderMove") {
      this.showOrderPanel(this.chosenSlot);
    }
  }
}
