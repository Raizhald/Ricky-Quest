//Trade a pizza for a random ingredient. Any pizza will do (carried or in storage), only the last one of the lineup has to stay.
class TradeMenu extends PanelMenu {
  constructor({ onComplete }) {
    super({ title: "Výměna", onComplete });
    this.note = "";
    this.chosen = null;
  }

  getTradeableIds() {
    //Carried pizzas first, then the ones in storage
    return [...playerState.getCarriedIds(), ...(playerState.storage || [])];
  }

  showIntroPanel() {
    const ids = this.getTradeableIds();
    const count = ids.length;
    const onlyOne = PlayerState.word(playerState.pizzas[ids[0]], "Máš jen jednu pizzu a tu si musíš nechat.", "Máš jen jeden burger a ten si musíš nechat.");
    this.showPanel(`
      <h2>Výměna za přísady</h2>
      ${this.note ? `<p class="PauseMenu_note PauseMenu_note--strong">${this.note}</p>` : ""}
      <p class="PauseMenu_note">${count > 1
        ? "Za každou pizzu nebo burger dostaneš jednu náhodnou přísadu. Co vyměníš, je pak pryč, i s úrovní a přísadami."
        : `${onlyOne} Další pizzy chytíš do krabic v uličce za obchodem.`}</p>
      <p class="PauseMenu_note">Přísady přidáš na pizza kameni.</p>
    `);
  }

  getOptions(pageKey) {
    if (pageKey === "confirm") {
      const pizza = playerState.pizzas[this.chosen];
      const name = PlayerState.nameOf(pizza);
      return [
        {
          label: "Ano, vyměnit",
          description: `${name} zmizí a dostaneš náhodnou přísadu`,
          onFocus: () => this.showPanel(PanelMenu.getPizzaMarkup(pizza)),
          handler: () => {
            const addonIds = Object.keys(Actions).filter(actionId => Actions[actionId].addon);
            const actionId = utils.randomFromArray(addonIds);
            playerState.removePizza(this.chosen);
            playerState.addItem(actionId);
            this.note = `Výměnou za ${name} máš: ${Actions[actionId].name}.`;
            this.isShowingResult = true;
            this.showPage("root");
          }
        },
        {
          label: PlayerState.word(pizza, "Ne, nechat si ji", "Ne, nechat si ho"),
          description: "Zpět na seznam",
          onFocus: () => this.showPanel(PanelMenu.getPizzaMarkup(pizza)),
          handler: () => {
            this.showPage("root");
          }
        }
      ];
    }

    const entries = this.getTradeableIds().map(id => {
      const pizza = playerState.pizzas[id];
      const isLast = playerState.isLastOfLineup(id);
      return {
        label: PlayerState.nameOf(pizza),
        description: isLast ? PlayerState.word(pizza, "Tvoji poslední pizzu v menu vyměnit nejde", "Tvůj poslední burger v menu vyměnit nejde") : "Vyměnit za náhodnou přísadu",
        disabled: isLast,
        right: () => PanelMenu.getPizzaSummary(pizza),
        onFocus: () => {
          //Right after a trade the panel says what you got; leave that up until the player moves on
          if (this.isShowingResult) {
            this.isShowingResult = false;
            return;
          }
          this.showPanel(PanelMenu.getPizzaMarkup(pizza));
        },
        handler: () => {
          this.chosen = id;
          this.showPage("confirm");
        }
      }
    })
    return this.getPagedOptions(entries, {
      label: "Odejít",
      description: "Ukončit výměnu",
      onFocus: () => {
        this.isShowingResult = false;
        this.showIntroPanel();
      },
      handler: () => {
        this.close();
      }
    }, () => this.showPage("root"));
  }

  showPage(pageKey) {
    if (pageKey !== this.pageKey) {
      this.listPage = 0;
    }
    this.pageKey = pageKey;
    if (pageKey === "root") {
      this.showIntroPanel();
    }
    this.setOptions(this.getOptions(pageKey));
  }
}
