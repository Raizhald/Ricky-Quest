class Progress {
  constructor() {
    this.mapId = "DemoRoom"; //a new game starts in the DEMO house, at the door
    this.startingHeroX = 0;
    this.startingHeroY = 0;
    this.startingHeroDirection = "down";
    this.saveFileKey = "PizzaLegends_SaveFile1";
  }

  save() {
    window.localStorage.setItem(this.saveFileKey, JSON.stringify({
      mapId: this.mapId,
      startingHeroX: this.startingHeroX,
      startingHeroY: this.startingHeroY,
      startingHeroDirection: this.startingHeroDirection,
      playerState: {
        pizzas: playerState.pizzas,
        lineup: playerState.lineup,
        storage: playerState.storage,
        dex: playerState.dex,
        items: playerState.items,
        storyFlags: playerState.storyFlags,
        money: playerState.money,
        playTime: playerState.playTime,
        gameMinutes: playerState.gameMinutes
      }
    }))
  }

  getSaveFile() {
    const file = window.localStorage.getItem(this.saveFileKey);
    return file ? JSON.parse(file) : null
  }

  //--- The saved game as a file (the settings: "Stáhnout zálohu", "Nahrát zálohu") ---
  //The save lives in the browser (localStorage), so it is lost with the browser's data and cannot be seen from another
  //browser. A file is a backup and a way to carry it over.

  //Offers the saved game for download. Returns the name of the file, or null when nothing is saved yet.
  downloadSave() {
    const text = window.localStorage.getItem(this.saveFileKey);
    if (!text) {
      return null;
    }
    const link = document.createElement("a");
    link.href = URL.createObjectURL(new Blob([text], { type: "application/json" }));
    link.download = Progress.BACKUP_NAME;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(link.href), 10000);
    return Progress.BACKUP_NAME;
  }

  //Is this the text of a saved game that this version can load? Returns it tidied up, or null.
  static readSave(text) {
    let file = null;
    try {
      file = JSON.parse(text);
    } catch (e) {
      return null;
    }
    const state = file && file.playerState;
    const isFine = state && typeof file.mapId === "string" && window.OverworldMaps[file.mapId]
      && state.pizzas && typeof state.pizzas === "object"
      && Array.isArray(state.lineup) && state.lineup.length > 0
      && state.lineup.every(id => state.pizzas[id])
      && Object.values(state.pizzas).every(pizza => pizza && Pizzas[pizza.pizzaId]);
    if (!isFine) {
      return null;
    }
    //Names the player gave are put into the menus as they are: the same tidying as when renaming (PlayerState.renamePizza)
    Object.values(state.pizzas).forEach(pizza => {
      if (typeof pizza.name === "string") {
        pizza.name = pizza.name.replace(/[<>&"'`\\]/g, "").trim().slice(0, 18);
      }
      if (!pizza.name) {
        delete pizza.name;
      }
    })
    return file;
  }

  //Lets the player pick a file and puts it in place of the saved game.
  //Resolves with "done", "wrong" (not a saved game of this game) or "none" (nothing was picked).
  uploadSave() {
    return new Promise(resolve => {
      const input = document.createElement("input");
      input.type = "file";
      input.accept = ".json,application/json";
      input.style.display = "none";
      input.setAttribute("data-no-translate", "");
      const finish = result => {
        input.remove();
        resolve(result);
      };
      input.addEventListener("cancel", () => finish("none"));
      input.addEventListener("change", () => {
        const picked = input.files && input.files[0];
        if (!picked) {
          finish("none");
          return;
        }
        const reader = new FileReader();
        reader.onerror = () => finish("wrong");
        reader.onload = () => {
          const file = Progress.readSave(String(reader.result));
          if (!file) {
            finish("wrong");
            return;
          }
          window.localStorage.setItem(this.saveFileKey, JSON.stringify(file));
          finish("done");
        };
        reader.readAsText(picked);
      });
      document.body.appendChild(input);
      //The key that chose this is still held down and the file window swallows its release, so the game would think
      //it is held for good and ignore the next press of it: tell the key listeners now that it went up.
      ["KeyE", "Enter"].forEach(code => document.dispatchEvent(new KeyboardEvent("keyup", { code })));
      input.click();
    })
  }

  //The two lines for the settings, the same in the pause menu and on the title screen.
  //  note        { index, text }: what happened last, shown as the description of that line (0 = download, 1 = upload)
  //  show(note)  the menu draws its settings again with this note
  //  onUploaded  optional; runs instead of the note when a saved game was taken in (the pause menu loads it right away)
  getBackupOptions({ note, show, onUploaded }) {
    const hasSave = !!window.localStorage.getItem(this.saveFileKey);
    const described = (index, text) => note && note.index === index ? note.text : text;
    return [
      {
        label: "Stáhnout zálohu",
        description: described(0, hasSave ? "Stáhne soubor s tvou uloženou hrou" : "Nejdřív hru ulož, zatím není co stáhnout"),
        disabled: !hasSave,
        handler: () => {
          const name = this.downloadSave();
          show({ index: 0, text: name ? `Staženo: ${name}` : "Nejdřív hru ulož, zatím není co stáhnout" });
        }
      },
      {
        label: "Nahrát zálohu",
        description: described(1, hasSave ? "Vybereš soubor s uloženou hrou. Přepíše tu, kterou tu máš teď" : "Vybereš soubor s uloženou hrou"),
        handler: async () => {
          const result = await this.uploadSave();
          if (result === "none") {
            return;
          }
          if (result === "done" && onUploaded) {
            onUploaded();
            return;
          }
          show({ index: 1, text: result === "done" ? "Uložená hra je nahraná. Dej Zpět a Pokračovat." : "Tenhle soubor není uložená hra z Ricky Quest." });
        }
      },
    ];
  }

  load() {
    const file = this.getSaveFile();
    if (file) {
      this.mapId = file.mapId;
      this.startingHeroX = file.startingHeroX;
      this.startingHeroY = file.startingHeroY;
      this.startingHeroDirection = file.startingHeroDirection;
      //Older save files carry no list of seen and owned kinds: start empty, migratePizzas fills it in from the pizzas
      playerState.dex = {};
      delete playerState.recipes;
      //...and no clock either: such a game starts counting now
      playerState.playTime = 0;
      playerState.gameMinutes = PlayerState.START_MINUTES;
      Object.keys(file.playerState).forEach(key => {
        playerState[key] = file.playerState[key];
      })
      playerState.migratePizzas();
      utils.emitEvent("ClockChanged");
    }
  }

}

//The name of the file "Stáhnout zálohu" offers
Progress.BACKUP_NAME = "ricky-quest-save.json";
