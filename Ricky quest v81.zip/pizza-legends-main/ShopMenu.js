class ShopMenu {
  //items: [{ actionId: "item_catchBox", price: 10 }, ...]
  //A single pizza for sale: { pizzaId: "c001", price: 80, freshness: 80, flag: "SOME_FLAG" }. It is there once:
  //after buying it is gone from the list and "flag" (if given) is written into the story flags.
  //A single item for sale works the same way: { actionId: "item_rod", price: 40, flag: "SOME_FLAG" } (gone after buying).
  //Its level is the level of the first pizza in the lineup (at most 5) unless "level" is given.
  constructor({ items, onComplete }) {
    this.items = items.map(item => {
      if (!item.pizzaId) {
        return item;
      }
      return {
        ...item,
        level: item.level || Math.min(5, playerState.getLeadLevel()),
        freshness: item.freshness || 60,
      };
    });
    this.onComplete = onComplete;
  }

  buyPizza(item) {
    if (playerState.money < item.price) {
      this.showNote("Na to nemáš dost peněz.");
      return;
    }
    playerState.money -= item.price;
    //The same stats a caught pizza of this level and freshness gets (Battle.js)
    const bonus = PlayerState.freshnessBonus(item.freshness);
    const maxHp = Math.round((50 + PlayerState.GROWTH.maxHp * (item.level - 1)) * bonus);
    playerState.addPizza(item.pizzaId, {
      level: item.level,
      maxXp: PlayerState.xpForLevel(item.level),
      caught: true,
      freshness: item.freshness,
      hp: maxHp,
      maxHp,
      attack: Math.round(PlayerState.statForLevel(item.level) * bonus),
      defense: Math.round(PlayerState.statForLevel(item.level) * bonus),
    });
    if (item.flag) {
      playerState.storyFlags[item.flag] = true;
    }
    this.items = this.items.filter(other => other !== item);
    this.keyboardMenu.setOptions(this.getOptions());
    this.showNote(`Koupeno: ${Pizzas[item.pizzaId].name}.`);
  }

  buy(item) {
    if (item.pizzaId) {
      this.buyPizza(item);
      return;
    }
    if (playerState.money < item.price) {
      this.showNote("Na to nemáš dost peněz.");
      return;
    }
    playerState.money -= item.price;
    playerState.addItem(item.actionId);
    if (item.flag) {
      playerState.storyFlags[item.flag] = true;
      this.items = this.items.filter(other => other !== item);
    }
    this.keyboardMenu.setOptions(this.getOptions()); //refresh the "you have" numbers
    this.showNote(`Koupeno: ${Actions[item.actionId].name}.`);
  }

  getOptions() {
    return [
      ...this.items.map(item => {
        if (item.pizzaId) {
          const pizza = Pizzas[item.pizzaId];
          return {
            label: `${pizza.name} (${item.price})`,
            description: `Úroveň ${item.level}, čerstvost ${item.freshness} %. ${pizza.description}`,
            right: () => "",
            handler: () => {
              this.buy(item);
            }
          }
        }
        const action = Actions[item.actionId];
        return {
          label: `${action.name} (${item.price})`,
          description: action.description,
          right: () => {
            return "máš " + playerState.countItems(item.actionId);
          },
          handler: () => {
            this.buy(item);
          }
        }
      }),
      {
        label: "Odejít",
        description: "Zavře obchod",
        handler: () => {
          this.close();
        }
      }
    ]
  }

  showNote(text) {
    this.element.querySelector(".ShopMenu_money").innerText = `Peníze: ${playerState.money}`;
    this.element.querySelector(".ShopMenu_note").innerText = text;
  }

  createElement() {
    this.element = document.createElement("div");
    this.element.classList.add("ShopMenu");
    this.element.classList.add("overlayMenu");
    this.element.innerHTML = (`
      <h2>Obchod</h2>
      <p class="ShopMenu_money"></p>
      <p class="ShopMenu_note"></p>
    `)
  }

  close() {
    this.esc?.unbind();
    this.keyboardMenu.end();
    this.element.remove();
    this.onComplete();
  }

  init(container) {
    this.createElement();
    this.keyboardMenu = new KeyboardMenu({
      descriptionContainer: container
    })
    this.keyboardMenu.init(this.element)
    this.keyboardMenu.setOptions(this.getOptions())
    this.showNote("");

    container.appendChild(this.element);

    this.esc = new KeyPressListener("Escape", () => {
      this.close();
    })
  }
}
