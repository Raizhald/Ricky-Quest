//The game's clock in the top right corner. It also does the counting: every real second adds one second
//of play time and, unless the pause menu is open, one minute of game time.
class GameClock {
  constructor({ overworld }) {
    this.overworld = overworld;
    this.element = null;
  }

  createElement() {
    this.element = document.createElement("div");
    this.element.classList.add("GameClock");
    this.element.innerHTML = (`
      <span class="GameClock_sky"></span>
      <span class="GameClock_day"></span>
      <span class="GameClock_time"></span>
    `)
    this.skyElement = this.element.querySelector(".GameClock_sky");
    this.dayElement = this.element.querySelector(".GameClock_day");
    this.timeElement = this.element.querySelector(".GameClock_time");
  }

  update() {
    const clock = playerState.getClock();
    this.dayElement.innerText = `Den ${clock.day}`;
    this.timeElement.innerText = clock.text;
    //The little window shows the sky: day, dusk (and dawn) or night
    this.skyElement.setAttribute("data-sky", playerState.getSky());
  }

  tick() {
    playerState.playTime = (playerState.playTime || 0) + 1;
    if (!this.overworld.map?.isPaused) {
      playerState.gameMinutes = (playerState.gameMinutes || 0) + 1;
    }
    this.update();
  }

  init(container) {
    this.createElement();
    this.update();
    container.appendChild(this.element);
    setInterval(() => this.tick(), 1000);
    //Sleeping, a lost fight or a loaded save file move the clock at once
    document.addEventListener("ClockChanged", () => this.update());
  }
}
