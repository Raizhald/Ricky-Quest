class OverworldMap {
  constructor(config) {
    this.overworld = null
    this.gameObjects = config.gameObjects
    this.cutsceneSpaces = config.cutsceneSpaces || {};
    this.encounters = config.encounters || null;
    this.fishing = config.fishing || null; //what bites when the hero fishes here (see OverworldEvent.fish)
    this.battleSrc = config.battleSrc || null; //picture behind battles fought on this map
    this.isOutdoors = !!config.isOutdoors; //under the open sky: evenings and nights are fully dark here
    //Copy, so walls added by people in one visit do not stay in the map config
    this.walls = { ...(config.walls || {}) }
    //Ledges: { "x, y": "down" } - walls that somebody walking in that direction hops over (see ledgeLanding)
    this.ledges = config.ledges || {};

    this.lowerImage = new Image();
    this.lowerImage.src = config.lowerSrc

    this.upperImage = new Image();
    this.upperImage.src = config.upperSrc

    //The map can look different once something has happened in the story (a wall knocked down):
    //variants: [{ required: ["FLAG"], lowerSrc, upperSrc, removeWalls: [[x, y]], addWalls: [[x, y]] }]
    //Every variant whose flags are all set is applied, in order. See applyVariants().
    this.variants = config.variants || [];
    this.applyVariants();

    this.isCutscenePlaying = false
    this.isPaused = false;
  }

  drawLowerImage(ctx, cameraPerson) {
    ctx.drawImage(this.lowerImage, utils.withGrid(10.5) - cameraPerson.x, utils.withGrid(6) - cameraPerson.y)
  }

  drawUpperImage(ctx, cameraPerson) {
    ctx.drawImage(this.upperImage, utils.withGrid(10.5) - cameraPerson.x, utils.withGrid(6) - cameraPerson.y)
  }

  //Called when the map starts and again by the event "updateMap" right after a story flag changed
  applyVariants() {
    this.variants.forEach(variant => {
      const isOn = (variant.required || []).every(flag => playerState.storyFlags[flag]);
      if (!isOn) {
        return;
      }
      if (variant.lowerSrc) { this.swapImage("lowerImage", variant.lowerSrc); }
      if (variant.upperSrc) { this.swapImage("upperImage", variant.upperSrc); }
      (variant.removeWalls || []).forEach(([x, y]) => this.removeWall(utils.withGrid(x), utils.withGrid(y)));
      (variant.addWalls || []).forEach(([x, y]) => this.addWall(utils.withGrid(x), utils.withGrid(y)));
    })
  }

  //The old picture stays on screen until the new one has loaded
  swapImage(key, src) {
    const image = new Image();
    image.onload = () => { this[key] = image; };
    image.src = src;
  }

  isSpaceTaken(currentX, currentY, direction) {
    const { x, y } = utils.nextPosition(currentX, currentY, direction)
    return this.walls[`${x}, ${y}`] || false // if there is a wall return true, else false
  }

  //A ledge is a wall with one way over it. Walking from (currentX, currentY) in the given direction into a ledge that
  //faces the same way ends two tiles on, behind it - if that tile is free. Returns that tile, or null when there is no hop.
  ledgeLanding(currentX, currentY, direction) {
    const over = utils.nextPosition(currentX, currentY, direction)
    if (this.ledges[`${over.x}, ${over.y}`] !== direction) {
      return null
    }
    const landing = utils.nextPosition(over.x, over.y, direction)
    return this.walls[`${landing.x}, ${landing.y}`] ? null : landing
  }

  mountObjects() {
    Object.keys(this.gameObjects).forEach(key => {

      let object = this.gameObjects[key]
      object.id = key

      object.applyStoryPosition()
      object.mount(this)
    })
  }

  async startCutscene(events) {
    this.isCutscenePlaying = true

    for (let i = 0; i < events.length; i++) {
      const eventHandler = new OverworldEvent({
        event: events[i],
        map: this
      })
      const result = await eventHandler.init()
      if (result === "LOST_BATTLE") {
        break;
      }
    }

    this.isCutscenePlaying = false

    // reset npcs to do their idle behaviors
    Object.values(this.gameObjects).forEach(object => object.doBehaviorEvent(this))
  }

  checkForActionCutscene() {
    const hero = this.gameObjects['hero']
    const nextCoords = utils.nextPosition(hero.x, hero.y, hero.direction)
    const match = Object.values(this.gameObjects).find(object => {
      return `${object.x}, ${object.y}` === `${nextCoords.x}, ${nextCoords.y}`
    })
    if (!this.isCutscenePlaying && match && match.talking.length) {

      const relevantScenario = match.talking.find(scenario => {
        return (scenario.required || []).every(sf => {
          return playerState.storyFlags[sf]
        })
      })
      relevantScenario && this.startCutscene(relevantScenario.events)
      return
    }

    //The action key in front of a ledge from the wrong side: a line of text says how it works
    const ledge = this.ledges[`${nextCoords.x}, ${nextCoords.y}`]
    if (!this.isCutscenePlaying && !match && ledge && ledge !== hero.direction) {
      const way = { down: "shora dolů", up: "zdola nahoru", left: "zprava doleva", right: "zleva doprava" }[ledge]
      this.startCutscene([
        { type: "textMessage", text: `Zídka. Vylézt na ni nejde, dá se přes ni jen seskočit ${way}.` },
      ])
    }
  }

  checkForFootstepCutscene() {
    const hero = this.gameObjects["hero"];
    const match = this.cutsceneSpaces[`${hero.x}, ${hero.y}`];
    if (!this.isCutscenePlaying && match) {
      //Like "talking": the first scenario whose story flags are all set plays (one with no events = nothing happens)
      const relevantScenario = match.find(scenario => {
        return (scenario.required || []).every(sf => playerState.storyFlags[sf])
      })
      if (!relevantScenario) {
        return;
      }
      //A scene that ends in a fight can ask for a pizza that is fit to fight (needsHealthyPizza);
      //without one its "otherwise" events play instead, e.g. a line of text and a step back
      const events = relevantScenario.needsHealthyPizza && !playerState.hasHealthyPizza()
        ? (relevantScenario.otherwise || [])
        : relevantScenario.events;
      events.length && this.startCutscene(events)
    }
  }

  //People with "sight" (the Burger Queen gang) watch the tiles in front of them. When the hero stands in view, with nothing
  //in between, a sign pops up over their head, they walk up to the hero, their "talking" scene plays (the fight) and they go
  //back to their place. Called after every step of the hero and on every step of the game loop (some of them turn around).
  checkForTrainerSight() {
    const hero = this.gameObjects["hero"];
    if (this.isCutscenePlaying || this.isPaused || !hero || hero.movingProgressRemaining > 0 || !playerState.hasHealthyPizza()) {
      return;
    }
    for (const [id, watcher] of Object.entries(this.gameObjects)) {
      if (!watcher.sight || watcher.movingProgressRemaining > 0) {
        continue;
      }
      if (watcher.sightFlag && playerState.storyFlags[watcher.sightFlag]) {
        continue;
      }
      let distance = 0;
      let position = { x: watcher.x, y: watcher.y };
      for (let step = 1; step <= watcher.sight; step++) {
        position = utils.nextPosition(position.x, position.y, watcher.direction);
        if (position.x === hero.x && position.y === hero.y) {
          distance = step;
          break;
        }
        if (this.walls[`${position.x}, ${position.y}`]) {
          break; //something stands in the way
        }
      }
      const scenario = distance && watcher.talking.find(candidate => {
        return (candidate.required || []).every(flag => playerState.storyFlags[flag]);
      });
      if (!scenario) {
        continue;
      }
      const wasLooking = watcher.direction;
      const away = utils.oppositeDirection(wasLooking);
      this.startCutscene([
        { type: "emote", who: id, time: 650 },
        { type: "walkPath", who: id, path: Array(distance - 1).fill(wasLooking) },
        { type: "stand", who: "hero", direction: away, time: 120 },
        ...scenario.events,
        { type: "walkPath", who: id, path: Array(distance - 1).fill(away) },
        { type: "stand", who: id, direction: wasLooking, time: 120 },
      ]);
      return;
    }
  }

  //Forgotten pizzas: on marked tiles every step has a chance to start a fight with one of them
  checkForWildEncounter() {
    if (this.isCutscenePlaying || !this.encounters || !playerState.hasHealthyPizza()) {
      return;
    }
    const hero = this.gameObjects["hero"];
    //"encounters" is one place or a list of places, each with its own tiles and kinds (the back alleys have pizza boxes
    //and, in the courtyard, burger boxes). "rustle" and "shinyText" are the lines shown before the fight.
    const places = Array.isArray(this.encounters) ? this.encounters : [this.encounters];
    const place = places.find(candidate => candidate.spaces[`${hero.x}, ${hero.y}`]);
    if (!place || Math.random() >= place.chance) {
      return;
    }
    //Some kinds only come out at night; "weight" makes a kind that much more likely than the others
    const isNight = playerState.isNight();
    let pool = [];
    place.pizzas.filter(entry => !entry.night || isNight).forEach(entry => {
      for (let i = 0; i < (entry.weight || 1); i++) {
        pool.push(entry);
      }
    })
    const { night, weight, ...pizza } = utils.randomFromArray(pool);
    const shiny = PlayerState.rollShiny(); //the golden one is very rare
    this.startCutscene([
      { type: "textMessage", text: place.rustle || "V krabicích něco zašustilo..." },
      ...(shiny ? [
        { type: "flash" },
        { type: "textMessage", text: place.shinyText || "Počkat... ta pizza se celá zlatě třpytí!" },
      ] : []),
      {
        type: "battle",
        wild: {
          ...pizza,
          shiny,
          freshness: 1 + Math.floor(Math.random() * 100), //1 to 100 %
          //Anything from level 1 up to the level of the player's front pizza, but no higher than the place allows
          level: 1 + Math.floor(Math.random() * Math.min(playerState.getLeadLevel(), place.maxLevel || 1)),
        }
      },
    ])
  }

  addWall(x, y) {
    this.walls[`${x}, ${y}`] = true
  }

  removeWall(x, y) {
    delete this.walls[`${x}, ${y}`]
  }

  moveWall(wasX, wasY, direction) {
    this.removeWall(wasX, wasY)
    const { x, y } = utils.nextPosition(wasX, wasY, direction)
    this.addWall(x, y)
  }
}

//Beth's fight (the same for the new opening and for old saves): afterwards she steps aside so the way out is free
function bethFightEvents() {
  return [
    { type: "textMessage", text: "Rozdrtím tě!", faceHero: "npcA" },
    { type: "battle", enemyId: "beth" },
    { type: "addStoryFlag", flag: "DEFEATED_BETH" },
    { type: "textMessage", text: "Skončila jsem rozdrcená jako slabý pepř.", faceHero: "npcA" },
    { type: "textMessage", text: "Dobře, dobře. Můžeš jít, dveře jsou volné.", faceHero: "npcA" },
    { type: "stepAside", who: "npcA", directions: ["right", "left"] },
    { who: "npcA", type: "stand", direction: "down", time: 300 },
  ]
}

//What happens when the bed at home is used (both of its tiles do the same)
function homeBedEvents() {
  return [
    { type: "textMessage", text: "Zalézáš pod peřinu. Ještě kousek pizzy a dobrou..." },
    { type: "sleep" },
    {
      type: "textMessage",
      text: () => {
        const sky = playerState.getSky();
        const greeting = sky === "night" ? "Venku je tma jako v peci." : (sky === "dusk" ? "Venku je šero." : "Venku je světlo.");
        return `Spal jsi ${PlayerState.SLEEP_HOURS} hodin jako v peřince z mozzarelly. ${greeting}`;
      }
    },
  ]
}

//The board with the three levels hangs on the arcade wall above tiles 5 to 7: one spot to read it from under each of them
function hernaScoreboard() {
  const spots = {};
  for (let x = 5; x <= 7; x++) {
    spots[`scoreboard${x}`] = new Hotspot({
      x: utils.withGrid(x),
      y: utils.withGrid(3),
      talking: [{
        events: [
          { type: "textMessage", text: "Tabule testovacích robotů. I – lehký, II – střední, III – těžký. Testovat jde pořád dokola." },
        ]
      }]
    });
  }
  return spots;
}

//The experiment in the cellar laboratory. It starts when the hero steps on tile (11, 7), right behind the gap
//in the row of boxes, and plays once (the flag CELLAR_MONSTER_FLED is set at its end; a lost fight ends the
//scene early and it starts over on the next visit).
function cellarExperimentScene() {
  return [
    //Everybody on their marks, whatever happened here before
    { type: "place", who: "scientistA", x: utils.withGrid(11), y: utils.withGrid(5), direction: "up" },
    { type: "place", who: "scientistB", x: utils.withGrid(15), y: utils.withGrid(5), direction: "up" },
    { type: "place", who: "monster", x: utils.withGrid(-30), y: utils.withGrid(-30) },
    { type: "textMessage", text: "Teplota pět set stupňů. Kvásek z hlubin už bublá.", speaker: "scientistA" },
    { type: "textMessage", text: "Spouštím experiment číslo 47. Tentokrát to vyjde!", speaker: "scientistB" },
    { type: "walkPath", who: "hero", path: ["right", "right"] },
    { type: "stand", who: "hero", direction: "up", time: 300 },
    { type: "stand", who: "scientistA", direction: "right", time: 300 },
    { type: "textMessage", text: "Hej, sem se nesmí! ...No, když už tu jsi, dívej se. Tohle změní pizzu navždy.", speaker: "scientistA" },
    { type: "stand", who: "scientistA", direction: "up", time: 200 },
    { type: "textMessage", text: "Tři... dva... jedna... TEĎ!", speaker: "scientistB" },
    { type: "flash", shake: true },
    //The monster comes out of the oven's mouth, between the two of them
    { type: "place", who: "monster", x: utils.withGrid(13), y: utils.withGrid(5), direction: "down" },
    { type: "textMessage", text: "Z pece se vyvalil kouř a s ním něco obrovského!" },
    { type: "stand", who: "scientistA", direction: "right", time: 200 },
    { type: "textMessage", text: "Ono to žije!", speaker: "scientistA" },
    { type: "stand", who: "scientistB", direction: "left", time: 200 },
    { type: "textMessage", text: "A má hlad! UTÍKEJ!", speaker: "scientistB" },
    //Both run out through the gap and stop behind the hero, in the store room
    {
      type: "parallel",
      tracks: [
        [{ type: "walkPath", who: "scientistA", path: ["down", "down", "left", "left", "left"] }, { type: "stand", who: "scientistA", direction: "right", time: 100 }],
        [{ type: "walkPath", who: "scientistB", path: ["down", "left", "left", "left", "left", "down", "left", "left"] }, { type: "stand", who: "scientistB", direction: "right", time: 100 }],
      ]
    },
    { type: "textMessage", text: "My... my ti budeme fandit odsud!", speaker: "scientistB" },
    { type: "battle", enemyId: "pizzaMonster" },
    //Won = the monster ran away. It backs off along the wall and goes through it.
    { type: "textMessage", text: "Monstrum couvá podél zdi a hledá, kudy ven..." },
    { type: "walkPath", who: "monster", path: ["right", "right", "right", "right", "right", "up"] },
    { type: "flash", shake: true },
    { type: "addStoryFlag", flag: "CELLAR_WALL_BROKEN" },
    { type: "updateMap" },
    { type: "walkPath", who: "monster", path: ["up"] },
    { type: "place", who: "monster", x: utils.withGrid(-30), y: utils.withGrid(-30) },
    { type: "textMessage", text: "PRÁSK! Monstrum prorazilo zeď a zmizelo ve tmě." },
    { type: "addStoryFlag", flag: "CELLAR_MONSTER_FLED" },
    //The scientists come back: one to the oven, one to the desk
    {
      type: "parallel",
      tracks: [
        [{ type: "walkPath", who: "scientistB", path: ["right", "right", "right", "up", "right", "right", "right", "right", "up"] }, { type: "stand", who: "scientistB", direction: "right", time: 100 }],
        [{ type: "walkPath", who: "scientistA", path: ["right", "right", "right", "right", "up", "up"] }, { type: "stand", who: "scientistA", direction: "right", time: 100 }],
      ]
    },
    { type: "textMessage", text: "Experiment číslo 47: těsto ožilo. A uteklo. To v plánu nebylo.", speaker: "scientistA" },
    { type: "textMessage", text: "Probouralo zeď do stok! Jestli se dostane do města, sní každou pizzerii.", speaker: "scientistB" },
    { type: "textMessage", text: "Tebe se bálo. Běž za ním, my tu zatím... uklidíme.", speaker: "scientistA" },
    { type: "stand", who: "scientistB", direction: "up", time: 100 },
  ]
}

//The guard at the west end of the main street (same sprite as the guard in Tony Boii's). The rest of column 4 (rows 10, 12, 13) is closed by
//bushes (drawn into StreetLower.png by tools/baracek.py, walls in the Street grid).
function streetGuards() {
  return {
    streetGuard: new Person({
      x: utils.withGrid(4),
      y: utils.withGrid(11),
      direction: "right",
      name: "Guard",
      src: "images/characters/people/npc27.png",
      behaviorLoop: [{ type: "stand", direction: "right", time: 3000 }],
      talking: [{ events: [{ type: "textMessage", text: "Ulice je uzavřená." }] }],
    }),
  };
}

//The barred tunnel at the end of the sewers (two tiles wide, both say the same)
function sewerGrateTalking() {
  return [
    {
      required: ["SEWER_GRATE_OPEN"],
      events: [{ type: "textMessage", text: "Prostřední pruty jsou pryč. Tunelem se dá projít." }]
    },
    //With the pliers from Hank (HAS_PLIERS) the middle bars come off: the map switches to its open form and the tunnel can be walked into
    {
      required: ["HAS_PLIERS"],
      events: [
        { type: "textMessage", text: "Mříž je ohnutá a olepená sýrem. Tudy se monstrum protáhlo." },
        { type: "textMessage", text: "Bereš kleště od Hanka. Cvak! Cvak! Cvak! Prostřední pruty padají na zem." },
        { type: "addStoryFlag", flag: "SEWER_GRATE_OPEN" },
        { type: "place", who: "grateA", x: utils.withGrid(-10), y: utils.withGrid(-10) },
        { type: "place", who: "grateB", x: utils.withGrid(-11), y: utils.withGrid(-10) },
        { type: "updateMap" },
        { type: "textMessage", text: "Cesta do tunelu je volná. Zevnitř táhne a je cítit rozteklý sýr." },
      ]
    },
    {
      events: [
        { type: "textMessage", text: "Mříž je ohnutá a olepená sýrem. Monstrum se protáhlo dovnitř." },
        { type: "textMessage", text: "Za mříží je tma a hučí tam voda. Dál se zatím nedostaneš." },
        { type: "textMessage", text: "Abych se tam dostal, budu potřebovat kleště." },
      ]
    },
  ];
}

//One tile of the grate (it is two tiles wide). Once it is cut open the spot is gone, so the tile can be walked into.
function sewerGrateSpot(x) {
  return new Hotspot({
    x: utils.withGrid(x),
    y: utils.withGrid(3),
    storyPositions: [{ required: ["SEWER_GRATE_OPEN"], x: utils.withGrid(-10 - (x % 2)), y: utils.withGrid(-10) }],
    talking: sewerGrateTalking(),
  });
}

//The tunnel behind the grate in the sewers, where the pizza monster went: a corridor that bends to the right and ends at a
//dark mouth in the back wall. Walking into the mouth leads to the monster's lair (sewerLairMap below).
//Drawn by tools/tunel.py (Content/sewerTunnel.js).
function sewerTunnelMap() {
  const grid = SewerTunnelGrid;
  const texts = {
    o: ["Z roury teče něco zeleného. Tady vzadu to smrdí ještě víc."],
  };
  const spots = {};
  grid.spots.forEach(([x, y, kind], index) => {
    spots[`spot${index}`] = new Hotspot({
      x: utils.withGrid(x),
      y: utils.withGrid(y),
      talking: [{ events: texts[kind].map(text => ({ type: "textMessage", text })) }]
    });
  });
  const cutsceneSpaces = {};
  grid.exit.forEach(([x, y], index) => {
    cutsceneSpaces[utils.asGridCoord(x, y)] = [
      { events: [{ type: "changeMap", map: "Sewer", x: utils.withGrid(18 + index), y: utils.withGrid(4), direction: "down" }] }
    ];
  });
  //The dark mouth: into the lair, to the top of its way in
  const lairExit = SewerLairGrid.exit;
  grid.mouth.forEach(([x, y]) => {
    cutsceneSpaces[utils.asGridCoord(x, y)] = [
      { events: [{ type: "changeMap", map: "SewerLair", x: utils.withGrid(lairExit[1][0]), y: utils.withGrid(lairExit[1][1] - 1), direction: "up" }] }
    ];
  });
  return {
    id: "SewerTunnel",
    lowerSrc: "images/maps/SewerTunnelLower.png",
    battleSrc: "images/maps/SewerBattle.png",
    upperSrc: "images/maps/SewerTunnelUpper.png",
    gameObjects: {
      hero: new Person({
        isPlayerControlled: true,
        x: utils.withGrid(grid.exit[0][0]),
        y: utils.withGrid(grid.exit[0][1] - 1),
        direction: "up",
      }),
      ...spots,
    },
    walls: utils.wallsFromGrid(grid.rows),
    cutsceneSpaces,
  };
}

//The fight in the monster's lair. It starts when the hero steps on any tile of the row SewerLairGrid.trigger (the whole
//width of the room, so there is no way round) and plays once: the flag MONSTER_DEFEATED is set after the fight is won.
//A lost fight ends the scene early (the hero wakes up at home) and it starts over on the next visit.
function sewerLairScene() {
  const [x, y] = SewerLairGrid.monster;
  return [
    { type: "stand", who: "hero", direction: "up", time: 300 },
    { type: "textMessage", text: "V hnízdě z krabic od pizzy něco mlaská a chroupe." },
    { type: "textMessage", text: "Pizzové monstrum! Od sklepa pořádně narostlo." },
    { type: "flash", shake: true },
    { type: "textMessage", text: "Monstrum zařvalo, až ze zdí odkapává sýr. Všimlo si tě!" },
    { type: "battle", enemyId: "pizzaMonsterLair" },
    //Won: it melts into its nest. The picture of the room switches to the one with the puddle (see "variants").
    { type: "flash", shake: true },
    { type: "addStoryFlag", flag: "MONSTER_DEFEATED" },
    { type: "place", who: "monster", x: utils.withGrid(-30), y: utils.withGrid(-30) },
    { type: "place", who: "nestHeart", x: utils.withGrid(x), y: utils.withGrid(y) },
    { type: "updateMap" },
    { type: "textMessage", text: "Pizzové monstrum se zapotácelo, splasklo a rozteklo se po hnízdě." },
    { type: "textMessage", text: "Zbyla po něm louže sýra, dvě olivy a kolečko salámu." },
    { type: "textMessage", text: "V sýru se lesknou mince, které cestou spolykalo. Ty už máš v kapse." },
    { type: "giveItem", actionId: "addon_mozzarella" },
    { type: "giveItem", actionId: "addon_chilli" },
    { type: "textMessage", text: "Na kraji hnízda zůstala Mozzarella a Chilli papričky. Bereš si je taky." },
    { type: "textMessage", text: "Město je v bezpečí. Vědci ve sklepě by to měli vědět." },
  ];
}

//The monster's lair at the end of the sewers (since v81): one big room with its nest of pizza boxes by the back wall.
//Drawn by tools/doupe.py (Content/sewerLair.js). The way in is the dark mouth at the end of the tunnel behind the grate.
function sewerLairMap() {
  const grid = SewerLairGrid;
  const [monsterX, monsterY] = grid.monster;
  const texts = {
    o: "Z roury se valí voda ze stok rovnou do kanálu.",
    B: "Krabice od pizzy. Vylízané do posledního drobku.",
    C: "Hrouda ztuhlého sýra, tvrdá jako kámen.",
    R: "Hromada okousaných kůrek. Kůrky monstru zjevně nechutnají.",
  };
  const spots = {};
  grid.spots.forEach(([x, y, kind], index) => {
    spots[`spot${index}`] = new Hotspot({
      x: utils.withGrid(x),
      y: utils.withGrid(y),
      talking: [{ events: [{ type: "textMessage", text: texts[kind] }] }]
    });
  });
  const cutsceneSpaces = {};
  //Back out: under the dark mouth in the tunnel
  const mouth = SewerTunnelGrid.mouth;
  grid.exit.forEach(([x, y], index) => {
    const [backX, backY] = mouth[Math.min(index, mouth.length - 1)];
    cutsceneSpaces[utils.asGridCoord(x, y)] = [
      { events: [{ type: "changeMap", map: "SewerTunnel", x: utils.withGrid(backX), y: utils.withGrid(backY + 1), direction: "down" }] }
    ];
  });
  grid.trigger.forEach(([x, y]) => {
    cutsceneSpaces[utils.asGridCoord(x, y)] = [
      { required: ["MONSTER_DEFEATED"], events: [] },
      {
        needsHealthyPizza: true,
        events: sewerLairScene(),
        otherwise: [
          { type: "textMessage", text: "Z hnízda vepředu se ozývá mlaskání. S menu na kaši se k němu radši nepřibližuj." },
          { type: "walk", who: "hero", direction: "down" },
        ]
      },
    ];
  });
  return {
    id: "SewerLair",
    lowerSrc: "images/maps/SewerLairLower.png",
    battleSrc: "images/maps/SewerBattle.png",
    upperSrc: "images/maps/SewerLairUpper.png",
    //After the fight: the nest with nothing in it but a puddle of cheese
    variants: [
      { required: ["MONSTER_DEFEATED"], lowerSrc: "images/maps/SewerLairDoneLower.png" },
    ],
    gameObjects: {
      hero: new Person({
        isPlayerControlled: true,
        x: utils.withGrid(grid.exit[1][0]),
        y: utils.withGrid(grid.exit[1][1] - 1),
        direction: "up",
      }),
      //Sits in the middle of its nest until it is beaten, then it is gone for good
      monster: new Monster({
        x: utils.withGrid(monsterX),
        y: utils.withGrid(monsterY),
        direction: "down",
        name: "Pizzové monstrum",
        src: "images/characters/pizza-monster.png",
        shadowSrc: "images/characters/pizza-monster-shadow.png",
        frames: 2,
        storyPositions: [
          { required: ["MONSTER_DEFEATED"], x: utils.withGrid(-30), y: utils.withGrid(-30) },
        ],
      }),
      //What is left of it in the nest (the puddle is part of the picture); off the map until then
      nestHeart: new Hotspot({
        x: utils.withGrid(-31),
        y: utils.withGrid(-30),
        storyPositions: [
          { required: ["MONSTER_DEFEATED"], x: utils.withGrid(monsterX), y: utils.withGrid(monsterY) },
        ],
        talking: [{ events: [{ type: "textMessage", text: "Louže rozteklého sýra. Dvě olivy na tebe koukají skoro vyčítavě." }] }],
      }),
      ...spots,
    },
    walls: utils.wallsFromGrid(grid.rows),
    cutsceneSpaces,
  };
}

//What Hank says in his hardware store (to him across the counter). He promised a discount; it turns out to be the whole price.
function hankTalking() {
  return [
    {
      required: ["HAS_PLIERS"],
      events: [
        { type: "textMessage", text: "Kleště drží? S těma přeštípneš i mříž na kanále.", faceHero: "hank" },
        { type: "textMessage", text: "Až budeš potřebovat něco dalšího, stav se. Pro tebe mám vždycky slevu.", faceHero: "hank" },
      ]
    },
    {
      events: [
        { type: "textMessage", text: "Tady jsi! Vítej v mým železářství, zachránce.", faceHero: "hank" },
        { type: "textMessage", text: "Slíbil jsem ti slevu a Hank sliby plní. Pro tebe sto procent.", faceHero: "hank" },
        { type: "textMessage", text: "Koukal jsi mi ve výloze na kleště, viď? Jsou tvoje. Přeštípnou i mříž na kanále.", faceHero: "hank" },
        { type: "giveItem", actionId: "item_pliers" },
        { type: "addStoryFlag", flag: "HAS_PLIERS" },
        { type: "textMessage", text: "Dostal jsi kleště! Najdeš je v Předmětech." },
        { type: "textMessage", text: "A až budeš potřebovat něco dalšího, stav se.", faceHero: "hank" },
      ]
    },
  ];
}

//Inside the hardware store on the square under Burger Tower. It opens when Hank is back from the tower (TOWER_POWER_ON).
//Drawn by tools/zelezarstvi.py (Content/hardware.js); the texts of the things are here, by their letter in its layout.
function hardwareMap() {
  const grid = HardwareGrid;
  const texts = {
    P: ["Děrovaná deska plná nářadí. Kladiva, klíče, pilka a šroubováky, všechno srovnané podle velikosti."],
    W: ["Oknem je vidět na náměstíčko. Burger Tower odsud zabírá půl oblohy."],
    K: ["Hodiny jdou přesně. Hank je natahuje každé ráno."],
    S: ["Regál s plechovkami barev. Červená, modrá, žlutá a jedna bez nálepky."],
    T: ["Stůl se zbožím: červená bedna na nářadí, klubko provazu a dvě plechovky barvy."],
    t: ["Lopata a hrábě v kbelíku. Cedulka: PŮJČOVNÉ 5 ZA DEN."],
    b: ["Sud plný hřebíků. Radši do něj nesahej."],
    k: ["Zatlučená bedna. Podle váhy jsou v ní šrouby."],
    L: ["Štafle. Vylézt na ně se ti nechce."],
  };
  const spots = {};
  grid.spots.forEach(([x, y, kind], index) => {
    spots[`spot${index}`] = new Hotspot({
      x: utils.withGrid(x),
      y: utils.withGrid(y),
      talking: kind === "C" ? hankTalking() : [{ events: texts[kind].map(text => ({ type: "textMessage", text })) }]
    });
  });
  const [ownerX, ownerY, ownerDirection] = grid.owner;
  const door = TowerSquareGrid.shutter;
  return {
    id: "Hardware",
    lowerSrc: "images/maps/HardwareLower.png",
    battleSrc: "images/maps/HardwareBattle.png",
    upperSrc: "images/maps/HardwareUpper.png",
    gameObjects: {
      hero: new Person({
        isPlayerControlled: true,
        x: utils.withGrid(grid.exit[0]),
        y: utils.withGrid(grid.exit[1] - 1),
        direction: "up",
      }),
      hank: new Person({
        x: utils.withGrid(ownerX),
        y: utils.withGrid(ownerY),
        direction: ownerDirection,
        name: "Hank",
        src: "images/characters/people/npc77.png",
        behaviorLoop: [
          { type: "stand", direction: ownerDirection, time: 3600 },
          { type: "stand", direction: "right", time: 1200 },
        ],
        talking: hankTalking(),
      }),
      ...spots,
    },
    walls: utils.wallsFromGrid(grid.rows),
    cutsceneSpaces: {
      [utils.asGridCoord(grid.exit[0], grid.exit[1])]: [
        { events: [{ type: "changeMap", map: "TowerSquare", x: utils.withGrid(door[0]), y: utils.withGrid(door[1] + 1), direction: "down" }] }
      ],
    },
  };
}

//Up the ladder in the sewers: the hero comes out of the manhole in the back alleys, one tile below it
function sewerLadderEvents() {
  return [
    {
      type: "changeMap",
      map: "BackAlleys",
      x: utils.withGrid(BackAlleysGrid.start[0]),
      y: utils.withGrid(BackAlleysGrid.start[1]),
      direction: "down"
    }
  ]
}

//The barrier at the north end of the back alleys (one spot to read it on each of its tiles).
//Dabl, the last of the gang, pulls it away when he is beaten (DEFEATED_BQ20): the map then switches to its variant
//without the barrier (see "variants" of BackAlleys) and these spots have nothing to say and move out of the way.
function backAlleysGate() {
  const spots = {};
  BackAlleysGrid.gate.forEach(([x, y], index) => {
    spots[`gate${index}`] = new Hotspot({
      x: utils.withGrid(x),
      y: utils.withGrid(y),
      storyPositions: [
        { required: ["DEFEATED_BQ20"], x: utils.withGrid(-10), y: utils.withGrid(-10) },
      ],
      talking: [
        {
          required: ["DEFEATED_BQ20"],
          events: []
        },
        {
          events: [
            { type: "textMessage", text: "Zábrana přes celou uličku. Za ní to vede dál do města." },
            { type: "textMessage", text: "Hlídá ji Double z gangu Burger Queen. Dokud tu stojí, nepohneš s ní." },
          ]
        }
      ]
    });
  });
  return spots;
}

//Walking off the north edge of the back alleys (behind the barrier) leads to the square under Burger Tower
function backAlleysNorthExit() {
  const spaces = {};
  BackAlleysGrid.beyond.filter(([x, y]) => y === 0).forEach(([x, y], index) => {
    const arrival = TowerSquareGrid.exit[Math.min(index, TowerSquareGrid.exit.length - 1)];
    spaces[utils.asGridCoord(x, y)] = [
      {
        events: [
          {
            type: "changeMap",
            map: "TowerSquare",
            x: utils.withGrid(arrival[0]),
            y: utils.withGrid(arrival[1] - 1),
            direction: "up"
          }
        ]
      }
    ];
  });
  return spaces;
}

//The way out of the square under Burger Tower: back south into the back alleys, behind the barrier
function towerSquareExit() {
  const spaces = {};
  const landing = BackAlleysGrid.beyond.filter(([x, y]) => y === 1);
  TowerSquareGrid.exit.forEach(([x, y], index) => {
    const arrival = landing[Math.min(index, landing.length - 1)];
    spaces[utils.asGridCoord(x, y)] = [
      {
        events: [
          {
            type: "changeMap",
            map: "BackAlleys",
            x: utils.withGrid(arrival[0]),
            y: utils.withGrid(arrival[1]),
            direction: "down"
          }
        ]
      }
    ];
  });
  return spaces;
}

//What Tony says in his shop (to him directly and across the counter). Nothing before he is back.
function tonyTalking() {
  const shop = [
    { type: "shopMenu", items: [{ actionId: "item_escapeRope", price: 30 }, { actionId: "item_lamp", price: 50 }] },
    { type: "textMessage", text: "Měj se! A kdyby bylo zle, zatáhni za lano.", faceHero: "tony" },
  ];
  return [
    {
      required: ["CELLAR_MONSTER_FLED", "TALKED_TO_TONY"],
      events: [
        { type: "textMessage", text: "Vítej u Tonyho! Únikové lano, ohřívací lampa? Vždycky skladem.", faceHero: "tony" },
        ...shop,
      ]
    },
    {
      required: ["CELLAR_MONSTER_FLED"],
      events: [
        { type: "textMessage", text: "Tony Boiii, k službám! Konečně zpátky ve svým krámě.", faceHero: "tony" },
        { type: "textMessage", text: "Dokud ve sklepě Neon Greens řádilo to pizzový monstrum, radši jsem zavřel a zmizel. Prý jsi ho vyhnal ty. Díky!", faceHero: "tony" },
        { type: "textMessage", text: "Hlídače jsem poslal domů. A mám novinku: únikové lano.", faceHero: "tony" },
        { type: "textMessage", text: "Zatáhneš za něj a ať jsi kdekoli, vytáhne tě rovnou domů. Najdeš ho v Předmětech.", faceHero: "tony" },
        { type: "textMessage", text: "A mám i ohřívací lampy. Posvítíš na toho, kdo je na kaši, a je zase jako z pece. Jde to i uprostřed souboje.", faceHero: "tony" },
        { type: "addStoryFlag", flag: "TALKED_TO_TONY" },
        ...shop,
      ]
    },
  ];
}

//Ráfek the courier and his bike: a quick way between the square under Burger Tower and the hero's house on the main street.
//He stands by the way in from the back alleys; the first time the hero walks in, he calls out and lends the bike
//(BIKE_ALLOWED). From then on the bike next to him takes the hero in front of the house, and a second bike stands
//there (tile BIKE_HOME) that takes the hero back. Where things are on the square comes from tools/vez.py.
const BIKE_HOME = [22, 8];       //the bike in front of the hero's house on the main street
const BIKE_HOME_STOP = [23, 8];  //where the hero gets off there (in front of the door)

function bikeRideEvents(text, answer, map, [x, y]) {
  return [
    {
      type: "choice",
      text,
      options: [
        {
          label: answer,
          description: "Nasedneš a kolo tě tam doveze",
          events: [
            { type: "textMessage", text: "Nasedáš na kolo a šlapeš do pedálů..." },
            { type: "changeMap", map, x: utils.withGrid(x), y: utils.withGrid(y), direction: "down" },
          ]
        },
        { label: "Zůstat tady", description: "Kolo nikam neuteče" },
      ]
    }
  ];
}

function courierLendsBike() {
  return [
    { type: "textMessage", text: "Hej, ty! Ty jsi sem došel přes celej gang Burger Queen? Pěšky?!", speaker: "courier" },
    { type: "textMessage", text: "Já jsem Spoke, kurýr. Rozvážím po celým městě, ale do těch uliček bych nevlez ani za zlatý prase.", speaker: "courier" },
    { type: "textMessage", text: "Víš co? Půjč si moje kolo. Kdykoli chceš. Doveze tě rovnou před tvůj barák na hlavní ulici.", speaker: "courier" },
    { type: "textMessage", text: "A až budeš chtít zpátky k Burger Tower, bude tam na tebe čekat. Stačí nasednout.", speaker: "courier" },
    { type: "addStoryFlag", flag: "BIKE_ALLOWED" },
  ];
}

function towerSquareBike() {
  return {
    courier: new Person({
      x: utils.withGrid(TowerSquareGrid.courier[0]),
      y: utils.withGrid(TowerSquareGrid.courier[1]),
      direction: "right",
      name: "Spoke",
      src: "images/characters/people/npc52.png",
      behaviorLoop: [
        { type: "stand", direction: "right", time: 3200 },
        { type: "stand", direction: "down", time: 1600 },
      ],
      talking: [
        {
          required: ["BIKE_ALLOWED"],
          events: [
            { type: "textMessage", text: "Kolo je tvoje, kdy chceš. Doveze tě před tvůj barák a od baráku zase sem.", faceHero: "courier" },
            { type: "textMessage", text: "Jen mi na něm nevoz pizzu vzhůru nohama.", faceHero: "courier" },
          ]
        },
        {
          //The same lines as in the scene on the way in, for somebody who got here another way (an older save file)
          events: courierLendsBike().map(event => event.speaker ? { ...event, faceHero: "courier" } : event),
        },
      ]
    }),
    bike: new Bike({
      x: utils.withGrid(TowerSquareGrid.bike[0]),
      y: utils.withGrid(TowerSquareGrid.bike[1]),
      talking: [
        {
          required: ["BIKE_ALLOWED"],
          events: bikeRideEvents("Jet domů?", "Jet domů", "Street", BIKE_HOME_STOP),
        },
        {
          events: [
            { type: "textMessage", text: "Červené kolo s krabicí od pizzy na nosiči. Někomu patří, radši se nejdřív zeptej." },
          ]
        },
      ]
    }),
  };
}

//The first steps on the square (the tiles around the way in from the back alleys): Ráfek spots the hero and lends the bike
function towerSquareCourierScene() {
  const spaces = {};
  const columns = TowerSquareGrid.exit.map(([x]) => x);
  const row = TowerSquareGrid.exit[0][1] - 1;
  const tiles = [
    ...columns.map(x => [x, row]),
    ...columns.map(x => [x, row - 1]),
    [Math.min(...columns) - 1, row],
    [Math.max(...columns) + 1, row],
  ];
  tiles.forEach(([x, y]) => {
    spaces[utils.asGridCoord(x, y)] = [
      { required: ["BIKE_ALLOWED"], events: [] },
      {
        events: [
          { type: "stand", who: "courier", direction: "right", time: 100 },
          { type: "emote", who: "courier", time: 650 },
          { type: "stand", who: "hero", direction: "left", time: 150 },
          ...courierLendsBike(),
        ]
      },
    ];
  });
  return spaces;
}

//The bike in front of the hero's house. It is not there (off the map) until Ráfek has lent his.
function streetBike() {
  return {
    homeBike: new Bike({
      x: utils.withGrid(-10),
      y: utils.withGrid(-10),
      storyPositions: [
        { required: ["BIKE_ALLOWED"], x: utils.withGrid(BIKE_HOME[0]), y: utils.withGrid(BIKE_HOME[1]) },
      ],
      talking: [
        {
          required: ["BIKE_ALLOWED"],
          events: bikeRideEvents("Jet k Burger Tower?", "Jet k věži", "TowerSquare", TowerSquareGrid.bikeStop),
        },
      ]
    }),
  };
}

//The glass doors of Burger Tower on the square: into the reception, in front of the way out there
function towerSquareDoor() {
  const spaces = {};
  const inside = TowerFloors[0].exit;
  TowerSquareGrid.towerDoor.forEach(([x, y], index) => {
    const arrival = inside[Math.min(index, inside.length - 1)];
    spaces[utils.asGridCoord(x, y)] = [
      {
        events: [
          {
            type: "changeMap",
            map: "Tower1",
            x: utils.withGrid(arrival[0]),
            y: utils.withGrid(arrival[1] - 1),
            direction: "up"
          }
        ]
      }
    ];
  });
  return spaces;
}

//What the things inside Burger Tower say, by the letter they have in the layout of tools/vez_vnitrek.py.
//With more lines than one, different pieces of the same kind say different ones.
//(The lift "E" and the reception desk "R" are not here: see towerLiftTalking() and receptionTalking().)
const TOWER_TEXTS = {
  F: ["Prapor gangu Burger Queen: zlatá koruna na tmavě červeném."],
  c: [
    "Bedny plné krabiček na burgery. Na každé je vypálená korunka.",
    "Bedna s nápisem HOUSKY - NEKLOPIT.",
    "Bedna je zatlučená. Voní z ní kečup.",
  ],
  M: ["Hlavní sloup věže, od sklepa až po střechu. Někdo do něj vyryl: ZDE BYL DOUBLE."],
  W: ["Z okna je vidět celé město. Hlavní ulice je odsud malinká."],
  Q: ["Obrovský stůl. Na zlaté jmenovce stojí: QUEEN."],
  g: ["Vitrína s poháry: NEJLEPŠÍ BURGER MĚSTA, pět let po sobě."],
  B: ["Socha hamburgeru s korunou na mramorovém podstavci."],
  S: ["Trezor. Je zamčený a pořádně těžký."],
};

//The twenty people on floors 1 to 4, in the same order as window.TowerCrew (Content/enemies.js) and TowerFloors[n].trainers:
//[what they say when they spot the hero, what they say when beaten, what they say when talked to later]
const TOWER_CREW_LINES = [
  ["Vítejte v Burger Tower! Dáte si k tomu souboj?", "Reklamace se vyřizují u pultu...", "Recepce je vlevo. Já tu jen utírám stoly."],
  ["Hele, pizzař! Šéfová slíbila za každého prémii!", "Tak nic. Zase bez prémií.", "Schody nahoru jsou v pravým koutě. Výtah nejede."],
  ["Stůj! Tady se čeká ve frontě!", "Dobře, dobře, tak si předbíhej.", "Bez proudu nejede ani zmrzlinovač. Tragédie."],
  ["Po koberci se chodí jen s burgerem v ruce!", "Vylil jsem se.", "Nahoře jsou horší než já. A mají delší směny."],
  ["Ke schodům jen přese mě. Mám to v popisu práce!", "Výpověď podám zítra.", "Ve skladu o patro výš hlídá Crate. Na toho si dej pozor."],

  ["Sklad je jen pro zaměstnance! Kde máš kartičku?", "Kartička neplatí. Projdi.", "Bez proudu taháme bedny po schodech. Záda mám v háji."],
  ["Co unese ruka, to unese Crate. A ty si odneseš porážku!", "Těžký. Tohle bylo těžký.", "Nahoře v chodbách sedí úředníci. Ti tě umoří papírama."],
  ["V mrazáku je tma a zima. A tobě bude taky!", "Rozmrzl jsem.", "Mražený housky tajou. Královna bude zuřit."],
  ["Pytel cibule, pytel brambor, pytel pizzařů!", "Roztrhl jsem se.", "Jdi už, ať to nikdo nevidí."],
  ["Vozím palety rychlejc, než stihneš mrknout!", "Píchla jsem.", "Schody jsou hned tady vlevo. Jeď."],

  ["Dobrý den. Máte vyplněný formulář B-12 na vstup do patra?", "Formulář zamítnut. Mně.", "Splatnost do čtrnácti dnů. Na shledanou."],
  ["Bez razítka neprojdeš. A razítko mám já!", "Bum. Schváleno.", "Podatelna je zavřená. Všechno je zavřený, nejde proud."],
  ["Založím si tě. Pod P jako porážka!", "Založím se sám.", "Tři chodby tam, tři zpátky. Kdo tohle projektoval?"],
  ["Za tvoje vyhození mám slíbený bonus!", "Bonus odepsán.", "Elita o patro výš nosí zlato. A koruny. Fakt."],
  ["Podle mých tabulek máš šanci nula celá nic!", "Chyba ve vzorci.", "Bez proudu mi nejede počítač. Počítám na prstech."],

  ["Do čtvrtého patra smí jen to nejlepší maso. A ty jsi těsto!", "Propečenej. Úplně.", "Královna sedí o patro výš. Klepej."],
  ["Hlídám hlavní sloup věže. A voním draze!", "Vyčichl jsem.", "Ten sloup drží celou věž. Neopírej se o něj."],
  ["Mně se neříká ne. Mně se říká ano, madam!", "Ano, pizzaři...", "Nahoře stojí dva bodyguardi, Lefty a Righty. Hádej, kterej je kterej."],
  ["Jsem sladká, ale kousnu!", "Au. Kousl jsi první.", "Ke schodům je to doleva a nahoru."],
  ["Poslední patro před Královnou. Přese mě neprošel nikdo!", "Tak teda jeden.", "Běž. A řekni jí, že jsem se bránil."],
];

//The trainers of one floor (1 to 4). They watch the tiles in front of them like the gang in the back alleys.
function towerCrew(number) {
  const crew = {};
  const first = TowerFloors.slice(0, number - 1).reduce((sum, floor) => sum + floor.trainers.length, 0);
  TowerFloors[number - 1].trainers.forEach(([x, y, direction, sight, also], offset) => {
    const index = first + offset;
    const id = `bt${index + 1}`;
    const flag = `DEFEATED_BT${index + 1}`;
    const [before, beaten, later] = TOWER_CREW_LINES[index];
    crew[id] = new Person({
      x: utils.withGrid(x),
      y: utils.withGrid(y),
      direction,
      name: TowerCrew[index][0],
      src: `images/characters/people/npc${53 + index}.png`,
      sight,
      sightFlag: flag,
      resetOnMount: true,
      //Some keep turning between two directions, so they can be sneaked past with good timing
      behaviorLoop: also ? [
        { type: "stand", direction, time: 2600 + (index % 3) * 300 },
        { type: "stand", direction: also, time: 1700 + (index % 2) * 400 },
      ] : [
        { type: "stand", direction, time: 3000 },
      ],
      talking: [
        { required: [flag], events: [{ type: "textMessage", text: later, faceHero: id }] },
        {
          events: [
            { type: "textMessage", text: before, faceHero: id },
            { type: "battle", enemyId: id },
            { type: "addStoryFlag", flag },
            { type: "textMessage", text: beaten, faceHero: id },
          ]
        }
      ]
    });
  });
  return crew;
}

//The lift, the same door on every floor. Without power it stands (and between the two top floors somebody is knocking
//inside: the ironmonger). Once the Burger Queen is beaten the power is back (TOWER_POWER_ON) and it goes to any floor.
const TOWER_FLOOR_NAMES = ["1F vstupní hala", "2F sklad", "3F chodby", "4F síň se sloupem", "5F kancelář"];
function towerLiftTalking(number) {
  const rides = TowerFloors.map((floor, index) => index + 1).filter(target => target !== number).map(target => {
    const [x, y] = TowerFloors[target - 1].lift[0];
    return {
      label: TOWER_FLOOR_NAMES[target - 1],
      description: "Výtah tě tam doveze",
      events: [{ type: "changeMap", map: `Tower${target}`, x: utils.withGrid(x), y: utils.withGrid(y + 1), direction: "down" }],
    };
  });
  return [
    {
      required: ["TOWER_POWER_ON"],
      events: [{ type: "choice", text: "Výtah. Kam pojedeš?", options: [...rides, { label: "Zůstat tady", description: "Výtah počká" }] }]
    },
    {
      events: [
        { type: "textMessage", text: "Výtah nejede, nejde elektřina. Na dveřích visí cedulka: MIMO PROVOZ." },
        ...(number >= 4 ? [{ type: "textMessage", text: "Počkat... Ze šachty se ozývá tlumené bouchání. Jako by ve výtahu někdo byl." }] : []),
      ]
    },
  ];
}

//What the receptionist says, to anyone who uses the desk in front of her (she cannot be reached herself)
function receptionTalking() {
  return [
    {
      required: ["TOWER_POWER_ON"],
      events: [
        { type: "textMessage", text: "Elektřina už zase jde! Výtah jezdí do všech pater.", faceHero: "receptionist" },
        { type: "textMessage", text: "A paní Královna vzkazuje, že dnes už nikoho nepřijímá. Ani zítra.", faceHero: "receptionist" },
      ]
    },
    {
      events: [
        { type: "textMessage", text: "Vítejte v Burger Tower! Bohužel nám nejde elektřina, takže výtah stojí.", faceHero: "receptionist" },
        { type: "textMessage", text: "Nahoru se dá jen po schodech, jsou vpravo v koutě. Opravář přišel už ráno, ale od té doby ho nikdo neviděl.", faceHero: "receptionist" },
        { type: "textMessage", text: "A paní Královna návštěvy nepřijímá. Pizzaře už vůbec ne.", faceHero: "receptionist" },
      ]
    },
  ];
}

//The top floor: the Burger Queen in front of her desk with a bodyguard on each side, so she can only be talked to from
//the carpet in front of her. The bodyguards watch the tiles in front of them; whoever walks up the middle of the carpet
//gets to the Queen without a fight, and then she calls them herself. Beating her switches off her Mega-grill, the power
//comes back, the lift opens and the ironmonger who was stuck in it comes out, thanks the hero and rides down.
function towerBossFloor(number) {
  const { queen, guardLeft, guardRight } = TowerFloors[number - 1].people;
  const [liftX, liftY] = TowerFloors[number - 1].lift[0];
  const guards = {
    guardLeft: ["DEFEATED_GUARD_LEFT", guardLeft, "Stát. Paní Královna nepřijímá.", "Lefty... jde k zemi.", "..."],
    guardRight: ["DEFEATED_GUARD_RIGHT", guardRight, "Slyšels kolegu. Čelem vzad.", "Righty taky.", "Hm."],
  };
  const guardFight = id => {
    const [flag, , before, beaten] = guards[id];
    return [
      { type: "textMessage", text: before, speaker: id },
      { type: "battle", enemyId: id },
      { type: "addStoryFlag", flag },
      { type: "textMessage", text: beaten, speaker: id },
    ];
  };
  const callGuards = ids => [
    { type: "textMessage", text: "Lefty! Righty! Vyveďte toho pizzaře z mé kanceláře.", faceHero: "queen" },
    ...ids.flatMap(guardFight),
    { type: "textMessage", text: "K ničemu. Oba dva. Tak pojď blíž, pizzaři, vyřídím si to s tebou sama.", speaker: "queen" },
  ];
  //The hero stands on the carpet under the Queen, looking up. The ironmonger walks from the lift to the tile on his left.
  const there = [
    ...Array(queen[1] + 1 - (liftY + 1)).fill("down"),
    ...Array(queen[0] - 1 - liftX).fill("right"),
  ];
  const back = [...there].reverse().map(direction => utils.oppositeDirection(direction));
  const queenFight = [
    { type: "textMessage", text: "Tak ty jsi ten pizzař, co mi rozprášil gang v uličkách.", faceHero: "queen" },
    { type: "textMessage", text: "Tohle město bude jíst burgery. Jenom burgery. Od snídaně do večeře!", faceHero: "queen" },
    { type: "textMessage", text: "Já jsem Burger Queen. Pokloň se, nebo bojuj!", faceHero: "queen" },
    { type: "battle", enemyId: "burgerQueen" },
    { type: "addStoryFlag", flag: "DEFEATED_QUEEN" },
    { type: "textMessage", text: "Moje koruna... Moje burgery! To není možné!", speaker: "queen" },
    { type: "textMessage", text: "Dobře. Vyhrál jsi, pizzaři. Tohle kolo.", speaker: "queen" },
    { type: "textMessage", text: "Proud? Všechen žere můj Mega-gril na střeše. Měl péct burgery pro celé město.", speaker: "queen" },
    { type: "textMessage", text: "Fajn! Vypínám ho. Stejně už nemám komu velet.", speaker: "queen" },
    { type: "flash", shake: true },
    { type: "addStoryFlag", flag: "TOWER_POWER_ON" },
    { type: "textMessage", text: "Mega-gril ztichl. Světla ve věži naskočila a výtah se s cuknutím rozjel." },
    { type: "textMessage", text: "Cink! Dveře výtahu se otevřely." },
    { type: "place", who: "ironmonger", x: utils.withGrid(liftX), y: utils.withGrid(liftY + 1), direction: "down" },
    { type: "stand", who: "hero", direction: "left", time: 300 },
    { type: "walkPath", who: "ironmonger", path: there },
    { type: "textMessage", text: "Uf! Konečně venku. Od rána jsem trčel ve výtahu mezi patry!", speaker: "ironmonger" },
    { type: "textMessage", text: "Jsem Hank, železář. Mám krám hned vedle věže. Přišel jsem jim opravit pojistky a vtom vypadl proud.", speaker: "ironmonger" },
    { type: "textMessage", text: "Slyšel jsem to až do šachty. Tys ji porazil! Děkuju ti, kuchaři.", speaker: "ironmonger" },
    { type: "textMessage", text: "Stav se u mě v železářství. Dostaneš pořádnou slevu, to ti slibuju.", speaker: "ironmonger" },
    { type: "textMessage", text: "Tak, a jedu dolů. Snad to tentokrát dojede.", speaker: "ironmonger" },
    { type: "walkPath", who: "ironmonger", path: back },
    { type: "stand", who: "ironmonger", direction: "up", time: 400 },
    { type: "place", who: "ironmonger", x: utils.withGrid(-10), y: utils.withGrid(-10) },
    { type: "textMessage", text: "Dveře se zavřely a výtah odjel dolů. Teď už jezdí do všech pater." },
    { type: "stand", who: "hero", direction: "up", time: 100 },
  ];

  const people = {
    queen: new Person({
      x: utils.withGrid(queen[0]),
      y: utils.withGrid(queen[1]),
      direction: queen[2],
      name: "Queen", //under the portrait there is room for about eight letters; in the fight she is "Burger Queen"
      src: "images/characters/people/npc76.png",
      behaviorLoop: [{ type: "stand", direction: queen[2], time: 3000 }],
      talking: [
        { required: ["DEFEATED_QUEEN"], events: [{ type: "textMessage", text: "Nech mě. Počítám, kolik burgerů mi zbylo.", faceHero: "queen" }] },
        { required: ["DEFEATED_GUARD_LEFT", "DEFEATED_GUARD_RIGHT"], events: queenFight },
        { required: ["DEFEATED_GUARD_LEFT"], events: callGuards(["guardRight"]) },
        { required: ["DEFEATED_GUARD_RIGHT"], events: callGuards(["guardLeft"]) },
        { events: callGuards(["guardLeft", "guardRight"]) },
      ]
    }),
    //The owner of the hardware store on the square. Stuck in the lift until the power is back; he only shows up in the scene above.
    ironmonger: new Person({
      x: utils.withGrid(-10),
      y: utils.withGrid(-10),
      name: "Hank",
      src: "images/characters/people/npc77.png",
    }),
  };
  Object.keys(guards).forEach(id => {
    const [flag, [x, y, direction], , , later] = guards[id];
    people[id] = new Person({
      x: utils.withGrid(x),
      y: utils.withGrid(y),
      direction,
      name: TowerBosses[id][0],
      src: `images/characters/people/${TowerBosses[id][2]}.png`,
      sight: 2,
      sightFlag: flag,
      resetOnMount: true,
      behaviorLoop: [{ type: "stand", direction, time: 3000 }],
      talking: [
        { required: [flag], events: [{ type: "textMessage", text: later, faceHero: id }] },
        { events: guardFight(id).map(event => event.speaker ? { ...event, faceHero: id } : event) },
      ]
    });
  });
  return people;
}

//One floor of Burger Tower (1 = the entrance hall, 5 = the office of the Burger Queen). The layout, the grid and the places
//of the stairs and of the people come from TowerFloors (Content/towerFloors.js, written by tools/vez_vnitrek.py). It is built
//like the towers in Pokémon: every floor is a hall cut into corridors by walls, the stairs are openings in the back wall in
//the corners, up alternately on the right and on the left, so every floor has to be walked through. Walking into a stairway
//leads to the floor above or below; the hero comes out one tile under the matching stairway there.
//Floors 1 to 4 have five trainers each (towerCrew), the receptionist sits on floor 1 and the Queen on floor 5 (towerBossFloor).
function towerFloor(number) {
  const floor = TowerFloors[number - 1];
  const below = (tile) => ({ x: utils.withGrid(tile[0]), y: utils.withGrid(tile[1] + 1), direction: "down" });
  const start = floor.exit.length
    ? { x: utils.withGrid(floor.exit[0][0]), y: utils.withGrid(floor.exit[0][1] - 1), direction: "up" }
    : below(floor.down[0]);

  const cutsceneSpaces = {};
  const leadsTo = (tile, map, arrival) => {
    cutsceneSpaces[utils.asGridCoord(tile[0], tile[1])] = [{ events: [{ type: "changeMap", map, ...arrival }] }];
  };
  //up the stairs: the hero comes out under the stairs down of the next floor (they are right above), and the other way round
  floor.up.forEach(tile => leadsTo(tile, `Tower${number + 1}`, below(TowerFloors[number].down[0])));
  floor.down.forEach(tile => leadsTo(tile, `Tower${number - 1}`, below(TowerFloors[number - 2].up[0])));
  //out of the house: onto the square, in front of the glass doors
  floor.exit.forEach((tile, index) => {
    const door = TowerSquareGrid.towerDoor[Math.min(index, TowerSquareGrid.towerDoor.length - 1)];
    leadsTo(tile, "TowerSquare", below(door));
  });

  const spots = {};
  floor.spots.forEach(([x, y, kind], index) => {
    const texts = TOWER_TEXTS[kind];
    const talking = kind === "E" ? towerLiftTalking(number)
      : kind === "R" ? receptionTalking()
      : texts ? [{ events: [{ type: "textMessage", text: texts[(x + y + number) % texts.length] }] }]
      : null;
    if (!talking) {
      return;
    }
    spots[`spot${index}`] = new Hotspot({ x: utils.withGrid(x), y: utils.withGrid(y), talking });
  });

  const people = {};
  if (floor.people.receptionist) {
    const [x, y, direction] = floor.people.receptionist;
    people.receptionist = new Person({
      x: utils.withGrid(x),
      y: utils.withGrid(y),
      direction,
      name: "Penny",
      src: "images/characters/people/npc73.png",
      behaviorLoop: [{ type: "stand", direction, time: 3000 }],
      talking: receptionTalking(),
    });
  }

  return {
    id: `Tower${number}`,
    lowerSrc: `images/maps/Tower${number}Lower.png`,
    battleSrc: "images/maps/TowerBattle.png",
    upperSrc: `images/maps/Tower${number}Upper.png`,
    gameObjects: {
      hero: new Person({ isPlayerControlled: true, ...start }),
      ...spots,
      ...towerCrew(number),
      ...people,
      ...(floor.people.queen ? towerBossFloor(number) : {}),
    },
    walls: utils.wallsFromGrid(floor.rows),
    cutsceneSpaces,
  };
}

//Spots with one line of text on several tiles of the same thing (a shop window, a double door)
function textSpots(prefix, tiles, texts) {
  const spots = {};
  tiles.forEach(([x, y], index) => {
    spots[`${prefix}${index}`] = new Hotspot({
      x: utils.withGrid(x),
      y: utils.withGrid(y),
      talking: [{ events: texts.map(text => ({ type: "textMessage", text })) }]
    });
  });
  return spots;
}

//The Burger Queen gang in the back alleys. Where they stand, which way they look and how far they see comes from
//BackAlleysGrid.trainers (tools/ulicky.py), in the same order as the lines here and as window.BurgerGang in Content/enemies.js.
//[what they say when they spot the hero, what they say when beaten, what they say when talked to later]
const BURGER_GANG_LINES = [
  ["Stůj! Tyhle uličky patří gangu Burger Queen!", "Cože? Pizza porazila burger?!", "Hlavně ať se to nedozví Královna..."],
  ["Pizzař v našem rajónu? To si vypiješ!", "Au. Ta tvoje placka má sílu.", "Běž, než si to rozmyslím."],
  ["Plot je náš, průchod je náš. Mýto se platí soubojem!", "No jo, no jo. Projdi.", "Příště si vezmu větší burger."],
  ["Z těsta se dělají housky, ne pizzy. Ukážu ti to!", "Slzím. To je od cibule, jasný?", "Nech mě být, krájím."],
  ["Tři burgery proti tvojí pizze. Počty umíš?", "Počty mi nikdy nešly.", "Sesame, zavři se..."],
  ["Královna nemá ráda cizí těsto ve svých uličkách.", "Křupavá porážka.", "Dál jsou horší než já. Fakt."],
  ["Roztavím tě jako plátek sýra!", "Roztekl jsem se já.", "Hele, nikomu to neříkej."],
  ["Na parkovišti parkujou jen naši. Vypadni!", "Tak jo, jedno místo je tvoje.", "Koukám jinam. Nic nevidím."],
  ["Dáš si k tomu hranolky? A nakládačku?", "Objednávka zrušena...", "Ven se jde tudy. Bohužel."],
  ["Ticho. Slyším tě šustit už od rohu.", "Hm. Dobrý těsto.", "Jdi potichu, ostatní spí."],
  ["Kontejnery jsou moje. A co je v nich, taky!", "Vem si co chceš, jen ne moje burgery.", "Ty krabice vzadu? Jen si posluž."],
  ["Šest kousků a každej tě bude bolet!", "Zbyl ze mě jen dip.", "Terasy jsou hned za rohem."],
  ["Tady nahoru se chodí jen s korunou na hlavě!", "Koruna mi spadla.", "Po zídkách dolů to máš rychlejší."],
  ["Na mým grilu se pizzy pálí na uhel.", "Dneska nějak nehřeje.", "Nemluv na mě. Chladnu."],
  ["Nikdo neproklouzne. Hlídám i poslepu!", "Tak jsem asi mrknul.", "Královnina pravá ruka stojí až u zábrany. Hodně štěstí."],
  ["Vylezl jsi až sem? Tak to bude bolet.", "Bolelo. Mě.", "Běž, běž. Dělám, že tě nevidím."],
  ["Vysrknu tě jedním tahem!", "Zaskočilo mi.", "Dál hlídá Shake. Ten nemá smysl pro humor."],
  ["Žádný smlouvání. Burger, nebo nic.", "Dobře, tak pizza. Výjimečně.", "Obchod je obchod. Jdi."],
  ["Poslední stůl před šéfem. Tady končíš, číšníku!", "Účet prosím...", "Double stojí u zábrany. S tím nevyhraješ."],
  ["Já jsem Double, pravá ruka Královny. K věži projdeš jen přese mě!", "Královna Bulka... poražená pizzou. Dobře, vyhrál jsi.", "Burger Tower je hned za rohem. Královna už o tobě ví."],
];

function backAlleysGang() {
  const gang = {};
  BackAlleysGrid.trainers.forEach(([x, y, direction, sight, also], index) => {
    const number = index + 1;
    const id = `bq${number}`;
    const flag = `DEFEATED_BQ${number}`;
    const [before, beaten, later] = BURGER_GANG_LINES[index];
    gang[id] = new Person({
      x: utils.withGrid(x),
      y: utils.withGrid(y),
      direction,
      name: BurgerGang[index][0],
      src: `images/characters/people/npc${27 + number}.png`,
      sight,
      sightFlag: flag,
      resetOnMount: true,
      //Some keep turning between two directions, so they can be sneaked past with good timing
      behaviorLoop: also ? [
        { type: "stand", direction, time: 2600 + (index % 3) * 300 },
        { type: "stand", direction: also, time: 1700 + (index % 2) * 400 },
      ] : [
        { type: "stand", direction, time: 3000 },
      ],
      talking: [
        {
          required: [flag],
          events: [{ type: "textMessage", text: later, faceHero: id }]
        },
        {
          events: [
            { type: "textMessage", text: before, faceHero: id },
            { type: "battle", enemyId: id },
            { type: "addStoryFlag", flag },
            { type: "textMessage", text: beaten, faceHero: id },
            //The last one guards the barrier: beaten, he pulls it away and the way north is open
            ...(number === BackAlleysGrid.trainers.length ? [
              { type: "textMessage", text: "Double odtáhl zábranu ke zdi. Cesta na sever je volná." },
              { type: "updateMap" },
            ] : []),
          ]
        }
      ]
    });
  });
  return gang;
}

//The canal in the sewers: every water tile (rows 6 and 7, except the plank bridge on column 11) starts fishing with the
//action key, if the hero has the rod from Hobo (story flag FISHER_SOLD)
function sewerWaterSpots() {
  const spots = {};
  for (let y = 6; y <= 7; y++) {
    for (let x = 1; x <= 20; x++) {
      if (x === 11) {
        continue;
      }
      spots[`water${x}_${y}`] = new Hotspot({
        x: utils.withGrid(x),
        y: utils.withGrid(y),
        talking: [
          { required: ["FISHER_SOLD"], events: [{ type: "fish" }] },
          { events: [{ type: "textMessage", text: "Zelená břečka. Kdyby sis měl čím zarybařit, třeba by něco zabralo." }] },
        ]
      });
    }
  }
  return spots;
}

window.OverworldMaps = {
  //The hero's house on the main street (the purple one next to the red house). A new game starts here,
  //a lost fight ends here, and a sleep in the bed moves the clock six hours ahead.
  Home: {
    id: "Home",
    lowerSrc: "images/maps/HomeLower.png",
    battleSrc: "images/maps/DemoBattle.png",
    upperSrc: "images/maps/HomeUpper.png",
    gameObjects: {
      hero: new Person({
        isPlayerControlled: true,
        x: utils.withGrid(2),
        y: utils.withGrid(5),
      }),
      //The bed takes two tiles, use either of them
      bedA: new Hotspot({ x: utils.withGrid(1), y: utils.withGrid(4), talking: [{ events: homeBedEvents() }] }),
      bedB: new Hotspot({ x: utils.withGrid(1), y: utils.withGrid(5), talking: [{ events: homeBedEvents() }] }),
      nightstand: new Hotspot({
        x: utils.withGrid(2),
        y: utils.withGrid(4),
        talking: [{
          events: [
            { type: "textMessage", text: "Lampička, budík a krabice od včerejší pizzy. Klasika." },
          ]
        }]
      }),
      bookshelfA: new Hotspot({ x: utils.withGrid(7), y: utils.withGrid(4), talking: [{ events: [{ type: "textMessage", text: "Samé kuchařky. „Těsto a já“, „Sto a jedna mozzarella“..." }] }] }),
      bookshelfB: new Hotspot({ x: utils.withGrid(8), y: utils.withGrid(4), talking: [{ events: [{ type: "textMessage", text: "Samé kuchařky. „Těsto a já“, „Sto a jedna mozzarella“..." }] }] }),
    },
    walls: utils.wallsFromGrid([
      "###########",
      "###########",
      "###########",
      "###########",
      "###....####",
      "##........#",
      "#.........#",
      "#.......#.#",
      "#.........#",
      "#.........#",
      "#####.#####",
      "###########",
    ]),
    cutsceneSpaces: {
      [utils.asGridCoord(5, 10)]: [
        {
          events: [
            {
              type: "changeMap",
              map: "Street",
              x: utils.withGrid(23),
              y: utils.withGrid(8),
              direction: "down"
            }
          ]
        }
      ]
    }
  },
  DemoRoom: {
    id: "DemoRoom",
    lowerSrc: "images/maps/DemoLower.png",
    battleSrc: "images/maps/DemoBattle.png",
    upperSrc: "images/maps/DemoUpper.png",
    gameObjects: {
      //A new game starts here: the hero comes out of the door in the back wall (7,4), see the opening scene in Overworld.js
      hero: new Person({
        isPlayerControlled: true,
        x: utils.withGrid(7),
        y: utils.withGrid(4),
        direction: "down",
      }),
      //Beth: after the opening scene (flag DEMO_INTRO_DONE) she stands in the doorway (5,9) and lets nobody out until the
      //hero has baked a pizza on the stone and beaten her; then she steps aside to (6,9). (Saves from before the
      //opening scene have neither flag: she stays on her old spot (7,9) and just fights.)
      npcA: new Person({
        x: utils.withGrid(7),
        y: utils.withGrid(9),
        name: "Beth",
        src: "images/characters/people/npc1.png",
        storyPositions: [
          { required: ["DEFEATED_BETH"], x: utils.withGrid(6), y: utils.withGrid(9), direction: "down" },
          { required: ["DEMO_INTRO_DONE"], x: utils.withGrid(5), y: utils.withGrid(9), direction: "down" },
        ],
        behaviorLoop: [
          { type: "stand", direction: "down", time: 2400 },
          { type: "stand", direction: "left", time: 800 },
          { type: "stand", direction: "down", time: 2000 },
          { type: "stand", direction: "right", time: 800 },
        ],
        talking: [
          {
            required: ["DEFEATED_BETH", "DEFEATED_ERIO"],
            events: [
              { type: "textMessage", text: "Erio že prohrál? To není možné!", faceHero: "npcA" },
            ]
          },
          {
            //She fights only once. Afterwards she just admires Erio.
            required: ["DEFEATED_BETH"],
            events: [
              { type: "textMessage", text: "Není Erio ten největší borec?", faceHero: "npcA" },
            ]
          },
          {
            //The pizza from the stone is baked: now the fight that opens the door
            required: ["DEMO_INTRO_DONE", "USED_PIZZA_STONE"],
            events: bethFightEvents(),
          },
          {
            required: ["DEMO_INTRO_DONE"],
            events: [
              { type: "textMessage", text: "Ven nepustím nikoho, kdo si neupekl pizzu!", faceHero: "npcA" },
              { type: "textMessage", text: "Pizza kámen je támhle vlevo. Upeč si pizzu a pak se ukaž!", faceHero: "npcA" },
            ]
          },
          {
            events: bethFightEvents(),
          }
        ]
      }),
      npcB: new Person({
        x: utils.withGrid(8),
        y: utils.withGrid(5),
        name: "Erio",
        src: "images/characters/people/erio.png",
        talking: [
          {
            required: ["DEFEATED_ERIO"],
            events: [
              { type: "textMessage", text: "Příště tě porazím. Bwahaha!", faceHero: "npcB" },
            ]
          },
          {
            //The rival: one fight, two pizzas
            events: [
              { type: "textMessage", text: "Bwahaha! Ty že chceš být kuchař? Tak se ukaž!", faceHero: "npcB" },
              { type: "addStoryFlag", flag: "TALKED_TO_ERIO" },
              { type: "battle", enemyId: "erio" },
              { type: "addStoryFlag", flag: "DEFEATED_ERIO" },
              { type: "textMessage", text: "To... to byla náhoda!", faceHero: "npcB" },
            ]
          }
        ]
        // behaviorLoop: [
        //   { type: "walk",  direction: "left" },
        //   { type: "stand",  direction: "up", time: 800 },
        //   { type: "walk",  direction: "up" },
        //   { type: "walk",  direction: "right" },
        //   { type: "walk",  direction: "down" },
        // ]
      }),
      pizzaStone: new PizzaStone({
        x: utils.withGrid(2),
        y: utils.withGrid(7),
        storyFlag: "USED_PIZZA_STONE",
        pizzas: ["v001", "f001"],
      }),
    },
    //# = wall, . = free tile (one character per 16px tile)
    walls: utils.wallsFromGrid([
      "############",
      "############",
      "############",
      "############",
      "#..##.#.#..#",
      "#..........#",
      "#......##..#",
      "#......##..#",
      "#..........#",
      "#..........#",
      "#####.######",
      "############",
    ]),
    cutsceneSpaces: {
      //The doorway in the back wall. Erio keeps everybody out of it until the pizza monster has been driven off
      //(CELLAR_MONSTER_FLED); after that it leads to the little room behind the house (DemoBack).
      [utils.asGridCoord(7, 4)]: [
        {
          required: ["CELLAR_MONSTER_FLED"],
          events: [
            {
              type: "changeMap",
              map: "DemoBack",
              x: utils.withGrid(3),
              y: utils.withGrid(7),
              direction: "up"
            }
          ]
        },
        {
          events: [
            { who: "npcB", type: "walk", direction: "left" },
            { who: "npcB", type: "stand", direction: "up", time: 500 },
            { type: "textMessage", text: "Tam nesmíš!", speaker: "npcB" },
            { who: "npcB", type: "walk", direction: "right" },
            { who: "hero", type: "walk", direction: "down" },
            { who: "hero", type: "walk", direction: "left" },
          ]
        }
      ],
      [utils.asGridCoord(5, 10)]: [
        {
          events: [
            {
              type: "changeMap",
              map: "Street",
              x: utils.withGrid(12),
              y: utils.withGrid(9),
              direction: "down"
            }
          ]
        }
      ]
    }

  },
  //The little room behind the doorway in the back wall of the DEMO house (drawn by tools/komora.py from pieces of the
  //DEMO house). Its door leads back into the house, the trapdoor in the floor (5,6) down the ladder into the sewers.
  //Erio lets the hero in only after the pizza monster has been driven off; from below it is reached by the left ladder.
  DemoBack: {
    id: "DemoBack",
    lowerSrc: "images/maps/DemoBackLower.png",
    battleSrc: "images/maps/DemoBattle.png",
    upperSrc: "images/maps/DemoBackUpper.png",
    gameObjects: {
      hero: new Person({
        isPlayerControlled: true,
        x: utils.withGrid(3),
        y: utils.withGrid(7),
        direction: "up",
      }),
      shelfA: new Hotspot({ x: utils.withGrid(1), y: utils.withGrid(4), talking: [{ events: [{ type: "textMessage", text: "Police plná kuchařek. Všechny jsou o pizze." }] }] }),
      shelfB: new Hotspot({ x: utils.withGrid(2), y: utils.withGrid(4), talking: [{ events: [{ type: "textMessage", text: "Police plná kuchařek. Všechny jsou o pizze." }] }] }),
      cratesA: new Hotspot({ x: utils.withGrid(4), y: utils.withGrid(4), talking: [{ events: [{ type: "textMessage", text: "Bedny s moukou. Někdo se tu zásobil na roky dopředu." }] }] }),
      cratesB: new Hotspot({ x: utils.withGrid(5), y: utils.withGrid(4), talking: [{ events: [{ type: "textMessage", text: "Bedny s moukou. Někdo se tu zásobil na roky dopředu." }] }] }),
    },
    walls: utils.wallsFromGrid([
      "#######",
      "#######",
      "#######",
      "#######",
      "###.###",
      "#.....#",
      "#.....#",
      "#.....#",
      "###.###",
      "#######",
    ]),
    cutsceneSpaces: {
      //The door: back into the DEMO house, in front of the doorway in its back wall
      [utils.asGridCoord(3, 8)]: [
        {
          events: [
            {
              type: "changeMap",
              map: "DemoRoom",
              x: utils.withGrid(7),
              y: utils.withGrid(5),
              direction: "down"
            }
          ]
        }
      ],
      //The trapdoor: down the ladder into the sewers (the left ladder there)
      [utils.asGridCoord(5, 6)]: [
        {
          events: [
            {
              type: "changeMap",
              map: "Sewer",
              x: utils.withGrid(1),
              y: utils.withGrid(4),
              direction: "down"
            }
          ]
        }
      ]
    }
  },
  Kitchen: {
    id: "Kitchen",
    lowerSrc: "images/maps/KitchenLower.png",
    battleSrc: "images/maps/KitchenBattle.png",
    upperSrc: "images/maps/KitchenUpper.png",
    gameObjects: {
      hero: new Person({
        isPlayerControlled: true,
        x: utils.withGrid(5),
        y: utils.withGrid(5),
      }),
      npcB: new Person({
        x: utils.withGrid(10),
        y: utils.withGrid(8),
        name: "Stacker",
        src: "images/characters/people/npc3.png",
        talking: [
          {
            events: [
              { type: "textMessage", text: "Vítej! Prodávám prázdné krabice na pizzu.", faceHero: "npcB" },
              { type: "textMessage", text: "Do nich chytíš zapomenuté pizzy z uličky za obchodem.", faceHero: "npcB" },
              { type: "shopMenu", items: [{ actionId: "item_catchBox", price: 10 }] },
              { type: "textMessage", text: "Tak zase někdy!", faceHero: "npcB" },
            ]
          }
        ]
      }),
      //Heals all pizzas for free, as often as you like
      mia: new Person({
        x: utils.withGrid(3),
        y: utils.withGrid(9),
        direction: "right",
        name: "Mia",
        src: "images/characters/people/npc11.png",
        behaviorLoop: [
          { type: "stand", direction: "right", time: 2400 },
          { type: "stand", direction: "up", time: 900 },
          { type: "stand", direction: "right", time: 1800 },
          { type: "stand", direction: "down", time: 900 },
        ],
        talking: [
          {
            events: [
              { type: "textMessage", text: "Ahoj! Ukaž, dám ti celé menu do pořádku.", faceHero: "mia" },
              { type: "healPizzas" },
              { type: "textMessage", text: "Hotovo, všechno je zase jako čerstvě z pece!", faceHero: "mia" },
            ]
          }
        ]
      }),
      //Trades pizzas for ingredients
      vito: new Person({
        x: utils.withGrid(7),
        y: utils.withGrid(5),
        direction: "up",
        name: "Vito",
        src: "images/characters/people/npc7.png",
        behaviorLoop: [
          { type: "stand", direction: "up", time: 2600 },
          { type: "stand", direction: "left", time: 700 },
          { type: "stand", direction: "up", time: 2000 },
          { type: "stand", direction: "down", time: 900 },
        ],
        talking: [
          {
            events: [
              { type: "textMessage", text: "Máš něco navíc? Pizzu, burger, to je fuk. Dej mi to a vytáhnu z toho přísadu.", faceHero: "vito" },
              { type: "tradeMenu" },
              { type: "textMessage", text: "Přísady pak přidáš na pizza kameni.", faceHero: "vito" },
            ]
          }
        ]
      }),
      //The counter along the left wall is the storage for pizzas and burgers (three tiles, use any of them)
      storageA: new Hotspot({ x: utils.withGrid(1), y: utils.withGrid(5), talking: [{ events: [{ type: "storageMenu" }] }] }),
      storageB: new Hotspot({ x: utils.withGrid(1), y: utils.withGrid(6), talking: [{ events: [{ type: "storageMenu" }] }] }),
      storageC: new Hotspot({ x: utils.withGrid(1), y: utils.withGrid(7), talking: [{ events: [{ type: "storageMenu" }] }] }),
    },
    walls: utils.wallsFromGrid([
      "##############",
      "##############",
      "##############",
      "##############",
      "####.#########",
      "##.........###",
      "##...........#",
      "##....##.##..#",
      "#............#",
      "###......##..#",
      "#####.########",
      "##############",
    ]),
    cutsceneSpaces: {
      [utils.asGridCoord(5, 10)]: [
        {
          events: [
            {
              type: "changeMap",
              map: "Street",
              x: utils.withGrid(29),
              y: utils.withGrid(9),
              direction: "down"
            }
          ]
        }
      ]
    }
  },
  StreetNorth: {
    id: "StreetNorth",
    isOutdoors: true,
    lowerSrc: "images/maps/StreetNorthLower.png",
    battleSrc: "images/maps/StreetBattle.png",
    upperSrc: "images/maps/StreetNorthUpper.png",
    gameObjects: {
      hero: new Person({
        isPlayerControlled: true,
        x: utils.withGrid(7),
        y: utils.withGrid(14),
      }),
      //Three chefs. Each one fights once, afterwards they only talk.
      bruno: new Person({
        x: utils.withGrid(4),
        y: utils.withGrid(10),
        direction: "right",
        name: "Bruno",
        src: "images/characters/people/npc5.png",
        behaviorLoop: [
          { type: "stand", direction: "right", time: 2000 },
          { type: "stand", direction: "down", time: 1200 },
          { type: "stand", direction: "right", time: 1600 },
          { type: "stand", direction: "up", time: 800 },
        ],
        talking: [
          {
            required: ["DEFEATED_BRUNO"],
            events: [
              { type: "textMessage", text: "Ještě teď cítím tu porážku. A česnek.", faceHero: "bruno" },
            ]
          },
          {
            events: [
              { type: "textMessage", text: "Tahle ulička patří kuchařům. Ukaž, co máš v peci!", faceHero: "bruno" },
              { type: "battle", enemyId: "bruno" },
              { type: "addStoryFlag", flag: "DEFEATED_BRUNO" },
              { type: "textMessage", text: "Uf. Tvoje těsto má říz.", faceHero: "bruno" },
            ]
          }
        ]
      }),
      gino: new Person({
        x: utils.withGrid(11),
        y: utils.withGrid(12),
        direction: "left",
        name: "Gino",
        src: "images/characters/people/npc2.png",
        behaviorLoop: [
          { type: "stand", direction: "left", time: 1800 },
          { type: "stand", direction: "down", time: 1400 },
          { type: "stand", direction: "left", time: 1200 },
          { type: "stand", direction: "right", time: 900 },
        ],
        talking: [
          {
            required: ["DEFEATED_GINO"],
            events: [
              { type: "textMessage", text: "Trénuju. Příště tě převálcuju.", faceHero: "gino" },
            ]
          },
          {
            events: [
              { type: "textMessage", text: "Dvě pizzy jsou lepší než jedna. Přesvědč se!", faceHero: "gino" },
              { type: "battle", enemyId: "gino" },
              { type: "addStoryFlag", flag: "DEFEATED_GINO" },
              { type: "textMessage", text: "No dobře, dneska ti to vyšlo.", faceHero: "gino" },
            ]
          }
        ]
      }),
      rosa: new Person({
        x: utils.withGrid(7),
        y: utils.withGrid(6),
        direction: "down",
        name: "Rosa",
        src: "images/characters/people/npc6.png",
        //Once beaten she no longer blocks the door of Neon Greens
        storyPositions: [{ required: ["DEFEATED_ROSA"], x: utils.withGrid(8), y: utils.withGrid(6) }],
        behaviorLoop: [
          { type: "stand", direction: "down", time: 2600 },
          { type: "stand", direction: "left", time: 900 },
          { type: "stand", direction: "down", time: 2000 },
          { type: "stand", direction: "right", time: 900 },
        ],
        talking: [
          {
            required: ["DEFEATED_ROSA"],
            events: [
              { type: "textMessage", text: "Menu ti ošetří Mia v budově SHOP.", faceHero: "rosa" },
            ]
          },
          {
            events: [
              { type: "textMessage", text: "Jsem nejlepší kuchařka v ulici. Troufneš si?", faceHero: "rosa" },
              { type: "battle", enemyId: "rosa" },
              { type: "addStoryFlag", flag: "DEFEATED_ROSA" },
              { type: "textMessage", text: "Tak to bylo... ostré. Běž dál, Neon Greens je tvoje.", faceHero: "rosa" },
              { type: "stepAside", who: "rosa", directions: ["right", "left"] },
              { who: "rosa", type: "stand", direction: "down", time: 300 },
            ]
          }
        ]
      }),
    },
    walls: utils.wallsFromGrid([
      "################",
      "################",
      "################",
      "################",
      "################",
      "#######.########",
      "####.......#####",
      "####..........##",
      "##.....##.....##",
      "##.....##.....##",
      "##.....####...##",
      "##............##",
      "##............##",
      "##............##",
      "##............##",
      "#######.########",
      "#######.########",
      "################",
    ]),
    cutsceneSpaces: {
      //The door of Neon Greens (Rosa stands in front of it until she is beaten)
      [utils.asGridCoord(7, 5)]: [
        {
          events: [
            {
              type: "changeMap",
              map: "GreenKitchen",
              x: utils.withGrid(5),
              y: utils.withGrid(12),
              direction: "up"
            }
          ]
        }
      ],
      [utils.asGridCoord(7, 16)]: [
        {
          events: [
            {
              type: "changeMap",
              map: "Street",
              x: utils.withGrid(25),
              y: utils.withGrid(5),
              direction: "down"
            }
          ]
        }
      ]
    }
  },
  //Inside Neon Greens: three opponents, the last one guards the stairs down in the top right corner
  GreenKitchen: {
    id: "GreenKitchen",
    lowerSrc: "images/maps/GreenKitchenLower.png",
    battleSrc: "images/maps/GreenKitchenBattle.png",
    upperSrc: "images/maps/GreenKitchenUpper.png",
    gameObjects: {
      hero: new Person({
        isPlayerControlled: true,
        x: utils.withGrid(5),
        y: utils.withGrid(11),
      }),
      olivia: new Person({
        x: utils.withGrid(2),
        y: utils.withGrid(8),
        direction: "right",
        name: "Olivia",
        src: "images/characters/people/npc8.png",
        behaviorLoop: [
          { type: "stand", direction: "right", time: 2200 },
          { type: "stand", direction: "down", time: 1100 },
          { type: "stand", direction: "right", time: 1700 },
          { type: "stand", direction: "up", time: 800 },
        ],
        talking: [
          {
            required: ["DEFEATED_OLIVIA"],
            events: [
              { type: "textMessage", text: "Verde hlídá schody dolů. Jen tak tě nepustí.", faceHero: "olivia" },
            ]
          },
          {
            events: [
              { type: "textMessage", text: "Vítej v Neon Greens. Tady se jí zdravě a bojuje tvrdě!", faceHero: "olivia" },
              { type: "battle", enemyId: "olivia" },
              { type: "addStoryFlag", flag: "DEFEATED_OLIVIA" },
              { type: "textMessage", text: "Dobře, uznávám. Ale salát ti stejně doporučuju.", faceHero: "olivia" },
            ]
          }
        ]
      }),
      pesto: new Person({
        x: utils.withGrid(6),
        y: utils.withGrid(8),
        direction: "left",
        name: "Pesto",
        src: "images/characters/people/npc9.png",
        behaviorLoop: [
          { type: "stand", direction: "left", time: 1900 },
          { type: "stand", direction: "down", time: 1300 },
          { type: "stand", direction: "left", time: 1500 },
          { type: "stand", direction: "right", time: 900 },
        ],
        talking: [
          {
            required: ["DEFEATED_PESTO"],
            events: [
              { type: "textMessage", text: "Dole pod schody je prý jídelna. Ještě jsem tam nebyl.", faceHero: "pesto" },
            ]
          },
          {
            events: [
              { type: "textMessage", text: "Dvě zelené pizzy a žádné slitování. Jdeme na to!", faceHero: "pesto" },
              { type: "battle", enemyId: "pesto" },
              { type: "addStoryFlag", flag: "DEFEATED_PESTO" },
              { type: "textMessage", text: "Pesto prohrálo. To se nestává často.", faceHero: "pesto" },
            ]
          }
        ]
      }),
      verde: new Person({
        x: utils.withGrid(9),
        y: utils.withGrid(6),
        direction: "down",
        name: "Verde",
        src: "images/characters/people/npc10.png",
        //Once beaten he no longer stands in front of the stairs
        storyPositions: [{ required: ["DEFEATED_VERDE"], x: utils.withGrid(8), y: utils.withGrid(6) }],
        behaviorLoop: [
          { type: "stand", direction: "down", time: 2600 },
          { type: "stand", direction: "left", time: 1000 },
          { type: "stand", direction: "down", time: 2000 },
        ],
        talking: [
          {
            required: ["DEFEATED_VERDE"],
            events: [
              { type: "textMessage", text: "Běž, schody jsou volné.", faceHero: "verde" },
            ]
          },
          {
            events: [
              { type: "textMessage", text: "Schody dolů hlídám já. Kdo chce projít, musí přese mě.", faceHero: "verde" },
              { type: "battle", enemyId: "verde" },
              { type: "addStoryFlag", flag: "DEFEATED_VERDE" },
              { type: "textMessage", text: "Tak dobře. Cesta dolů je tvoje.", faceHero: "verde" },
              //He gets out of the way of the stairs
              { type: "stepAside", who: "verde", directions: ["left", "down"] },
              { who: "verde", type: "stand", direction: "down", time: 300 },
            ]
          }
        ]
      }),
    },
    walls: utils.wallsFromGrid([
      "###########",
      "###########",
      "###########",
      "###########",
      "##.##.#####",
      "#.......#.#",
      "#######...#",
      "#..##.#...#",
      "#.........#",
      "#.###.....#",
      "#......####",
      "#.........#",
      "#####.#####",
      "###########",
    ]),
    cutsceneSpaces: {
      [utils.asGridCoord(5, 12)]: [
        {
          events: [
            {
              type: "changeMap",
              map: "StreetNorth",
              x: utils.withGrid(7),
              y: utils.withGrid(5),
              direction: "down"
            }
          ]
        }
      ],
      //Stairs down
      [utils.asGridCoord(9, 5)]: [
        {
          events: [
            {
              type: "changeMap",
              map: "DiningRoom",
              x: utils.withGrid(7),
              y: utils.withGrid(4),
              direction: "down"
            }
          ]
        }
      ]
    }
  },
  //The floor below Neon Greens: five chefs spread around the tables. Their boss stands in front of the second
  //doorway (stairs down to the cellar) and only fights once all five are beaten.
  DiningRoom: {
    id: "DiningRoom",
    lowerSrc: "images/maps/DiningRoomLower.png",
    battleSrc: "images/maps/DiningRoomBattle.png",
    upperSrc: "images/maps/DiningRoomUpper.png",
    gameObjects: {
      hero: new Person({
        isPlayerControlled: true,
        x: utils.withGrid(7),
        y: utils.withGrid(5),
      }),
      mata: new Person({
        x: utils.withGrid(3),
        y: utils.withGrid(6),
        direction: "down",
        name: "Mint",
        src: "images/characters/people/npc12.png",
        behaviorLoop: [
          { type: "stand", direction: "down", time: 2400 },
          { type: "stand", direction: "right", time: 1000 },
          { type: "stand", direction: "down", time: 1800 },
          { type: "stand", direction: "left", time: 900 },
        ],
        talking: [
          {
            required: ["DEFEATED_MATA"],
            events: [
              { type: "textMessage", text: "Šéf stojí vzadu u schodů. Dokud neporazíš nás pět, nehne se.", faceHero: "mata" },
            ]
          },
          {
            events: [
              { type: "textMessage", text: "Vítej v jídelně! Tady dole se neobsluhuje, tady se bojuje.", faceHero: "mata" },
              { type: "battle", enemyId: "mata" },
              { type: "addStoryFlag", flag: "DEFEATED_MATA" },
              { type: "textMessage", text: "Brr. Tak tohle mě pěkně zchladilo.", faceHero: "mata" },
            ]
          }
        ]
      }),
      kopr: new Person({
        x: utils.withGrid(9),
        y: utils.withGrid(8),
        direction: "left",
        name: "Dill",
        src: "images/characters/people/npc13.png",
        behaviorLoop: [
          { type: "stand", direction: "left", time: 2000 },
          { type: "stand", direction: "down", time: 1200 },
          { type: "stand", direction: "left", time: 1500 },
          { type: "stand", direction: "up", time: 900 },
        ],
        talking: [
          {
            required: ["DEFEATED_KOPR"],
            events: [
              { type: "textMessage", text: "Kopr patří do okurek, ne na pizzu. Ale šéfovi to neříkej.", faceHero: "kopr" },
            ]
          },
          {
            events: [
              { type: "textMessage", text: "Hej! Čepici mi nikdo nesundá a pizzu mi nikdo neporazí.", faceHero: "kopr" },
              { type: "battle", enemyId: "kopr" },
              { type: "addStoryFlag", flag: "DEFEATED_KOPR" },
              { type: "textMessage", text: "No... aspoň ta čepice mi zůstala.", faceHero: "kopr" },
            ]
          }
        ]
      }),
      rukola: new Person({
        x: utils.withGrid(1),
        y: utils.withGrid(8),
        direction: "right",
        name: "Rocket",
        src: "images/characters/people/npc14.png",
        behaviorLoop: [
          { type: "stand", direction: "right", time: 2600 },
          { type: "stand", direction: "down", time: 1100 },
          { type: "stand", direction: "right", time: 1700 },
          { type: "stand", direction: "up", time: 800 },
        ],
        talking: [
          {
            required: ["DEFEATED_RUKOLA"],
            events: [
              { type: "textMessage", text: "Don Broccolini ještě nikdy neprohrál. Tedy, zatím.", faceHero: "rukola" },
            ]
          },
          {
            events: [
              { type: "textMessage", text: "Podle mých výpočtů máš šanci přesně čtyři procenta.", faceHero: "rukola" },
              { type: "battle", enemyId: "rukola" },
              { type: "addStoryFlag", flag: "DEFEATED_RUKOLA" },
              { type: "textMessage", text: "Zajímavé. Budu muset přepočítat celý recept.", faceHero: "rukola" },
            ]
          }
        ]
      }),
      fenykl: new Person({
        x: utils.withGrid(6),
        y: utils.withGrid(11),
        direction: "up",
        name: "Fennel",
        src: "images/characters/people/npc15.png",
        behaviorLoop: [
          { type: "stand", direction: "up", time: 2200 },
          { type: "stand", direction: "left", time: 1300 },
          { type: "stand", direction: "up", time: 1600 },
          { type: "stand", direction: "right", time: 1300 },
        ],
        talking: [
          {
            required: ["DEFEATED_FENYKL"],
            events: [
              { type: "textMessage", text: "Za šéfem jsou schody do sklepa. Co tam je, to ví jen on.", faceHero: "fenykl" },
            ]
          },
          {
            events: [
              { type: "textMessage", text: "Pekl jsem pizzu, když tvůj děda ještě tahal kačera. Pojď!", faceHero: "fenykl" },
              { type: "battle", enemyId: "fenykl" },
              { type: "addStoryFlag", flag: "DEFEATED_FENYKL" },
              { type: "textMessage", text: "Ech, klouby už neslouží. Ale těsto máš dobré, mladý.", faceHero: "fenykl" },
            ]
          }
        ]
      }),
      pazitka: new Person({
        x: utils.withGrid(12),
        y: utils.withGrid(9),
        direction: "left",
        name: "Chive",
        src: "images/characters/people/npc16.png",
        behaviorLoop: [
          { type: "stand", direction: "left", time: 2300 },
          { type: "stand", direction: "up", time: 1000 },
          { type: "stand", direction: "left", time: 1400 },
          { type: "stand", direction: "down", time: 1000 },
        ],
        talking: [
          {
            required: ["DEFEATED_PAZITKA"],
            events: [
              { type: "textMessage", text: "Šéf má rád ticho, tmavé brýle a brokolici. V tomhle pořadí.", faceHero: "pazitka" },
            ]
          },
          {
            events: [
              { type: "textMessage", text: "Tohle je můj plácek. Kdo sem vleze, dostane naloženo!", faceHero: "pazitka" },
              { type: "battle", enemyId: "pazitka" },
              { type: "addStoryFlag", flag: "DEFEATED_PAZITKA" },
              { type: "textMessage", text: "Tss. Tak jo, máš to u mě.", faceHero: "pazitka" },
            ]
          }
        ]
      }),
      brokolini: new Person({
        x: utils.withGrid(11),
        y: utils.withGrid(5),
        direction: "down",
        name: "Don",
        src: "images/characters/people/npc17.png",
        //Once beaten he no longer stands in front of the stairs to the cellar
        storyPositions: [{ required: ["DEFEATED_BROKOLINI"], x: utils.withGrid(12), y: utils.withGrid(5) }],
        behaviorLoop: [
          { type: "stand", direction: "down", time: 3000 },
          { type: "stand", direction: "left", time: 1200 },
          { type: "stand", direction: "down", time: 2400 },
        ],
        //The first scenario whose flags are all set is the one that plays
        talking: [
          {
            required: ["DEFEATED_BROKOLINI"],
            events: [
              { type: "textMessage", text: "Sklep je tvůj. Jen mi tam nic nesněz.", faceHero: "brokolini" },
            ]
          },
          {
            required: ["DEFEATED_MATA", "DEFEATED_KOPR", "DEFEATED_RUKOLA", "DEFEATED_FENYKL", "DEFEATED_PAZITKA"],
            events: [
              { type: "textMessage", text: "Tak ty jsi porazil celou mou kuchyni. Dobrá.", faceHero: "brokolini" },
              { type: "textMessage", text: "Teď ochutnáš šéfovu specialitu. Don Broccolini neprohrává!", faceHero: "brokolini" },
              { type: "battle", enemyId: "brokolini" },
              { type: "addStoryFlag", flag: "DEFEATED_BROKOLINI" },
              { type: "textMessage", text: "Mamma mia... Don Broccolini je rozvařený.", faceHero: "brokolini" },
              { type: "textMessage", text: "Schody do sklepa jsou tvoje.", faceHero: "brokolini" },
              //He gets out of the way of the stairs
              { type: "stepAside", who: "brokolini", directions: ["right", "left"] },
              { who: "brokolini", type: "stand", direction: "down", time: 300 },
            ]
          },
          {
            events: [
              { type: "textMessage", text: "Don Broccolini nemluví s nikým, kdo neporazil jeho lidi.", faceHero: "brokolini" },
              { type: "textMessage", text: "Je jich tu pět. Vrať se, až budou všichni na lopatkách.", faceHero: "brokolini" },
            ]
          }
        ]
      }),
    },
    walls: utils.wallsFromGrid([
      "##############",
      "##############",
      "##############",
      "#######.######",
      "#####.#..##.##",
      "#####.#......#",
      "#............#",
      "#.###..###.###",
      "#............#",
      "#............#",
      "#.###..###...#",
      "#............#",
      "##############",
      "##############",
    ]),
    cutsceneSpaces: {
      //Stairs up to Neon Greens
      [utils.asGridCoord(7, 3)]: [
        {
          events: [
            {
              type: "changeMap",
              map: "GreenKitchen",
              x: utils.withGrid(9),
              y: utils.withGrid(6),
              direction: "down"
            }
          ]
        }
      ],
      //Stairs down to the cellar (Don Brokolini stands in front of them until he is beaten)
      [utils.asGridCoord(11, 4)]: [
        {
          events: [
            {
              type: "changeMap",
              map: "Cellar",
              x: utils.withGrid(5),
              y: utils.withGrid(4),
              direction: "down"
            }
          ]
        }
      ]
    }
  },
  //The cellar under the dining room. Nothing lives here yet; barrels and boxes are just walls.
  //The cellar under the dining room. On the left a store room, on the right, behind a row of boxes with one gap,
  //the laboratory of two scientists with a big oven. Walking in through the gap starts their experiment (once):
  //the pizza monster comes out of the oven, the scientists run behind the hero, the hero fights it, and when it
  //has had enough it breaks through the back wall into the sewers. See cellarExperimentScene() above.
  Cellar: {
    id: "Cellar",
    lowerSrc: "images/maps/CellarLower.png",
    battleSrc: "images/maps/CellarBattle.png",
    upperSrc: "images/maps/CellarUpper.png",
    //Once the monster has gone through the wall: the picture with the hole, and the hole can be walked into
    variants: [
      {
        required: ["CELLAR_WALL_BROKEN"],
        lowerSrc: "images/maps/CellarBrokenLower.png",
        upperSrc: "images/maps/CellarBrokenUpper.png",
        removeWalls: [[18, 3]],
      }
    ],
    gameObjects: {
      hero: new Person({
        isPlayerControlled: true,
        x: utils.withGrid(5),
        y: utils.withGrid(5),
      }),
      //The two scientists stand at the oven until the experiment; afterwards one by the oven, one at the desk
      scientistA: new Person({
        x: utils.withGrid(11),
        y: utils.withGrid(5),
        direction: "up",
        name: "Yeast",
        src: "images/characters/people/npc24.png",
        storyPositions: [
          { required: ["CELLAR_MONSTER_FLED"], x: utils.withGrid(12), y: utils.withGrid(5), direction: "right" },
        ],
        talking: [
          {
            required: ["MONSTER_DEFEATED"],
            events: [
              { type: "textMessage", text: "Ty jsi ho dohnal až ve stokách a porazil? Experiment číslo 48 bude menší. Mnohem menší.", faceHero: "scientistA" },
              { type: "stand", who: "scientistA", direction: "right", time: 100 },
            ]
          },
          {
            required: ["CELLAR_MONSTER_FLED"],
            events: [
              { type: "textMessage", text: "Kvásek z hlubin už nikdy. Příště zkusíme obyčejné droždí.", faceHero: "scientistA" },
              { type: "stand", who: "scientistA", direction: "right", time: 100 },
            ]
          }
        ]
      }),
      scientistB: new Person({
        x: utils.withGrid(15),
        y: utils.withGrid(5),
        direction: "up",
        name: "Crust",
        src: "images/characters/people/npc25.png",
        storyPositions: [
          { required: ["CELLAR_MONSTER_FLED"], x: utils.withGrid(16), y: utils.withGrid(5), direction: "up" },
        ],
        talking: [
          {
            required: ["MONSTER_DEFEATED"],
            events: [
              { type: "textMessage", text: "Rozteklo se? Škoda vzorku... Teda, chci říct: díky! Město ti dluží pizzu.", faceHero: "scientistB" },
              { type: "stand", who: "scientistB", direction: "up", time: 100 },
            ]
          },
          {
            required: ["CELLAR_MONSTER_FLED"],
            events: [
              { type: "textMessage", text: "Díra vede do stok. Monstrum za sebou nechává sýr, jeho stopu neztratíš.", faceHero: "scientistB" },
              { type: "stand", who: "scientistB", direction: "up", time: 100 },
            ]
          }
        ]
      }),
      //Waits off the map until the experiment puts it in front of the oven, and leaves the map again when it flees.
      //(The entry in storyPositions also makes it go back off the map if the scene was cut short by a lost fight.)
      monster: new Monster({
        x: utils.withGrid(-30),
        y: utils.withGrid(-30),
        name: "Pizzové monstrum",
        src: "images/characters/pizza-monster.png",
        shadowSrc: "images/characters/pizza-monster-shadow.png",
        frames: 2,
        storyPositions: [
          { required: ["CELLAR_MONSTER_FLED"], x: utils.withGrid(-30), y: utils.withGrid(-30) },
        ],
      }),
      //Things in the laboratory that only have something to say
      ovenA: new Hotspot({ x: utils.withGrid(12), y: utils.withGrid(4), talking: [{ events: [{ type: "textMessage", text: "Obrovská pec. Sálá z ní takové horko, že se ti kroutí zástěra." }] }] }),
      ovenB: new Hotspot({ x: utils.withGrid(13), y: utils.withGrid(4), talking: [{ events: [{ type: "textMessage", text: "Obrovská pec. Sálá z ní takové horko, že se ti kroutí zástěra." }] }] }),
      ovenC: new Hotspot({ x: utils.withGrid(14), y: utils.withGrid(4), talking: [{ events: [{ type: "textMessage", text: "Obrovská pec. Sálá z ní takové horko, že se ti kroutí zástěra." }] }] }),
      labDesk: new Hotspot({ x: utils.withGrid(16), y: utils.withGrid(4), talking: [{ events: [{ type: "textMessage", text: "Ovládací pult. Páka je v poloze „VÍC“ a nejde vrátit." }] }] }),
      labTableA: new Hotspot({ x: utils.withGrid(20), y: utils.withGrid(6), talking: [{ events: [{ type: "textMessage", text: "Baňky s něčím zeleným a fialovým. Na papíře stojí: „Kvásek z hlubin, pokus č. 47“." }] }] }),
      labTableB: new Hotspot({ x: utils.withGrid(20), y: utils.withGrid(7), talking: [{ events: [{ type: "textMessage", text: "Baňky s něčím zeleným a fialovým. Na papíře stojí: „Kvásek z hlubin, pokus č. 47“." }] }] }),
    },
    walls: utils.wallsFromGrid([
      "######################",
      "######################",
      "######################",
      "#####.################",
      "####....#########....#",
      "##........#..........#",
      "#.........#.........##",
      "#...................##",
      "#.........#..........#",
      "###.......#..........#",
      "######################",
    ]),
    cutsceneSpaces: {
      //Stairs back up to the dining room
      [utils.asGridCoord(5, 3)]: [
        {
          events: [
            {
              type: "changeMap",
              map: "DiningRoom",
              x: utils.withGrid(11),
              y: utils.withGrid(5),
              direction: "down"
            }
          ]
        }
      ],
      //The first tile of the laboratory, right behind the gap in the row of boxes: the experiment, once
      [utils.asGridCoord(11, 7)]: [
        { required: ["CELLAR_MONSTER_FLED"], events: [] },
        {
          needsHealthyPizza: true,
          events: cellarExperimentScene(),
          otherwise: [
            { type: "textMessage", text: "Z laboratoře sálá horko a něco tam bublá. S menu na kaši tam radši nelez." },
            { type: "walk", who: "hero", direction: "left" },
          ]
        },
      ],
      //The hole in the back wall (a wall until the monster breaks it)
      [utils.asGridCoord(18, 3)]: [
        {
          events: [
            {
              type: "changeMap",
              map: "Sewer",
              x: utils.withGrid(4),
              y: utils.withGrid(9),
              direction: "up"
            }
          ]
        }
      ],
    }
  },
  //The sewers under the cellar, reached through the hole the pizza monster made. For now only a place to look
  //around: its trail of cheese leads over the planks to a barred tunnel it squeezed into.
  Sewer: {
    id: "Sewer",
    lowerSrc: "images/maps/SewerLower.png",
    battleSrc: "images/maps/SewerBattle.png",
    upperSrc: "images/maps/SewerUpper.png",
    gameObjects: {
      hero: new Person({
        isPlayerControlled: true,
        x: utils.withGrid(4),
        y: utils.withGrid(9),
      }),
      grateA: sewerGrateSpot(18),
      grateB: sewerGrateSpot(19),
      ...sewerWaterSpots(),
      pipeA: new Hotspot({ x: utils.withGrid(3), y: utils.withGrid(3), talking: [{ events: [{ type: "textMessage", text: "Z roury teče něco zeleného. Radši to neochutnávej." }] }] }),
      pipeB: new Hotspot({ x: utils.withGrid(8), y: utils.withGrid(3), talking: [{ events: [{ type: "textMessage", text: "Z roury teče něco zeleného. Radši to neochutnávej." }] }] }),
      //Hobo, a homeless man fishing for pizzas from the upper bank, looking down at the canal. The rod, the line and the two boxes next to him are part
      //of the map pictures (tools/rybar.py). He has two rods and sells one of them (once, flag FISHER_SOLD).
      //He also saw the pizza monster pass through the sewers.
      fisher: new Person({
        x: utils.withGrid(15),
        y: utils.withGrid(5),
        direction: "down",
        name: "Hobo",
        src: "images/characters/people/npc26.png",
        behaviorLoop: [
          { type: "stand", direction: "down", time: 5200 },
          { type: "stand", direction: "left", time: 900 },
          { type: "stand", direction: "down", time: 3400 },
        ],
        talking: [
          {
            required: ["FISHER_SOLD"],
            events: [
              { type: "textMessage", text: "Ten druhej prut je můj. Toho se nezbavím ani za prachy.", faceHero: "fisher" },
              { type: "textMessage", text: "A kdyby se ta potvora vrátila, jsem fuč. Fakt.", faceHero: "fisher" },
            ]
          },
          {
            events: [
              { type: "textMessage", text: "Pšt! Neřvi, vyplašíš mi je. Já jsem Hobo.", faceHero: "fisher" },
              { type: "textMessage", text: "Před chvílí tudy něco prolezlo. Velký, měkký a smrdělo to pizzou.", faceHero: "fisher" },
              { type: "textMessage", text: "Přeleze lávku, nechá po sobě sýr a zmizí támhle za mříží. Málem mi to vzalo prut!", faceHero: "fisher" },
              { type: "textMessage", text: "Já mám naštěstí dva. Jeden ti klidně prodám.", faceHero: "fisher" },
              { type: "shopMenu", items: [{ actionId: "item_rod", price: 40, flag: "FISHER_SOLD" }] },
              {
                type: "textMessage",
                text: () => playerState.storyFlags["FISHER_SOLD"]
                  ? "Platí. Stoupni si k vodě, zmáčkni E a měj trpělivost."
                  : "No jak chceš. Já tu budu. Kam bych taky šel.",
                faceHero: "fisher"
              },
            ]
          }
        ]
      }),
    },
    //Fishing in the canal (action key facing the water, with the rod): after a short wait something bites and a fight starts.
    //These two kinds are found nowhere else. Level 1 up to the level of the front pizza, but at most maxLevel.
    fishing: {
      maxLevel: 5,
      pizzas: [
        { pizzaId: "d001", maxHp: 30, level: 1 },
        { pizzaId: "m001", maxHp: 30, level: 1 },
      ],
    },
    //Once the grate is cut with the pliers: the picture with the bars gone, and its two tiles are free
    variants: [
      {
        required: ["SEWER_GRATE_OPEN"],
        lowerSrc: "images/maps/SewerOpenLower.png",
        upperSrc: "images/maps/SewerOpenUpper.png",
        removeWalls: [[18, 3], [19, 3]],
      },
    ],
    walls: utils.wallsFromGrid([
      "######################",
      "######################",
      "######################",
      "#.############.#######",
      "#....................#",
      "#.............#......#",
      "###########.##########",
      "###########.##########",
      "#....................#",
      "#....................#",
      "####.#################",
      "######################",
    ]),
    cutsceneSpaces: {
      //Through the cut grate (tiles 18 and 19 of row 3, walls until then) into the tunnel behind it
      ...Object.fromEntries(SewerTunnelGrid.exit.map(([x, y], index) => [utils.asGridCoord(18 + index, 3), [
        { events: [{ type: "changeMap", map: "SewerTunnel", x: utils.withGrid(x), y: utils.withGrid(y - 1), direction: "up" }] }
      ]])),
      //The ladder on the left (tile 1,3): up through a trapdoor into the little room behind the DEMO house,
      //a short way back to the main street
      [utils.asGridCoord(1, 3)]: [
        {
          events: [
            {
              type: "changeMap",
              map: "DemoBack",
              x: utils.withGrid(4),
              y: utils.withGrid(6),
              direction: "left"
            }
          ]
        }
      ],
      //The ladder in the back wall (tile 14,3): up through the manhole into the back alleys.
      //The first time the rusty lid has to be forced open.
      [utils.asGridCoord(14, 3)]: [
        {
          required: ["SEWER_HATCH_OPEN"],
          events: sewerLadderEvents()
        },
        {
          events: [
            { type: "textMessage", text: "Žebřík vede nahoru k poklopu. Je celý zarezlý, ale zapřeš se do něj ramenem..." },
            { type: "flash", shake: true },
            { type: "textMessage", text: "Povolil! Shora sem zafoukal čerstvý vzduch." },
            { type: "addStoryFlag", flag: "SEWER_HATCH_OPEN" },
            ...sewerLadderEvents(),
          ]
        }
      ],
      //The gap back into the cellar
      [utils.asGridCoord(4, 10)]: [
        {
          events: [
            {
              type: "changeMap",
              map: "Cellar",
              x: utils.withGrid(18),
              y: utils.withGrid(4),
              direction: "down"
            }
          ]
        }
      ]
    }
  },
  //Back alleys above the sewers: the ladder in the Sewer comes out of a manhole here. A big winding area in the style
  //of a route between two towns: alleys behind the houses, ledges that can only be hopped down (shortcuts on the way
  //back), patches of pizza boxes with forgotten pizzas, a few dead ends. At the north end a barrier closes the way on.
  //The pictures and the grid (walls, ledges "v", boxes "b") are drawn by tools/ulicky.py into images/maps/BackAlleys*.png
  //and Content/backAlleys.js; change the layout there, not here.
  BackAlleys: {
    id: "BackAlleys",
    isOutdoors: true,
    lowerSrc: "images/maps/BackAlleysLower.png",
    battleSrc: "images/maps/BackAlleysBattle.png",
    upperSrc: "images/maps/BackAlleysUpper.png",
    //Once Dabl has been beaten: the pictures without the barrier, and the barrier and the pavement behind it can be walked on
    variants: [
      {
        required: ["DEFEATED_BQ20"],
        lowerSrc: "images/maps/BackAlleysOpenLower.png",
        upperSrc: "images/maps/BackAlleysOpenUpper.png",
        removeWalls: [...BackAlleysGrid.gate, ...BackAlleysGrid.beyond],
      }
    ],
    gameObjects: {
      hero: new Person({
        isPlayerControlled: true,
        x: utils.withGrid(BackAlleysGrid.start[0]),
        y: utils.withGrid(BackAlleysGrid.start[1]),
      }),
      ...backAlleysGate(),
      ...backAlleysGang(),
      //Olda sells burger boxes in the courtyard with the stray burgers (the dead end south of the top alley)
      olda: new Person({
        x: utils.withGrid(BackAlleysGrid.seller[0]),
        y: utils.withGrid(BackAlleysGrid.seller[1]),
        direction: "down",
        name: "Otis",
        src: "images/characters/people/npc51.png",
        behaviorLoop: [
          { type: "stand", direction: "down", time: 2600 },
          { type: "stand", direction: "right", time: 1500 },
        ],
        talking: [
          {
            required: ["TALKED_TO_OLDA"],
            events: [
              { type: "textMessage", text: "Krabičky na burger? Mám. Ber, dokud jsou.", faceHero: "olda" },
              { type: "shopMenu", items: [{ actionId: "item_burgerBox", price: 15 }] },
              { type: "textMessage", text: "A pamatuj: nikdy jsi mě neviděl.", faceHero: "olda" },
            ]
          },
          {
            events: [
              { type: "textMessage", text: "Pst! Hledáš burgery? Tady ve dvoře se jich válí, kolik chceš. Utekly gangu z krabiček.", faceHero: "olda" },
              { type: "textMessage", text: "Do krabice na pizzu je ale nenacpeš. Chce to krabičku na burger. Náhodou jich pár mám.", faceHero: "olda" },
              { type: "addStoryFlag", flag: "TALKED_TO_OLDA" },
              { type: "shopMenu", items: [{ actionId: "item_burgerBox", price: 15 }] },
              { type: "textMessage", text: "Hodně štěstí. A kdyby se někdo ptal, nikdy jsi mě neviděl.", faceHero: "olda" },
            ]
          }
        ]
      }),
      //Nicky: a cook who looks almost exactly like the hero (the hero's picture in other colours, tools/dvojnik.py).
      //He stands in the loading bay off the car park and heals pizzas for free, as often as you like.
      nicky: new Person({
        x: utils.withGrid(BackAlleysGrid.healer[0]),
        y: utils.withGrid(BackAlleysGrid.healer[1]),
        direction: "down",
        name: "Nicky",
        src: "images/characters/people/npc50.png",
        behaviorLoop: [
          { type: "stand", direction: "down", time: 2800 },
          { type: "stand", direction: "left", time: 1000 },
          { type: "stand", direction: "down", time: 2200 },
          { type: "stand", direction: "right", time: 1000 },
        ],
        talking: [
          {
            required: ["TALKED_TO_NICKY"],
            events: [
              { type: "textMessage", text: "Zase ty? Teda... zase já? Ukaž, co neseš.", faceHero: "nicky" },
              { type: "healPizzas" },
              { type: "textMessage", text: "Hotovo, jako čerstvě z pece. Dávej na sebe pozor. Na nás oba.", faceHero: "nicky" },
            ]
          },
          {
            events: [
              { type: "textMessage", text: "Počkat... ty vypadáš úplně jako já!", faceHero: "nicky" },
              { type: "textMessage", text: "Jsem Nicky. Taky kuchař, taky pizzy. Jen já zůstal trčet tady v uličkách mezi burgery.", faceHero: "nicky" },
              { type: "textMessage", text: "Ukaž, dám ti všechno do pořádku, pizzy i burgery. Kuchaři si musí pomáhat.", faceHero: "nicky" },
              { type: "healPizzas" },
              { type: "textMessage", text: "Hotovo, jako čerstvě z pece. Kdykoli budeš potřebovat, jsem tady.", faceHero: "nicky" },
              { type: "addStoryFlag", flag: "TALKED_TO_NICKY" },
            ]
          }
        ]
      }),
    },
    walls: utils.wallsFromGrid(BackAlleysGrid.rows),
    ledges: utils.ledgesFromGrid(BackAlleysGrid.rows),
    encounters: [
      //Forgotten pizzas in the pizza boxes: only the five street kinds, found nowhere else
      {
        chance: 0.15,
        maxLevel: 7,
        spaces: utils.spacesFromGrid(BackAlleysGrid.rows, "b"),
        pizzas: [
          { pizzaId: "u001", maxHp: 30, level: 1 },
          { pizzaId: "u002", maxHp: 30, level: 1 },
          { pizzaId: "u003", maxHp: 30, level: 1 },
          { pizzaId: "u004", maxHp: 30, level: 1 },
          { pizzaId: "u005", maxHp: 30, level: 1 },
        ],
      },
      //Stray hamburgers in the burger boxes of the courtyard off the top alley: they got away from the gang and can be
      //caught, but only into a burger box (item_burgerBox, sold by Olda right there). The Queen's own burger (b010) is not among them.
      {
        chance: 0.2,
        maxLevel: 7,
        spaces: utils.spacesFromGrid(BackAlleysGrid.rows, "B"),
        rustle: "V krabičkách od burgerů něco zašustilo...",
        shinyText: "Počkat... ten burger se celý zlatě třpytí!",
        pizzas: [
          { pizzaId: "b001", maxHp: 30, level: 1, weight: 3 },
          { pizzaId: "b009", maxHp: 30, level: 1, weight: 3 },
          { pizzaId: "b004", maxHp: 30, level: 1, weight: 2 },
          { pizzaId: "b005", maxHp: 30, level: 1, weight: 2 },
          { pizzaId: "b008", maxHp: 30, level: 1, weight: 2 },
          { pizzaId: "b003", maxHp: 30, level: 1 },
          { pizzaId: "b006", maxHp: 30, level: 1 },
          { pizzaId: "b007", maxHp: 30, level: 1 },
          { pizzaId: "b002", maxHp: 30, level: 1 },
        ],
      },
    ],
    cutsceneSpaces: {
      ...backAlleysNorthExit(),
      //The open manhole: down the ladder, back into the sewers
      [utils.asGridCoord(BackAlleysGrid.manhole[0], BackAlleysGrid.manhole[1])]: [
        {
          events: [
            {
              type: "changeMap",
              map: "Sewer",
              x: utils.withGrid(14),
              y: utils.withGrid(4),
              direction: "down"
            }
          ]
        }
      ]
    }
  },
  //The little square under Burger Tower, north of the back alleys (through the barrier Dabl guards). Two houses: a small
  //hardware store on the left, closed (its owner went to the tower and has not come back), and Burger Tower on the right;
  //its glass doors lead inside (Tower1). The pictures and the grid are drawn by tools/vez.py (Content/towerSquare.js); change the layout there.
  TowerSquare: {
    id: "TowerSquare",
    isOutdoors: true,
    lowerSrc: "images/maps/TowerSquareLower.png",
    battleSrc: "images/maps/StreetBattle.png",
    upperSrc: "images/maps/TowerSquareUpper.png",
    gameObjects: {
      hero: new Person({
        isPlayerControlled: true,
        x: utils.withGrid(TowerSquareGrid.exit[0][0]),
        y: utils.withGrid(TowerSquareGrid.exit[0][1] - 1),
        direction: "up",
      }),
      //The apprentice of the hardware store, standing in front of the shutter
      apprentice: new Person({
        x: utils.withGrid(TowerSquareGrid.apprentice[0]),
        y: utils.withGrid(TowerSquareGrid.apprentice[1]),
        direction: "down",
        //Once his boss is back he stands one tile to the left, out of the doorway
        storyPositions: [
          { required: ["TOWER_POWER_ON"], x: utils.withGrid(TowerSquareGrid.apprentice[0] - 1), y: utils.withGrid(TowerSquareGrid.apprentice[1]), direction: "down" },
        ],
        name: "Billy",
        src: "images/characters/people/npc48.png",
        behaviorLoop: [
          { type: "stand", direction: "down", time: 2600 },
          { type: "stand", direction: "right", time: 1400 },
          { type: "stand", direction: "down", time: 2000 },
          { type: "stand", direction: "left", time: 900 },
        ],
        talking: [
          {
            required: ["TOWER_POWER_ON"],
            events: [
              { type: "textMessage", text: "Šéf je zpátky a máme otevřeno! Celej den trčel ve výtahu v Burger Tower, věřil bys tomu?", faceHero: "apprentice" },
              { type: "textMessage", text: "Prej jsi ho odtamtud dostal ty. Jen běž dál, čeká na tebe.", faceHero: "apprentice" },
            ]
          },
          {
            events: [
              { type: "textMessage", text: "Železářství je zavřené.", faceHero: "apprentice" },
              { type: "textMessage", text: "Majitel musel jít něco zařídit do věže vedle. Do Burger Tower.", faceHero: "apprentice" },
              { type: "textMessage", text: "Kdy se vrátí? To bych taky rád věděl. Šel tam už ráno.", faceHero: "apprentice" },
            ]
          }
        ]
      }),
      //The door of the hardware store: shut until Hank is back, then the spot is gone and the tile leads inside
      shutter: new Hotspot({
        x: utils.withGrid(TowerSquareGrid.shutter[0]),
        y: utils.withGrid(TowerSquareGrid.shutter[1]),
        storyPositions: [{ required: ["TOWER_POWER_ON"], x: utils.withGrid(-10), y: utils.withGrid(-10) }],
        talking: [{ events: [{ type: "textMessage", text: "Roleta je stažená. Na cedulce stojí: HNED JSEM ZPÁTKY." }] }],
      }),
      ...textSpots("shopWindow", TowerSquareGrid.shopWindow, ["Ve výloze jsou kladiva, klíče, pila a jedny pořádné kleště."]),
      //Ráfek the courier and the bike that takes the hero home
      ...towerSquareBike(),
      //Micky: another cook who looks almost exactly like the hero (like Nicky in the back alleys; tools/dvojnik.py).
      //He stands right next to the doors of Burger Tower and heals for free, as often as you like: nobody heals inside.
      micky: new Person({
        x: utils.withGrid(TowerSquareGrid.healer[0]),
        y: utils.withGrid(TowerSquareGrid.healer[1]),
        direction: "down",
        name: "Micky",
        src: "images/characters/people/npc78.png",
        behaviorLoop: [
          { type: "stand", direction: "down", time: 3000 },
          { type: "stand", direction: "left", time: 1200 },
          { type: "stand", direction: "down", time: 2400 },
        ],
        talking: [
          {
            required: ["TALKED_TO_MICKY"],
            events: [
              { type: "textMessage", text: "Zase ty? Nebo já? Už se v tom ztrácím. Ukaž, co neseš.", faceHero: "micky" },
              { type: "healPizzas" },
              { type: "textMessage", text: "Hotovo, jako čerstvě z pece. Dávej na ně pozor.", faceHero: "micky" },
            ]
          },
          {
            events: [
              { type: "textMessage", text: "No ne. Další, co vypadá jako já!", faceHero: "micky" },
              { type: "textMessage", text: "Jsem Micky. Nickyho z uliček znáš? Tak to jsme tři.", faceHero: "micky" },
              { type: "textMessage", text: "Chystáš se do věže? Tam ti nikdo nepomůže. Ukaž, dám ti všechno do pořádku, pizzy i burgery.", faceHero: "micky" },
              { type: "healPizzas" },
              { type: "textMessage", text: "Hotovo, jako čerstvě z pece. Stojím tu pořád, stav se, kdykoli budeš potřebovat.", faceHero: "micky" },
              { type: "addStoryFlag", flag: "TALKED_TO_MICKY" },
            ]
          }
        ]
      }),
    },
    //With Hank back (TOWER_POWER_ON) the shutter is up: other pictures, and the door tile is free
    variants: [
      {
        required: ["TOWER_POWER_ON"],
        lowerSrc: "images/maps/TowerSquareOpenLower.png",
        upperSrc: "images/maps/TowerSquareOpenUpper.png",
        removeWalls: [TowerSquareGrid.shutter],
      },
    ],
    walls: utils.wallsFromGrid(TowerSquareGrid.rows),
    cutsceneSpaces: {
      ...towerSquareExit(),
      ...towerSquareDoor(),
      ...towerSquareCourierScene(),
      //into the hardware store (the tile is a wall while the shutter is down)
      [utils.asGridCoord(TowerSquareGrid.shutter[0], TowerSquareGrid.shutter[1])]: [
        { events: [{ type: "changeMap", map: "Hardware", x: utils.withGrid(HardwareGrid.exit[0]), y: utils.withGrid(HardwareGrid.exit[1] - 1), direction: "up" }] }
      ],
    }
  },
  //The tunnel behind the grate in the sewers and the inside of the hardware store (see the functions above)
  SewerTunnel: sewerTunnelMap(),
  SewerLair: sewerLairMap(),
  Hardware: hardwareMap(),
  //Inside Burger Tower: five floors (see towerFloor() above), drawn by tools/vez_vnitrek.py
  Tower1: towerFloor(1),
  Tower2: towerFloor(2),
  Tower3: towerFloor(3),
  Tower4: towerFloor(4),
  Tower5: towerFloor(5),
  PizzaShop: {
    id: "PizzaShop",
    lowerSrc: "images/maps/PizzaShopLower.png",
    battleSrc: "images/maps/PizzaShopBattle.png",
    upperSrc: "images/maps/PizzaShopUpper.png",
    gameObjects: {
      hero: new Person({
        isPlayerControlled: true,
        x: utils.withGrid(5),
        y: utils.withGrid(11),
      }),
      //The guard in the gap between the two counters (tile 6,6): the way behind the counter. He never moves.
      //Once the pizza monster has been driven off (CELLAR_MONSTER_FLED), Tony sends him home: he is not there any more.
      guard: new Person({
        x: utils.withGrid(6),
        y: utils.withGrid(6),
        direction: "down",
        name: "Guard",
        src: "images/characters/people/npc27.png",
        storyPositions: [
          { required: ["CELLAR_MONSTER_FLED"], x: utils.withGrid(-10), y: utils.withGrid(-10) },
        ],
        behaviorLoop: [
          { type: "stand", direction: "down", time: 3000 },
        ],
        talking: [
          {
            events: [
              { type: "textMessage", text: "Stop. Za pult smí jen personál.", faceHero: "guard" },
              { type: "textMessage", text: "Dál tě nepustím, ať říkáš co chceš. Tony si to přeje.", faceHero: "guard" },
            ]
          }
        ]
      }),
      //Tony Boiii, the owner. He stayed away while the pizza monster sat in the cellar of Neon Greens; once it has been
      //driven off he is back behind the left counter (tile 4,5) and sells escape ropes. Until then he is off the map.
      tony: new Person({
        x: utils.withGrid(-12),
        y: utils.withGrid(-12),
        direction: "down",
        name: "Tony",
        src: "images/characters/people/npc49.png",
        storyPositions: [
          { required: ["CELLAR_MONSTER_FLED"], x: utils.withGrid(4), y: utils.withGrid(5), direction: "down" },
        ],
        behaviorLoop: [
          { type: "stand", direction: "down", time: 3200 },
          { type: "stand", direction: "right", time: 1200 },
          { type: "stand", direction: "down", time: 2400 },
          { type: "stand", direction: "left", time: 900 },
        ],
        talking: tonyTalking()
      }),
      //Talking to Tony across the counter (the three counter tiles in front of him)
      tonyCounterA: new Hotspot({ x: utils.withGrid(3), y: utils.withGrid(6), talking: tonyTalking() }),
      tonyCounterB: new Hotspot({ x: utils.withGrid(4), y: utils.withGrid(6), talking: tonyTalking() }),
      tonyCounterC: new Hotspot({ x: utils.withGrid(5), y: utils.withGrid(6), talking: tonyTalking() }),
    },
    walls: utils.wallsFromGrid([
      "############",
      "############",
      "############",
      "############",
      "#.#####..#.#",
      "#.#......#.#",
      "#.####.###.#",
      "#..........#",
      "#..##..##..#",
      "#..##..##..#",
      "#..##......#",
      "#..........#",
      "#####.######",
      "############",
    ]),
    cutsceneSpaces: {
      [utils.asGridCoord(5, 12)]: [
        {
          events: [
            {
              type: "changeMap",
              map: "Street",
              x: utils.withGrid(5),
              y: utils.withGrid(9),
              direction: "down"
            }
          ]
        }
      ]
    }
  },
  //The arcade on the main street (the red house between the stairs and the hero's house). Three test robots
  //stand on their pads under the scoreboard, the numbered mat in front of each tells how hard it is.
  Herna: {
    id: "Herna",
    lowerSrc: "images/maps/HernaLower.png",
    battleSrc: "images/maps/HernaBattle.png",
    upperSrc: "images/maps/HernaUpper.png",
    gameObjects: {
      hero: new Person({
        isPlayerControlled: true,
        x: utils.withGrid(6),
        y: utils.withGrid(9),
      }),
      //Test robots SAM-1, EMMA-2, JACK-3 (easy, medium, hard): talk to one to start a practice battle, as often as you like
      trainer: new Person({
        x: utils.withGrid(4),
        y: utils.withGrid(6),
        name: "SAM-1",
        src: "images/characters/people/npc20.png",
        behaviorLoop: [
          { type: "stand", direction: "down", time: 2500 },
        ],
        talking: [
          {
            events: [
              { type: "textMessage", text: "PÍP! Testovací režim I: lehký. Ukaž, co umíš!", faceHero: "trainer" },
              { type: "battle", enemyId: "trainer" },
              { type: "healPizzas" },
              { type: "textMessage", text: "Test dokončen. Dobrá práce! Menu máš zase jako nové.", faceHero: "trainer" },
            ]
          }
        ]
      }),
      trainer2: new Person({
        x: utils.withGrid(6),
        y: utils.withGrid(6),
        name: "EMMA-2",
        src: "images/characters/people/npc21.png",
        behaviorLoop: [
          { type: "stand", direction: "down", time: 2500 },
        ],
        talking: [
          {
            events: [
              { type: "textMessage", text: "Testovací režim II: střední. Tady už si nic nedaruješ. Do toho!", faceHero: "trainer2" },
              { type: "battle", enemyId: "trainer2" },
              { type: "healPizzas" },
              { type: "textMessage", text: "Test dokončen. Dobrý zápas! Menu máš zase jako nové.", faceHero: "trainer2" },
            ]
          }
        ]
      }),
      trainer3: new Person({
        x: utils.withGrid(8),
        y: utils.withGrid(6),
        name: "JACK-3",
        src: "images/characters/people/npc22.png",
        behaviorLoop: [
          { type: "stand", direction: "down", time: 2500 },
        ],
        talking: [
          {
            events: [
              { type: "textMessage", text: "TESTOVACÍ REŽIM III: TĚŽKÝ. Moje pizzy jsou o level výš než tvoje menu. Zvládneš to?", faceHero: "trainer3" },
              { type: "battle", enemyId: "trainer3" },
              { type: "healPizzas" },
              { type: "textMessage", text: "Test dokončen. Respekt! Menu máš zase jako nové.", faceHero: "trainer3" },
            ]
          }
        ]
      }),
      //Things along the back wall that only have something to say
      cabinetA: new Hotspot({ x: utils.withGrid(1), y: utils.withGrid(4), talking: [{ events: [{ type: "textMessage", text: "Automat „Pizza v peci“. Rekord: 999 990. Někdo tu musel strávit celé prázdniny." }] }] }),
      cabinetB: new Hotspot({ x: utils.withGrid(2), y: utils.withGrid(4), talking: [{ events: [{ type: "textMessage", text: "Automat „Raketa z kuchyně“. Na obrazovce bliká VLOŽ MINCI." }] }] }),
      clawMachine: new Hotspot({ x: utils.withGrid(3), y: utils.withGrid(4), talking: [{ events: [{ type: "textMessage", text: "Automat s plyšovými pizzami. Chapadlo vypadá, že ještě nikdy nic nechytilo." }] }] }),
      cabinetC: new Hotspot({ x: utils.withGrid(10), y: utils.withGrid(4), talking: [{ events: [{ type: "textMessage", text: "Závodní automat. Volant je trochu mastný od pizzy." }] }] }),
      cabinetD: new Hotspot({ x: utils.withGrid(11), y: utils.withGrid(4), talking: [{ events: [{ type: "textMessage", text: "Automat s padajícími kostkami. Někdo to vzdal uprostřed hry." }] }] }),
      ...hernaScoreboard(),
    },
    walls: utils.wallsFromGrid([
      "#############",
      "#############",
      "#############",
      "#############",
      "####.....####",
      "#...........#",
      "#...........#",
      "#...........#",
      "#...........#",
      "#...........#",
      "######.######",
      "#############",
    ]),
    cutsceneSpaces: {
      [utils.asGridCoord(6, 10)]: [
        {
          events: [
            {
              type: "changeMap",
              map: "Street",
              x: utils.withGrid(18),
              y: utils.withGrid(8),
              direction: "down"
            }
          ]
        }
      ]
    }
  },
  Street: {
    id: "Street",
    isOutdoors: true,
    lowerSrc: "images/maps/StreetLower.png",
    battleSrc: "images/maps/StreetBattle.png",
    upperSrc: "images/maps/StreetUpper.png",
    gameObjects: {
      hero: new Person({
        isPlayerControlled: true,
        x: utils.withGrid(30),
        y: utils.withGrid(10),
      }),
      //Two trainers in the middle of a duel on the plaza in front of the arcade. It is only a scene: their
      //pizzas lie between them and take turns attacking (DuelPizza), talking to anyone gives a line of text.
      duelSam: new Person({
        x: utils.withGrid(19),
        y: utils.withGrid(9),
        direction: "right",
        name: "Sam",
        src: "images/characters/people/npc4.png",
        behaviorLoop: [
          { type: "stand", direction: "right", time: 2500 },
        ],
        talking: [
          {
            events: [
              { type: "textMessage", text: "Teď ne, mám rozehraný souboj! Jestli chceš trénovat, zajdi za roboty do herny.", faceHero: "duelSam" },
            ]
          }
        ]
      }),
      duelEmma: new Person({
        x: utils.withGrid(22),
        y: utils.withGrid(11),
        direction: "left",
        name: "Emma",
        src: "images/characters/people/npc23.png",
        behaviorLoop: [
          { type: "stand", direction: "left", time: 2500 },
        ],
        talking: [
          {
            events: [
              { type: "textMessage", text: "Moje Studená Havaj mu tu houbovou zmrazí. Dívej se a uč se!", faceHero: "duelEmma" },
            ]
          }
        ]
      }),
      duelPizzaSam: new DuelPizza({
        x: utils.withGrid(20),
        y: utils.withGrid(10),
        src: "images/characters/pizzas/f001.png",
        towards: 1,
        talking: [{ events: [{ type: "textMessage", text: "Samův Portobello Expres. Je uprostřed souboje, radši na něj nesahej." }] }]
      }),
      duelPizzaEmma: new DuelPizza({
        x: utils.withGrid(21),
        y: utils.withGrid(10),
        src: "images/characters/pizzas/c001.png",
        towards: -1,
        delay: 90,
        talking: [{ events: [{ type: "textMessage", text: "Emmina Studená Havaj. Je uprostřed souboje, radši na ni nesahej." }] }]
      }),
      //The board with the crossed pizza peels in the corner of the plaza (tiles 18 and 19 of row 11 are walls)
      duelSignA: new Hotspot({ x: utils.withGrid(18), y: utils.withGrid(11), talking: [{ events: [{ type: "textMessage", text: "Cedule se dvěma zkříženými pálkami: tady se bojuje s pizzami." }] }] }),
      //A guard closes the west end of the street in front of Tony Boii's (tile 4,11; the rest of column 4 is bushes), so nobody can walk off to the left
      ...streetGuards(),
      //The bike in front of the hero's house, once Ráfek has lent his: the way back to Burger Tower
      ...streetBike(),
      duelSignB: new Hotspot({ x: utils.withGrid(19), y: utils.withGrid(11), talking: [{ events: [{ type: "textMessage", text: "Cedule se dvěma zkříženými pálkami: tady se bojuje s pizzami." }] }] }),
    },
    walls: utils.wallsFromGrid([
      "########################################",
      "########################################",
      "########################################",
      "########################################",
      "########################################",
      "#########################.#########..###",
      "#########################.########.....#",
      "##################.####.#.########.....#",
      "###############.............######.....#",
      "#####.######....##.......##.#.####.....#",
      "#####...........##.......##............#",
      "#####...........####.....##............#",
      "#####..................................#",
      "#########..............................#",
      "########################################",
      "########################################",
      "########################################",
      "########################################",
      "########################################",
      "########################################",
    ]),
    //Side alley east of the shop: the tiles littered with boxes hide forgotten pizzas
    encounters: {
      chance: 0.2,
      maxLevel: 5,
      spaces: utils.gridArea(34, 6, 38, 8),
      pizzas: [
        { pizzaId: "c001", maxHp: 30, level: 1 },
        { pizzaId: "v002", maxHp: 30, level: 1 },
        { pizzaId: "f002", maxHp: 30, level: 1 },
        //Only at night (20:00-5:00), and then twice as likely as each of the others
        { pizzaId: "s002", maxHp: 30, level: 1, night: true, weight: 2 },
      ],
    },
    cutsceneSpaces: {
      //The arcade (the red house with the ARCADE sign)
      [utils.asGridCoord(18, 7)]: [
        {
          events: [
            {
              type: "changeMap",
              map: "Herna",
              x: utils.withGrid(6),
              y: utils.withGrid(9),
              direction: "up"
            }
          ]
        }
      ],
      //The hero's house
      [utils.asGridCoord(23, 7)]: [
        {
          events: [
            {
              type: "changeMap",
              map: "Home",
              x: utils.withGrid(5),
              y: utils.withGrid(9),
              direction: "up"
            }
          ]
        }
      ],
      [utils.asGridCoord(25, 5)]: [
        {
          events: [
            {
              type: "changeMap",
              map: "StreetNorth",
              x: utils.withGrid(7),
              y: utils.withGrid(16),
              direction: "up"
            }
          ]
        }
      ],
      [utils.asGridCoord(5, 9)]: [
        {
          events: [
            {
              type: "changeMap",
              map: "PizzaShop",
              x: utils.withGrid(5),
              y: utils.withGrid(12),
              direction: "up"
            }
          ]
        }
      ],
      [utils.asGridCoord(12, 9)]: [
        {
          events: [
            {
              type: "changeMap",
              map: "DemoRoom",
              x: utils.withGrid(5),
              y: utils.withGrid(10),
              direction: "up"
            }
          ]
        }
      ],
      [utils.asGridCoord(29, 9)]: [
        {
          events: [
            {
              type: "changeMap",
              map: "Kitchen",
              x: utils.withGrid(5),
              y: utils.withGrid(10),
              direction: "up"
            }
          ]
        }
      ]
    }
  }
}