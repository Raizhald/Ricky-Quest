//Vnitřek železářství (mapa Hardware): mřížka a místa, která vypisuje tools/zelezarstvi.py spolu s obrázky.
//NEUPRAVOVAT RUČNĚ - rozmístění se mění v tools/zelezarstvi.py, ten tenhle soubor přepíše.
window.HardwareGrid = {
  exit: [6, 10], //dveře ven na náměstíčko
  owner: [3, 4, "down"], //Hank za pultem
  spots: [[1, 3, "P"], [2, 3, "P"], [3, 3, "P"], [4, 3, "P"], [6, 3, "W"], [7, 3, "W"], [9, 3, "K"], [8, 4, "C"], [10, 4, "S"], [11, 4, "S"], [12, 4, "S"], [1, 5, "C"], [2, 5, "C"], [3, 5, "C"], [4, 5, "C"], [5, 5, "C"], [6, 5, "C"], [7, 5, "C"], [8, 5, "C"], [12, 6, "L"], [9, 7, "T"], [10, 7, "T"], [1, 9, "b"], [2, 9, "b"], [11, 9, "t"], [12, 9, "k"]], //[x, y, druh věci] s textem
  rows: [
    "##############",
    "##############",
    "##############",
    "##############",
    "#.......#.####",
    "#########....#",
    "#...........##",
    "#........##..#",
    "#............#",
    "###........###",
    "######.#######",
    "##############",
  ]
}
