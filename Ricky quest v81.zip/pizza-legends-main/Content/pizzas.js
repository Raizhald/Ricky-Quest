window.PizzaTypes = {
  normal: "normal",
  spicy: "spicy",
  veggie: "veggie",
  fungi: "fungi",
  chill: "chill",
  burger: "burger",
}

//Names of pizza types shown in menus (keys are used in logic)
window.PizzaTypeNames = {
  normal: "klasická",
  spicy: "pálivá",
  veggie: "zeleninová",
  fungi: "houbová",
  chill: "ledová",
  burger: "burgerová",
}

window.Pizzas = {
  "s001": {
    name: "Samuraj Kráječ",
    origin: "Tvoje první pizza",
    description: "Chuť tak ostrá, že se pořežeš",
    type: PizzaTypes.spicy,
    src: "images/characters/pizzas/s001.png",
    icon: "images/icons/spicy.png",
    actions: ["saucyStatus", "clumsyStatus", "damage1"],
  },
  "s002": {
    name: "Slaninová brigáda",
    origin: "V noci v krabicích v boční uličce",
    description: "Slaný válečník, který se ničeho nebojí",
    type: PizzaTypes.spicy,
    src: "images/characters/pizzas/s002.png",
    icon: "images/icons/spicy.png",
    actions: ["damage1", "saucyStatus", "clumsyStatus"],
  },
  "v001": {
    name: "Říkej mi Kadeřávek",
    origin: "Kámen na pizzu",
    description: "Zelená, křupavá a nebojácná",
    type: PizzaTypes.veggie,
    src: "images/characters/pizzas/v001.png",
    icon: "images/icons/veggie.png",
    actions: ["damage1"],
  },
  //Forgotten pizzas. They live in the boxes of the side alley and can only be caught, not made.
  //(s002 above is one of them too, but it only comes out at night.)
  "c001": {
    name: "Studená Havaj",
    origin: "Krabice v boční uličce",
    description: "Zapomenutá v krabici. Studená chutná nejlíp",
    type: PizzaTypes.chill,
    src: "images/characters/pizzas/c001.png",
    icon: "images/icons/chill.png",
    actions: ["damage1", "clumsyStatus"],
  },
  "v002": {
    name: "Zvadlá Zahrádka",
    origin: "Krabice v boční uličce",
    description: "Kdysi čerstvá. Bojovnost jí zůstala",
    type: PizzaTypes.veggie,
    src: "images/characters/pizzas/v002.png",
    icon: "images/icons/veggie.png",
    actions: ["damage1", "saucyStatus"],
  },
  "f002": {
    name: "Včerejší Funghi",
    origin: "Krabice v boční uličce",
    description: "Den stará a pořád nebezpečná",
    type: PizzaTypes.fungi,
    src: "images/characters/pizzas/f002.png",
    icon: "images/icons/fungi.png",
    actions: ["damage1", "clumsyStatus", "saucyStatus"],
  },
  "f001": {
    name: "Portobello Expres",
    origin: "Kámen na pizzu",
    description: "Houbová rychlovka, co nikde nestaví",
    type: PizzaTypes.fungi,
    src: "images/characters/pizzas/f001.png",
    icon: "images/icons/fungi.png",
    actions: ["damage1"],
  },
  //Sewer pizzas. They only bite in the canal under the cellar (fishing, see "fishing" of the Sewer map).
  "d001": {
    name: "Špinavá Margherita",
    origin: "Rybaření ve stokách",
    description: "Kdysi bílá. Teď aspoň zvyklá na špínu",
    type: PizzaTypes.fungi,
    src: "images/characters/pizzas/d001.png",
    icon: "images/icons/fungi.png",
    actions: ["damage1", "clumsyStatus"],
  },
  "m001": {
    name: "Bahnitá Šunkovka",
    origin: "Rybaření ve stokách",
    description: "Šunka, sýr a pořádná hrouda bahna",
    type: PizzaTypes.chill,
    src: "images/characters/pizzas/m001.png",
    icon: "images/icons/chill.png",
    actions: ["damage1", "saucyStatus", "clumsyStatus"],
  },
  //Street pizzas. They live in the boxes of the back alleys (map BackAlleys) and nowhere else. Drawn by tools/burgery.py.
  "u001": {
    name: "Toulavá Tuňáková",
    origin: "Krabice v zadních uličkách",
    description: "Někdo si kousnul a nechal ji být. Od té doby se toulá",
    type: PizzaTypes.chill,
    src: "images/characters/pizzas/u001.png",
    icon: "images/icons/chill.png",
    actions: ["damage1", "clumsyStatus"],
  },
  "u002": {
    name: "Sprejerka",
    origin: "Krabice v zadních uličkách",
    description: "Přestříkaná sprejem od kůrky ke kůrce",
    type: PizzaTypes.spicy,
    src: "images/characters/pizzas/u002.png",
    icon: "images/icons/spicy.png",
    actions: ["damage1", "saucyStatus", "clumsyStatus"],
  },
  "u003": {
    name: "Betonová Funghi",
    origin: "Krabice v zadních uličkách",
    description: "Ležela na chodníku tak dlouho, až ztvrdla jako on",
    type: PizzaTypes.fungi,
    src: "images/characters/pizzas/u003.png",
    icon: "images/icons/fungi.png",
    actions: ["damage1", "saucyStatus"],
  },
  "u004": {
    name: "Plevelná Rukola",
    origin: "Krabice v zadních uličkách",
    description: "Co vyrostlo ve spárách dlažby, skončilo na ní",
    type: PizzaTypes.veggie,
    src: "images/characters/pizzas/u004.png",
    icon: "images/icons/veggie.png",
    actions: ["damage1", "saucyStatus"],
  },
  "u005": {
    name: "Noční Kebabová",
    origin: "Krabice v zadních uličkách",
    description: "Koupená ve tři ráno, zapomenutá ve čtvrt na čtyři",
    type: PizzaTypes.spicy,
    src: "images/characters/pizzas/u005.png",
    icon: "images/icons/spicy.png",
    actions: ["damage1", "clumsyStatus", "saucyStatus"],
  },
  //Hamburgers of the Burger Queen gang (the back alleys). They fight like pizzas; so far only the gang has them.
  //Drawn by tools/burgery.py. What an enemy does with these actions: SubmissionMenu.decide().
  "b001": {
    name: "Sýrák",
    origin: "Gang Burger Queen",
    description: "Obyčejný cheeseburger. Pěšák gangu",
    type: PizzaTypes.burger,
    src: "images/characters/pizzas/b001.png",
    icon: "images/icons/burger.png",
    actions: ["greasySlap", "saucyStatus"],
  },
  "b002": {
    name: "Dvojitej Drtič",
    origin: "Gang Burger Queen",
    description: "Dvě masa, dva sýry, žádné slitování",
    type: PizzaTypes.burger,
    src: "images/characters/pizzas/b002.png",
    icon: "images/icons/burger.png",
    actions: ["doubleStack", "clumsyStatus"],
  },
  "b003": {
    name: "Pálivej Pepa",
    origin: "Gang Burger Queen",
    description: "Jalapeños, chilli a omáčka, která teče všude",
    type: PizzaTypes.burger,
    src: "images/characters/pizzas/b003.png",
    icon: "images/icons/burger.png",
    actions: ["hotSauce", "saucyStatus"],
  },
  "b004": {
    name: "Špekoun",
    origin: "Gang Burger Queen",
    description: "Slanina mu čouhá na obě strany",
    type: PizzaTypes.burger,
    src: "images/characters/pizzas/b004.png",
    icon: "images/icons/burger.png",
    actions: ["greasySlap", "clumsyStatus"],
  },
  "b005": {
    name: "Zelenej Podrazák",
    origin: "Gang Burger Queen",
    description: "Tváří se zdravě. Nevěř mu",
    type: PizzaTypes.burger,
    src: "images/characters/pizzas/b005.png",
    icon: "images/icons/burger.png",
    actions: ["greasySlap", "saucyStatus"],
  },
  "b006": {
    name: "Žampionovej Kápo",
    origin: "Gang Burger Queen",
    description: "Tmavá houska, žampiony a sýr s dírami",
    type: PizzaTypes.burger,
    src: "images/characters/pizzas/b006.png",
    icon: "images/icons/burger.png",
    actions: ["greasySlap", "clumsyStatus"],
  },
  "b007": {
    name: "Mražák",
    origin: "Gang Burger Queen",
    description: "Rybí burger rovnou z mrazáku, i s rampouchy",
    type: PizzaTypes.burger,
    src: "images/characters/pizzas/b007.png",
    icon: "images/icons/burger.png",
    actions: ["mustardShot", "clumsyStatus"],
  },
  "b008": {
    name: "Křupavá Slepice",
    origin: "Gang Burger Queen",
    description: "Kuřecí řízek větší než houska",
    type: PizzaTypes.burger,
    src: "images/characters/pizzas/b008.png",
    icon: "images/icons/burger.png",
    actions: ["mustardShot", "saucyStatus"],
  },
  "b009": {
    name: "Malej Sígr",
    origin: "Gang Burger Queen",
    description: "Jednohubka s párátkem. Malej, ale drzej",
    type: PizzaTypes.burger,
    src: "images/characters/pizzas/b009.png",
    icon: "images/icons/burger.png",
    actions: ["nudge", "clumsyStatus"],
  },
  "b010": {
    name: "Královna Bulka",
    origin: "Gang Burger Queen",
    description: "Tři patra a koruna. Nosí ji jen pravá ruka Královny",
    type: PizzaTypes.burger,
    src: "images/characters/pizzas/b010.png",
    icon: "images/icons/burger.png",
    actions: ["doubleStack", "saucyStatus", "clumsyStatus"],
  }
}

//The pizza monster (boss). It is not a kind the player can make or catch, so it is added in a way that keeps it
//out of every list built from Object.keys(Pizzas) (the recipes in the pause menu); Pizzas.x001 still works.
//"big": its picture is 48 px instead of 32. "hidden": meeting it is not written into the recipes.
Object.defineProperty(window.Pizzas, "x001", {
  enumerable: false,
  value: {
    name: "Pizzové monstrum",
    description: "Těsto, které ožilo v peci",
    type: PizzaTypes.spicy,
    src: "images/characters/pizzas/x001.png",
    icon: "images/icons/spicy.png",
    actions: ["damage1"],
    big: true,
    hidden: true,
  }
});

//Every kind has a golden version of its picture (name-shiny.png, drawn by tools/zlate.py); a pizza with "shiny: true" uses it.
//The boss is left out, nobody can catch it.
Object.keys(window.Pizzas).forEach(pizzaId => {
  window.Pizzas[pizzaId].shinySrc = window.Pizzas[pizzaId].src.replace(".png", "-shiny.png");
});
