window.Enemies = {
  //The pizza monster from the oven in the cellar: one big pizza and no chef behind it (no "src").
  //It never goes down: when its health drops to fleeAtPercent it runs away and the fight counts as won.
  "pizzaMonster": {
    name: "Pizzové monstrum",
    intro: "Pizzové monstrum se valí přímo na tebe!",
    fleeText: "Pizzové monstrum zařvalo a dává se na útěk!",
    pizzas: {
      "a": {
        pizzaId: "x001",
        maxHp: 110,
        level: 6,
        fleeAtPercent: 25,
      },
    }
  },
  //The same monster later, in its lair at the end of the sewers (map SewerLair): grown a lot, with an attack of its own
  //and both tricks, and this time it does not run away. One big pizza again; the health is set so that a menu that got
  //past the Burger Queen wins without healing (tools/souboje.py). The prize money is what it swallowed on its way.
  "pizzaMonsterLair": {
    name: "Pizzové monstrum",
    intro: "Pizzové monstrum se zvedá z hnízda. Tentokrát neuteče!",
    reward: 400,
    pizzas: {
      "a": {
        pizzaId: "x001",
        maxHp: 180,
        level: 18,
        actions: ["cheeseAvalanche", "damage1", "saucyStatus", "clumsyStatus"],
      },
    }
  },
  "erio": {
    name: "Erio",
    reward: 30,
    src: "images/characters/people/erio.png",
    pizzas: {
      //Beatable with one fresh pizza.
      "a": {
        pizzaId: "f001",
        maxHp: 20,
        level: 1,
      },
      "b": {
        pizzaId: "s002",
        maxHp: 30,
        level: 1,
      },
    }
  },
  //Test robot in the arcade (Herna): easy, can be fought again and again, pays no money
  "trainer": {
    name: "SAM-1",
    matchesPlayerLevel: true,
    src: "images/characters/people/npc20.png",
    pizzas: {
      "a": {
        pizzaId: "v001",
        maxHp: 30,
        level: 1,
      },
    }
  },
  //Two more test robots next to the easy one, each a step harder. Same rules: any number of fights, no money.
  //levelBonus raises their pizzas above the level of the player's front pizza.
  "trainer2": {
    name: "EMMA-2",
    matchesPlayerLevel: true,
    src: "images/characters/people/npc21.png",
    pizzas: {
      "a": {
        pizzaId: "f001",
        maxHp: 32,
        level: 1,
      },
      "b": {
        pizzaId: "s002",
        maxHp: 36,
        level: 1,
      },
    }
  },
  "trainer3": {
    name: "JACK-3",
    matchesPlayerLevel: true,
    levelBonus: 1,
    src: "images/characters/people/npc22.png",
    pizzas: {
      "a": {
        pizzaId: "v002",
        maxHp: 38,
        level: 1,
      },
      "b": {
        pizzaId: "c001",
        maxHp: 38,
        level: 1,
      },
      "c": {
        pizzaId: "f002",
        maxHp: 42,
        level: 1,
      },
    }
  },
  //Chefs in the northern street
  "bruno": {
    name: "Bruno",
    reward: 20,
    src: "images/characters/people/npc5.png",
    pizzas: {
      "a": {
        pizzaId: "s002",
        maxHp: 40,
        level: 1,
      },
    }
  },
  "gino": {
    name: "Gino",
    reward: 25,
    src: "images/characters/people/npc2.png",
    pizzas: {
      "a": {
        pizzaId: "f001",
        maxHp: 20,
        level: 1,
      },
      "b": {
        pizzaId: "v001",
        maxHp: 20,
        level: 1,
      },
    }
  },
  "rosa": {
    name: "Rosa",
    reward: 40,
    src: "images/characters/people/npc6.png",
    pizzas: {
      "a": {
        pizzaId: "s002",
        maxHp: 45,
        level: 2,
      },
    }
  },
  //The crew of Neon Greens, a step up from the chefs outside
  "olivia": {
    name: "Olivia",
    reward: 30,
    src: "images/characters/people/npc8.png",
    pizzas: {
      "a": {
        pizzaId: "v001",
        maxHp: 44,
        level: 2,
      },
    }
  },
  "pesto": {
    name: "Pesto",
    reward: 40,
    src: "images/characters/people/npc9.png",
    pizzas: {
      "a": {
        pizzaId: "v002",
        maxHp: 33,
        level: 2,
      },
      "b": {
        pizzaId: "f001",
        maxHp: 33,
        level: 2,
      },
    }
  },
  "verde": {
    name: "Verde",
    reward: 60,
    src: "images/characters/people/npc10.png",
    pizzas: {
      "a": {
        pizzaId: "v001",
        maxHp: 45,
        level: 3,
      },
      "b": {
        pizzaId: "c001",
        maxHp: 35,
        level: 3,
      },
    }
  },
  //The dining room under Neon Greens: five chefs, and their boss who only fights once all five are beaten
  "mata": {
    name: "Mint",
    reward: 45,
    src: "images/characters/people/npc12.png",
    pizzas: {
      "a": {
        pizzaId: "c001",
        maxHp: 42,
        level: 3,
      },
    }
  },
  "kopr": {
    name: "Dill",
    reward: 50,
    src: "images/characters/people/npc13.png",
    pizzas: {
      "a": {
        pizzaId: "v002",
        maxHp: 36,
        level: 3,
      },
      "b": {
        pizzaId: "f002",
        maxHp: 34,
        level: 3,
      },
    }
  },
  "rukola": {
    name: "Rocket",
    reward: 55,
    src: "images/characters/people/npc14.png",
    pizzas: {
      "a": {
        pizzaId: "v001",
        maxHp: 50,
        level: 4,
      },
    }
  },
  "fenykl": {
    name: "Fennel",
    reward: 60,
    src: "images/characters/people/npc15.png",
    pizzas: {
      "a": {
        pizzaId: "f001",
        maxHp: 38,
        level: 4,
      },
      "b": {
        pizzaId: "f002",
        maxHp: 38,
        level: 4,
      },
    }
  },
  "pazitka": {
    name: "Chive",
    reward: 65,
    src: "images/characters/people/npc16.png",
    pizzas: {
      "a": {
        pizzaId: "s002",
        maxHp: 42,
        level: 4,
      },
      "b": {
        pizzaId: "v002",
        maxHp: 40,
        level: 4,
      },
    }
  },
  "brokolini": {
    name: "Don Broccolini",
    reward: 150,
    src: "images/characters/people/npc17.png",
    pizzas: {
      "a": {
        pizzaId: "f002",
        maxHp: 45,
        level: 5,
      },
      "b": {
        pizzaId: "v002",
        maxHp: 50,
        level: 5,
      },
      "c": {
        pizzaId: "v001",
        maxHp: 60,
        level: 6,
      },
    }
  },
  "beth": {
    name: "Beth",
    reward: 15,
    src: "images/characters/people/npc1.png",
    pizzas: {
      "a": {
        pizzaId: "f001",
        maxHp: 50,
        level: 1,
      },
    }
  }
}

//The Burger Queen gang in the back alleys (map BackAlleys): twenty members, in the order they stand along the way from
//the manhole to the barrier. Their pictures are npc28 to npc47 (tools/gang.py), instead of pizzas they have hamburgers
//(b001 to b010 in Content/pizzas.js). Health of a burger = 22 + 5 for every level (+ the third number, if there is one).
//Who says what and the story flags (DEFEATED_BQ1 to DEFEATED_BQ20) are in backAlleysGang() in OverWorldMap.js.
//How many burgers each has (since v81, the user asked for it to be evened out): most have one, about every third has two,
//Sesame has three tiny ones (it is what he brags about) and Double, the last one, three proper ones. It was 41 burgers
//with ones, twos and threes all mixed up, now it is 30. So that the hero still gets to the tower as strong as before,
//every burger of the gang is worth more experience (BURGER_GANG_XP: 30 burgers give about what the 41 did).
window.BurgerGang = [
  ["Ketchup", 40, [["b001", 3]]],
  ["Mustard", 45, [["b009", 4, -8]]],
  ["Pickle", 50, [["b005", 4]]],
  ["Onion", 55, [["b001", 4], ["b004", 4]]],
  ["Sesame", 60, [["b009", 4, -8], ["b005", 4, -8], ["b009", 4, -8]]],
  ["Bun", 60, [["b008", 5]]],
  ["Cheddar", 65, [["b001", 5], ["b002", 5, 6]]],
  ["Bacon", 70, [["b004", 6]]],
  ["Fries", 70, [["b005", 6]]],
  ["Mayo", 75, [["b007", 6, 6]]],
  ["Tartar", 80, [["b007", 6], ["b003", 6]]],
  ["Nugget", 85, [["b008", 7]]],
  ["Grinder", 90, [["b006", 7]]],
  ["Grill", 95, [["b003", 7], ["b004", 7]]],
  ["Chunk", 95, [["b007", 7]]],
  ["Cutlet", 100, [["b005", 8]]],
  ["Straw", 100, [["b009", 8, -8], ["b002", 8, 6]]],
  ["Shake", 110, [["b006", 8]]],
  ["Tray", 120, [["b003", 8], ["b001", 8]]],
  ["Double", 200, [["b004", 8], ["b002", 9, 6], ["b010", 9, 12]]],
];
window.BURGER_GANG_XP = 1.35;
window.BurgerGang.forEach(([name, reward, burgers], index) => {
  const pizzas = {};
  burgers.forEach(([pizzaId, level, extraHp], slot) => {
    pizzas["abc"[slot]] = { pizzaId, level, maxHp: 22 + level * 5 + (extraHp || 0), xpScale: window.BURGER_GANG_XP };
  });
  window.Enemies[`bq${index + 1}`] = {
    name,
    reward,
    src: `images/characters/people/npc${28 + index}.png`,
    pizzas,
  };
});

//The people inside Burger Tower: twenty of them, five to a floor, in the order they are met on the way up (floor 1 first).
//Their pictures are npc53 to npc72 (tools/gang.py, TOWER), where they stand comes from tools/vez_vnitrek.py
//(TowerFloors[n].trainers) and what they say is in TOWER_CREW_LINES in OverWorldMap.js, all in the same order.
//Burgers are written like the gang's: [kind, level, extra health]. Story flags DEFEATED_BT1 to DEFEATED_BT20.
window.TowerCrew = [
  //Most of them have one burger and six have two (the last one on every floor, Crate and Wagyu): since v78, because
  //with two or three each the tower took far too long to climb (it was 45 burgers, now it is 26).
  //1 the entrance hall: part-timers
  ["Napkin", 130, [["b001", 9]]],
  ["Skewer", 135, [["b009", 9, -8]]],
  ["Salty", 140, [["b008", 9]]],
  ["Cup", 145, [["b007", 10, 6]]],
  ["Dressing", 150, [["b005", 10], ["b003", 10]]],
  //2 the store room: warehouse hands
  ["Pallet", 155, [["b004", 10]]],
  ["Crate", 160, [["b002", 10, 6], ["b006", 11]]],
  ["Freezer", 165, [["b007", 11]]],
  ["Sack", 170, [["b006", 11]]],
  ["Forklift", 175, [["b008", 11], ["b002", 11, 6]]],
  //3 the corridors: clerks
  ["Invoice", 180, [["b005", 11]]],
  ["Stamp", 185, [["b003", 12]]],
  ["Binder", 190, [["b004", 12]]],
  ["Bonus", 195, [["b002", 12, 6]]],
  ["Chart", 200, [["b006", 12], ["b005", 12]]],
  //4 the hall with the pillar: the Queen's own people
  ["Wagyu", 220, [["b002", 13, 6], ["b004", 13]]],
  ["Truffle", 230, [["b006", 13]]],
  ["Caviar", 240, [["b007", 14]]],
  ["Brioche", 250, [["b003", 14]]],
  ["Steak", 260, [["b004", 14], ["b002", 14, 6]]],
];
//On the top floor: the two bodyguards next to the Queen, and the Burger Queen herself (the boss of the whole gang).
//Since v79 the bodyguards have one burger each and the Queen two (they had two each and she had four): the user
//wanted the tower shorter, and the three fights come right after one another.
window.TowerBosses = {
  guardLeft: ["Lefty", 300, "npc74", [["b004", 15]]],
  guardRight: ["Righty", 300, "npc75", [["b003", 15]]],
  burgerQueen: ["Burger Queen", 600, "npc76", [["b002", 16, 8], ["b010", 17, 20]]],
};
(() => {
  const team = burgers => {
    const pizzas = {};
    burgers.forEach(([pizzaId, level, extraHp], slot) => {
      pizzas["abcd"[slot]] = { pizzaId, level, maxHp: 22 + level * 5 + (extraHp || 0) };
    });
    return pizzas;
  };
  window.TowerCrew.forEach(([name, reward, burgers], index) => {
    window.Enemies[`bt${index + 1}`] = { name, reward, src: `images/characters/people/npc${53 + index}.png`, pizzas: team(burgers) };
  });
  Object.keys(window.TowerBosses).forEach(id => {
    const [name, reward, picture, burgers] = window.TowerBosses[id];
    window.Enemies[id] = { name, reward, src: `images/characters/people/${picture}.png`, pizzas: team(burgers) };
  });
})();
