//Náměstíčko pod Burger Tower (mapa TowerSquare): mřížka a místa, která vypisuje tools/vez.py spolu s obrázky mapy.
//NEUPRAVOVAT RUČNĚ - rozmístění se mění v tools/vez.py, ten tenhle soubor přepíše.   # zeď   . volno
window.TowerSquareGrid = {
  exit: [[9, 22], [10, 22]], //východ na jih, zpátky do zadních uliček
  shutter: [5, 13], //dveře železářství: roleta je stažená, dokud se železář nevrátí z věže; pak se jimi vchází
  shopWindow: [[6, 13], [7, 13], [8, 13]], //výloha železářství
  towerDoor: [[17, 13], [18, 13]], //dveře Burger Tower
  apprentice: [5, 14], //kde stojí učeň ze železářství
  courier: [7, 20], //kde stojí kurýr Ráfek
  bike: [6, 20], //jeho kolo
  bikeStop: [6, 21], //kde hrdina sesedne, když přijede na kole z hlavní ulice
  healer: [19, 14], //kde stojí Micky, který léčí (hned vedle dveří věže)
  rows: [
    "############################",
    "############################",
    "############################",
    "############################",
    "############################",
    "############################",
    "############################",
    "############################",
    "############################",
    "############################",
    "############################",
    "############################",
    "############################",
    "#################..#########",
    "#..#.......................#",
    "#..............#....#...##.#",
    "#.......................##.#",
    "#.##....................##.#",
    "#.##.......................#",
    "#.##.......................#",
    "#..........#.............#.#",
    "#..........................#",
    "#########..#################",
    "############################",
  ]
}
