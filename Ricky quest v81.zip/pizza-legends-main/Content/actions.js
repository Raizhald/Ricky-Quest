//Názvy stavů zobrazené v souboji (klíče se používají v logice, nepřekládat)
window.StatusNames = {
  saucy: "omáčka",
  clumsy: "skluz",
}

window.Actions = {
  damage1: {
    name: "Buch!",
    description: "Nadýchaná rána těstem",
    success: [
      { type: "textMessage", text: "{CASTER} použije {ACTION}!" },
      { type: "animation", animation: "spin" },
      { type: "stateChange", damage: 10 }
    ]
  },
  saucyStatus: {
    name: "Rajčatový stisk",
    description: "Udělí stav Omáčka",
    targetType: "friendly",
    success: [
      { type: "textMessage", text: "{CASTER} použije {ACTION}!" },
      { type: "stateChange", status: { type: "saucy", expiresIn: 3 } }
    ]
  },
  clumsyStatus: {
    name: "Olivový olej",
    description: "Kluzká a lahodná spoušť",
    success: [
      { type: "textMessage", text: "{CASTER} použije {ACTION}!" },
      { type: "animation", animation: "glob", color: "#dafd2a" },
      { type: "stateChange", status: { type: "clumsy", expiresIn: 3 } },
      { type: "textMessage", text: "{TARGET} klouže na všechny strany!" },
    ]
  },
  //Attacks of the hamburgers (the Burger Queen gang)
  greasySlap: {
    name: "Mastná facka",
    description: "Plácnutí houskou, po kterém zůstane flek",
    success: [
      { type: "textMessage", text: "{CASTER} použije {ACTION}!" },
      { type: "animation", animation: "spin" },
      { type: "stateChange", damage: 10 }
    ]
  },
  doubleStack: {
    name: "Dvojitá nálož",
    description: "Dvě patra masa najednou",
    success: [
      { type: "textMessage", text: "{CASTER} použije {ACTION}!" },
      { type: "animation", animation: "spin" },
      { type: "stateChange", damage: 13 }
    ]
  },
  hotSauce: {
    name: "Pálivá omáčka",
    description: "Sprška, která štípe ještě týden",
    success: [
      { type: "textMessage", text: "{CASTER} použije {ACTION}!" },
      { type: "animation", animation: "glob", color: "#e3342a" },
      { type: "stateChange", damage: 11 }
    ]
  },
  mustardShot: {
    name: "Hořčičná střela",
    description: "Žlutá a přesná",
    success: [
      { type: "textMessage", text: "{CASTER} použije {ACTION}!" },
      { type: "animation", animation: "glob", color: "#f8c93a" },
      { type: "stateChange", damage: 11 }
    ]
  },
  nudge: {
    name: "Drzej šťouchanec",
    description: "Párátkem do kůrky",
    success: [
      { type: "textMessage", text: "{CASTER} použije {ACTION}!" },
      { type: "animation", animation: "spin" },
      { type: "stateChange", damage: 8 }
    ]
  },
  //The pizza monster's own attack, in its lair in the sewers (the enemy "pizzaMonsterLair")
  cheeseAvalanche: {
    name: "Sýrová lavina",
    description: "Vlna roztaveného sýra, která smete všechno",
    success: [
      { type: "textMessage", text: "{CASTER} použije {ACTION}!" },
      { type: "animation", animation: "glob", color: "#f1c25a" },
      { type: "stateChange", damage: 14 }
    ]
  },
  //Items
  //The warming lamp works like a revive: it puts one of the player's own that is knocked out back on its feet, with half
  //of its health ("revives" is that share). In a fight it is chosen among the items and then the one to wake is picked
  //(SubmissionMenu); outside a fight it is used from the pause menu, Předměty (PauseMenu, page "revive"). Tony sells it.
  //Until v72 this was "item_recoverStatus", an item of the original game that took a status away and that nobody could get.
  item_lamp: {
    name: "Ohřívací lampa",
    description: "Vrátí do hry toho, kdo je na kaši, s polovinou životů",
    targetType: "friendly",
    revives: 0.5,
    success: [
      { type: "textMessage", text: "Ohřívací lampa se rozsvítila. {TARGET} se pomalu zvedá!" },
      { type: "stateChange", revive: 0.5 },
      { type: "textMessage", text: "{TARGET} je zase jako z pece!" },
    ]
  },
  //Ingredients. Not usable in battle: they are added to a pizza at the pizza stone (up to three per pizza)
  //and raise its stats for good. You get them by trading in caught pizzas.
  addon_mozzarella: {
    name: "Mozzarella",
    description: "Přísada: +10 životů",
    addon: { maxHp: 10 },
  },
  addon_chilli: {
    name: "Chilli papričky",
    description: "Přísada: +2 útok",
    addon: { attack: 2 },
  },
  addon_olives: {
    name: "Olivy",
    description: "Přísada: +2 obrana",
    addon: { defense: 2 },
  },
  addon_basil: {
    name: "Bazalka",
    description: "Přísada: +1 útok a +1 obrana",
    addon: { attack: 1, defense: 1 },
  },
  addon_garlic: {
    name: "Česnek",
    description: "Přísada: +5 životů a +1 útok",
    addon: { maxHp: 5, attack: 1 },
  },
  //Used from the pause menu (Předměty), not in a fight: "fieldEvents" play right after the menu closes and one piece
  //is used up. "notOnMap" is the map where using it makes no sense. Sold by Tony in his shop (map PizzaShop).
  //The spot at home is the same one the hero wakes up on after a lost fight (tile 2,5).
  item_escapeRope: {
    name: "Únikové lano",
    description: "Vytáhne tě odkudkoli rovnou domů. Na jedno použití",
    fieldUse: true,
    notOnMap: "Home",
    fieldEvents: [
      { type: "textMessage", text: "Chytíš se únikového lana a pořádně zatáhneš..." },
      { type: "changeMap", map: "Home", x: 2 * 16, y: 5 * 16, direction: "down" },
    ],
  },
  //A key item: nothing to use it on yet, it just sits in the bag (not offered in battle). Sold by Hobo in the sewers.
  item_rod: {
    name: "Rybářský prut",
    description: "Hobův náhradní. Zatím na něj nic nevisí",
    keyItem: true,
  },
  //A key item from Hank in the hardware store: with it the grate in the sewers can be cut (see sewerGrateTalking in OverWorldMap.js)
  item_pliers: {
    name: "Kleště",
    description: "Od Hanka ze železářství. Přeštípnou i mříž",
    keyItem: true,
  },
  //Thrown at a forgotten pizza to catch it. The catching itself is the catchAttempt battle event.
  //"catchesKind": what fits into it - a pizza box holds pizzas, a burger box holds burgers (SubmissionMenu checks it).
  item_catchBox: {
    name: "Prázdná krabice",
    description: "Zkus do ní chytit zapomenutou pizzu",
    catchesWild: true,
    catchesKind: "pizza",
    success: [
      { type: "textMessage", text: "Letí prázdná krabice!" },
      { type: "animation", animation: "glob", color: "#c79a5b" },
      { type: "catchAttempt" },
    ]
  },
  //Thrown at a hamburger that belongs to nobody (the burger boxes in the courtyard of the back alleys). Sold by Olda there.
  item_burgerBox: {
    name: "Krabička na burger",
    description: "Zkus do ní chytit hamburger, který nikomu nepatří",
    catchesWild: true,
    catchesKind: "burger",
    success: [
      { type: "textMessage", text: "Letí krabička na burger!" },
      { type: "animation", animation: "glob", color: "#f8c93a" },
      { type: "catchAttempt" },
    ]
  },
  item_recoverHp: {
    name: "Parmazán",
    description: "Doplní 10 HP",
    targetType: "friendly",
    success: [
      { type: "textMessage", text: "{CASTER} si přisype {ACTION}!", },
      { type: "stateChange", recover: 10, },
      { type: "textMessage", text: "{CASTER} si doplní HP!", },
    ]
  },
}