//Doupě pizzového monstra ve stokách (mapa SewerLair): mřížka a místa, která vypisuje tools/doupe.py spolu s obrázky.
//NEUPRAVOVAT RUČNĚ - rozmístění se mění v tools/doupe.py, ten tenhle soubor přepíše.   # zeď   . chodník
window.SewerLairGrid = {
  exit: [[9, 15], [10, 15], [11, 15]], //cesta zpátky do tunelu (pod tmavý průchod)
  monster: [10, 6], //dlaždice uprostřed hnízda, na které sedí monstrum (po souboji louže sýra)
  trigger: [[2, 8], [3, 8], [4, 8], [5, 8], [6, 8], [7, 8], [8, 8], [9, 8], [10, 8], [11, 8], [12, 8], [13, 8], [14, 8], [15, 8], [16, 8], [17, 8], [18, 8]], //kdo sem šlápne, vzbudí monstrum
  spots: [[1, 3, "o"], [19, 3, "o"], [3, 4, "B"], [17, 4, "C"], [3, 6, "C"], [16, 6, "B"], [4, 9, "R"], [16, 9, "B"], [3, 10, "B"], [15, 10, "R"]], //[x, y, druh]: o roura, B krabice, C hrouda sýra, R kůrky
  rows: [
    "#####################",
    "#####################",
    "#####################",
    "#####################",
    "##.#.............#.##",
    "##......#####......##",
    "##.#....##.##...#..##",
    "##.................##",
    "##.................##",
    "##..#...........#..##",
    "##.#...........#...##",
    "#########...#########",
    "#########...#########",
    "#########...#########",
    "#########...#########",
    "#########...#########",
    "#####################",
  ]
}
