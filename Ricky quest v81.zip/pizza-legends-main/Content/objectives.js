//Objectives shown in the pause menu. One is done when its story flag is set.
//With "flags" instead of "flag" it is done when all of them are set, and the menu shows how many already are.
window.Objectives = [
  { flag: "USED_PIZZA_STONE", text: "Vytvoř pizzu na pizza kameni" },
  { flag: "DEFEATED_BETH", text: "Poraz Beth u dveří a dostaň se ven" },
  { flag: "TALKED_TO_ERIO", text: "Promluv si s Eriem" },
  { flag: "DEFEATED_ERIO", text: "Poraz svého rivala Eria" },
  { flag: "DEFEATED_BRUNO", text: "Poraz Bruna v severní ulici" },
  { flag: "DEFEATED_GINO", text: "Poraz Gina v severní ulici" },
  { flag: "DEFEATED_ROSA", text: "Poraz Rosu, nejlepší kuchařku v ulici" },
  { flag: "CAUGHT_PIZZA", text: "Chyť zapomenutou pizzu do krabice" },
  { flag: "DEFEATED_OLIVIA", text: "Poraz Olivii v Neon Greens" },
  { flag: "DEFEATED_PESTO", text: "Poraz Pesta v Neon Greens" },
  { flag: "DEFEATED_VERDE", text: "Poraz Verdeho a uvolni schody dolů" },
  { flags: ["DEFEATED_MATA", "DEFEATED_KOPR", "DEFEATED_RUKOLA", "DEFEATED_FENYKL", "DEFEATED_PAZITKA"], text: "Poraz pět kuchařů v jídelně" },
  { flag: "DEFEATED_BROKOLINI", text: "Poraz Dona Broccoliniho a uvolni schody do sklepa" },
  { flag: "CELLAR_MONSTER_FLED", text: "Zjisti, co se děje ve sklepě" },
  { flags: Array.from({ length: 20 }, (_, index) => `DEFEATED_BQ${index + 1}`), text: "Poraz gang Burger Queen v zadních uličkách" },
  { flags: Array.from({ length: 20 }, (_, index) => `DEFEATED_BT${index + 1}`), text: "Poraz lidi Burger Queen v Burger Tower" },
  { flag: "DEFEATED_QUEEN", text: "Poraz Burger Queen na vrcholu věže" },
  { flag: "MONSTER_DEFEATED", text: "Najdi ve stokách pizzové monstrum a poraz ho" },
]
