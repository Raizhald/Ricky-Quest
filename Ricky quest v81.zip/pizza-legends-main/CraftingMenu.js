//The pizza stone. Two modes:
//  "create"  - pick one of the stone's recipes, optionally add up to three ingredients, bake it
//  "improve" - pick a pizza you carry and add ingredients to it
class CraftingMenu extends PanelMenu {
  constructor({ pizzas, storyFlag, mode, onComplete }) {
    super({ title: mode === "improve" ? "Přísady" : "Vytvoř pizzu", onComplete });
    this.pizzas = pizzas || [];
    this.storyFlag = storyFlag;
    this.mode = mode || "create";
    this.chosen = null; //recipe id (create) or id of a player pizza (improve)
    this.pendingAddons = []; //ingredients picked for a pizza that is not baked yet
  }

  //The pizza the right panel shows: an existing one, or a preview of the one about to be baked
  getCurrentPizza() {
    if (this.mode === "improve") {
      return playerState.pizzas[this.chosen];
    }
    //A pizza straight from the stone is always this fresh; its stats start from that
    const fresh = PlayerState.freshStats(PlayerState.BAKED_FRESHNESS);
    let preview = { pizzaId: this.chosen, hp: fresh.maxHp, maxHp: fresh.maxHp, attack: fresh.attack, defense: fresh.defense, level: 1, freshness: PlayerState.BAKED_FRESHNESS, addons: [...this.pendingAddons] };
    this.pendingAddons.forEach(actionId => {
      const bonus = Actions[actionId].addon;
      preview.maxHp += bonus.maxHp || 0;
      preview.hp = preview.maxHp;
      preview.attack += bonus.attack || 0;
      preview.defense += bonus.defense || 0;
    })
    return preview;
  }

  //Ingredients the player still has, minus the ones already picked for the preview
  getAvailableAddons() {
    return Object.keys(Actions).filter(actionId => Actions[actionId].addon).map(actionId => {
      const picked = this.pendingAddons.filter(id => id === actionId).length;
      return { actionId, quantity: playerState.countItems(actionId) - picked };
    }).filter(entry => entry.quantity > 0);
  }

  showPizzaPanel(note = "") {
    this.showPanel(PanelMenu.getPizzaMarkup(this.getCurrentPizza(), note));
  }

  showIntroPanel() {
    this.showPanel(this.mode === "improve" ? (`
      <h2>Pizza kámen</h2>
      <p class="PauseMenu_note">Vyber pizzu nebo burger a přidej přísady. Na jeden kus nejvýš tři a přísada už v něm zůstane napořád.</p>
      <p class="PauseMenu_note">Přísady dostaneš ve stejné budově jako krabice, výměnou za chycené pizzy a burgery.</p>
    `) : (`
      <h2>Pizza kámen</h2>
      <p class="PauseMenu_note">Vyber si recept. Kámen upeče jen jednu pizzu, tak vybírej dobře.</p>
    `));
  }

  getOptions(pageKey) {
    const leave = {
      label: "Odejít",
      description: "Odejít od kamene",
      onFocus: () => this.showIntroPanel(),
      handler: () => {
        this.close();
      }
    };

    //Case 1: the list of recipes or of carried pizzas
    if (pageKey === "root") {
      const ids = this.mode === "improve" ? playerState.getCarriedIds() : this.pizzas;
      const entries = ids.map(id => {
        const pizza = this.mode === "improve" ? playerState.pizzas[id] : { pizzaId: id };
        const base = Pizzas[pizza.pizzaId];
        return {
          label: PlayerState.nameOf(pizza),
          description: base.description,
          right: () => this.mode === "improve" ? `${(pizza.addons || []).length}/3` : "",
          onFocus: () => {
            this.chosen = id;
            this.showPizzaPanel();
          },
          handler: () => {
            this.chosen = id;
            this.pendingAddons = [];
            this.showPage("pizza");
          }
        }
      })
      return this.getPagedOptions(entries, leave, () => this.showPage("root"));
    }

    const current = this.getCurrentPizza();
    const addonCount = (current.addons || []).length;

    //Case 2: one pizza
    if (pageKey === "pizza") {
      const addAddons = {
        label: `Přidat přísady (${addonCount}/3)`,
        description: addonCount >= 3
          ? PlayerState.word(current, "Víc přísad už se na pizzu nevejde", "Víc přísad už se do burgeru nevejde")
          : PlayerState.word(current, "Přidej pizze přísady, zlepší jí statistiky", "Přidej burgeru přísady, zlepší mu statistiky"),
        disabled: addonCount >= 3,
        onFocus: () => this.showPizzaPanel(),
        handler: () => {
          this.showPage("addons");
        }
      };
      const back = {
        label: "Zpět",
        description: "Zpět na seznam",
        onFocus: () => this.showPizzaPanel(),
        handler: () => {
          this.pendingAddons = [];
          this.showPage("root");
        }
      };
      if (this.mode === "improve") {
        return [addAddons, back];
      }
      return [
        {
          label: "Vytvořit tuhle pizzu",
          description: "Upeče pizzu i s vybranými přísadami",
          onFocus: () => this.showPizzaPanel(),
          handler: () => {
            const preview = this.getCurrentPizza();
            const shiny = PlayerState.rollShiny(); //the golden one is very rare
            playerState.addPizza(this.chosen, {
              shiny,
              hp: preview.maxHp,
              maxHp: preview.maxHp,
              attack: preview.attack,
              defense: preview.defense,
              freshness: preview.freshness,
              addons: preview.addons,
            });
            this.pendingAddons.forEach(actionId => playerState.removeItem(actionId));
            if (this.storyFlag) {
              playerState.storyFlags[this.storyFlag] = true;
            }
            if (shiny) {
              const message = new TextMessage({
                text: "Ta pizza se celá zlatě leskne! Takovou jsi ještě neviděl.",
                onComplete: () => this.close(true)
              });
              message.init(document.querySelector(".game-container"));
              return;
            }
            this.close(true);
          }
        },
        addAddons,
        back
      ];
    }

    //Case 3: pick an ingredient
    const available = this.getAvailableAddons();
    const backToPizza = {
      label: "Zpět",
      description: PlayerState.word(current, "Zpět k pizze", "Zpět k burgeru"),
      onFocus: () => this.showPizzaPanel(available.length ? "" : "Nemáš žádné přísady. Dostaneš je výměnou za chycené pizzy a burgery."),
      handler: () => {
        this.showPage("pizza");
      }
    };
    const entries = available.map(entry => {
      const action = Actions[entry.actionId];
      return {
        label: action.name,
        description: action.description,
        right: () => "máš " + entry.quantity,
        onFocus: () => this.showPizzaPanel(action.description),
        handler: () => {
          if (this.mode === "improve") {
            playerState.applyAddon(this.chosen, entry.actionId);
          } else {
            this.pendingAddons.push(entry.actionId);
          }
          this.showPage("pizza");
        }
      }
    })
    return this.getPagedOptions(entries, backToPizza, () => this.showPage("addons"));
  }

  showPage(pageKey) {
    if (pageKey !== this.pageKey) {
      this.listPage = 0;
    }
    this.pageKey = pageKey;
    if (pageKey === "root") {
      this.showIntroPanel();
    }
    this.setOptions(this.getOptions(pageKey));
  }
}
