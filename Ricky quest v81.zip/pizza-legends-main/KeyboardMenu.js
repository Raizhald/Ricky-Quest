class KeyboardMenu {
  constructor(config = {}) {
    this.options = []; //set by updater method
    this.up = null;
    this.down = null;
    this.prevFocus = null;
    this.descriptionContainer = config.descriptionContainer || null;
  }

  //focusIndex: which option gets the highlight (when it can be chosen); without it the first one that can be
  setOptions(options, focusIndex = null) {
    this.options = options;
    this.element.innerHTML = this.options.map((option, index) => {
      const disabledAttr = option.disabled ? "disabled" : "";
      return (`
        <div class="option">
          <button ${disabledAttr} data-button="${index}" data-description="${option.description}">
            ${option.label}
          </button>
          <span class="right">${option.right ? option.right() : ""}</span>
        </div>
      `)
    }).join("");

    this.element.querySelectorAll("button").forEach(button => {

      button.addEventListener("click", () => {
        const chosenOption = this.options[Number(button.dataset.button)];
        chosenOption.handler();
      })
      button.addEventListener("mouseenter", () => {
        button.focus();
      })
      button.addEventListener("focus", () => {
        this.prevFocus = button;
        this.descriptionElementText.innerText = button.dataset.description;
        this.options[Number(button.dataset.button)]?.onFocus?.();
      })
    })

    setTimeout(() => {
      const wanted = focusIndex === null ? null : this.element.querySelector(`button[data-button="${focusIndex}"]:not([disabled])`);
      (wanted || this.element.querySelector("button[data-button]:not([disabled])"))?.focus();
    }, 10)




  }

  createElement() {
    this.element = document.createElement("div");
    this.element.classList.add("KeyboardMenu");

    //Description box element
    this.descriptionElement = document.createElement("div");
    this.descriptionElement.classList.add("DescriptionBox");
    this.descriptionElement.innerHTML = (`<p>Spustit hru! \n (Na mobilech nefunguje)</p>`);
    this.descriptionElementText = this.descriptionElement.querySelector("p");
  }

  end() {

    //Remove menu element and description element
    this.element.remove();
    this.descriptionElement.remove();

    //Clean up bindings
    this.up.unbind();
    this.down.unbind();
    this.confirm.unbind();
  }

  init(container) {
    this.createElement();
    (this.descriptionContainer || container).appendChild(this.descriptionElement);
    container.appendChild(this.element);

    this.up = new KeyPressListener(["ArrowUp", "KeyW"], () => {
      const current = Number(this.prevFocus.getAttribute("data-button"));
      const prevButton = Array.from(this.element.querySelectorAll("button[data-button]")).reverse().find(el => {
        return el.dataset.button < current && !el.disabled;
      })
      prevButton?.focus();
    })
    this.down = new KeyPressListener(["ArrowDown", "KeyS"], () => {
      const current = Number(this.prevFocus.getAttribute("data-button"));
      const nextButton = Array.from(this.element.querySelectorAll("button[data-button]")).find(el => {
        return el.dataset.button > current && !el.disabled;
      })
      nextButton?.focus();
    })
    //E confirms the highlighted option (Enter still works through the focused button itself)
    this.confirm = new KeyPressListener("KeyE", () => {
      const button = this.prevFocus;
      if (!button || button.disabled || !this.element.contains(button)) {
        return;
      }
      this.options[Number(button.dataset.button)]?.handler();
    })

  }

}