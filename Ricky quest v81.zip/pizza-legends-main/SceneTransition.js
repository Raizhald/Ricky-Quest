class SceneTransition {
  //dark: fade through night blue instead of white (falling asleep, passing out)
  constructor({ dark } = {}) {
    this.element = null;
    this.dark = !!dark;
  }
  createElement() {
    this.element = document.createElement("div");
    this.element.classList.add("SceneTransition");
    if (this.dark) {
      this.element.classList.add("SceneTransition--dark");
    }
  }

  fadeOut() {
    this.element.classList.add("fade-out");
    this.element.addEventListener("animationend", () => {
      this.element.remove();
    }, { once: true })
  }

  init(container, callback) {
    this.createElement();
    container.appendChild(this.element);

    this.element.addEventListener("animationend", () => {
      callback();
    }, { once: true })

  }
}