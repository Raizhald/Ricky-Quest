const utils = {
  withGrid(n) {
    return n * 16
  },
  asGridCoord(x, y) {
    return `${x * 16}, ${y * 16}`
  },
  //Builds a walls object from rows of text: "#" is a wall, anything else is free
  //(a ledge "v", "^", "<", ">" is a wall too, see ledgesFromGrid)
  wallsFromGrid(rows) {
    const walls = {}
    rows.forEach((row, y) => {
      row.split("").forEach((character, x) => {
        if (character === "#" || utils.ledgeCharacters[character]) {
          walls[utils.asGridCoord(x, y)] = true
        }
      })
    })
    return walls
  },
  //Ledges in a grid: a wall that somebody walking in the direction of the arrow hops over, onto the tile behind it
  ledgeCharacters: { "v": "down", "^": "up", "<": "left", ">": "right" },
  ledgesFromGrid(rows) {
    const ledges = {}
    rows.forEach((row, y) => {
      row.split("").forEach((character, x) => {
        if (utils.ledgeCharacters[character]) {
          ledges[utils.asGridCoord(x, y)] = utils.ledgeCharacters[character]
        }
      })
    })
    return ledges
  },
  //All tiles of a grid marked with the given character, in the same form as walls: { "x, y": true }
  spacesFromGrid(rows, wanted) {
    const spaces = {}
    rows.forEach((row, y) => {
      row.split("").forEach((character, x) => {
        if (character === wanted) {
          spaces[utils.asGridCoord(x, y)] = true
        }
      })
    })
    return spaces
  },
  //All tiles of a rectangle (corners included), in the same form as walls: { "x, y": true }
  gridArea(x1, y1, x2, y2) {
    const spaces = {}
    for (let y = y1; y <= y2; y++) {
      for (let x = x1; x <= x2; x++) {
        spaces[utils.asGridCoord(x, y)] = true
      }
    }
    return spaces
  },
  nextPosition(initialX, initialY, direction) {
    let x = initialX
    let y = initialY
    const size = 16
    if (direction === 'left') {
      x -= size
    } else if (direction === 'right') {
      x += size
    } else if (direction === 'up') {
      y -= size
    } else if (direction === 'down') {
      y += size
    }
    return { x, y }
  },
  oppositeDirection(direction) {
    if (direction === "left") { return "right" }
    if (direction === "right") { return "left" }
    if (direction === "up") { return "down" }
    return "up"
  },
  wait(ms) {
    return new Promise(resolve => {
      setTimeout(() => {
        resolve()
      }, ms)
    })
  },
  randomFromArray(array) {
    return array[Math.floor(Math.random() * array.length)]
  },
  emitEvent(name, detail) {
    const event = new CustomEvent(name, {
      detail
    })
    document.dispatchEvent(event)
  }
}