//A creature bigger than a person: its sheet has frames of 48 px lying side by side, the same ones whichever
//way it moves (the pizza monster in the cellar). It walks in cutscenes like a person does.
//  new Monster({ x, y, src: "images/characters/pizza-monster.png", shadowSrc: "…-shadow.png", frames: 2 })
class Monster extends Person {
  constructor(config) {
    super(config);
    const frames = [];
    for (let i = 0; i < (config.frames || 1); i++) {
      frames.push([i, 0]);
    }
    const animations = {};
    ["down", "right", "up", "left"].forEach(direction => {
      animations["idle-" + direction] = frames;
      animations["walk-" + direction] = frames;
    });
    this.sprite = new Sprite({
      gameObject: this,
      src: config.src,
      shadowSrc: config.shadowSrc,
      animations,
      animationFrameLimit: 14,
      frameSize: 48,
      offsetX: -16, //centred on its tile
      offsetY: -34, //its lower edge a little above the bottom of the tile, like people's feet
    });
  }
}
