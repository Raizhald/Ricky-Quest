class KeyPressListener {
  //keyCode can be one key code ("KeyE") or a list of them (["KeyE", "Enter"])
  constructor(keyCode, callback) {
    const keyCodes = [].concat(keyCode)
    let keySafe = true
    this.keydownFunction = function (event) {
      //Ignore auto-repeat from a key that is still held down
      if (event.repeat) { return }
      //Ignore typing into a text field (renaming a pizza), otherwise W, S and E would work the menu
      if (event.target && event.target.tagName === 'INPUT') { return }
      if (keyCodes.includes(event.code)) {
        if (keySafe) {
          keySafe = false
          callback()
        }
      }
    }
    this.keyupFunction = function (event) {
      if (keyCodes.includes(event.code)) {
        keySafe = true
      }
    }
    document.addEventListener('keydown', this.keydownFunction)
    document.addEventListener('keyup', this.keyupFunction)
  }
  unbind() {
    document.removeEventListener('keydown', this.keydownFunction)
    document.removeEventListener('keyup', this.keyupFunction)
  }
}