class TextMessage {
  //portrait is optional: { src: character sprite sheet, name: shown under the face }
  constructor({ text, onComplete, portrait }) {
    this.text = Lang.tr(text) //in English when the game is (the text is then typed out letter by letter)
    this.portrait = portrait || null
    this.onComplete = onComplete
    this.element = null
  }

  createElement() {
    // create the element
    this.element = document.createElement('div')
    this.element.classList.add('TextMessage')

    const portraitMarkup = this.portrait ? (`
      <div class="TextMessage_portrait">
        <div class="TextMessage_face"><img src="${this.portrait.src}" alt="" /></div>
        <div class="TextMessage_name">${this.portrait.name || ""}</div>
      </div>
    `) : ""
    if (this.portrait) {
      this.element.classList.add('TextMessage--withPortrait')
    }

    this.element.innerHTML = (`
      ${portraitMarkup}
      <p class="TextMessage_p"></p>
      <button class="TextMessage_button">Dál</button>
    `)


    this.element.querySelector('button').addEventListener('click', () => {
      // close the text message
      this.done()
    })

    this.actionListener = new KeyPressListener(['KeyE', 'Enter'], () => {
      this.done()
    })
  }

  //The box holds two lines. A longer text is cut into pages of two lines each, measured in the box itself (so with the real
  //font and the real width, which is smaller next to a portrait). A page ends at the end of a sentence when there is one.
  getPages() {
    const paragraph = this.element.querySelector(".TextMessage_p")
    paragraph.textContent = "A"
    const lineHeight = paragraph.offsetHeight
    if (!lineHeight) {
      paragraph.textContent = ""
      return [this.text]
    }
    const fits = text => {
      paragraph.textContent = text
      return paragraph.offsetHeight <= lineHeight * 2 + 1
    }
    const pages = []
    let current = ""
    String(this.text).split(" ").forEach(word => {
      const longer = current ? current + " " + word : word
      if (!current || fits(longer)) {
        current = longer
        return
      }
      //Too long with this word: close the page, after the last whole sentence on it if there is one
      const sentenceEnd = Math.max(current.lastIndexOf(". "), current.lastIndexOf("! "), current.lastIndexOf("? "), current.lastIndexOf("... "))
      if (sentenceEnd > 0) {
        const cut = current.indexOf(" ", sentenceEnd)
        pages.push(current.slice(0, cut))
        current = current.slice(cut + 1) + " " + word
      } else {
        pages.push(current)
        current = word
      }
    })
    pages.push(current)
    paragraph.textContent = ""
    return pages
  }

  showPage(index) {
    this.pageIndex = index
    const paragraph = this.element.querySelector(".TextMessage_p")
    paragraph.textContent = ""
    //The typewriter effect
    this.revealingText = new RevealingText({
      element: paragraph,
      text: this.pages[index]
    })
    this.revealingText.init()
  }

  done() {
    if (!this.revealingText.isDone) {
      this.revealingText.warpToDone()
      return
    }
    if (this.pageIndex < this.pages.length - 1) {
      this.showPage(this.pageIndex + 1)
      return
    }
    this.element.remove()
    this.actionListener.unbind()
    this.onComplete()
  }

  init(container) {
    this.createElement()
    container.appendChild(this.element)
    this.pages = this.getPages()
    this.showPage(0)
  }
}