class Combatant {
  constructor(config, battle) {
    Object.keys(config).forEach(key => {
      this[key] = config[key];
    })
    this.hp = typeof (this.hp) === "undefined" ? this.maxHp : this.hp;
    this.battle = battle;
    if (this.shiny && this.shinySrc) {
      this.src = this.shinySrc;
    }
  }

  get hpPercent() {
    const percent = this.hp / this.maxHp * 100;
    return percent > 0 ? percent : 0;
  }

  get xpPercent() {
    return this.xp / this.maxXp * 100;
  }

  get isActive() {
    return this.battle?.activeCombatants[this.team] === this.id;
  }

  //Experience for beating it: 20 for every level. "xpScale" (Content/enemies.js) makes somebody's worth more or less;
  //the gang in the back alleys has it, see there.
  get givesXp() {
    return Math.round(this.level * 20 * (this.xpScale || 1));
  }

  createElement() {
    this.hudElement = document.createElement("div");
    this.hudElement.classList.add("Combatant");
    this.hudElement.setAttribute("data-combatant", this.id);
    this.hudElement.setAttribute("data-team", this.team);
    this.hudElement.innerHTML = (`
      <p class="Combatant_name">${this.shiny ? "★ " : ""}${this.name}${this.freshness ? ` ${this.freshness} %` : ""}</p>
      <p class="Combatant_level"></p>
      <div class="Combatant_character_crop">
        <img class="Combatant_character" alt="${this.name}" src="${this.src}" />
      </div>
      <img class="Combatant_type" src="${this.icon}" alt="${this.type}" />
      <svg viewBox="0 0 26 3" class="Combatant_life-container">
        <rect x=0 y=0 width="0%" height=1 fill="#82ff71" />
        <rect x=0 y=1 width="0%" height=2 fill="#3ef126" />
        <text class="Combatant_barText" x="13" y="2.6" text-anchor="middle"></text>
      </svg>
      <svg viewBox="0 0 26 2" class="Combatant_xp-container">
        <rect x=0 y=0 width="0%" height=1 fill="#ffd76a" />
        <rect x=0 y=1 width="0%" height=1 fill="#ffc934" />
        <text class="Combatant_barText" x="13" y="1.85" text-anchor="middle"></text>
      </svg>
      <p class="Combatant_status"></p>
    `);

    this.pizzaElement = document.createElement("img");
    this.pizzaElement.classList.add("Pizza");
    this.pizzaElement.setAttribute("src", this.src);
    this.pizzaElement.setAttribute("alt", this.name);
    this.pizzaElement.setAttribute("data-team", this.team);
    if (this.big) {
      this.pizzaElement.setAttribute("data-big", "true"); //a 48 px picture instead of 32 (the pizza monster)
    }

    this.hpFills = this.hudElement.querySelectorAll(".Combatant_life-container > rect");
    this.xpFills = this.hudElement.querySelectorAll(".Combatant_xp-container > rect");
  }

  update(changes = {}) {
    //Update anything incoming
    Object.keys(changes).forEach(key => {
      this[key] = changes[key]
    });

    //Update active flag to show the correct pizza & hud
    this.hudElement.setAttribute("data-active", this.isActive);
    this.pizzaElement.setAttribute("data-active", this.isActive);

    //Update HP & XP percent fills
    this.hpFills.forEach(rect => rect.style.width = `${this.hpPercent}%`)
    this.xpFills.forEach(rect => rect.style.width = `${this.xpPercent}%`)

    //Update the numbers written inside the bars (only shown in battle; enemies have no XP)
    this.hudElement.querySelector(".Combatant_life-container text").textContent = `${Math.max(0, this.hp)}/${this.maxHp}`;
    this.hudElement.querySelector(".Combatant_xp-container text").textContent = typeof this.xp === "number" ? `${this.xp}/${this.maxXp}` : "";

    //Update level on screen
    this.hudElement.querySelector(".Combatant_level").innerText = this.level;

    //Update status
    const statusElement = this.hudElement.querySelector(".Combatant_status");
    if (this.status) {
      statusElement.innerText = window.StatusNames?.[this.status.type] || this.status.type;
      statusElement.style.display = "block";
    } else {
      statusElement.innerText = "";
      statusElement.style.display = "none";
    }
  }

  //One point of experience. At the top of the bar the level goes up: a bit more health, attack and defense, and the
  //next level takes longer. Used by the animated bar of the one who fought (BattleEvent.giveXp) and by the share of
  //the others on the menu (TurnCycle.rewardXp).
  addXpPoint() {
    this.xp += 1;
    if (this.xp >= this.maxXp) {
      this.xp = 0;
      this.level += 1;
      this.maxXp = PlayerState.xpForLevel(this.level);
      this.maxHp += PlayerState.GROWTH.maxHp;
      this.hp += PlayerState.GROWTH.maxHp;
      this.attack = (this.attack || 10) + PlayerState.GROWTH.attack;
      this.defense = (this.defense || 10) + PlayerState.GROWTH.defense;
    }
  }

  getReplacedEvents(originalEvents) {

    if (this.status?.type === "clumsy" && utils.randomFromArray([true, false, false])) {
      return [
        { type: "textMessage", text: `${this.name} sebou plácne o zem!` },
      ]
    }

    return originalEvents;
  }

  getPostEvents() {
    if (this.status?.type === "saucy") {
      return [
        { type: "textMessage", text: "Mňam, samá omáčka!" },
        { type: "stateChange", recover: 5, onCaster: true }
      ]
    }
    return [];
  }

  decrementStatus() {
    if (this.status?.expiresIn > 0) {
      this.status.expiresIn -= 1;
      if (this.status.expiresIn === 0) {
        this.update({
          status: null
        })
        return {
          type: "textMessage",
          text: "Stav vypršel!"
        }
      }
    }
    return null;
  }

  init(container) {
    this.createElement();
    container.appendChild(this.hudElement);
    container.appendChild(this.pizzaElement);
    this.update();
  }

}