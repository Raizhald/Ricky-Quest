class TurnCycle {
  constructor({ battle, onNewEvent, onWinner }) {
    this.battle = battle;
    this.onNewEvent = onNewEvent;
    this.onWinner = onWinner;
    this.currentTeam = "player"; //or "enemy"
  }

  async turn() {
    //Get the caster
    const casterId = this.battle.activeCombatants[this.currentTeam];
    const caster = this.battle.combatants[casterId];
    const enemyId = this.battle.activeCombatants[caster.team === "player" ? "enemy" : "player"]
    const enemy = this.battle.combatants[enemyId];

    const submission = await this.onNewEvent({
      type: "submissionMenu",
      caster,
      enemy
    })

    //Running away. There is no running from somebody who challenged the hero: the menu simply comes back.
    //From a forgotten pizza or a stray burger it works with a chance that grows with the level of the pizza in front
    //(against the level of the other one) and with every try that failed; a failed try costs the turn.
    if (submission.flee) {
      if (!this.battle.isWild) {
        await this.onNewEvent({ type: "textMessage", text: "Tady se utéct nedá! Soupeř tě nepustí." })
        this.turn();
        return;
      }
      this.battle.fleeTries = (this.battle.fleeTries || 0) + 1;
      const chance = Math.max(0.3, Math.min(0.95, 0.5 + 0.1 * (caster.level - enemy.level) + 0.15 * (this.battle.fleeTries - 1)));
      if (Math.random() < chance) {
        await this.onNewEvent({ type: "textMessage", text: "Podařilo se ti utéct!" })
        this.onWinner("fled");
        return;
      }
      await this.onNewEvent({ type: "textMessage", text: "Útěk se nepovedl!" })
      this.nextTurn();
      return;
    }

    //Stop here if we are replacing this Pizza
    if (submission.replacement) {
      await this.onNewEvent({
        type: "replace",
        replacement: submission.replacement
      })
      await this.onNewEvent({
        type: "textMessage",
        text: `Na ně! Nastupuje ${submission.replacement.name}!`
      })
      this.nextTurn();
      return;
    }

    if (submission.instanceId) {

      //Add to list to persist to player state later
      this.battle.usedInstanceIds[submission.instanceId] = true;

      //Removing item from battle state
      this.battle.items = this.battle.items.filter(i => i.instanceId !== submission.instanceId)
    }

    const resultingEvents = caster.getReplacedEvents(submission.action.success);

    for (let i = 0; i < resultingEvents.length; i++) {
      const event = {
        ...resultingEvents[i],
        submission,
        action: submission.action,
        caster,
        target: submission.target,
      }
      await this.onNewEvent(event);
    }

    //Caught in a box: the fight is over and the pizza is ours
    if (this.battle.caught) {
      this.onWinner("player");
      return;
    }

    //A boss with "fleeAtPercent" runs away once its health drops that low: the fight ends there as a win
    const fleeing = submission.target;
    if (fleeing.team === "enemy" && fleeing.fleeAtPercent && fleeing.hp > 0 && fleeing.hpPercent <= fleeing.fleeAtPercent) {
      await this.onNewEvent({
        type: "textMessage",
        text: this.battle.enemy.fleeText || `${fleeing.name} se dává na útěk!`
      })
      fleeing.pizzaElement.style.opacity = 0;
      await this.rewardXp(fleeing.givesXp);
      this.onWinner("player");
      return;
    }

    //Did the target die?
    const targetDead = submission.target.hp <= 0;
    if (targetDead) {
      await this.onNewEvent({
        type: "textMessage", text: `${submission.target.name} je na kaši!`
      })

      if (submission.target.team === "enemy") {
        await this.rewardXp(submission.target.givesXp);
      }
    }

    //Do we have a winning team?
    const winner = this.getWinningTeam();
    if (winner) {
      //Only a win is announced here; a lost fight gets its own words afterwards (OverworldEvent.defeat)
      if (winner === "player") {
        await this.onNewEvent({
          type: "textMessage",
          text: "Vítězství!"
        })
      }
      if (winner === "player" && this.battle.enemy.reward) {
        await this.onNewEvent({
          type: "textMessage",
          text: `Získáváš ${this.battle.enemy.reward} peněz!`
        })
      }
      this.onWinner(winner);
      return;
    }

    //We have a dead target, but still no winner, so bring in a replacement
    if (targetDead) {
      const replacement = await this.onNewEvent({
        type: "replacementMenu",
        team: submission.target.team
      })
      await this.onNewEvent({
        type: "replace",
        replacement: replacement
      })
      await this.onNewEvent({
        type: "textMessage",
        text: `${replacement.name} nastupuje!`
      })
    }


    //Check for post events
    //(Do things AFTER your original turn submission)
    const postEvents = caster.getPostEvents();
    for (let i = 0; i < postEvents.length; i++) {
      const event = {
        ...postEvents[i],
        submission,
        action: submission.action,
        caster,
        target: submission.target,
      }
      await this.onNewEvent(event);
    }

    //Check for status expire
    const expiredEvent = caster.decrementStatus();
    if (expiredEvent) {
      await this.onNewEvent(expiredEvent)
    }

    this.nextTurn();
  }

  //Experience for an enemy that went down (or ran away). The one who is fighting gets all of it, with the bar filling up.
  //The others on the menu get a share (TurnCycle.XP_SHARE, a half) even though they did not fight, so the menu does not
  //end up with one strong pizza and two weak ones. Whoever is knocked out gets nothing, like in Pokémon.
  async rewardXp(xp) {
    const levelUpText = combatant => `${combatant.name}: úroveň ${combatant.level}! Životy, útok i obrana vzrostly.`;
    await this.onNewEvent({ type: "textMessage", text: `Získáno ${xp} XP!` })
    const rewarded = this.battle.combatants[this.battle.activeCombatants.player];
    const levelBefore = rewarded.level;
    await this.onNewEvent({ type: "giveXp", xp, combatant: rewarded })
    if (rewarded.level > levelBefore) {
      await this.onNewEvent({ type: "textMessage", text: levelUpText(rewarded) })
    }

    const share = Math.max(1, Math.floor(xp * TurnCycle.XP_SHARE));
    const others = Object.values(this.battle.combatants).filter(combatant => {
      return combatant.team === "player" && combatant !== rewarded && combatant.hp > 0;
    });
    if (others.length === 0) {
      return;
    }
    await this.onNewEvent({ type: "textMessage", text: `Ostatní v menu dostávají ${share} XP.` })
    for (const combatant of others) {
      const before = combatant.level;
      for (let point = 0; point < share; point++) {
        combatant.addXpPoint();
      }
      combatant.update();
      if (combatant.level > before) {
        await this.onNewEvent({ type: "textMessage", text: levelUpText(combatant) })
      }
    }
  }

  nextTurn() {
    this.currentTeam = this.currentTeam === "player" ? "enemy" : "player";
    this.turn();
  }

  getWinningTeam() {
    let aliveTeams = {};
    Object.values(this.battle.combatants).forEach(c => {
      if (c.hp > 0) {
        aliveTeams[c.team] = true;
      }
    })
    if (!aliveTeams["player"]) { return "enemy" }
    if (!aliveTeams["enemy"]) { return "player" }
    return null;
  }

  async init() {
    await this.onNewEvent({
      type: "textMessage",
      //(each of these is one whole sentence, so that it can be translated: see tools/preklad.py)
      text: this.battle.isWild
        ? (Pizzas[this.battle.enemy.pizzas.a.pizzaId].type === "burger"
          ? `Z krabičky se vykutálel burger: ${this.battle.enemy.name}! Úroveň ${this.battle.enemy.pizzas.a.level}, čerstvost ${this.battle.enemy.pizzas.a.freshness} %.`
          : `Z krabice vyskočila ${this.battle.enemy.name}! Úroveň ${this.battle.enemy.pizzas.a.level}, čerstvost ${this.battle.enemy.pizzas.a.freshness} %.`)
        : (this.battle.enemy.intro || `${this.battle.enemy.name} tě vyzývá na souboj!`)
    })

    //Start the first turn!
    this.turn();

  }

}

//What part of the experience the ones on the menu who did not fight get (the one who fought gets all of it)
TurnCycle.XP_SHARE = 0.5;
