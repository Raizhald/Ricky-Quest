class SubmissionMenu {
  constructor({ caster, enemy, onComplete, items, replacements, fainted, isWild }) {
    this.isWild = !!isWild;
    this.fainted = fainted || [];
    this.caster = caster;
    this.enemy = enemy;
    this.replacements = replacements;
    this.onComplete = onComplete;

    let quantityMap = {};
    items.forEach(item => {
      if (item.team === caster.team) {
        let existing = quantityMap[item.actionId];
        if (existing) {
          existing.quantity += 1;
        } else {
          quantityMap[item.actionId] = {
            actionId: item.actionId,
            quantity: 1,
            instanceId: item.instanceId,
          }
        }
      }
    })
    this.items = Object.values(quantityMap);
  }

  getPages() {

    const backOption = {
      label: "Zpět",
      description: "Návrat na předchozí stránku",
      handler: () => {
        this.keyboardMenu.setOptions(this.getPages().root)
      }
    };

    return {
      root: [
        {
          label: "Útok",
          description: "Vyber útok",
          handler: () => {
            //Do something when chosen...
            this.keyboardMenu.setOptions(this.getPages().attacks)
          }
        },
        {
          label: "Předměty",
          description: "Vyber předmět",
          handler: () => {
            //Go to items page...
            this.keyboardMenu.setOptions(this.getPages().items)
          }
        },
        {
          label: "Střídat",
          description: "Pošli do souboje někoho jiného z menu",
          handler: () => {
            //See pizza options
            this.keyboardMenu.setOptions(this.getPages().replacements)
          }
        },
        //Running away: only from what jumped out of a box, and it may not work (TurnCycle decides).
        //Against somebody it stays on the menu, but choosing it only gets a line of text.
        {
          label: "Utéct",
          description: this.isWild ? "Zkus ze souboje zmizet. Nemusí to vyjít" : "Před soupeřem se utéct nedá",
          handler: () => {
            this.menuSubmitFlee()
          }
        },
      ],
      attacks: [
        ...this.caster.actions.map(key => {
          const action = Actions[key];
          return {
            label: action.name,
            description: action.description,
            handler: () => {
              this.menuSubmit(action)
            }
          }
        }),
        backOption
      ],
      items: [
        ...this.items.map(item => {
          const action = Actions[item.actionId];
          //Boxes only work on forgotten pizzas and stray burgers, what belongs to somebody cannot be caught.
          //And each kind needs its own box: a burger does not fit into a pizza box and the other way round.
          const enemyKind = this.enemy.type === "burger" ? "burger" : "pizza";
          const isOwned = action.catchesWild && !this.isWild;
          const isWrongBox = action.catchesWild && !isOwned && action.catchesKind && action.catchesKind !== enemyKind;
          //The warming lamp needs somebody who is knocked out; then it asks who to wake
          const nobodyToWake = !!action.revives && this.fainted.length === 0;
          const isUnusable = isOwned || isWrongBox || nobodyToWake;
          const whyNot = nobodyToWake ? "Nikdo z tvého menu není na kaši"
            : isOwned
            ? (enemyKind === "burger" ? "Burger, který někomu patří, chytit nejde" : "Pizzu, která patří kuchaři, chytit nejde")
            : (enemyKind === "burger" ? "Do krabice na pizzu se burger nevejde. Chce to krabičku na burger" : "Do krabičky na burger se pizza nevejde");
          return {
            label: action.name,
            description: isUnusable ? whyNot : (action.catchesWild ? `${action.description}. ${(window.playerState.dex || {})[this.enemy.pizzaId] === "owned" ? "Tenhle druh už máš" : "Tenhle druh ještě nemáš"}` : action.description),
            disabled: isUnusable,
            right: () => {
              return "x" + item.quantity;
            },
            handler: () => {
              if (action.revives) {
                this.keyboardMenu.setOptions(this.getRevivePage(action, item.instanceId))
                return;
              }
              this.menuSubmit(action, item.instanceId)
            }
          }
        }),
        backOption
      ],
      replacements: [
        ...this.replacements.map(replacement => {
          return {
            label: replacement.name,
            description: replacement.description,
            handler: () => {
              //Swap me in, coach!
              this.menuSubmitReplacement(replacement)
            }
          }
        }),
        backOption
      ]
    }
  }

  //Who the warming lamp should wake: the knocked out ones of the team
  getRevivePage(action, instanceId) {
    return [
      ...this.fainted.map(combatant => {
        return {
          label: combatant.name,
          description: "Na kaši. Vrátí se s polovinou životů", //short: the menu box covers the right end of this line
          handler: () => {
            this.menuSubmit(action, instanceId, combatant)
          }
        }
      }),
      {
        label: "Zpět",
        description: "Zpět na předměty",
        handler: () => {
          this.keyboardMenu.setOptions(this.getPages().items)
        }
      }
    ]
  }

  menuSubmitReplacement(replacement) {
    this.keyboardMenu?.end();
    this.onComplete({
      replacement
    })
  }

  menuSubmitFlee() {
    this.keyboardMenu?.end();
    this.onComplete({
      flee: true
    })
  }

  //"target" is given only when the item asked who it is for (the warming lamp)
  menuSubmit(action, instanceId = null, target = null) {

    this.keyboardMenu?.end();

    this.onComplete({
      action,
      target: target || (action.targetType === "friendly" ? this.caster : this.enemy),
      instanceId
    })
  }

  //What an enemy does on its turn (since v81; until then it always used its first action).
  //Mostly it attacks: with one of its damaging actions, picked by chance when it has several.
  //Its other actions are "tricks" (Rajčatový stisk heals it over three turns, Olivový olej makes the player's one slip).
  //They are used sparingly, so that fights are not all the same and still no harder than before:
  //  - each trick at most once in a fight by each enemy pizza or burger, and never two tricks in a row,
  //  - only when it makes sense (healing: at least 15 health missing and no state on itself; oil: the player's one has
  //    no state and more than a third of its health left),
  //  - and even then only with the chance SubmissionMenu.TRICK_CHANCE.
  //A trick costs the enemy an attack, which is about what it gains: tools/souboje.py plays whole fights both ways.
  decide() {
    const caster = this.caster;
    const target = this.enemy; //from the enemy's side: the player's pizza in front
    const hasDamage = key => (Actions[key].success || []).some(event => event.damage);
    const attacks = caster.actions.filter(hasDamage);
    caster.usedTricks = caster.usedTricks || {};
    const tricks = caster.actions.filter(key => {
      const action = Actions[key];
      const givesStatus = (action.success || []).some(event => event.status);
      if (hasDamage(key) || !givesStatus || caster.usedTricks[key]) {
        return false;
      }
      return action.targetType === "friendly"
        ? !caster.status && caster.hp <= caster.maxHp - 15
        : !target.status && target.hp > target.maxHp / 3;
    });

    let chosen = attacks.length ? utils.randomFromArray(attacks) : caster.actions[0];
    if (tricks.length && attacks.length && !caster.lastWasTrick && Math.random() < SubmissionMenu.TRICK_CHANCE) {
      chosen = utils.randomFromArray(tricks);
      caster.usedTricks[chosen] = true;
    }
    caster.lastWasTrick = chosen !== caster.actions[0] && !hasDamage(chosen);
    this.menuSubmit(Actions[chosen]);
  }

  showMenu(container) {
    this.keyboardMenu = new KeyboardMenu();
    this.keyboardMenu.init(container);
    this.keyboardMenu.setOptions(this.getPages().root)
  }

  init(container) {

    if (this.caster.isPlayerControlled) {
      //Show some UI
      this.showMenu(container)
    } else {
      this.decide()
    }
  }
}

//How often an enemy uses a trick (heals itself, oils the player) on a turn when one would make sense
SubmissionMenu.TRICK_CHANCE = 0.5;
