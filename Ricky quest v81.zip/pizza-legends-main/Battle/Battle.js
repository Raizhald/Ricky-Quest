class Battle {
  constructor({ enemy, onComplete, backgroundSrc }) {

    this.enemy = enemy;
    this.backgroundSrc = backgroundSrc || null;
    this.onComplete = onComplete;
    this.isWild = !!enemy.isWild; //a forgotten pizza without a chef
    this.caught = null; //the enemy pizza, once it has been caught in a box

    this.combatants = {
      // "player1": new Combatant({
      //   ...Pizzas.s001,
      //   team: "player",
      //   hp: 30,
      //   maxHp: 50,
      //   xp: 95,
      //   maxXp: 100,
      //   level: 1,
      //   status: { type: "saucy" },
      //   isPlayerControlled: true
      // }, this),
      // "player2": new Combatant({
      //   ...Pizzas.s002,
      //   team: "player",
      //   hp: 30,
      //   maxHp: 50,
      //   xp: 75,
      //   maxXp: 100,
      //   level: 1,
      //   status: null,
      //   isPlayerControlled: true
      // }, this),
      // "enemy1": new Combatant({
      //   ...Pizzas.v001,
      //   team: "enemy",
      //   hp: 1,
      //   maxHp: 50,
      //   xp: 20,
      //   maxXp: 100,
      //   level: 1,
      // }, this),
      // "enemy2": new Combatant({
      //   ...Pizzas.f001,
      //   team: "enemy",
      //   hp: 25,
      //   maxHp: 50,
      //   xp: 30,
      //   maxXp: 100,
      //   level: 1,
      // }, this)
    }

    this.activeCombatants = {
      player: null, //"player1",
      enemy: null, //"enemy1",
    }

    //Dynamically add the Player team
    window.playerState.lineup.forEach(id => {
      this.addCombatant(id, "player", window.playerState.pizzas[id])
    });
    //Now the enemy team
    Object.keys(this.enemy.pizzas).forEach(key => {
      window.playerState.markSeen(this.enemy.pizzas[key].pizzaId);
      this.addCombatant("e_" + key, "enemy", this.enemy.pizzas[key])
    })


    //Start empty
    this.items = []

    //Add in player items (ingredients are for the pizza stone and key items for the bag, not for fighting)
    window.playerState.items.filter(item => !Actions[item.actionId].addon && !Actions[item.actionId].keyItem && !Actions[item.actionId].fieldUse).forEach(item => {
      this.items.push({
        ...item,
        team: "player"
      })
    })

    this.usedInstanceIds = {};

  }

  addCombatant(id, team, config) {
    //Pizzas that do not carry their own attack and defense (enemies) get them from their level
    const levelStat = PlayerState.statForLevel(config.level);
    this.combatants[id] = new Combatant({
      attack: levelStat,
      defense: levelStat,
      ...Pizzas[config.pizzaId],
      ...config,
      //The player may have put the attacks of a pizza in an order of their own (the storage counter)
      ...(team === "player" ? { actions: PlayerState.actionsOf(config) } : {}),
      team,
      isPlayerControlled: team === "player"
    }, this)

    //The first pizza that can still fight starts. One that was beaten earlier (0 health) stays on the bench.
    const canFight = typeof config.hp === "undefined" || config.hp > 0;
    if (canFight) {
      this.activeCombatants[team] = this.activeCombatants[team] || id
    }
  }

  createElement() {
    this.element = document.createElement("div");
    this.element.classList.add("Battle");
    this.element.innerHTML = (`
    <div class="Battle_hero">
      <img src="${'images/characters/people/hero.png'}" alt="Hero" />
    </div>
    ${this.isWild || !this.enemy.src ? "" : `
    <div class="Battle_enemy">
      <img src=${this.enemy.src} alt=${this.enemy.name} />
    </div>
    `}
    ${this.getOwnedMarkup()}
    `)
  }

  //Wild fights only: a small pixel mark, green tick = the player already has this kind,
  //red cross = not yet (a golden one counts as its own kind)
  getOwnedMarkup() {
    if (!this.isWild) {
      return "";
    }
    const wild = Object.values(this.enemy.pizzas)[0];
    const dex = window.playerState.dex || {};
    const owned = wild.shiny ? dex[wild.pizzaId + "_shiny"] === "owned" : dex[wild.pizzaId] === "owned";

    //Drawn pixel by pixel on a 14 x 14 grid (the size of the sky icon next to it), with a dark outline round the sign
    const pixels = new Set();
    const add = (x, y) => pixels.add(x + "," + y);
    if (owned) {
      [[10,4],[11,4],[9,5],[10,5],[3,6],[4,6],[8,6],[9,6],[4,7],[5,7],[7,7],[8,7],[5,8],[6,8],[7,8]].forEach(([x, y]) => add(x, y));
    } else {
      for (let i = 0; i < 7; i++) {
        add(3 + i, 3 + i); add(3 + i, 4 + i);
        add(10 - i, 3 + i); add(10 - i, 4 + i);
      }
    }
    const outline = new Set();
    pixels.forEach(key => {
      const [x, y] = key.split(",").map(Number);
      for (let dx = -1; dx <= 1; dx++) {
        for (let dy = -1; dy <= 1; dy++) {
          const k = (x + dx) + "," + (y + dy);
          if (!pixels.has(k)) { outline.add(k); }
        }
      }
    });
    const rect = (key, fill) => {
      const [x, y] = key.split(",");
      return `<rect x="${x}" y="${y}" width="1" height="1" fill="${fill}" />`;
    };
    const signColor = owned ? "#3ef126" : "#e8362b";
    const outlineColor = owned ? "#14501a" : "#5a0f0a";
    const title = owned ? "Tohle už máš" : "Tohle ještě nemáš";
    return `<div class="Battle_owned" title="${title}"><svg viewBox="0 0 14 14" shape-rendering="crispEdges">
      <rect x="0" y="0" width="14" height="14" style="fill: var(--menu-font-color)" />
      <rect x="1" y="1" width="12" height="12" fill="#ffe8d6" />
      ${[...outline].map(k => rect(k, outlineColor)).join("")}
      ${[...pixels].map(k => rect(k, signColor)).join("")}
    </svg></div>`;
  }

  //Puts the mark right next to the yellow circle of the enemy team in the top right corner (Team.js), same size, same height
  placeOwnedMark(container) {
    const mark = this.element.querySelector(".Battle_owned");
    const team = this.element.querySelector('.Team[data-team="enemy"]');
    if (!mark || !team) {
      return;
    }
    const box = container.getBoundingClientRect();
    const teamBox = team.getBoundingClientRect();
    const scale = container.offsetWidth ? box.width / container.offsetWidth : 1;
    if (!teamBox.width || !scale) {
      return;
    }
    //The circle starts one pixel below the top of the team element (the icon picture starts at y = -0.5 of 7 units)
    mark.style.top = ((teamBox.top - box.top) / scale + 1) + "px";
    mark.style.right = ((box.right - teamBox.left) / scale + 4) + "px";
  }

  init(container) {
    this.createElement();
    if (this.backgroundSrc) {
      this.element.style.backgroundImage = `url("${this.backgroundSrc}")`;
    }
    container.appendChild(this.element);

    this.playerTeam = new Team("player", "Hero");
    this.enemyTeam = new Team("enemy", "Bully");

    Object.keys(this.combatants).forEach(key => {
      let combatant = this.combatants[key];
      combatant.id = key;
      combatant.init(this.element)

      //Add to correct team
      if (combatant.team === "player") {
        this.playerTeam.combatants.push(combatant);
      } else if (combatant.team === "enemy") {
        this.enemyTeam.combatants.push(combatant);
      }
    })

    this.playerTeam.init(this.element);
    this.enemyTeam.init(this.element);
    this.placeOwnedMark(container);

    this.turnCycle = new TurnCycle({
      battle: this,
      onNewEvent: event => {
        return new Promise(resolve => {
          const battleEvent = new BattleEvent(event, this)
          battleEvent.init(resolve);
        })
      },
      onWinner: winner => {

        //"fled": the hero ran away from a wild fight. What happened to the pizzas and the items used stays, like after a win.
        if (winner === "player" || winner === "fled") {
          const playerState = window.playerState;
          Object.keys(playerState.pizzas).forEach(id => {
            const playerStatePizza = playerState.pizzas[id];
            const combatant = this.combatants[id];
            if (combatant) {
              playerStatePizza.hp = Math.max(0, combatant.hp);
              playerStatePizza.xp = combatant.xp;
              playerStatePizza.maxXp = combatant.maxXp;
              playerStatePizza.level = combatant.level;
              //A level gained in this fight also changed these
              playerStatePizza.maxHp = combatant.maxHp;
              playerStatePizza.attack = combatant.attack;
              playerStatePizza.defense = combatant.defense;
            }
          })

          //A caught pizza joins the player
          if (this.caught) {
            //Its own stats come from freshness: the fresher, the better
            const freshness = this.caught.freshness || 0;
            const bonus = PlayerState.freshnessBonus(freshness);
            const level = this.caught.level || 1;
            const maxHp = Math.round((50 + PlayerState.GROWTH.maxHp * (level - 1)) * bonus);
            playerState.addPizza(this.caught.pizzaId, {
              level,
              maxXp: PlayerState.xpForLevel(level),
              caught: true,
              shiny: !!this.caught.shiny,
              freshness,
              hp: maxHp,
              maxHp,
              attack: Math.round(PlayerState.statForLevel(level) * bonus),
              defense: Math.round(PlayerState.statForLevel(level) * bonus),
            });
            playerState.storyFlags["CAUGHT_PIZZA"] = true;
          }

          //Prize money
          playerState.money += this.enemy.reward || 0;

          //Get rid of player used items
          playerState.items = playerState.items.filter(item => {
            return !this.usedInstanceIds[item.instanceId]
          })

          //Send signal to update
          utils.emitEvent("PlayerStateUpdated");
        }

        this.element.remove();
        this.onComplete(winner !== "enemy");
      }
    })
    this.turnCycle.init();


  }

}