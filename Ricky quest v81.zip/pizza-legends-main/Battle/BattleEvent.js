class BattleEvent {
  constructor(event, battle) {
    this.event = event;
    this.battle = battle;
  }

  textMessage(resolve) {

    //The line is translated first and the names are put into it afterwards (each of them translated too)
    const text = Lang.tr(this.event.text)
      .replace("{CASTER}", Lang.tr(this.event.caster?.name))
      .replace("{TARGET}", Lang.tr(this.event.target?.name))
      .replace("{ACTION}", Lang.tr(this.event.action?.name))

    const message = new TextMessage({
      text,
      onComplete: () => {
        resolve();
      }
    })
    message.init(this.battle.element)
  }

  async stateChange(resolve) {
    const { caster, target, damage, recover, status, action } = this.event;
    let who = this.event.onCaster ? caster : target;

    if (damage) {
      //modify the target to have less HP: the attack's own damage, scaled by attack against defense
      const dealt = Math.max(1, Math.round(damage * (caster.attack || 10) / (target.defense || 10)));
      //An enemy that is meant to run away (fleeAtPercent) cannot be finished with one blow: it keeps 1 health
      //and the turn cycle then lets it flee
      const left = target.hp - dealt;
      target.update({
        hp: target.fleeAtPercent && target.team === "enemy" ? Math.max(1, left) : left
      })

      //start blinking
      target.pizzaElement.classList.add("battle-damage-blink");
    }

    if (recover) {
      let newHp = who.hp + recover;
      if (newHp > who.maxHp) {
        newHp = who.maxHp;
      }
      who.update({
        hp: newHp
      })
    }

    if (status) {
      who.update({
        status: { ...status }
      })
    }
    if (status === null) {
      who.update({
        status: null
      })
    }
    //Back on its feet with a share of its health (the warming lamp), whatever state it was in
    if (this.event.revive) {
      who.update({
        hp: Math.max(1, Math.round(who.maxHp * this.event.revive)),
        status: null
      })
    }


    //Wait a little bit
    await utils.wait(600)

    //Update Team components
    this.battle.playerTeam.update();
    this.battle.enemyTeam.update();

    //stop blinking
    target.pizzaElement.classList.remove("battle-damage-blink");
    resolve();
  }

  //A box was thrown at the enemy pizza. The weaker the pizza, the better the odds (35 % at full health, 90 % near zero).
  catchAttempt(resolve) {
    const { target } = this.event;
    const chance = 0.35 + 0.55 * (1 - target.hpPercent / 100);
    const isCaught = this.battle.isWild && Math.random() < chance;

    if (isCaught) {
      this.battle.caught = target;
      target.pizzaElement.style.visibility = "hidden";
    }
    //Three is all the hero carries; one more goes straight to storage (PlayerState.addPizza).
    //Say so, otherwise it looks as if the catch got lost.
    const playerState = window.playerState;
    const goesToStorage = isCaught && playerState.lineup.length >= 3;
    const message = new TextMessage({
      text: target.type === "burger"
        ? (isCaught ? `Chyceno! ${target.name} je v krabičce.` : `Nevyšlo to! ${target.name} je zase venku.`)
        : (isCaught ? `Chyceno! ${target.name} je v krabici.` : `${target.name} z krabice vyklouzla!`),
      onComplete: () => {
        if (!goesToStorage) {
          resolve();
          return;
        }
        const note = new TextMessage({
          text: `U sebe můžeš mít jen tři. ${target.name} putuje do úložiště v budově SHOP.`,
          onComplete: () => {
            resolve();
          }
        })
        note.init(this.battle.element)
      }
    })
    message.init(this.battle.element)
  }

  submissionMenu(resolve) {
    const { caster } = this.event;
    const menu = new SubmissionMenu({
      isWild: this.battle.isWild,
      caster: caster,
      enemy: this.event.enemy,
      items: this.battle.items,
      replacements: Object.values(this.battle.combatants).filter(c => {
        return c.id !== caster.id && c.team === caster.team && c.hp > 0
      }),
      //the knocked out ones of the same team: the warming lamp can wake one of them
      fainted: Object.values(this.battle.combatants).filter(c => {
        return c.team === caster.team && c.hp <= 0
      }),
      onComplete: submission => {
        //submission { what move to use, who to use it on }
        resolve(submission)
      }
    })
    menu.init(this.battle.element)
  }

  replacementMenu(resolve) {
    const menu = new ReplacementMenu({
      replacements: Object.values(this.battle.combatants).filter(c => {
        return c.team === this.event.team && c.hp > 0
      }),
      onComplete: replacement => {
        resolve(replacement)
      }
    })
    menu.init(this.battle.element)
  }

  async replace(resolve) {
    const { replacement } = this.event;

    //Clear out the old combatant
    const prevCombatant = this.battle.combatants[this.battle.activeCombatants[replacement.team]];
    this.battle.activeCombatants[replacement.team] = null;
    prevCombatant.update();
    await utils.wait(400);

    //In with the new!
    this.battle.activeCombatants[replacement.team] = replacement.id;
    replacement.update();
    await utils.wait(400);

    //Update Team components
    this.battle.playerTeam.update();
    this.battle.enemyTeam.update();

    resolve();
  }

  giveXp(resolve) {
    let amount = this.event.xp;
    const { combatant } = this.event;
    const step = () => {
      if (amount > 0) {
        amount -= 1;
        combatant.addXpPoint(); //levels up at the top of the bar

        combatant.update();
        setTimeout(step, 1000 / 60); //fixed pace, not tied to the screen refresh rate
        return;
      }
      resolve();
    }
    setTimeout(step, 1000 / 60);
  }

  animation(resolve) {
    const fn = BattleAnimations[this.event.animation];
    fn(this.event, resolve);
  }

  init(resolve) {
    this[this.event.type](resolve);
  }
}