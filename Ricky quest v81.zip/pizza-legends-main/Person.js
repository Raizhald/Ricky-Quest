class Person extends GameObject {
  constructor(config) {
    super(config)
    this.movingProgressRemaining = 0
    this.isStanding = false

    this.isPlayerControlled = config.isPlayerControlled || false

    this.directionUpdate = {
      'up': ['y', -1],
      'down': ['y', 1],
      'left': ['x', -1],
      'right': ['x', 1],
    }
  }

  update(state) {
    if (this.movingProgressRemaining > 0) {
      this.updatePosition()
    } else {

      //More cases for starting to walk will come here
      //
      //

      //Case: We're keyboard ready (it's ok for a player to provide input) and have an arrow pressed
      if (!state.map.isCutscenePlaying && this.isPlayerControlled && state.arrow) {
        this.startBehavior(state, {
          type: 'walk',
          direction: state.arrow
        })
      }
      this.updateSprite(state)
    }
  }

  startBehavior(state, behavior) {
    //Set character direction to whatever behavior has
    this.direction = behavior.direction

    if (behavior.type === 'walk') {
      //Stop here if space is not free
      if (state.map.isSpaceTaken(this.x, this.y, this.direction)) {

        //...unless it is a ledge facing this way: then hop over it, two tiles in one go
        const landing = state.map.ledgeLanding(this.x, this.y, this.direction)
        if (landing) {
          state.map.removeWall(this.x, this.y)
          state.map.addWall(landing.x, landing.y)
          this.movingProgressRemaining = Person.HOP_LENGTH
          this.hopRemaining = Person.HOP_LENGTH
          this.updateSprite(state)
          return
        }

        behavior.retry && setTimeout(() => {
          this.startBehavior(state, behavior)
        }, 10)

        return
      }

      //Ready to walk!
      state.map.moveWall(this.x, this.y, this.direction)
      this.movingProgressRemaining = 16
      this.updateSprite(state)
    }

    if (behavior.type === 'stand') {
      this.isStanding = true
      setTimeout(() => {
        utils.emitEvent('PersonStandComplete', {
          whoId: this.id
        })
        this.isStanding = false
      }, behavior.time)
    }

  }

  updatePosition() {
    const [property, change] = this.directionUpdate[this.direction]
    this[property] += change
    this.movingProgressRemaining -= 1

    //In the middle of a hop over a ledge the picture rises and comes down again (the shadow stays on the ground)
    if (this.hopRemaining > 0) {
      this.hopRemaining -= 1
      const done = 1 - this.hopRemaining / Person.HOP_LENGTH
      this.spriteOffsetY = this.hopRemaining > 0 ? -Math.round(Math.sin(Math.PI * done) * Person.HOP_HEIGHT) : 0
    }

    if (this.movingProgressRemaining === 0) {
      //We finished the walk!
      utils.emitEvent('PersonWalkingComplete', {
        whoId: this.id
      })

    }
  }

  updateSprite() {
    if (this.movingProgressRemaining > 0) {
      this.sprite.setAnimation('walk-' + this.direction)
      return
    }
    this.sprite.setAnimation('idle-' + this.direction)
  }

}

//A hop over a ledge: how many pixels along the ground (two tiles) and how high the picture rises
Person.HOP_LENGTH = 32
Person.HOP_HEIGHT = 9