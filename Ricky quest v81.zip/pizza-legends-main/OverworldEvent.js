class OverworldEvent {
  constructor({ map, event }) {
    this.map = map
    this.event = event
  }

  stand(resolve) {
    const who = this.map.gameObjects[this.event.who]
    who.startBehavior({
      map: this.map
    }, {
      type: 'stand',
      direction: this.event.direction,
      time: this.event.time
    })

    // setup a handler to complete when correct person is done standing, then resolve the event
    const completeHandler = e => {
      if (e.detail.whoId === this.event.who) {
        document.removeEventListener('PersonStandComplete', completeHandler)
        resolve()
      }
    }

    document.addEventListener('PersonStandComplete', completeHandler)
  }

  walk(resolve) {
    const who = this.map.gameObjects[this.event.who]
    who.startBehavior({
      map: this.map
    }, {
      type: 'walk',
      direction: this.event.direction,
      retry: true
    })

    // setup a handler to complete when correct person is done walking, then resolve the event
    const completeHandler = e => {
      if (e.detail.whoId === this.event.who) {
        document.removeEventListener('PersonWalkingComplete', completeHandler)
        resolve()
      }
    }

    document.addEventListener('PersonWalkingComplete', completeHandler)
  }

  //Several steps one after another: { type: "walkPath", who, path: ["left", "left", "up"] }
  async walkPath(resolve) {
    for (const direction of this.event.path) {
      await new OverworldEvent({ map: this.map, event: { type: "walk", who: this.event.who, direction } }).init()
    }
    resolve()
  }

  //Things that happen at the same time: { type: "parallel", tracks: [[events], [events]] }.
  //Every track plays its own events in order; the scene goes on when all tracks are done.
  async parallel(resolve) {
    await Promise.all(this.event.tracks.map(async track => {
      for (const event of track) {
        await new OverworldEvent({ map: this.map, event }).init()
      }
    }))
    resolve()
  }

  //Puts somebody on another tile at once (and turns them): { type: "place", who, x, y, direction }
  place(resolve) {
    const who = this.map.gameObjects[this.event.who]
    this.map.removeWall(who.x, who.y)
    who.x = this.event.x
    who.y = this.event.y
    if (this.event.direction) {
      who.direction = this.event.direction
    }
    this.map.addWall(who.x, who.y)
    resolve()
  }

  //A sign over somebody's head for a moment: { type: "emote", who, time } (drawn by Sprite, an exclamation mark)
  emote(resolve) {
    const who = this.map.gameObjects[this.event.who]
    who.emote = this.event.emote || "!"
    setTimeout(() => {
      who.emote = null
      resolve()
    }, this.event.time || 600)
  }

  //A bright flash over the whole picture, and the picture shakes if "shake" is set: { type: "flash", shake: true }
  flash(resolve) {
    const container = document.querySelector('.game-container')
    const element = document.createElement('div')
    element.classList.add('SceneFlash')
    container.appendChild(element)
    if (this.event.shake) {
      container.classList.add('scene-shake')
    }
    element.addEventListener('animationend', () => {
      element.remove()
      container.classList.remove('scene-shake')
      resolve()
    }, { once: true })
  }

  //Fishing with the rod: the hero throws the line, waits a moment, something bites and a fight with it starts.
  //What can bite comes from the "fishing" of the map: { maxLevel, pizzas: [{ pizzaId, maxHp, level, weight? }] }
  async fish(resolve) {
    const run = event => new OverworldEvent({ map: this.map, event }).init();
    const fishing = this.map.fishing;
    if (!fishing) {
      resolve();
      return;
    }
    if (!playerState.hasHealthyPizza()) {
      await run({ type: "textMessage", text: "Celé menu máš na kaši. Nejdřív ho nech ošetřit, než něco zavoláš z vody." });
      resolve();
      return;
    }

    await run({ type: "textMessage", text: "Vytahuješ prut a hážeš vlasec do kanálu. Teď jen čekat..." });

    //A little note while the float sits on the water: three dots that keep coming and going
    const container = document.querySelector(".game-container");
    const note = document.createElement("div");
    note.classList.add("FishingNote");
    note.innerHTML = '<span>Čekáš na záběr</span><span class="FishingNote_dots"><i>.</i><i>.</i><i>.</i></span>';
    container.appendChild(note);
    await utils.wait(2500 + Math.random() * 3000);
    note.remove();

    await run({ type: "flash", shake: true });
    await run({ type: "textMessage", text: "Plovák se potopil! Něco se zakouslo do háčku!" });
    const shiny = PlayerState.rollShiny(); //the golden one is very rare
    if (shiny) {
      await run({ type: "flash" });
      await run({ type: "textMessage", text: "Počkat... to, co se zakouslo, se celé zlatě třpytí!" });
    }

    let pool = [];
    fishing.pizzas.forEach(entry => {
      for (let i = 0; i < (entry.weight || 1); i++) {
        pool.push(entry);
      }
    });
    const { weight, ...pizza } = utils.randomFromArray(pool);
    const result = await run({
      type: "battle",
      wild: {
        ...pizza,
        shiny,
        freshness: 1 + Math.floor(Math.random() * 100), //1 to 100 %
        level: 1 + Math.floor(Math.random() * Math.min(playerState.getLeadLevel(), fishing.maxLevel || 1)),
      }
    });
    resolve(result);
  }

  //The map looks at the story flags again and switches to the variant that fits now (see OverworldMap.applyVariants)
  updateMap(resolve) {
    this.map.applyVariants()
    resolve()
  }

  //Somebody gets out of the way: one step in the first of the given directions that is free
  //(the hero may be standing in one of them)
  stepAside(resolve) {
    const who = this.map.gameObjects[this.event.who]
    const direction = (this.event.directions || ["right", "left", "down", "up"]).find(candidate => {
      return !this.map.isSpaceTaken(who.x, who.y, candidate)
    })
    if (!direction) {
      resolve()
      return
    }
    this.event.direction = direction
    this.walk(resolve)
  }

  textMessage(resolve) {

    if (this.event.faceHero) {
      const obj = this.map.gameObjects[this.event.faceHero]
      obj.direction = utils.oppositeDirection(this.map.gameObjects['hero'].direction)
    }

    //Whoever says the line (speaker, or the person turning to the hero) gets a small portrait
    const speaker = this.map.gameObjects[this.event.speaker || this.event.faceHero]
    const portrait = speaker ? { src: speaker.sprite.image.src, name: speaker.name } : null

    //The text can be a function, for lines that depend on the state of the game (e.g. the time)
    const message = new TextMessage({
      text: typeof this.event.text === "function" ? this.event.text() : this.event.text,
      portrait,
      onComplete: () => resolve()
    })
    message.init(document.querySelector('.game-container'))
  }

  //A question with a short list of answers; the events of the chosen answer play right away, inside this cutscene:
  //{ type: "choice", text: "Jet domů?", options: [{ label: "Ano", description: "...", events: [...] }, { label: "Ne" }] }
  //Esc picks the last answer, so put the one that changes nothing there.
  async choice(resolve) {
    const container = document.querySelector(".game-container");
    const element = document.createElement("div");
    element.classList.add("overlayMenu", "ChoiceMenu");
    element.innerHTML = `<h2>${this.event.text}</h2>`;
    const keyboardMenu = new KeyboardMenu({ descriptionContainer: container });
    keyboardMenu.init(element);

    const openedAt = performance.now();
    let esc = null;
    const picked = await new Promise(done => {
      keyboardMenu.setOptions(this.event.options.map(option => {
        return {
          label: option.label,
          description: option.description || "",
          handler: () => {
            //A key still held down from the text before must not answer the question
            if (performance.now() - openedAt > 250) {
              done(option);
            }
          }
        }
      }));
      container.appendChild(element);
      esc = new KeyPressListener("Escape", () => done(this.event.options[this.event.options.length - 1]));
    });
    esc.unbind();
    keyboardMenu.end();
    element.remove();

    for (const event of picked.events || []) {
      const result = await new OverworldEvent({ map: this.map, event }).init();
      if (result === "LOST_BATTLE") {
        resolve(result);
        return;
      }
    }
    resolve();
  }

  changeMap(resolve) {

    const sceneTransition = new SceneTransition();
    sceneTransition.init(document.querySelector(".game-container"), () => {
      this.map.overworld.startMap(window.OverworldMaps[this.event.map], {
        x: this.event.x,
        y: this.event.y,
        direction: this.event.direction,
      });
      resolve();

      sceneTransition.fadeOut();

    })
  }

  battle(resolve) {
    //Nobody left to fight with: say so instead of sending a beaten pizza in
    if (!playerState.hasHealthyPizza()) {
      const message = new TextMessage({
        text: "Celé menu máš na kaši. Ošetří ti ho Mia v budově SHOP.",
        onComplete: () => resolve("LOST_BATTLE")
      })
      message.init(document.querySelector('.game-container'))
      return;
    }

    //A forgotten pizza has no chef behind it, so its "enemy" is built here from the pizza itself
    const wild = this.event.wild;
    const bonus = wild ? PlayerState.freshnessBonus(wild.freshness) : 1;
    let enemy = wild ? {
      name: Pizzas[wild.pizzaId].name,
      isWild: true,
      pizzas: {
        "a": {
          ...wild,
          //In the fight freshness only makes it tougher (more health). Its full bonus shows once it is caught:
          //with attack and defense boosted too, a very fresh one would beat a single pizza of the same level.
          maxHp: Math.round(PlayerState.hpForLevel(wild.maxHp, wild.level) * bonus),
          attack: PlayerState.statForLevel(wild.level),
          defense: PlayerState.statForLevel(wild.level),
        }
      },
    } : Enemies[this.event.enemyId];

    //Sparring partners fight at the level of the player's front pizza, so training never gets too easy or too hard
    if (enemy.matchesPlayerLevel) {
      const level = playerState.getLeadLevel() + (enemy.levelBonus || 0);
      let pizzas = {};
      Object.keys(enemy.pizzas).forEach(key => {
        pizzas[key] = {
          ...enemy.pizzas[key],
          level,
          maxHp: PlayerState.hpForLevel(enemy.pizzas[key].maxHp, level),
        }
      })
      enemy = { ...enemy, pizzas };
    }

    const battle = new Battle({
      enemy,
      backgroundSrc: this.map.battleSrc,
      onComplete: (didWin) => {
        if (didWin) {
          resolve("WON_BATTLE");
          return;
        }
        this.defeat(resolve);
      }
    })
    battle.init(document.querySelector(".game-container"));

  }

  //A lost fight ends at home: the screen goes dark and the hero comes round in bed two hours later,
  //with all pizzas back at full health.
  defeat(resolve) {
    const container = document.querySelector(".game-container");
    const message = new TextMessage({
      text: "Padlo celé tvoje menu. Všechno kolem tebe zčernalo...",
      onComplete: () => {
        const sceneTransition = new SceneTransition({ dark: true });
        sceneTransition.init(container, () => {
          const overworld = this.map.overworld;
          playerState.advanceMinutes(120);
          playerState.healPizzas();
          //Lost against Beth at the door of the DEMO house: the hero wakes up there, in front of her, so the way out stays shut
          const atBethsDoor = playerState.storyFlags["DEMO_INTRO_DONE"] && !playerState.storyFlags["DEFEATED_BETH"];
          overworld.startMap(window.OverworldMaps[atBethsDoor ? "DemoRoom" : "Home"], atBethsDoor ? {
            x: utils.withGrid(5),
            y: utils.withGrid(8),
            direction: "down",
          } : {
            x: utils.withGrid(2),
            y: utils.withGrid(5),
            direction: "down",
          });
          //Ends the cutscene of the map the fight was on; what follows plays on the new one
          resolve("LOST_BATTLE");
          sceneTransition.fadeOut();
          overworld.map.startCutscene(atBethsDoor ? [
            { type: "textMessage", text: "Ležíš na podlaze v domě DEMO. Hlava ti třeští jako přepečená kůrka." },
            { type: "textMessage", text: "Pizzy máš zase v pořádku. Beth stojí ve dveřích a čeká na odvetu.", speaker: "npcA" },
          ] : [
            { type: "textMessage", text: "Probouzíš se doma v posteli. Hlava ti třeští jako přepečená kůrka." },
            { type: "textMessage", text: "Někdo tě sem donesl a celé menu ti dal do pořádku. Na stolku leží lístek:" },
            { type: "textMessage", text: "„Příště míň řečí a víc tréninku. A dávej si pozor na okraje!“" },
          ]);
        })
      }
    })
    message.init(container);
  }

  //A sleep in the bed: fade to dark, the clock moves six hours ahead
  sleep(resolve) {
    const sceneTransition = new SceneTransition({ dark: true });
    sceneTransition.init(document.querySelector(".game-container"), () => {
      playerState.sleep();
      setTimeout(() => {
        sceneTransition.fadeOut();
        resolve();
      }, 700)
    })
  }

  pause(resolve) {
    this.map.isPaused = true;
    const menu = new PauseMenu({
      progress: this.map.overworld.progress,
      onComplete: async (didLoad) => {
        const overworld = this.map.overworld;
        if (didLoad) {
          //A save file was loaded from the menu: restart from the saved map and spot
          const progress = overworld.progress;
          overworld.startMap(window.OverworldMaps[progress.mapId], {
            x: progress.startingHeroX,
            y: progress.startingHeroY,
            direction: progress.startingHeroDirection,
          });
          utils.emitEvent("LineupChanged");
        }
        this.map.isPaused = false;
        overworld.startGameLoop();
        //Something was used from the menu (the escape rope): what it does plays now, still inside this cutscene
        const fieldEvents = (menu.fieldAction && Actions[menu.fieldAction].fieldEvents) || [];
        for (const event of fieldEvents) {
          await new OverworldEvent({ map: this.map, event }).init();
        }
        resolve();
      }
    });
    menu.init(document.querySelector(".game-container"));
  }

  //Bring every pizza of the player back to full health
  healPizzas(resolve) {
    window.playerState.healPizzas();
    resolve();
  }

  //Puts an item into the hero's bag: { type: "giveItem", actionId: "item_pliers" }
  giveItem(resolve) {
    window.playerState.addItem(this.event.actionId);
    resolve();
  }

  addStoryFlag(resolve) {
    window.playerState.storyFlags[this.event.flag] = true;
    resolve();
  }

  shopMenu(resolve) {
    const menu = new ShopMenu({
      items: this.event.items,
      onComplete: () => {
        resolve();
      }
    })
    menu.init(document.querySelector(".game-container"))
  }

  storageMenu(resolve) {
    const menu = new StorageMenu({
      onComplete: () => {
        resolve();
      }
    })
    menu.init(document.querySelector(".game-container"))
  }

  tradeMenu(resolve) {
    const menu = new TradeMenu({
      onComplete: () => {
        resolve();
      }
    })
    menu.init(document.querySelector(".game-container"))
  }

  craftingMenu(resolve) {
    const menu = new CraftingMenu({
      pizzas: this.event.pizzas,
      storyFlag: this.event.storyFlag,
      mode: this.event.mode,
      onComplete: () => {
        resolve();
      }
    })
    menu.init(document.querySelector(".game-container"))
  }

  init() {
    return new Promise(resolve => {
      this[this.event.type](resolve)
    })
  }
}