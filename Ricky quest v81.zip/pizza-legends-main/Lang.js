//The language of the game. The texts are written in Czech right in the code; English is a dictionary (Content/en.js,
//made by tools/preklad.py) that is looked into while the game runs:
// - Lang.tr(text) translates one piece of text. TextMessage and the battle messages call it themselves, because they
//   cut the text up (letter by letter, or put names into it) before it gets on the screen.
// - Everything else (menus, panels, the HUD, the clock) is caught on the way to the screen: an observer watches the page
//   and swaps every bit of text that appears for its English version. So new menus need no extra code, only their
//   texts in tools/preklad-en.json.
//What has no translation stays Czech. The choice is kept in the browser (not in the save file), so it holds on the
//title screen too. It is changed in the settings: the pause menu and the title screen.
window.Lang = {
  STORAGE_KEY: "PizzaLegends_Lang",
  current: "cs",
  patterns: [],
  misses: new Map(),        //texts already found to have no translation (so the patterns are not tried again and again)
  originals: new WeakMap(), //text node -> { cs, en }: what it said before it was translated, to switch back

  init() {
    try {
      this.current = window.localStorage.getItem(this.STORAGE_KEY) === "en" ? "en" : "cs";
    } catch (e) {
      this.current = "cs";
    }
    const escape = text => text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    //"{0}" is any text, "{0:n}" a number; the most specific patterns (most letters of their own) are tried first
    this.patterns = ((window.EN && window.EN.patterns) || []).map(([cs, en]) => {
      const order = [];
      const source = escape(cs).replace(/\\\{(\d)(:n)?\\\}/g, (all, digit, isNumber) => {
        order.push(Number(digit));
        return isNumber ? "(\\d+)" : "(.+?)";
      });
      return { regex: new RegExp("^" + source + "$"), en, order, weight: cs.replace(/\{\d(:n)?\}/g, "").length };
    }).sort((a, b) => b.weight - a.weight);
    document.documentElement.lang = this.current;

    this.observer = new MutationObserver(records => {
      if (this.current !== "en") {
        return;
      }
      records.forEach(record => {
        if (record.type === "characterData") {
          this.translateNode(record.target);
        }
        record.addedNodes.forEach(node => this.translateTree(node));
      })
    });
    this.observer.observe(document.body, { childList: true, subtree: true, characterData: true });
    if (this.current === "en") {
      this.translateTree(document.body);
    }
  },

  //The English for one piece of text, or null when there is none
  lookup(core) {
    const exact = window.EN && window.EN.exact;
    if (exact && Object.prototype.hasOwnProperty.call(exact, core)) {
      return exact[core];
    }
    if (this.misses.has(core)) {
      return null;
    }
    for (const pattern of this.patterns) {
      const match = core.match(pattern.regex);
      if (match) {
        //what was caught in the holes (a name, a description) is translated too, when it can be
        const caught = {};
        pattern.order.forEach((digit, index) => {
          caught[digit] = this.lookup(match[index + 1]) ?? match[index + 1];
        });
        return pattern.en.replace(/\{(\d)\}/g, (all, digit) => caught[digit]);
      }
    }
    if (this.misses.size > 3000) {
      this.misses.clear();
    }
    this.misses.set(core, true);
    return null;
  },

  //Translates a text when the game is in English; white space around it stays as it was
  tr(text) {
    if (this.current !== "en" || typeof text !== "string") {
      return text;
    }
    const core = text.trim().replace(/\s+/g, " ");
    if (core.length < 2) {
      return text;
    }
    const found = this.lookup(core);
    if (found === null) {
      return text;
    }
    return text.match(/^\s*/)[0] + found + text.match(/\s*$/)[0];
  },

  translateNode(node) {
    if (node.nodeType !== Node.TEXT_NODE || !node.isConnected) {
      return;
    }
    const parent = node.parentElement;
    if (!parent || parent.closest("script, style, textarea, [data-no-translate]")) {
      return;
    }
    const translated = this.tr(node.data);
    if (translated !== node.data) {
      this.originals.set(node, { cs: node.data, en: translated });
      node.data = translated;
    }
  },

  translateTree(node) {
    if (node.nodeType === Node.TEXT_NODE) {
      this.translateNode(node);
      return;
    }
    if (node.nodeType !== Node.ELEMENT_NODE) {
      return;
    }
    const walker = document.createTreeWalker(node, NodeFilter.SHOW_TEXT);
    const found = [];
    while (walker.nextNode()) {
      found.push(walker.currentNode);
    }
    found.forEach(textNode => this.translateNode(textNode));
  },

  //Switching while the game runs: what is on the screen changes in place
  set(language) {
    this.current = language === "en" ? "en" : "cs";
    try {
      window.localStorage.setItem(this.STORAGE_KEY, this.current);
    } catch (e) { }
    document.documentElement.lang = this.current;
    if (this.current === "en") {
      this.translateTree(document.body);
      return;
    }
    //back to Czech: every bit of text that was swapped and has not changed since gets its own words back
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    const found = [];
    while (walker.nextNode()) {
      found.push(walker.currentNode);
    }
    found.forEach(textNode => {
      const kept = this.originals.get(textNode);
      if (kept && kept.en === textNode.data) {
        textNode.data = kept.cs;
      }
      this.originals.delete(textNode);
    });
  },

  toggle() {
    this.set(this.current === "en" ? "cs" : "en");
  },

  //The line of the settings that switches the language: it says which one is on
  label() {
    return this.current === "en" ? "Language: English" : "Jazyk: čeština";
  },

  describe() {
    return this.current === "en" ? "Switches the game to Czech" : "Přepne hru do angličtiny";
  },
};
