class PizzaStone extends GameObject {
  constructor(config) {
    super(config);
    this.sprite = new Sprite({
      gameObject: this,
      src: "images/characters/pizza-stone.png",
      animations: {
        "used-down": [[0, 0]],
        "unused-down": [[1, 0]],
      },
      currentAnimation: "used-down"
    });
    this.storyFlag = config.storyFlag;
    this.pizzas = config.pizzas;

    this.talking = [
      {
        required: [this.storyFlag],
        //Once it has baked its pizza, the stone still adds ingredients to the pizzas you carry
        events: [
          { type: "textMessage", text: "Kámen je ještě teplý. Novou pizzu neupeče, ale přísady přidat umí." },
          { type: "craftingMenu", mode: "improve" },
        ]
      },
      {
        events: [
          { type: "textMessage", text: "Blížíš se k legendárnímu pizza kameni..." },
          //The menu sets the story flag itself, and only when a pizza was really baked
          { type: "craftingMenu", pizzas: this.pizzas, storyFlag: this.storyFlag },
        ]
      }
    ]

  }

  update() {
    this.sprite.currentAnimation = playerState.storyFlags[this.storyFlag]
      ? "used-down"
      : "unused-down";
  }

}