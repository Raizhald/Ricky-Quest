class Sprite {
  constructor(config) {

    // setup the image
    this.image = new Image()
    this.image.src = config.src
    this.image.onload = () => {
      this.isLoaded = true
    }

    // shadow
    this.shadow = new Image()
    this.useShadow = true // config.useShadow || false
    if (this.useShadow) {
      this.shadow.src = config.shadowSrc || 'images/characters/shadow.png'
    }
    this.shadow.onload = () => {
      this.isShadowLoaded = true
    }

    // configure animation and initial state
    this.animations = config.animations || {
      'idle-down': [[0, 0]],
      'idle-right': [[0, 1]],
      'idle-up': [[0, 2]],
      'idle-left': [[0, 3]],
      'walk-down': [[1, 0], [0, 0], [3, 0], [0, 0]],
      'walk-right': [[1, 1], [0, 1], [3, 1], [0, 1]],
      'walk-up': [[1, 2], [0, 2], [3, 2], [0, 2]],
      'walk-left': [[1, 3], [0, 3], [3, 3], [0, 3]],
    }
    this.currentAnimation = config.currentAnimation || 'idle-down'
    this.currentAnimationFrame = 0

    this.animationFrameLimit = config.animationFrameLimit || 8
    this.animationFrameProgress = config.animationFrameLimit

    // reference the game object
    this.gameObject = config.gameObject

    // people are 32 px frames standing on a 16 px tile; something bigger (the pizza monster) gives its own
    // frame size and where the frame sits relative to the tile's top left corner
    this.frameSize = config.frameSize || 32
    this.offsetX = typeof config.offsetX === 'number' ? config.offsetX : -8
    this.offsetY = typeof config.offsetY === 'number' ? config.offsetY : -18
  }

  get frame() {
    return this.animations[this.currentAnimation][this.currentAnimationFrame]
  }

  setAnimation(key) {
    if (this.currentAnimation !== key) {
      this.currentAnimation = key
      this.currentAnimationFrame = 0
      this.animationFrameProgress = this.animationFrameLimit
    }
  }

  updateAnimationProgress() {
    // downtick frame progress
    if (this.animationFrameProgress > 0) {
      this.animationFrameProgress -= 1
      return
    }
    // reset the counter
    this.animationFrameProgress = this.animationFrameLimit
    this.currentAnimationFrame += 1

    if (this.frame === undefined) {
      this.currentAnimationFrame = 0
    }
  }

  draw(ctx, cameraPerson) {
    const x = this.gameObject.x + this.offsetX + utils.withGrid(10.5) - cameraPerson.x
    const y = this.gameObject.y + this.offsetY + utils.withGrid(6) - cameraPerson.y
    // an object may shift its picture off its tile for a moment (DuelPizza): sideways with the shadow, up without it
    const offsetX = this.gameObject.spriteOffsetX || 0
    const offsetY = this.gameObject.spriteOffsetY || 0
    this.isShadowLoaded && ctx.drawImage(this.shadow, x + offsetX, y)

    const [frameX, frameY] = this.frame

    const size = this.frameSize
    this.isLoaded && ctx.drawImage(this.image,
      frameX * size, frameY * size,
      size, size,
      x + offsetX, y + offsetY,
      size, size
    )
    //a sign over the head: somebody has just spotted the hero
    if (this.gameObject.emote) {
      const bx = Math.round(x + offsetX + size / 2 - 4)
      const by = Math.round(y + offsetY)
      ctx.fillStyle = "#222034"
      ctx.fillRect(bx + 1, by, 5, 10)
      ctx.fillRect(bx, by + 1, 7, 8)
      ctx.fillStyle = "#ffffff"
      ctx.fillRect(bx + 1, by + 1, 5, 8)
      ctx.fillStyle = "#c8443a"
      ctx.fillRect(bx + 3, by + 2, 1, 4)
      ctx.fillRect(bx + 3, by + 7, 1, 1)
    }
    //the animation is advanced by the game loop (Overworld.startGameLoop), once per fixed 1/60 s step
  }
}