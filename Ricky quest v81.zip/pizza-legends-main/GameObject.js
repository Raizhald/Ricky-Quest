class GameObject {
  constructor(config) {
    this.id = null;
    this.isMounted = false;
    this.x = config.x || 0;
    this.y = config.y || 0;
    this.direction = config.direction || "down";
    this.name = config.name || null;

    //Where this object stands depends on the story: the first entry whose flags are all set wins,
    //otherwise it is the spot from the config. E.g. a guard who moved away from a door after losing.
    //[{ required: ["SOME_FLAG"], x: utils.withGrid(8), y: utils.withGrid(6), direction: "down" }]
    this.storyPositions = config.storyPositions || [];
    this.startX = this.x;
    this.startY = this.y;
    this.startDirection = this.direction;

    //Somebody who watches the tiles in front of them: when the hero steps into view (up to "sight" tiles, nothing in
    //between), they come over and their "talking" scene plays - see OverworldMap.checkForTrainerSight.
    //Once the story flag "sightFlag" is set (they were beaten), they stop watching.
    this.sight = config.sight || 0;
    this.sightFlag = config.sightFlag || null;
    //Put back on their starting tile every time the map is entered (they may have walked off towards the hero)
    this.resetOnMount = !!config.resetOnMount;
    //A sign over the head for a moment ("!"), set by the event "emote" and drawn by Sprite
    this.emote = null;
    this.sprite = new Sprite({
      gameObject: this,
      src: config.src || "images/characters/people/hero.png",
    });

    this.behaviorLoop = config.behaviorLoop || [];
    this.behaviorLoopIndex = 0;

    this.talking = config.talking || []

  }

  applyStoryPosition() {
    if (this.storyPositions.length === 0 && !this.resetOnMount) {
      return;
    }
    const match = this.storyPositions.find(position => {
      return (position.required || []).every(flag => playerState.storyFlags[flag]);
    })
    this.x = match ? match.x : this.startX;
    this.y = match ? match.y : this.startY;
    //The way it faces is reset as well, so a scene that was cut short (a lost fight) starts over cleanly
    this.direction = (match && match.direction) || this.startDirection;
  }

  mount(map) {
    this.isMounted = true;
    map.addWall(this.x, this.y);

    //If we have a behavior, kick off after a short delay
    setTimeout(() => {
      this.doBehaviorEvent(map);
    }, 10)
  }

  update() {
  }

  async doBehaviorEvent(map) {

    //If this map was replaced (map change or a loaded save), carry on in the map that is active now,
    //otherwise an old loop keeps turning people around in the middle of a conversation
    const activeMap = map.overworld?.map;
    if (activeMap && activeMap !== map) {
      if (activeMap.gameObjects[this.id] === this) {
        return this.doBehaviorEvent(activeMap);
      }
      return;
    }

    //Don't do anything if there is a more important cutscene or I don't have config to do anything
    //anyway.
    if (map.isCutscenePlaying || this.behaviorLoop.length === 0 || this.isStanding) {
      return;
    }

    //Setting up our event with relevant info
    let eventConfig = this.behaviorLoop[this.behaviorLoopIndex];
    eventConfig.who = this.id;

    //Create an event instance out of our next event config
    const eventHandler = new OverworldEvent({ map, event: eventConfig });
    await eventHandler.init();

    //Setting the next event to fire
    this.behaviorLoopIndex += 1;
    if (this.behaviorLoopIndex === this.behaviorLoop.length) {
      this.behaviorLoopIndex = 0;
    }

    //Do it again!
    this.doBehaviorEvent(map);


  }


}