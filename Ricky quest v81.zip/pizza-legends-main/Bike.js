//A bike standing on the map (picture and shadow drawn by tools/kolo.py). It is a thing like the pizza stone:
//it takes up its tile and what happens when the hero uses it comes from "talking", like with a person.
//The two bikes of the game (the square under Burger Tower, the hero's house) are set up in OverWorldMap.js.
class Bike extends GameObject {
  constructor(config) {
    super(config);
    this.sprite = new Sprite({
      gameObject: this,
      src: "images/characters/bike.png",
      shadowSrc: "images/characters/bike-shadow.png",
      animations: {
        "idle-down": [[0, 0]],
      },
    });
  }
}
