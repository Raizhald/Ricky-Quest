//Shared base of the full screen menus with a list on the left and details on the right
//(pizza stone, pizza storage, trading). It reuses the look of the pause menu.
class PanelMenu {
  constructor({ title, onComplete }) {
    this.title = title;
    this.onComplete = onComplete;
    this.listPage = 0;
  }

  //Stat sheet of one pizza. pizza is a player pizza ({ pizzaId, maxHp, attack, ... }); note is an optional line at the bottom.
  static getPizzaMarkup(pizza, note = "") {
    const base = Pizzas[pizza.pizzaId];
    const row = (label, value) => (`
      <div class="PauseMenu_row">
        <span class="PauseMenu_label">${label}</span>
        <span class="PauseMenu_value">${value}</span>
      </div>
    `);
    const chip = (text, isEmpty = false) => `<span class="PauseMenu_chip ${isEmpty ? "PauseMenu_chip--empty" : ""}">${text}</span>`;
    const addons = pizza.addons || [];
    const hp = typeof pizza.hp === "number" && pizza.hp !== pizza.maxHp ? `${Math.max(0, pizza.hp)} / ${pizza.maxHp}` : pizza.maxHp;
    return (`
      <h2>${PlayerState.nameOf(pizza)}</h2>
      <p class="PauseMenu_tagline">${pizza.name ? `${base.name}. ` : ""}${base.description}</p>
      <div class="PauseMenu_stats">
        ${row("Životy", pizza.hp <= 0 ? "na kaši" : hp)}
        ${row("Typ", window.PizzaTypeNames?.[base.type] || base.type)}
        ${row("Útok", pizza.attack || 10)}
        ${row("Obrana", pizza.defense || 10)}
        ${row("Úroveň", pizza.level || 1)}
        ${row("Čerstvost", pizza.freshness ? `${pizza.freshness} %` : "z pece")}
      </div>
      <h3>Přísady</h3>
      <div class="PauseMenu_chips">
        ${[0, 1, 2].map(index => addons[index] ? chip(Actions[addons[index]].name) : chip("volné místo", true)).join("")}
      </div>
      <h3>Útoky</h3>
      <div class="PauseMenu_chips">
        ${PlayerState.actionsOf(pizza).map(key => chip(Actions[key].name)).join("")}
      </div>
      ${note ? `<p class="PauseMenu_note">${note}</p>` : ""}
    `)
  }

  //Short line for lists: level and freshness
  static getPizzaSummary(pizza) {
    return `úr. ${pizza.level || 1}` + (pizza.freshness ? `, ${pizza.freshness} %` : "");
  }

  //Lists longer than the screen: six entries per page, then "next page", then whatever leaves the list
  getPagedOptions(entries, lastOption, redraw) {
    const perPage = 6;
    if (entries.length <= perPage + 1) {
      return [...entries, lastOption];
    }
    const pageCount = Math.ceil(entries.length / perPage);
    this.listPage = Math.min(this.listPage, pageCount - 1);
    return [
      ...entries.slice(this.listPage * perPage, (this.listPage + 1) * perPage),
      {
        label: `Další strana (${this.listPage + 1}/${pageCount})`,
        description: "Ukáže další část seznamu",
        handler: () => {
          this.listPage = (this.listPage + 1) % pageCount;
          redraw();
        }
      },
      lastOption
    ];
  }

  setOptions(options, focusIndex = null) {
    this.keyboardMenu.setOptions(options, focusIndex);
  }

  showPanel(markup) {
    this.panelElement.innerHTML = markup;
  }

  createElement() {
    this.element = document.createElement("div");
    this.element.classList.add("PauseMenu"); //same layout and styles as the pause menu
    this.element.innerHTML = (`
      <div class="PauseMenu_side" data-page="sub">
        <h2>${this.title}</h2>
      </div>
      <div class="PauseMenu_panel"></div>
    `)
    this.sideElement = this.element.querySelector(".PauseMenu_side");
    this.panelElement = this.element.querySelector(".PauseMenu_panel");
  }

  close(result) {
    this.esc?.unbind();
    this.keyboardMenu.end();
    this.element.remove();
    this.onComplete(result);
  }

  //Menus built on this class implement showPage(pageKey) and start on "root"
  init(container) {
    this.createElement();
    this.keyboardMenu = new KeyboardMenu({
      descriptionContainer: this.element
    })
    this.keyboardMenu.init(this.sideElement);
    this.showPage("root");

    container.appendChild(this.element);

    this.esc = new KeyPressListener("Escape", () => {
      this.close();
    })
  }
}
