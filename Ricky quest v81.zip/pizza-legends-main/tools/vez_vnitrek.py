# Kreslí vnitřek Burger Tower, pět pater (mapy Tower1 až Tower5):
#   images/maps/Tower1Lower.png ... Tower5Lower.png, Tower1Upper.png ... Tower5Upper.png, TowerBattle.png
#   Content/towerFloors.js  (mřížky a místa pro OverWorldMap.js - NEUPRAVOVAT RUČNĚ, přepíše se)
#   tools/vez-vnitrek-nahled.png (všech pět pater pod sebou, jen na koukání)
# Spuštění z kořene projektu:  python3 tools/vez_vnitrek.py      (potřebuje Pillow; jde pouštět opakovaně)
#
# Od v63 je věž postavená jako věže v Pokémonech: každé patro je skoro čtvercová síň (16 x 12 dlaždic, sloupce 1-16,
# řádky 4-15, zadní zeď je řádek 3) rozdělená zdmi na chodby, kterými se musí projít od jedněch schodů ke druhým.
# Schody jsou průchody v zadní zdi v rozích patra (nakreslené jako schody v Neon Greens), nahoru vedou střídavě vpravo a vlevo a patra na sebe sedí:
# schody dolů jsou přesně nad schody nahoru z patra pod nimi. Rozmístění je v seznamu FLOORS jako text, jeden znak =
# jedna dlaždice:
#   # obvodová zeď   x zeď uvnitř patra   . podlaha   = koberec (dá se po něm chodit)
#   v zadní zdi:  U schody nahoru   D schody dolů   (pod nimi musí být volno, tam se z nich vychází)   W okno   F prapor gangu   E výtah (jedny dveře, mimo provoz; na všech patrech ve stejném sloupci,
#     aby šachta vedla rovně, a pod ním musí být volno; nad dveřmi je cedulka s číslem patra)
#   věci (nedá se přes ně):  P sloup   M hlavní sloup věže (2 x 2)   B socha burgeru   c bedny   p květina
#     R pult recepce   Q stůl Burger Queen   q její křeslo   g vitrína   S trezor
# Skript ohlídá, že se mezi schody (a východem) dá dojít.
#
# Lidi (od v67) jsou u každého patra v `trainers`: (x, y, kam kouká, na kolik dlaždic vidí, druhý směr nebo None). Kdo má
# druhý směr, střídavě se otáčí a dá se kolem něj proklouznout. Je jich pět na patro, v pořadí, v jakém se potkávají cestou
# nahoru; jejich obrázky (npc53 až npc72) kreslí tools/gang.py, jména a burgery jsou v Content/enemies.js (window.TowerCrew)
# a věty v OverWorldMap.js (TOWER_CREW_LINES), všude ve stejném pořadí. `people` jsou ostatní: recepční za pultem v přízemí,
# nahoře Burger Queen a její dva bodyguardi. Skript ohlídá, že nikdo nestojí ve zdi a že se i s nimi dá projít.
from PIL import Image
import os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P = os.path.join(ROOT, 'images', 'maps') + os.sep
T = 16
W, H = 18, 18


def c(h, a=255):
    return (int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16), a)


# ---------------------------------------------------------------- ROZVRŽENÍ: řádky 3 až 16 každého patra
FLOORS = [
    # vstupní hala: pult recepce vlevo nahoře, alej sloupů od dveří, schody v koutě vpravo
    dict(name='vstupní hala', floor='stone', sign='BURGER TOWER',
         trainers=[(5, 13, 'right', 5, None), (11, 11, 'up', 3, 'left'), (4, 8, 'right', 4, None), (9, 7, 'down', 3, None), (12, 7, 'right', 4, None)],
         people=dict(receptionist=(3, 5, 'down')), rows=[
        "##WWWF#E#####F##U#",
        "#p....R.......x..#",
        "#.....R.......x..#",
        "#RRRRRR.......x..#",
        "#................#",
        "#................#",
        "#...P........P...#",
        "#.......==.......#",
        "#.......==.......#",
        "#...P...==...P...#",
        "#.......==.......#",
        "#p.....B==B.....p#",
        "#.......==.......#",
        "########..########",
    ]),
    # sklad: cesta ve tvaru S, od schodů vpravo dolů do haly, vlevo zpátky nahoru a horní chodbou ke schodům
    dict(name='sklad', floor='slab',
         trainers=[(14, 7, 'right', 2, None), (10, 10, 'down', 5, 'left'), (1, 9, 'right', 2, 'down'), (6, 7, 'down', 1, None), (5, 4, 'down', 1, 'right')], rows=[
        "#U#WW##E##WW##F#D#",
        "#............x...#",
        "#............x...#",
        "#xxxxxxxx....x...#",
        "#..........c.x...#",
        "#............x...#",
        "#...xxxxxxxxxx...#",
        "#................#",
        "#................#",
        "#...P....P....P..#",
        "#................#",
        "#c..............c#",
        "#cc............cc#",
        "##################",
    ]),
    # chodby: tři dlouhé zdi, kolem kterých se jde střídavě dolů a nahoru
    dict(name='chodby', floor='slab',
         trainers=[(1, 8, 'right', 2, 'down'), (6, 13, 'down', 2, None), (7, 9, 'left', 2, 'up'), (9, 10, 'right', 2, None), (13, 6, 'right', 3, 'down')], rows=[
        "#DW####E#WWF##W#U#",
        "#...x.......x....#",
        "#...x.......x....#",
        "#...x...x...x....#",
        "#...x...x...x....#",
        "#...x...x...x..B.#",
        "#...x...x...x....#",
        "#...x...x...x....#",
        "#...x...x...x....#",
        "#...x...x...x....#",
        "#.......x........#",
        "#p......x.......c#",
        "#.....c.x......cc#",
        "##################",
    ]),
    # síň se sloupem: uprostřed komora s hlavním sloupem věže, obchází se dokola pravou a spodní chodbou
    dict(name='síň se sloupem', floor='slab',
         trainers=[(16, 7, 'left', 2, None), (11, 9, 'right', 3, None), (9, 13, 'down', 2, 'left'), (4, 12, 'right', 1, None), (1, 6, 'right', 1, 'down')], rows=[
        "#U###F#E##WW##W#D#",
        "#..xcc...x.......#",
        "#..x.....x.......#",
        "#..x..xxxxxxxx...#",
        "#.....x......x...#",
        "#.....x......x...#",
        "#.....x..MM......#",
        "#.....x..MM......#",
        "#.....x......x...#",
        "#..x..xxxxxxxx...#",
        "#..x.............#",
        "#..x....P..P.....#",
        "#p.x............p#",
        "##################",
    ]),
    # kancelář Burger Queen: od schodů úzkou chodbou dolů a pak po koberci mezi sochami až ke stolu
    dict(name='kancelář Burger Queen', floor='wood', trainers=[],
         people=dict(queen=(10, 6, 'down'), guardLeft=(9, 6, 'down'), guardRight=(11, 6, 'down')), rows=[
        "#D##W##E#WWW##WW##",
        "#..x.Sg...q..g...#",
        "#..x....QQQQQ....#",
        "#..x.....===.....#",
        "#..x..B..===..B..#",
        "#..x.....===.....#",
        "#..x.....===.....#",
        "#..x..B..===..B..#",
        "#..x.....===.....#",
        "#..x.....===.....#",
        "#..xxxxx.===.xxxx#",
        "#p.......===....p#",
        "#........===.....#",
        "##################",
    ]),
]
FIRST_PERSON = 53                      # npc53.png is the first of the twenty, see tools/gang.py (TOWER)
PEOPLE_SRC = dict(receptionist='npc73.png', guardLeft='npc74.png', guardRight='npc75.png', queen='npc76.png')
ROW0 = 3                               # the first row of the text is tile row 3
WALKABLE = '.=UD'
SPOTS = 'RWQgBScMFE'                   # things with a line of text (the texts are in OverWorldMap.js)
for spec in FLOORS:
    assert len(spec['rows']) == H - ROW0 - 1 and all(len(r) == W for r in spec['rows']), spec['name']

# ---------------------------------------------------------------- barvy
OUT = c('#4b2000')                     # outline of the room (the brown of the tower outside)
WALL_TOP, WALL_HI, WALL_FACE, WALL_BASE = c('#e6d5b4'), c('#f3e9d2'), c('#c4aa7c'), c('#8a6f47')
K = c('#222034')
NAVY = c('#1e2151')
METAL = {'k': K, 'L': c('#d4dbe3'), 'M': c('#a3afbd'), 's': c('#75808f')}
WOOD = dict(out=c('#5c3b1f'), top=c('#d9b27c'), hi=c('#e8c998'), face=c('#b3854c'), dk=c('#9a6f3c'))
DARKWOOD = dict(out=c('#3a1d10'), top=c('#8a5031'), hi=c('#a8683f'), face=c('#6b3a22'), dk=c('#4a2616'))
COUNTER = dict(out=OUT, top=c('#f3e9d2'), hi=c('#ffffff'), face=c('#c4aa7c'), dk=c('#a98f62'))
INNER = dict(out=OUT, top=WALL_TOP, hi=WALL_HI, face=WALL_FACE, dk=WALL_BASE)          # walls inside a floor: the same as the back wall
FLOORCOL = {
    'stone': (c('#dcd6ca'), c('#d0c9bc'), c('#c4bcad')),
    'slab': (c('#aab5c0'), c('#9fabb7'), c('#8c99a8')),
    'wood': (c('#c79f72'), c('#bd9468'), c('#a67d54')),
}
FONT = {
    'A': ["XXX", "X.X", "XXX", "X.X", "X.X"], 'R': ["XXX", "X.X", "XX.", "X.X", "X.X"], 'E': ["XXX", "X..", "XXX", "X..", "XXX"],
    'W': ["X.X", "X.X", "X.X", "XXX", "X.X"], 'B': ["XX.", "X.X", "XX.", "X.X", "XX."], 'U': ["X.X", "X.X", "X.X", "X.X", "XXX"],
    'G': ["XXX", "X..", "X.X", "X.X", "XXX"], 'T': ["XXX", ".X.", ".X.", ".X.", ".X."], 'O': ["XXX", "X.X", "X.X", "X.X", "XXX"],
    'F': ["XXX", "X..", "XX.", "X..", "X.."], ' ': ["...", "...", "...", "...", "..."],
    '1': [".X.", "XX.", ".X.", ".X.", "XXX"], '2': ["XXX", "..X", "XXX", "X..", "XXX"], '3': ["XXX", "..X", "XXX", "..X", "XXX"],
    '4': ["X.X", "X.X", "XXX", "..X", "..X"], '5': ["XXX", "X..", "XXX", "..X", "XXX"],
}
PIZZAS = os.path.join(ROOT, 'images', 'characters', 'pizzas') + os.sep


def sprite(rows, pal):
    im = Image.new('RGBA', (len(rows[0]), len(rows)), (0, 0, 0, 0))
    p = im.load()
    for y, row in enumerate(rows):
        assert len(row) == len(rows[0]), row
        for x, ch in enumerate(row):
            if ch != '.': p[x, y] = pal[ch]
    return im
def R(im, x0, y0, x1, y1, col):
    p = im.load()
    for y in range(max(0, y0), min(im.height - 1, y1) + 1):
        for x in range(max(0, x0), min(im.width - 1, x1) + 1): p[x, y] = col
def boxed(w, h, body, top=None, top_h=0, out=K):
    """A plain box with an outline; the top top_h rows in another colour (its top side)."""
    im = Image.new('RGBA', (w, h), out)
    R(im, 1, 1, w - 2, h - 2, body)
    if top: R(im, 1, 1, w - 2, top_h, top); R(im, 1, top_h + 1, w - 2, top_h + 1, out)
    return im

# ---------------------------------------------------------------- kusy nábytku (obrázky)
# the potted plant of the hero's house and the arcade (tools/domov.py, tools/herna.py): the leaves sit right on the pot.
# The first one here was a street bush put over a pot, with a gap between the two, so it looked like it was floating.
S_PLANT = Image.new('RGBA', (14, 17), (0, 0, 0, 0))
G1, G2, G3 = c('#58c463'), c('#31933f'), c('#17521f')
for r, (a, b) in enumerate([(5, 8), (3, 10), (2, 11), (1, 12), (1, 12), (2, 11), (1, 12), (2, 11), (3, 10), (5, 8)]):
    R(S_PLANT, a, r, b, r, G3)
    if b - a > 2: R(S_PLANT, a + 1, r, b - 1, r, G2)
for lx, ly in ((4, 2), (5, 3), (8, 1), (9, 2), (3, 5), (6, 6), (9, 5), (10, 6), (5, 8), (7, 4)):
    S_PLANT.putpixel((lx, ly), G1)
R(S_PLANT, 3, 10, 10, 11, K); R(S_PLANT, 4, 10, 9, 10, c('#e08a5a'))
R(S_PLANT, 4, 11, 9, 16, K); R(S_PLANT, 5, 11, 8, 15, c('#c9683f')); R(S_PLANT, 8, 11, 8, 15, c('#a04e2c'))

# a stone column: base, shaft, capital (taller than a person, its top goes over the tile behind it)
STONE = {'k': c('#4a4438'), 'L': c('#f3f0e8'), 'M': c('#d9d2c2'), 'D': c('#b9b09c'), 's': c('#9a917e')}
S_PILLAR = sprite(
    [".kkkkkkkkkkkk.", "kLLLLLLLLLLLLk", "kMMMMMMMMMMMDk", ".kkkkkkkkkkkk.", "..kLMMMMMMDk.."] +
    ["..kLMMMMMMDk.."] * 19 +
    ["..kLMMMMMMDk..", ".kkkkkkkkkkkk.", "kLMMMMMMMMMMDk", "kMMMMMMMMMMDsk", "kkkkkkkkkkkkkk"], STONE)
# a stack of crates with the crown of the gang stamped on
CR = {'k': c('#5c3b1f'), 'T': c('#e8c998'), 't': c('#d9b27c'), 'F': c('#b3854c'), 'f': c('#9a6f3c'), 'y': c('#8a5a10')}
S_CRATE = sprite([
    "..kkkkkkkkkkkk..", "..kTTTTTTTTTTk..", "..kttttttttttk..", "..kkkkkkkkkkkk..", "..kFFFFFFFFFFk..", "..kFyFyFFyFyFk..", "..kFyyyyyyyyFk..",
    "..kFFFFFFFFFFk..", "kkkkkkkkkkkkkkkk", "kTTTTTTTTTTTTTTk", "kttttttttttttttk", "kkkkkkkkkkkkkkkk", "kFFFFFFkkFFFFFFk", "kFfFFFFkkFFFFfFk",
    "kFFFFFFkkFFFFFFk", "kFFFFFFkkFFFFFFk", "kFfFFFFkkFFFFfFk", "kFFFFFFkkFFFFFFk", "kffffffkkffffffk", "kkkkkkkkkkkkkkkk"], CR)
# the banner of the gang for the back wall: a gold crown on dark red
BN = {'k': c('#3a1016'), 'r': c('#8a3b3b'), 'R': c('#a84f4f'), 'g': c('#ffd23f'), 'G': c('#e09a1c'), 'w': c('#5c3b1f')}
S_BANNER = sprite([
    "wwwwwwwwwwwwww", ".kkkkkkkkkkkk.", ".kRRRRRRRRRRk.", ".kRrrrrrrrrRk.", ".kRrrrrrrrrRk.", ".kRrgrggrgrRk.", ".kRrgggggggRk.", ".kRrgGGGGGgRk.",
    ".kRrrrrrrrrRk.", ".kRrrrrrrrrRk.", ".kRrrrrrrrrRk.", ".kRrrrrrrrrRk.", ".kRrrrrrrrrRk.", ".kRrrrrrrrrRk.", ".kRrrrrrrrrRk.", ".kRrrrrrrrrRk.",
    ".kRrrrrrrrrRk.", ".kkRrrrrrrRkk.", "..kkRrrrrRkk..", "...kkRrrRkk...", "....kkRRkk....", ".....kkkk....."], BN)
S_SAFE = boxed(16, 22, c('#4c5464'), c('#75808f'), 4)
R(S_SAFE, 2, 7, 13, 19, K); R(S_SAFE, 3, 8, 12, 18, c('#5a687a')); R(S_SAFE, 5, 10, 8, 13, K); R(S_SAFE, 6, 11, 7, 12, c('#ffd23f')); R(S_SAFE, 10, 10, 11, 15, c('#d4dbe3'))
S_CASE = boxed(16, 28, c('#cfeeff'), WOOD['top'], 3, WOOD['out'])
R(S_CASE, 1, 14, 14, 15, WOOD['face']); R(S_CASE, 1, 23, 14, 26, WOOD['face'])
for (x, y) in ((3, 7), (9, 7), (3, 17), (9, 17)):
    R(S_CASE, x, y, x + 3, y + 2, c('#ffd23f')); R(S_CASE, x + 1, y + 3, x + 2, y + 5, c('#e09a1c')); R(S_CASE, x, y + 6, x + 3, y + 6, c('#e09a1c'))
queen = Image.open(PIZZAS + 'b010.png').convert('RGBA')
queen = queen.crop(queen.getbbox())
S_STATUE = Image.new('RGBA', (queen.width, queen.height + 10), (0, 0, 0, 0))
S_STATUE.alpha_composite(boxed(16, 12, c('#cfc8bb'), c('#f3f0e8'), 4, c('#5a5448')), ((queen.width - 16) // 2, queen.height - 2))
S_STATUE.alpha_composite(queen, (0, 0))
THRONE = {'k': c('#3a1016'), 'r': c('#8a3b3b'), 'R': c('#a84f4f'), 'd': c('#6e2a2c'), 'g': c('#ffd23f'), 'G': c('#e09a1c')}
S_THRONE = sprite([
    "...g..gg..g...", "..kgkkggkkgk..", ".kgggggggggGk.", ".kGGGGGGGGGGk.", ".kRRRRRRRRRRk.", ".kRrrrrrrrrRk.", ".kRrrrrrrrrRk.", ".kRrrrrrrrrRk.",
    ".kRrrrrrrrrRk.", ".kRrrrrrrrrRk.", ".kRrrrrrrrrRk.", ".kRrrrrrrrrRk.", ".kRrrrrrrrrRk.", ".kRrrrrrrrrRk.", "kkkkkkkkkkkkkk", "kGkRRRRRRRRkGk",
    "kGkrrrrrrrrkGk", "kGkrrrrrrrrkGk", "kGkddddddddkGk", "kkkkkkkkkkkkkk", ".kd........dk.", ".kk........kk."], THRONE)
ARROW = sprite(["...kkkkkk...", "...kWWWWk...", "...kWWWWk...", "kkkkWWWWkkkk", "kWWWWWWWWWWk", ".kWWWWWWWWk.", "..kWWWWWWk..", "...kWWWWk...",
                "....kWWk....", ".....kk....."], {'k': c('#a39c8e'), 'W': c('#f4f1ea')})


# =====================================================================================================
def draw_floor(number, spec):
    rows = spec['rows']
    lower = Image.new('RGBA', (W * T, H * T), (0, 0, 0, 0))
    upper = Image.new('RGBA', (W * T, H * T), (0, 0, 0, 0))
    px = lower.load()
    at = lambda x, y: rows[y - ROW0][x] if 0 <= x < W and 0 <= y - ROW0 < len(rows) else '#'
    free = lambda x, y: at(x, y) in WALKABLE and y > ROW0
    cells = {(x, y): at(x, y) for y in range(ROW0, ROW0 + len(rows)) for x in range(W)}
    last = ROW0 + len(rows) - 1                                    # the row of the bottom edge (and of the way out, if any)
    def rect(x0, y0, x1, y1, col): R(lower, x0, y0, x1, y1, col)
    def blend(x, y, col, a):
        if not (0 <= x < W * T and 0 <= y < H * T): return
        r, g, b, al = px[x, y]
        if al: px[x, y] = (round(r * (1 - a) + col[0] * a), round(g * (1 - a) + col[1] * a), round(b * (1 - a) + col[2] * a), 255)
    def word(text, x, y, col, scale=1):
        for ch in text:
            for r, row in enumerate(FONT[ch]):
                for i, on in enumerate(row):
                    if on == 'X': rect(x + i * scale, y + r * scale, x + i * scale + scale - 1, y + r * scale + scale - 1, col)
            x += 4 * scale
    def commit(tmp, footprint):
        """Puts a drawn thing on the map: whatever of it lies over a tile the hero can stand on goes to the upper layer."""
        tp = tmp.load(); up = upper.load()
        box = tmp.getbbox()
        if not box: return
        for y in range(box[1], box[3]):
            for x in range(box[0], box[2]):
                if tp[x, y][3] == 0: continue
                tile = (x // T, y // T)
                if tile not in footprint and free(*tile): up[x, y] = tp[x, y]
                else: px[x, y] = tp[x, y]
    def stamp(sp, tx, ty, wide=1, dy=0):
        tmp = Image.new('RGBA', lower.size, (0, 0, 0, 0))
        x = tx * T + (wide * T - sp.width) // 2
        y = ty * T + T - sp.height + dy
        for i in range(x + 1, x + sp.width - 1): blend(i, ty * T + T - 1 + dy, K, 0.22)
        tmp.alpha_composite(sp, (x, y))
        commit(tmp, {(tx + i, ty) for i in range(wide)})

    # ---- floor
    A, B, seam = FLOORCOL[spec['floor']]
    for (tx, ty), ch in cells.items():
        if ty == ROW0 or ch == '#': continue
        for y in range(T):
            for x in range(T):
                gx, gy = tx * T + x, ty * T + y
                if spec['floor'] == 'wood':
                    board = gy // 8
                    col = seam if gy % 8 == 0 or (gx + board * 11) % 32 == 0 else (A, B)[board % 2]
                else:
                    col = seam if x == 0 or y == 0 else (A, B)[(tx + ty) % 2]
                px[gx, gy] = col
    # ---- walls: the top (two tiles), the face (one tile), the outline of the room
    x0, x1 = T, (W - 1) * T - 1
    rect(x0, T, x1, 3 * T - 1, WALL_TOP); rect(x0, 3 * T, x1, 4 * T - 1, WALL_FACE)
    rect(x0, 3 * T, x1, 3 * T, WALL_HI); rect(x0, 4 * T - 2, x1, 4 * T - 2, WALL_BASE); rect(x0, 4 * T - 1, x1, 4 * T - 1, OUT)
    rect(x0 - 1, T - 1, x1 + 1, T - 1, OUT)
    rect(x0 - 1, T - 1, x0 - 1, last * T + 2, OUT); rect(x1 + 1, T - 1, x1 + 1, last * T + 2, OUT)
    for x in range(x0, x1 + 1):                                    # shadow of the wall on the floor
        blend(x, 4 * T, K, 0.3); blend(x, 4 * T + 1, K, 0.15)
    exits = [x for x in range(W) if at(x, last) in WALKABLE]
    for x in range(x0, x1 + 1):                                    # bottom edge: a light line, a darker one, the outline
        if x // T in exits: continue
        px[x, last * T] = WALL_HI; px[x, last * T + 1] = WALL_BASE; px[x, last * T + 2] = OUT
    for tx in exits:
        lower.alpha_composite(ARROW, (tx * T + 2, last * T + 3))
        for x in range(tx * T, tx * T + T): px[x, last * T + T - 3] = WALL_HI; px[x, last * T + T - 2] = WALL_BASE; px[x, last * T + T - 1] = OUT
    if exits:
        for y in range(last * T, last * T + T): px[exits[0] * T - 1, y] = OUT; px[exits[-1] * T + T, y] = OUT

    # ---- things on the back wall
    def plate(gx, kind):                                           # a small navy plate with a white arrow, over the stairs
        rect(gx + 3, 2 * T + 2, gx + 12, 2 * T + 10, c('#f3f0e8')); rect(gx + 4, 2 * T + 3, gx + 11, 2 * T + 9, NAVY)
        head = 2 * T + (4 if kind == 'U' else 6)
        for i, wdt in enumerate((1, 2, 3) if kind == 'U' else (3, 2, 1)):
            rect(gx + 8 - wdt, head + i, gx + 7 + wdt, head + i, c('#ffffff'))
        shaft = 2 * T + (7 if kind == 'U' else 4)
        rect(gx + 7, shaft, gx + 8, shaft + 1, c('#ffffff'))
    for tx in range(W):
        ch = at(tx, ROW0)
        gx = tx * T
        if ch == 'W':                                              # a tall window over the town
            rect(gx + 1, 2 * T - 4, gx + 14, 4 * T - 4, K); rect(gx + 2, 2 * T - 3, gx + 13, 4 * T - 5, c('#f3f0e8'))
            for y in range(2 * T - 2, 4 * T - 5):
                for x in range(gx + 3, gx + 13): px[x, y] = (c('#c4f7ff'), c('#95f0ff'), c('#7ee7f7'), c('#6de1f4'))[((x + y) // 4) % 4]
            for x in range(gx + 3, gx + 13):                       # the town outside: houses close by on the ground floor, roofs far below from the top
                h = (3, 5, 4, 6, 3, 5, 7, 4, 3, 6)[((x + tx * 3) // (1 if number > 2 else 2)) % 10] + (5 - number) * 2
                rect(x, 4 * T - 5 - min(h, 2 * T - 2), x, 4 * T - 6, c('#8fb8c9'))
        elif ch == 'F':                                            # the banner of the gang
            lower.alpha_composite(S_BANNER, (gx + 1, T + 9))
        elif ch == 'E':                                            # the lift: one metal door, a display over it, out of order
            rect(gx - 1, 3 * T - 6, gx + 16, 4 * T - 1, K); rect(gx, 3 * T - 5, gx + 15, 3 * T, METAL['s'])
            rect(gx + 3, 3 * T - 4, gx + 12, 3 * T - 1, K)                                                                    # the display: red dashes, it is not moving
            rect(gx + 5, 3 * T - 3, gx + 6, 3 * T - 2, c('#c8443a')); rect(gx + 9, 3 * T - 3, gx + 10, 3 * T - 2, c('#c8443a'))
            rect(gx + 1, 3 * T + 1, gx + 14, 4 * T - 1, METAL['M']); rect(gx + 1, 3 * T + 1, gx + 2, 4 * T - 1, METAL['L']); rect(gx + 13, 3 * T + 1, gx + 14, 4 * T - 1, METAL['s'])
            rect(gx + 11, 3 * T + 7, gx + 11, 3 * T + 11, K)                                                                  # the handle
            rect(gx + 3, 3 * T + 3, gx + 9, 3 * T + 8, K); rect(gx + 4, 3 * T + 4, gx + 8, 3 * T + 7, c('#f7d95a'))           # the notice on the door
            rect(gx + 5, 3 * T + 5, gx + 7, 3 * T + 5, K)
            rect(gx + 18, 3 * T + 5, gx + 20, 3 * T + 9, K); px[gx + 19, 3 * T + 6] = c('#c8443a')                            # the call button next to it
            # the number of the floor over the door
            rect(gx + 2, T + 11, gx + 13, T + 21, c('#f3f0e8')); rect(gx + 3, T + 12, gx + 12, T + 20, NAVY)
            word('%dF' % number, gx + 4, T + 14, c('#ffffff'))
    if spec.get('sign'):                                           # the name of the house, over the middle of the hall
        text = spec['sign']; wdt = len(text) * 4 - 1
        gx = 9 * T + (4 * T - wdt) // 2
        rect(gx - 3, T + 9, gx + wdt + 2, T + 19, c('#f3f0e8')); rect(gx - 2, T + 10, gx + wdt + 1, T + 18, NAVY)
        word(text, gx, T + 12, c('#ffffff'))

    # ---- carpet
    carpet = {t for t, ch in cells.items() if ch == '='}
    for (tx, ty) in carpet:
        for y in range(T):
            for x in range(T):
                gx, gy = tx * T + x, ty * T + y
                edge = (x < 2 and (tx - 1, ty) not in carpet) or (x > 13 and (tx + 1, ty) not in carpet) or \
                       (y < 2 and (tx, ty - 1) not in carpet and at(tx, ty - 1) in WALKABLE)
                if number == 5: col = c('#b08f5c') if edge else (c('#8a3b3b') if (gx + gy) % 6 else c('#9a4848'))
                else: col = c('#8a6f47') if edge else (c('#b9a37c') if (gx + gy) % 6 else c('#c4aa7c'))
                px[gx, gy] = col

    # ---- stairs: openings in the back wall (the user wanted them in the wall, not under it), drawn like the stairs in Neon Greens (the tile at 9,5 of
    #      GreenKitchenLower.png): a dark frame on both sides and five steps between, each two rows of tread and one row of
    #      edge, light at the hero's end and sinking into the dark towards the wall. Both ways look the same, as in the rest
    #      of the game; the plate with an arrow over them says which way they go.
    FRAME = c('#3d2a1a')
    STEPS = [(c('#1f150c'), c('#32251a')), (c('#4f3d2b'), c('#4c3b29')), (c('#735a40'), c('#6e563d')), (c('#9c7f5c'), c('#927556')), (c('#c9ad85'), c('#b99c74'))]
    for (tx, ty), ch in cells.items():
        if ch not in 'UD': continue
        gx, gy = tx * T, ty * T
        plate(gx, ch)
        rect(gx, gy - 1, gx + 15, gy + T - 1, FRAME)
        for i, (tread, edge) in enumerate(STEPS):                  # the farthest step first
            y = gy + 1 + i * 3
            rect(gx + 2, y, gx + 13, y + 1, tread); rect(gx + 2, y + 2, gx + 13, y + 2, edge)

    # ---- things made of runs of tiles (walls inside the floor, the main pillar, counters, the desk)
    def run(letters, style, rise, face_h, joins_wall=False):
        tiles = {t for t, ch in cells.items() if ch in letters}
        if not tiles: return
        tmp = Image.new('RGBA', lower.size, (0, 0, 0, 0)); tp = tmp.load()
        for (tx, ty) in sorted(tiles, key=lambda t: (t[1], t[0])):
            n, s_, w_, e = (tx, ty - 1) in tiles, (tx, ty + 1) in tiles, (tx - 1, ty) in tiles, (tx + 1, ty) in tiles
            joined = joins_wall and ty == ROW0 + 1                 # grows out of the back wall: its top runs into the top of that wall
            gx, gy = tx * T, ty * T
            top = gy - (0 if n else (T if joined else rise)); bottom = gy + T - 1
            for y in range(top, bottom + 1):
                for x in range(gx, gx + T):
                    col = style['top']
                    if not s_ and y > bottom - face_h: col = style['face'] if y < bottom - 1 else style['dk']
                    if not s_ and y == bottom - face_h: col = style['out']
                    if (not n and not joined and y == top) or (not s_ and y == bottom) or (not w_ and x == gx) or (not e and x == gx + T - 1): col = style['out']
                    elif not n and not joined and y == top + 1: col = style['hi']
                    tp[x, y] = col
            if not s_:
                for x in range(gx, gx + T): blend(x, bottom + 1, K, 0.25)
                for x in range(gx, gx + T): blend(x, bottom + 2, K, 0.12)
        commit(tmp, tiles)
    run('x', INNER, 8, 14, joins_wall=True)
    run('M', DARKWOOD, 12, 16)
    run('R', COUNTER, 4, 8)
    run('Q', DARKWOOD, 4, 8)
    # the main pillar of the tower: gold bands and the crown of the gang on its face
    pillar = sorted(t for t, ch in cells.items() if ch == 'M')
    if pillar:
        gx, gy = pillar[0][0] * T, pillar[-1][1] * T                # left edge, the tile row of its face
        wdt = (pillar[-1][0] - pillar[0][0] + 1) * T
        tmp = Image.new('RGBA', lower.size, (0, 0, 0, 0))
        for y in (gy + 1, gy + 12):
            R(tmp, gx + 1, y, gx + wdt - 2, y + 1, c('#e09a1c')); R(tmp, gx + 1, y, gx + wdt - 2, y, c('#ffd23f'))
        crown = ["g.g.gg.g.g", "gggggggggg", "gGGGGGGGGg"]
        for r, row in enumerate(crown):
            for i, ch in enumerate(row):
                if ch != '.': R(tmp, gx + wdt // 2 - 5 + i, gy + 5 + r, gx + wdt // 2 - 5 + i, gy + 5 + r, c('#ffd23f') if ch == 'g' else c('#e09a1c'))
        commit(tmp, set(pillar))

    # ---- things standing on tiles, back to front
    for (tx, ty), ch in sorted(cells.items(), key=lambda kv: (kv[0][1], kv[0][0])):
        gx, gy = tx * T, ty * T
        if ty == ROW0: continue
        if ch == 'p': stamp(S_PLANT, tx, ty)
        elif ch == 'P': stamp(S_PILLAR, tx, ty, dy=-1)
        elif ch == 'c': stamp(S_CRATE, tx, ty, dy=-1)
        elif ch == 'S': stamp(S_SAFE, tx, ty)
        elif ch == 'g': stamp(S_CASE, tx, ty)
        elif ch == 'B': stamp(S_STATUE, tx, ty)
        elif ch == 'q': stamp(S_THRONE, tx, ty, dy=-3)
        elif ch == 'R' and at(tx, ty + 1) != 'R' and at(tx - 1, ty) == 'R' and at(tx + 1, ty) == 'R' and tx in (2, 4):   # a bell and a little sign on the reception desk
            if tx == 2:
                rect(gx + 4, gy + 1, gx + 9, gy + 4, K); rect(gx + 5, gy + 1, gx + 8, gy + 3, c('#ffd23f')); px[gx + 6, gy] = K; px[gx + 7, gy] = K
            else:
                rect(gx + 2, gy + 1, gx + 13, gy + 5, K); rect(gx + 3, gy + 2, gx + 12, gy + 4, c('#f3f0e8')); rect(gx + 4, gy + 3, gx + 11, gy + 3, METAL['M'])
        elif ch == 'Q' and at(tx - 2, ty) == 'Q' and at(tx + 2, ty) == 'Q':     # the middle of her desk: the name plate
            rect(gx + 1, gy + 2, gx + 14, gy + 6, c('#3a1d10')); rect(gx + 2, gy + 3, gx + 13, gy + 5, c('#ffd23f')); rect(gx + 4, gy + 4, gx + 11, gy + 4, c('#e09a1c'))
        elif ch == 'Q' and at(tx - 1, ty) != 'Q':                                # papers at its left end
            rect(gx + 5, gy + 1, gx + 11, gy + 6, c('#f3f0e8')); rect(gx + 6, gy + 3, gx + 10, gy + 3, METAL['M'])

    # ---- check: from the way out and from under every flight of stairs the others can be reached
    stairs = sorted(t for t, ch in cells.items() if ch in 'UD')
    for (x, y) in stairs:
        if y != ROW0 or not free(x, y + 1):
            print('patro %d: schody na %s musí být v zadní zdi a pod sebou mít volno' % (number, (x, y))); sys.exit(1)
    # the wall over every stairway goes to the upper layer too, so the head of somebody walking in goes behind it
    up_px = upper.load()
    for (x, y) in stairs:
        for yy in range(T - 1, y * T - 1):
            for xx in range(max(0, x * T - 8), min(W * T, x * T + T + 8)):
                if px[xx, yy][3]: up_px[xx, yy] = px[xx, yy]
    lift = [x for x in range(W) if at(x, ROW0) == 'E']
    doors = [(x, y + 1) for (x, y) in stairs] + [(x, ROW0 + 1) for x in lift] + [(x, last - 1) for x in exits[:1]]
    seen, todo = {doors[0]}, [doors[0]]
    while todo:
        x, y = todo.pop()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            n = (x + dx, y + dy)
            if n not in seen and free(*n): seen.add(n); todo.append(n)
    for d in doors:
        if not free(*d) or d not in seen: print('patro %d: ke schodům/východu na %s se nedá dojít' % (number, d)); sys.exit(1)
    # how far it is from the way in (the door, or the stairs from below) to the stairs up, just to print
    below = lambda kind: [(x, y + 1) for (x, y) in stairs if cells[(x, y)] == kind]
    way_in = [(x, last - 1) for x in exits[:1]] or below('D')
    steps, frontier = {way_in[0]: 0}, [way_in[0]]
    while frontier:
        x, y = frontier.pop(0)
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            n = (x + dx, y + dy)
            if n not in steps and free(*n): steps[n] = steps[(x, y)] + 1; frontier.append(n)
    walk = steps[below('U')[0]] if below('U') else 0

    # the people: nobody in a wall or right under the stairs, and with all of them standing there the way is still open
    standing = [(x, y) for (x, y, *_rest) in spec.get('trainers', [])] + [(x, y) for (x, y, _d) in spec.get('people', {}).values()]
    for t in standing:
        if not free(*t) or t in doors or standing.count(t) > 1:
            print('patro %d: na %s nemůže nikdo stát (zeď, schody, nebo už tam někdo je)' % (number, t)); sys.exit(1)
    open_, todo = {doors[0]}, [doors[0]]
    while todo:
        x, y = todo.pop()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            n = (x + dx, y + dy)
            if n not in open_ and free(*n) and n not in standing: open_.add(n); todo.append(n)
    for d in doors:
        if d not in open_: print('patro %d: lidi zastavěli cestu k %s' % (number, d)); sys.exit(1)

    lower.save(P + 'Tower%dLower.png' % number)
    upper.save(P + 'Tower%dUpper.png' % number)
    grid = []
    for y in range(H):
        line = ''
        for x in range(W):
            ch = at(x, y) if ROW0 <= y < ROW0 + len(rows) else '#'
            line += '.' if (ch in WALKABLE and y > ROW0) or (ch in 'UD' and y == ROW0) else '#'
        grid.append(line)
    info = dict(
        rows=grid,
        up=[t for t in stairs if cells[t] == 'U'],
        down=[t for t in stairs if cells[t] == 'D'],
        exit=[(x, last) for x in exits],
        spots=[(x, y, ch) for (x, y), ch in sorted(cells.items(), key=lambda kv: (kv[0][1], kv[0][0])) if ch in SPOTS],
        lift=lift,
        trainers=spec.get('trainers', []),
        people=spec.get('people', {}),
        free=len(seen),
        walk=walk,
    )
    # the preview shows the people too, and what each of them watches (their second direction lighter)
    both = lower.copy()
    def person(src, x, y, direction):
        sheet = Image.open(os.path.join(ROOT, 'images', 'characters', 'people', src)).convert('RGBA')
        row = {'down': 0, 'right': 1, 'up': 2, 'left': 3}[direction]
        both.alpha_composite(sheet.crop((0, row * 32, 32, row * 32 + 32)), (x * T - 8, y * T - 18))
    tint = Image.new('RGBA', both.size, (0, 0, 0, 0))
    step = {'down': (0, 1), 'up': (0, -1), 'left': (-1, 0), 'right': (1, 0)}
    for (x, y, direction, sight, also) in spec.get('trainers', []):
        for way, alpha in ((direction, 110), (also, 55)):
            if not way: continue
            cx, cy = x, y
            for _ in range(sight):
                cx, cy = cx + step[way][0], cy + step[way][1]
                if not free(cx, cy) or (cx, cy) in standing: break
                R(tint, cx * T + 2, cy * T + 2, cx * T + 13, cy * T + 13, (200, 68, 58, alpha))
    both.alpha_composite(tint)
    for k, (x, y, direction, sight, also) in enumerate(spec.get('trainers', [])):
        person('npc%d.png' % (FIRST_PERSON + (number - 1) * 5 + k), x, y, direction)
    for who, (x, y, direction) in spec.get('people', {}).items():
        person(PEOPLE_SRC[who], x, y, direction)
    both.alpha_composite(upper)
    return info, both


if __name__ == '__main__':
    infos, pictures = [], []
    for n, spec in enumerate(FLOORS):
        info, both = draw_floor(n + 1, spec)
        infos.append(info); pictures.append(both)
    for n in range(len(infos) - 1):                                # the floors sit on top of each other
        if infos[n]['up'] != infos[n + 1]['down']:
            print('schody nahoru z patra %d nesedí pod schody dolů z patra %d' % (n + 1, n + 2)); sys.exit(1)
    if any(i['lift'] != infos[0]['lift'] for i in infos):
        print('výtah není na všech patrech ve stejných sloupcích:', [i['lift'] for i in infos]); sys.exit(1)
    # battle background: the sandy wall and the grey slabs of the floors
    bt = Image.new('RGBA', (176, 99), (0, 0, 0, 255)); bp = bt.load()
    A, B, seam = FLOORCOL['slab']
    for y in range(99):
        for x in range(176):
            if y < 14: col = WALL_TOP
            elif y == 14: col = WALL_HI
            elif y < 17: col = WALL_FACE if y < 16 else OUT
            else:
                gy = y - 17
                col = seam if x % 16 == 0 or gy % 16 == 0 else (A, B)[(x // 16 + gy // 16) % 2]
                if gy < 2: col = tuple(int(v * 0.8) for v in col[:3]) + (255,)
            bp[x, y] = col
    bt.save(P + 'TowerBattle.png')
    step = H * T - 8
    sheet = Image.new('RGBA', (W * T, len(pictures) * step), (34, 32, 52, 255))
    for n, pic in enumerate(pictures):
        sheet.alpha_composite(pic, (0, (len(pictures) - 1 - n) * step))          # the top floor at the top
    sheet.save(os.path.join(ROOT, 'tools', 'vez-vnitrek-nahled.png'))
    with open(os.path.join(ROOT, 'Content', 'towerFloors.js'), 'w', encoding='utf-8') as f:
        f.write('//Vnitřek Burger Tower (mapy Tower1 až Tower5): mřížky a místa, která vypisuje tools/vez_vnitrek.py spolu s obrázky.\n')
        f.write('//NEUPRAVOVAT RUČNĚ - rozmístění se mění v tools/vez_vnitrek.py, ten tenhle soubor přepíše.\n')
        f.write('//  up / down: schody v zadní zdi (vychází se z nich o dlaždici níž), exit: východ ven (jen přízemí), spots: [x, y, druh věci] s textem\n')
        f.write('//  lift: dveře výtahu, trainers: [x, y, kam kouká, dohled, druhý směr], people: recepční, Burger Queen a bodyguardi\n')
        f.write('window.TowerFloors = [\n')
        for spec, info in zip(FLOORS, infos):
            pairs = lambda items: ', '.join('[%d, %d]' % t for t in items)
            f.write('  { //%s\n' % spec['name'])
            f.write('    up: [%s],\n    down: [%s],\n    exit: [%s],\n' % (pairs(info['up']), pairs(info['down']), pairs(info['exit'])))
            f.write('    spots: [%s],\n' % ', '.join('[%d, %d, "%s"]' % s for s in info['spots']))
            f.write('    lift: [%s],\n' % ', '.join('[%d, %d]' % (x, ROW0) for x in info['lift']))
            f.write('    trainers: [%s],\n' % ', '.join('[%d, %d, "%s", %d, %s]' % (x, y, d, sight, '"%s"' % also if also else 'null') for (x, y, d, sight, also) in info['trainers']))
            f.write('    people: {%s},\n' % ', '.join('%s: [%d, %d, "%s"]' % (who, x, y, d) for who, (x, y, d) in info['people'].items()))
            f.write('    rows: [\n')
            for row in info['rows']: f.write('      "%s",\n' % row)
            f.write('    ]\n  },\n')
        f.write(']\n')
    print('images/maps/Tower1-5 Lower/Upper.png, TowerBattle.png, Content/towerFloors.js, tools/vez-vnitrek-nahled.png')
    print('volných dlaždic po patrech:', ', '.join(str(i['free']) for i in infos))
    print('kroků ke schodům nahoru (v přízemí od dveří, jinde od schodů zdola):', ', '.join(str(i['walk']) for i in infos))
