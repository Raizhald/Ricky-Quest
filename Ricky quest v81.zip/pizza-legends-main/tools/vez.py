# Kreslí náměstíčko pod Burger Tower (mapa TowerSquare), kam se dojde ze Zadních uliček za zábranou:
#   images/maps/TowerSquareLower.png, TowerSquareUpper.png
#   Content/towerSquare.js  (mřížka a důležitá místa pro OverWorldMap.js - NEUPRAVOVAT RUČNĚ, přepíše se)
# Spuštění z kořene projektu:  python3 tools/vez.py      (potřebuje Pillow; jde pouštět opakovaně)
#
# Na náměstíčku jsou dva domy: vlevo malé železářství (cedule HARDWARE, stažená roleta) a vpravo vysoká Burger Tower
# (schválně klidná: pískové zdi, hnědé lemy, stejná okna, tmavomodrá cedule; barevný je jen hamburger nad nápisem). Dlažbu, keře a květináč si skript bere z images/maps/StreetLower.png, šipky u východu
# ze StreetNorthLower.png a hamburger na střechu z images/characters/pizzas/b001.png (tools/burgery.py).
from PIL import Image
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P = os.path.join(ROOT, 'images', 'maps') + os.sep
T = 16
W, H = 28, 24


def c(h, a=255):
    return (int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16), a)


K = c('#222034')
NAVY = c('#1e2151')
lower = Image.new('RGBA', (W * T, H * T), (0, 0, 0, 0))
upper = Image.new('RGBA', (W * T, H * T), (0, 0, 0, 0))
px = lower.load()
street = Image.open(P + 'StreetLower.png').convert('RGBA')
north = Image.open(P + 'StreetNorthLower.png').convert('RGBA')


def rect(x0, y0, x1, y1, col):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            if 0 <= x < W * T and 0 <= y < H * T: px[x, y] = col
def blend(x, y, col, a):
    r, g, b, al = px[x, y]
    if al: px[x, y] = (round(r * (1 - a) + col[0] * a), round(g * (1 - a) + col[1] * a), round(b * (1 - a) + col[2] * a), 255)
def art(rows, pal, x, y, target=None):
    p = target or px
    for j, row in enumerate(rows):
        assert len(row) == len(rows[0]), row
        for i, ch in enumerate(row):
            if ch != '.': p[x + i, y + j] = pal[ch]

# the lettering of the game's signs: 3 x 5 pixels, one pixel apart (as in tools/herna.py)
FONT = {
    'A': ["XXX", "X.X", "XXX", "X.X", "X.X"], 'R': ["XXX", "X.X", "XX.", "X.X", "X.X"], 'D': ["XX.", "X.X", "X.X", "X.X", "XX."],
    'E': ["XXX", "X..", "XXX", "X..", "XXX"], 'H': ["X.X", "X.X", "XXX", "X.X", "X.X"], 'W': ["X.X", "X.X", "X.X", "XXX", "X.X"],
    'B': ["XX.", "X.X", "XX.", "X.X", "XX."], 'U': ["X.X", "X.X", "X.X", "X.X", "XXX"], 'G': ["XXX", "X..", "X.X", "X.X", "XXX"],
    'T': ["XXX", ".X.", ".X.", ".X.", ".X."], 'O': ["XXX", "X.X", "X.X", "X.X", "XXX"], ' ': ["...", "...", "...", "...", "..."],
}
def word(text, x, y, rows, scale=1):
    for ch in text:
        for r, row in enumerate(FONT[ch]):
            for i, on in enumerate(row):
                if on == 'X': rect(x + i * scale, y + r * scale, x + i * scale + scale - 1, y + r * scale + scale - 1, rows[r])
        x += 4 * scale

# ---------------------------------------------------------------- layout (tiles)
FLOOR_ROWS = range(14, 22)            # the square itself, columns 1-26
EXIT = [(9, 22), (10, 22)]            # the way back south, into the back alleys
STORE = (3, 8)                        # hardware store: columns
TOWER = (13, 22)                      # Burger Tower: columns
SHUTTER = (5, 13)                     # the shop door with the shutter down
WINDOW = [(6, 13), (7, 13), (8, 13)]  # the shop window
TOWER_DOOR = [(17, 13), (18, 13)]
NPC = (5, 14)                         # the apprentice in front of the shop
COURIER = (7, 20)                     # Ráfek the courier, next to the way in from the back alleys
BIKE = (6, 20)                        # his bike (the object Bike, drawn by tools/kolo.py - not part of the map picture)
BIKE_STOP = (6, 21)                   # where the hero gets off after the ride from the main street
HEALER = (19, 14)                     # Micky, the cook who looks like the hero and heals, right next to the doors of the tower
props = {}                            # (x, y) -> kind, all of them walls
for (x, y) in ((3, 14),): props[(x, y)] = 'crate'
for (x, y) in ((15, 15), (20, 15), (11, 20), (25, 20)): props[(x, y)] = 'lamp'
PLANTERS = [(24, 15), (2, 17)]
for (x0, y0) in PLANTERS:
    for dy in range(3):
        for dx in range(2): props[(x0 + dx, y0 + dy)] = 'planter' if (dx, dy) == (0, 0) else '_'

# ---------------------------------------------------------------- pavement
PAVE = (c('#b5c1c3'), c('#a7b5b7')); SEAM = c('#98abae')
def floor_tile(tx, ty):
    for y in range(T):
        for x in range(T):
            px[tx * T + x, ty * T + y] = SEAM if x == 0 or y == 0 else PAVE[(tx + ty) % 2]
for ty in FLOOR_ROWS:
    for tx in range(1, 27): floor_tile(tx, ty)
rect(T, 22 * T, 27 * T - 1, 22 * T, SEAM)

# ---------------------------------------------------------------- the brick wall behind everything and the walls at the sides
CAP = (c('#5a4d68'), c('#3a3046'), c('#3a3046'), c('#1e2151'))
for y in range(12 * T, 14 * T):
    r = y - 12 * T
    for x in range(T, 27 * T):
        if r < 4: col = CAP[r]
        else:
            row, inrow = (r - 4) // 5, (r - 4) % 5
            bx = x + (5 if row % 2 else 0)
            if inrow == 4 or bx % 10 == 9: col = c('#52434f')
            elif inrow == 0: col = c('#8e7c88')
            else: col = c('#7d6b78') if ((bx // 10) * 7 + row * 3) % 5 in (1, 3) else c('#6c5b69')
        px[x, y] = col
for x0 in (T - 6, 27 * T):
    rect(x0, 12 * T, x0 + 5, 23 * T - 1, CAP[1]); rect(x0, 12 * T, x0, 23 * T - 1, CAP[0]); rect(x0 + 5, 12 * T, x0 + 5, 23 * T - 1, CAP[3])
for x in range(T, 27 * T):                                           # the wall's shadow on the pavement
    px[x, 14 * T] = c('#76838b'); px[x, 14 * T + 1] = c('#8a9299') if (x // T) % 2 == 0 else c('#808a91')

# ---------------------------------------------------------------- hedge along the south side, the way out with arrows
shrub = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
for yy in range(123, 135):
    for xx in range(208, 224):
        r, g, b, al = street.getpixel((xx, yy))
        if g > r + 20 and g > b + 20: shrub.putpixel((xx - 208, yy - 123), (r, g, b, 255))
bush = Image.new('RGBA', (16, 16), c('#804a40')); bp = bush.load()
for x in range(16):
    bp[x, 0] = c('#71362b'); bp[x, 14] = c('#663128'); bp[x, 15] = c('#71362b')
    for y in (3, 7, 11):
        if x % 4: bp[x, y] = c('#90574c')
bush.alpha_composite(shrub, (0, 3))
arrow = north.crop((7 * T, 16 * T, 8 * T, 17 * T))
for tx in range(1, 27):
    lower.paste(arrow if (tx, 22) in EXIT else bush, (tx * T, 22 * T))
rect(T - 6, 23 * T, 27 * T + 5, 23 * T + 1, c('#4c3a36'))
rect(EXIT[0][0] * T - 1, 22 * T, EXIT[0][0] * T - 1, 23 * T + 1, c('#4c3a36')); rect(EXIT[1][0] * T + T, 22 * T, EXIT[1][0] * T + T, 23 * T + 1, c('#4c3a36'))

# ---------------------------------------------------------------- the hardware store
sx0, sx1 = STORE[0] * T, STORE[1] * T + T - 1                        # 48..143
S_OUT, S_WALL, S_RIB, S_ROOF, S_HI, S_BASE = c('#1f3f4a'), c('#7fa8b8'), c('#6c97a8'), c('#a9cdd8'), c('#cfe6ec'), c('#557d8e')
rect(sx0, 150, sx1, 176, S_OUT); rect(sx0 + 1, 151, sx1 - 1, 175, S_ROOF); rect(sx0 + 1, 151, sx1 - 1, 151, S_HI)
for x in range(sx0 + 6, sx1 - 4, 9): rect(x, 153, x, 174, c('#98bfcc'))                      # sheet metal roof
rect(sx0, 176, sx1, 223, S_OUT); rect(sx0 + 1, 177, sx1 - 1, 222, S_WALL)
for y in range(180, 222, 4): rect(sx0 + 1, y, sx1 - 1, y, S_RIB)                           # corrugated wall
rect(sx0 + 1, 220, sx1 - 1, 222, S_BASE)
# sign
gx = sx0 + (96 - 35) // 2
rect(gx - 1, 179, gx + 35, 187, c('#f3f0e8')); rect(gx, 180, gx + 34, 186, NAVY)
word('HARDWARE', gx + 2, 181, [c('#ffffff'), c('#ffffff'), c('#fffee0'), c('#ffffff'), c('#e8e69c')])
# crossed hammer and wrench next to the sign
TOOLP = {'k': K, 'g': c('#a3afbd'), 'G': c('#d4dbe3'), 'w': c('#b3854c'), 'W': c('#d9b27c')}
art(["..kkkk...", ".kGGGGk..", ".kggggk..", "..kkWk...", "...kWk...", "...kwk...", "...kwk...", "...kkk..."], TOOLP, sx0 + 7, 179)
art(["..kk.kk..", ".kGk.kGk.", ".kGGkGGk.", "..kgggk..", "...kgk...", "...kgk...", "...kgk...", "...kkk..."], TOOLP, sx1 - 16, 179)
# the door with the shutter down, a little lamp above it
dx0 = SHUTTER[0] * T
rect(dx0, 193, dx0 + 15, 223, K); rect(dx0 + 1, 194, dx0 + 14, 222, c('#b5c1c3'))
for y in range(196, 222, 3): rect(dx0 + 1, y, dx0 + 14, y, c('#8a9aa0'))
rect(dx0 + 1, 220, dx0 + 14, 222, c('#76838b')); rect(dx0 + 6, 218, dx0 + 9, 219, K)
art([".kkkk.", "kMMMMk", ".kYYk.", ".kYWk.", "..kk.."], {'k': K, 'M': c('#a3afbd'), 'Y': c('#f7d95a'), 'W': c('#fff6c9')}, dx0 + 5, 188)
# the shop window with tools on show, a striped awning over it
wx0, wx1 = WINDOW[0][0] * T + 2, WINDOW[-1][0] * T + 10
rect(wx0, 196, wx1, 215, K); rect(wx0 + 1, 197, wx1 - 1, 214, c('#f3f0e8'))
for y in range(198, 214):
    for x in range(wx0 + 2, wx1 - 1):
        px[x, y] = (c('#c4f7ff'), c('#95f0ff'), c('#7ee7f7'), c('#6de1f4'))[((x + y) // 3) % 4]
SIL = {'k': c('#2c3870'), 'r': c('#c8443a')}
art(["kkkkk.", "kkkkk.", "..k...", "..k...", "..k...", "..k...", "..k...", "..k..."], SIL, wx0 + 4, 203)                    # hammer
art(["k...k", "kk.kk", ".kkk.", "..k..", "..k..", "..k..", "..k..", "..k.."], SIL, wx0 + 13, 203)                          # wrench
art(["kk....kk", ".kk..kk.", "..kkkk..", "...kk...", "..rkkr..", ".rr..rr.", ".rr..rr.", ".rr..rr."], SIL, wx0 + 21, 203)   # pliers
art(["kkkkkkkkk.", "kkkkkkkkkk", "k.k.k.k.kk", ".........k", "........kk"], SIL, wx0 + 31, 205)                              # saw
for x in range(wx0 - 2, wx1 + 3):
    stripe = c('#f08a2e') if ((x - wx0) // 4) % 2 == 0 else c('#f3f0e8')
    rect(x, 191, x, 194, stripe); px[x, 190] = K; px[x, 195] = c('#c9661c') if stripe[0] == 240 else c('#bdb7a6')
rect(wx0 - 3, 190, wx0 - 3, 195, K); rect(wx1 + 3, 190, wx1 + 3, 195, K)
# pipes leaning in the corner on the left
for i, x in enumerate((sx0 + 4, sx0 + 7, sx0 + 10)):
    rect(x, 196 + i * 2, x + 2, 221, K); rect(x + 1, 197 + i * 2, x + 1, 220, c('#d4dbe3') if i != 1 else c('#b8703a'))

# ---------------------------------------------------------------- Burger Tower
# Kept calm on purpose: one sandy colour with brown trim (the colours of the hero's house on the main street), the same
# glass in every window and a dark blue sign with white letters like the other signs in the game. The only colourful
# thing on it is the hamburger over the sign.
tx0, tx1 = TOWER[0] * T, TOWER[1] * T + T - 1                        # 208..367
T_OUT, T_WALL, T_PIL, T_PIL_HI, T_DARK = c('#4b2000'), c('#d9c096'), c('#cdb181'), c('#e6d2ae'), c('#b89660')
TRIM, TRIM_HI, TRIM_DK = c('#875837'), c('#9c775d'), c('#6e4526')
GLASS = (c('#c4f7ff'), c('#95f0ff'), c('#7ee7f7'), c('#6de1f4'))
CREAM = c('#f3f0e8')
rect(tx0, 40, tx1, 223, T_OUT); rect(tx0 + 1, 41, tx1 - 1, 222, T_WALL)
for a in (tx0 + 1, tx1 - 7):                                          # pilasters at both corners
    rect(a, 41, a + 6, 222, T_PIL); rect(a, 41, a, 222, T_PIL_HI); rect(a + 6, 41, a + 6, 222, T_DARK)
rect(tx0 - 2, 36, tx1 + 2, 47, T_OUT); rect(tx0 - 1, 37, tx1 + 1, 46, TRIM); rect(tx0 - 1, 37, tx1 + 1, 38, TRIM_HI); rect(tx0 - 1, 45, tx1 + 1, 46, TRIM_DK)
for j in range(9):                                                    # nine floors of windows
    for i in range(8):
        x, y = tx0 + 13 + i * 17, 53 + j * 13
        if 2 <= i <= 5 and j >= 6: continue                           # room for the emblem
        rect(x, y, x + 12, y + 8, NAVY)
        for yy in range(y + 1, y + 8):
            for xx in range(x + 1, x + 12): px[xx, yy] = GLASS[((xx + yy + i) // 3) % 4]
        rect(x + 6, y + 1, x + 6, y + 7, NAVY)
        rect(x, y + 9, x + 12, y + 9, T_DARK)
# the big sign: white letters on dark blue, like SHOP and ARCADE on the main street
rect(tx0 + 24, 169, tx1 - 24, 186, CREAM); rect(tx0 + 25, 170, tx1 - 25, 185, NAVY)
word('BURGER TOWER', tx0 + 34, 173, [c('#ffffff'), c('#ffffff'), c('#fffee0'), c('#ffffff'), c('#e8e69c')], scale=2)
# the entrance: dark glass double doors under a plain brown canopy, a big window on each side
ex0 = TOWER_DOOR[0][0] * T
rect(ex0 - 2, 192, ex0 + 33, 223, T_OUT); rect(ex0 - 1, 193, ex0 + 32, 222, TRIM); rect(ex0 - 1, 193, ex0 + 32, 193, TRIM_HI)
for a in (ex0 + 1, ex0 + 17):
    rect(a, 195, a + 13, 222, T_OUT)
    for y in range(196, 222):
        for x in range(a + 1, a + 13): px[x, y] = (c('#3b4a8a'), c('#2c3870'), c('#2c3870'), c('#1e2151'))[((x - y) // 4) % 4]
rect(ex0 + 12, 208, ex0 + 13, 212, CREAM); rect(ex0 + 18, 208, ex0 + 19, 212, CREAM)
rect(ex0 - 7, 186, ex0 + 38, 192, T_OUT); rect(ex0 - 6, 187, ex0 + 37, 191, TRIM); rect(ex0 - 6, 187, ex0 + 37, 187, TRIM_HI); rect(ex0 - 6, 191, ex0 + 37, 191, TRIM_DK)
for a in (tx0 + 14, tx1 - 49):
    rect(a, 196, a + 35, 216, NAVY); rect(a + 1, 197, a + 34, 215, CREAM)
    for y in range(198, 215):
        for x in range(a + 2, a + 34): px[x, y] = GLASS[((x + y) // 3) % 4]
    rect(a + 17, 198, a + 18, 214, NAVY); rect(a, 217, a + 35, 217, T_DARK)
rect(tx0 + 1, 220, tx1 - 1, 222, T_DARK); rect(ex0 + 1, 220, ex0 + 30, 222, T_OUT)
# the roof: a low parapet and a giant hamburger (too high up to be seen from the square)
burger = Image.open(os.path.join(ROOT, 'images', 'characters', 'pizzas', 'b001.png')).convert('RGBA')
burger = burger.crop(burger.getbbox())
rect(tx0 + 6, 30, tx1 - 6, 36, T_OUT); rect(tx0 + 7, 31, tx1 - 7, 35, TRIM_DK)
big = burger.resize((burger.width * 2, burger.height * 2), Image.NEAREST)
lower.alpha_composite(big, ((tx0 + tx1) // 2 - big.width // 2 + 1, 33 - big.height))
# the same hamburger as an emblem over the sign, on a plain light plate
mx = (tx0 + tx1) // 2
rect(mx - 22, 129, mx + 23, 167, T_OUT); rect(mx - 21, 130, mx + 22, 166, TRIM); rect(mx - 21, 130, mx + 22, 130, TRIM_HI)
rect(mx - 19, 132, mx + 20, 164, T_PIL_HI)
lower.alpha_composite(big, (mx - big.width // 2 + 1, 132 + (33 - big.height) // 2))
for x in range(tx0, tx1 + 1):                                          # shadows of both houses on the pavement
    px[x, 224] = c('#76838b'); px[x, 225] = c('#8a9299')
for x in range(sx0, sx1 + 1): px[x, 224] = c('#76838b'); px[x, 225] = c('#8a9299')

# ---------------------------------------------------------------- things on the square
def stamp(sp, x, y, ty):
    """What sticks out above the tile goes to the upper layer, so the hero can walk behind it."""
    cut = ty * T - y
    if cut > 0:
        upper.alpha_composite(sp.crop((0, 0, sp.width, cut)), (x, y)); lower.alpha_composite(sp.crop((0, cut, sp.width, sp.height)), (x, ty * T))
    else: lower.alpha_composite(sp, (x, y))
def sprite(rows, pal):
    im = Image.new('RGBA', (len(rows[0]), len(rows)), (0, 0, 0, 0)); art(rows, pal, 0, 0, im.load()); return im
METAL = {'k': K, 'L': c('#d4dbe3'), 'M': c('#a3afbd'), 's': c('#75808f'), 'Y': c('#f7d95a'), 'W': c('#fff6c9')}
LAMP = sprite(["...kkkkkkkk...", "..kMMMMMMMMk..", ".kkkkkkkkkkkk.", "..kYYYWWYYYk..", "..kYYWWWWYYk..", "..kYYWWWWYYk..", "...kYYWWYYk...",
               "....kkkkkk...."] + [".....kMsk....."] * 27 + ["....kkMskk....", "...kLMMMssk...", "...kLMMMssk...", "...kkkkkkkk..."], METAL)
WOOD = {'k': c('#5c3b1f'), 'T': c('#e8c998'), 't': c('#d9b27c'), 'F': c('#b3854c'), 'f': c('#9a6f3c'), 'p': c('#c9a068')}
CRATE = sprite(["kkkkkkkkkkkkkkkk", "kTTTTTTTTTTTTTTk", "kTttttTttttTtttk", "kTttttTttttTtttk", "kttttttttttttttk", "kkkkkkkkkkkkkkkk",
                "kppppppppppppppk", "kpkkkkkkkkkkkkpk", "kpkFFFFFFFFppkpk", "kpkFFFFFFFppFkpk", "kpkFFFFFFppFFkpk", "kpkFFFFFppFFFkpk",
                "kpkFFFFppFFFFkpk", "kpkFFFppFFFFFkpk", "kpkFFppFFFFFFkpk", "kpkFppFFFFFFFkpk", "kpkppFFFFFFFFkpk", "kpkkkkkkkkkkkkpk",
                "kffffffffffffffk", "kkkkkkkkkkkkkkkk"], WOOD)
planter = street.crop((256, 144, 288, 192))
for (tx, ty), kind in sorted(props.items(), key=lambda kv: (kv[0][1], kv[0][0])):
    x0, y0 = tx * T, ty * T
    if kind == 'planter':
        lower.paste(planter, (x0, y0))
        for x in range(x0, x0 + 32): blend(x, y0 + 48, K, 0.3); blend(x, y0 + 49, K, 0.18)
    elif kind == 'lamp':
        for x in range(x0 + 4, x0 + 13): blend(x, y0 + 14, K, 0.25); blend(x, y0 + 15, K, 0.15)
        stamp(LAMP, x0 + 1, y0 + 15 - LAMP.height, ty)
    elif kind == 'crate':
        for x in range(x0 + 1, x0 + 16): blend(x, y0 + 15, K, 0.25)
        lower.alpha_composite(CRATE, (x0, y0 + 15 - CRATE.height))

lower.save(P + 'TowerSquareLower.png')
upper.save(P + 'TowerSquareUpper.png')

# ---------------------------------------------------------------- the same square with the hardware store open
# Once the Burger Queen is beaten the ironmonger is back (story flag TOWER_POWER_ON) and the map switches to these two
# pictures: the shutter is rolled up and the doorway is dark, so the hero can walk in. The rolled shutter and the bit of
# wall over the door are in the upper layer too, so the head of somebody walking in goes behind them.
open_lower, open_upper = lower.copy(), upper.copy()
op = open_lower.load()
def orect(x0, y0, x1, y1, col):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1): op[x, y] = col
orect(dx0, 193, dx0 + 15, 223, K)
for y in range(198, 223):                                            # the dark inside, a little lighter towards the floor
    shade = (c('#16242b'), c('#1d2f38'), c('#253b46'))[min(2, (y - 198) // 9)]
    orect(dx0 + 1, y, dx0 + 14, y, shade)
orect(dx0 + 1, 219, dx0 + 14, 222, c('#8b6a45')); orect(dx0 + 1, 219, dx0 + 14, 219, c('#b08a5c'))      # the wooden floor of the shop showing in the door
orect(dx0 + 1, 194, dx0 + 14, 197, c('#b5c1c3')); orect(dx0 + 1, 196, dx0 + 14, 196, c('#8a9aa0')); orect(dx0 + 1, 198, dx0 + 14, 198, K)   # the shutter rolled up
open_upper.alpha_composite(open_lower.crop((dx0 - 1, 186, dx0 + 17, 199)), (dx0 - 1, 186))
open_lower.save(P + 'TowerSquareOpenLower.png')
open_upper.save(P + 'TowerSquareOpenUpper.png')

# ---------------------------------------------------------------- the grid for the game
def grid_char(x, y):
    if (x, y) in EXIT or (x, y) in TOWER_DOOR: return '.'          # the doors of the tower are walked into
    if y in FLOOR_ROWS and 1 <= x <= 26 and (x, y) not in props: return '.'
    return '#'
with open(os.path.join(ROOT, 'Content', 'towerSquare.js'), 'w', encoding='utf-8') as f:
    f.write('//Náměstíčko pod Burger Tower (mapa TowerSquare): mřížka a místa, která vypisuje tools/vez.py spolu s obrázky mapy.\n')
    f.write('//NEUPRAVOVAT RUČNĚ - rozmístění se mění v tools/vez.py, ten tenhle soubor přepíše.   # zeď   . volno\n')
    f.write('window.TowerSquareGrid = {\n')
    f.write('  exit: [%s], //východ na jih, zpátky do zadních uliček\n' % ', '.join('[%d, %d]' % t for t in EXIT))
    f.write('  shutter: [%d, %d], //dveře železářství: roleta je stažená, dokud se železář nevrátí z věže; pak se jimi vchází\n' % SHUTTER)
    f.write('  shopWindow: [%s], //výloha železářství\n' % ', '.join('[%d, %d]' % t for t in WINDOW))
    f.write('  towerDoor: [%s], //dveře Burger Tower\n' % ', '.join('[%d, %d]' % t for t in TOWER_DOOR))
    f.write('  apprentice: [%d, %d], //kde stojí učeň ze železářství\n' % NPC)
    f.write('  courier: [%d, %d], //kde stojí kurýr Ráfek\n' % COURIER)
    f.write('  bike: [%d, %d], //jeho kolo\n' % BIKE)
    f.write('  bikeStop: [%d, %d], //kde hrdina sesedne, když přijede na kole z hlavní ulice\n' % BIKE_STOP)
    f.write('  healer: [%d, %d], //kde stojí Micky, který léčí (hned vedle dveří věže)\n' % HEALER)
    f.write('  rows: [\n')
    for y in range(H): f.write('    "%s",\n' % ''.join(grid_char(x, y) for x in range(W)))
    f.write('  ]\n}\n')
print('images/maps/TowerSquareLower.png, TowerSquareUpper.png, TowerSquareOpenLower.png, TowerSquareOpenUpper.png, Content/towerSquare.js')
