# Kreslí k rybáři ve stokách (Hobo, bezdomovec npc26 na horním břehu na dlaždici (15, 5), kouká dolů ke kanálu) prut s vlascem a plovákem a dvě krabice od pizzy:
#  - SewerUpper.png: prut z jeho ruky šikmo dolů nad kanál, vlasec a plovák ve vodě (kreslí se přes postavy)
#  - SewerLower.png: dvě krabice na dlaždici (14, 5), vedle něj (dlaždice je v OverWorldMap.js zeď)
# Spuštění z kořene projektu:  python3 tools/rybar.py      (potřebuje Pillow; jde pouštět opakovaně)
# Pouštět až PO tools/stoky.py (to obrázky stok kreslí celé znovu) a potom ještě tools/vychody.py (šipka u východu).
from PIL import Image
import os

P = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'images', 'maps') + os.sep
FISHER = (15, 5)        # kde stojí rybář (dlaždice)
BOXES = (14, 5)         # kde leží krabice (dlaždice)


def c(h, a=255):
    return (int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16), a)


# ---------------------------------------------------------------- horní vrstva: prut, vlasec, plovák
up = Image.new('RGBA', (352, 192), (0, 0, 0, 0))
u = up.load()

hand = (FISHER[0] * 16 + 13, FISHER[1] * 16 + 8)          # ruka rybáře vpravo od hráče (jeho levá)
tip = (hand[0] + 28, hand[1] + 14)                         # špička prutu těsně nad hladinou kanálu

ROD_BASE, ROD_MID, ROD_TIP = c('#3a2615'), c('#6b4a2b'), c('#a98355')
n = 28
for i in range(n + 1):
    x, y = hand[0] + i, hand[1] + i // 2                   # prut jde šikmo dolů doprava (sklon 1:2)
    col = ROD_BASE if i < 8 else (ROD_MID if i < 20 else ROD_TIP)
    u[x, y] = col
    if i < 10:                                              # rukojeť je silnější
        u[x, y + 1] = ROD_BASE
        u[x + 1, y] = ROD_BASE
u[tip[0] + 1, tip[1] + 1] = ROD_TIP

# vlasec ze špičky dolů do vody
LINE = c('#e6e6dc', 230)
for y in range(tip[1] + 2, 117):
    u[tip[0] + 1, y] = LINE
bx, by = tip[0] + 1, 117                                    # plovák: červený nahoře, bílý dole
for dx in (-1, 0, 1):
    u[bx + dx, by] = c('#d93a3a')
    u[bx + dx, by + 1] = c('#d93a3a')
u[bx, by - 1] = c('#d93a3a')
for dx in (-1, 0, 1):
    u[bx + dx, by + 2] = c('#f4f4f0')
# kolečka na hladině
RIPPLE = c('#a6d6b0', 200)
for dx in range(-6, 7):
    if abs(dx) >= 3:
        u[bx + dx, by + 4] = RIPPLE
for dx in range(-4, 5):
    if abs(dx) >= 2 and abs(dx) <= 4:
        u[bx + dx, by + 3] = RIPPLE
up.save(P + 'SewerUpper.png')

# ---------------------------------------------------------------- spodní vrstva: dvě krabice od pizzy
low = Image.open(P + 'SewerLower.png').convert('RGBA')
l = low.load()
X, Y = BOXES[0] * 16, BOXES[1] * 16
OUT, SIDE, TOP, TOP_HI, SHADE = c('#2e1f10'), c('#b27f43'), c('#d9aa6a'), c('#ecc88d'), c('#5a6662')


def rect(x0, y0, x1, y1, col):
    for yy in range(y0, y1 + 1):
        for xx in range(x0, x1 + 1):
            l[X + xx, Y + yy] = col


def box(x0, y0, w, h):
    """Plochá krabice: světlé víko nahoře, tmavší bok, obrys."""
    rect(x0, y0, x0 + w - 1, y0 + h - 1, OUT)
    rect(x0 + 1, y0 + 1, x0 + w - 2, y0 + 2, TOP)                 # víko
    rect(x0 + 1, y0 + 1, x0 + w - 2, y0 + 1, TOP_HI)
    rect(x0 + 1, y0 + 3, x0 + w - 2, y0 + h - 2, SIDE)            # bok
    l[X + x0 + w // 2, Y + y0 + 3] = c('#d93a3a')                 # červený pruh na boku
    l[X + x0 + w // 2 - 1, Y + y0 + 3] = c('#d93a3a')


rect(1, 14, 15, 15, SHADE)                                        # stín pod hromádkou
box(1, 9, 14, 5)                                                 # spodní krabice
box(2, 4, 12, 5)                                                  # horní krabice, o kousek užší
l[X + 5, Y + 6] = c('#a8793f')                                    # mastná skvrna na víku
l[X + 6, Y + 6] = c('#a8793f')
low.save(P + 'SewerLower.png')
print('hotovo: SewerUpper.png (prut, vlasec, plovák), SewerLower.png (krabice)')
