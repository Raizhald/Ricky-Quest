# Upravuje hrdinův domek na hlavní ulici (images/maps/StreetLower.png): bez srdce nad dveřmi a s velkými okny
# jako mají ostatní budovy (stříška, rámeček, světlé sklo). Spuštění z kořene projektu: python3 tools/baracek.py
# Jde pouštět opakovaně jen nad původním obrázkem ulice (kreslí přes celou plochu mezi zdí a dveřmi).
from PIL import Image
import os
P = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'images', 'maps') + os.sep
im = Image.open(P + 'StreetLower.png').convert('RGBA')
px = im.load()
WALL = (176, 156, 217, 255)
DARK = (30, 33, 81, 255)
LIGHT = (219, 203, 251, 255)
AWN = (201, 181, 240, 255)
AWN_SH = (132, 135, 208, 255)
GL = [(226, 249, 253, 255), (196, 247, 255, 255), (126, 231, 247, 255), (149, 240, 255, 255)]
def rect(x0, y0, x1, y1, col):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            px[x, y] = col

# heart sign over the door (x 371-382, y 98-105) and the old small windows with flower boxes (left of the door
# x 353-367, right x 386-398; the door awning at x 368-385 stays)
rect(371, 98, 382, 105, WALL)
rect(353, 99, 367, 126, WALL)
rect(386, 99, 398, 126, WALL)

def window(x, y, w=8, h=20):                       # glass w wide; awning on top, light frame, dark outline
    rect(x - 1, y, x + w, y + 4, DARK)             # awning
    rect(x, y + 1, x + w - 1, y + 3, AWN)
    rect(x, y + 1, x + w - 1, y + 1, LIGHT)
    rect(x, y + 3, x + w - 1, y + 3, AWN_SH)
    rect(x - 2, y + 4, x + w + 1, y + h - 1, DARK)  # frame
    rect(x - 1, y + 5, x + w, y + h - 2, LIGHT)
    rect(x, y + 6, x + w - 1, y + h - 3, DARK)
    for yy in range(y + 7, y + h - 3):             # glass, light diagonal bands like the arcade windows
        for xx in range(x + 1, x + w - 1):
            px[xx, yy] = GL[((xx - x) + (yy - y)) // 2 % 4 if (yy - y) % 4 < 3 else 1]
    rect(x - 1, y + h, x + w, y + h, AWN_SH)       # shadow under the sill
window(357, 100)
window(389, 100)

# west end of the main street: a guard stands at tile (4,11), the other three tiles of column 4 (rows 10, 12, 13) are
# bushes (see below). The old planter there is paved over first
# (tile (4,11) and (4,13) take the pavement of (5,10), tile (4,12) that of (4,10)).
im.paste(im.crop((80, 160, 96, 176)), (64, 176)); im.paste(im.crop((80, 160, 96, 176)), (64, 208))
im.paste(im.crop((64, 160, 80, 176)), (64, 192))
# one clean bush per tile: a brown bed in the colours of the hedge by the road with one whole shrub (taken from the
# bush pots beside the stairs, x 209-222, y 123-134) - no clipped hedge pieces
shrub = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
for yy in range(123, 135):
    for xx in range(208, 224):
        r, g, b, al = im.getpixel((xx, yy))
        if g > r + 20 and g > b + 20:
            shrub.putpixel((xx - 208, yy - 123), (r, g, b, 255))
bush = Image.new('RGBA', (16, 16), (0x80, 0x4a, 0x40, 255))
bp = bush.load()
for x in range(16):
    bp[x, 0] = (0x71, 0x36, 0x2b, 255); bp[x, 14] = (0x66, 0x31, 0x28, 255); bp[x, 15] = (0x71, 0x36, 0x2b, 255)
    for y in (3, 7, 11):
        bp[x, y] = (0x90, 0x57, 0x4c, 255) if x % 4 else bp[x, y]
bush.alpha_composite(shrub, (0, 3))
for y in (160, 192, 208):
    im.paste(bush, (64, y))

# the east end of the street had a "tooth": the hedge and the road stuck out 8 px beyond the dark wall (x 624-631).
# Below the wall (y 224 and down) everything right of x 631 is cut away, so the edge is one straight vertical line (the
# west edge, x 64, already is); the thin dark outline that used to end the road at x 639 now ends it at x 631.
edge = [im.getpixel((639, y)) for y in range(224, 320)]
for y in range(224, 320):
    for x in range(632, 640):
        px[x, y] = (0, 0, 0, 0)
    px[631, y] = edge[y - 224]

# west edge: the building has a 2 px dark outline at x 64-65, the bushes, pavement, hedge and road had none or only 1 px,
# so the edge looked uneven. Now one 2 px dark line runs straight from the building down to the end of the road.
for y in range(160, 304):
    px[64, y] = (0x22, 0x20, 0x34, 255); px[65, y] = (0x22, 0x20, 0x34, 255)

# the hero's house gets new colours (same shading, only hue / saturation / brightness change): the roof (x 352-399,
# y 48-96, above the wall line) turns brown, the walls below turn warm sand; navy door and frames and the blue glass stay
import colorsys
def recolor(y0, y1, hue, sat_mul, v_mul, min_v):
    for yy in range(y0, y1):
        for xx in range(352, 400):
            r, g, b, al = px[xx, yy]
            if al == 0:
                continue
            h, sat, v = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
            if sat < 0.05 or not 0.6 < h < 0.85 or v < min_v:   # keep greys, whites, blue glass and the dark navy
                continue
            r2, g2, b2 = colorsys.hsv_to_rgb(hue, min(1, sat * sat_mul), min(1, v * v_mul))
            px[xx, yy] = (round(r2 * 255), round(g2 * 255), round(b2 * 255), al)
recolor(48, 97, 0.07, 2.1, 0.62, 0.0)
recolor(97, 128, 0.105, 1.1, 1.0, 0.5)

im.save(P + 'StreetLower.png')
