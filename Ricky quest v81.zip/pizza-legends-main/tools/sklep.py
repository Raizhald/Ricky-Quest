# Kreslí sklep pod jídelnou: images/maps/CellarLower.png, CellarUpper.png, CellarBattle.png
# a druhou podobu po útěku monstra s probouranou zdí: CellarBrokenLower.png, CellarBrokenUpper.png.
# Spuštění z kořene projektu:  python3 tools/sklep.py      (potřebuje Pillow)
# Vlevo je sklad (sudy a krabice), vpravo za řadou krabic laboratoř: velká pec, pult, stůl a tabule.
# Sudy a krabice se rozmisťují dole voláním barrel(x, y) a crate(x, y) v dlaždicích;
# po změně je potřeba upravit i mřížku zdí mapy Cellar v OverWorldMap.js.
from PIL import Image
import math, os, random
P = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'images') + os.sep
TW, TH = 22, 11                      # tiles
W, H = TW * 16, TH * 16
X0, X1 = 16, W - 17                  # interior columns 16..335
def c(h, a=255): return (int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16), a)

EDGE_TOP = c('#2b2836'); EDGE = c('#211f2a'); LEDGE = c('#4a4757')
WALLTOP = c('#6d6979'); HL = c('#8a8698'); FACE = c('#575365'); MORTAR = c('#48445a'); BRICK_HI = c('#625e71'); BASE = c('#3a3747')
LINE = c('#4d4b58'); GRID = c('#6c6a78')
TILE = {1: c('#7f7d8c'), 0: c('#8b8998')}
SHADOW = {1: c('#5f5d6b'), 0: c('#676573')}
SPECK = {1: c('#777584'), 0: c('#838190')}
HOLE_X = 18                          # tile column of the hole the monster leaves in the back wall

def render(broken):
    im = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    px = im.load()
    def rect(x0, y0, x1, y1, col):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                px[x, y] = col
    def blend(x, y, col, a):
        r, g, b, _ = px[x, y]
        px[x, y] = (int(r * (1 - a) + col[0] * a), int(g * (1 - a) + col[1] * a), int(b * (1 - a) + col[2] * a), 255)
    def stamp(art, pal, x, y):
        for r, row in enumerate(art):
            for i, ch in enumerate(row):
                if ch == '.': continue
                col = pal[ch]
                if col[3] < 255: blend(x + i, y + r, col, col[3] / 255)
                else: px[x + i, y + r] = col

    # upper wall
    for x in range(X0, X1 + 1):
        px[x, 15] = EDGE_TOP
        for y in range(16, 48):
            px[x, y] = WALLTOP
    for y in range(16, 64):
        px[X0 - 1, y] = EDGE_TOP; px[X1 + 1, y] = EDGE_TOP

    # wall face: bricks 8x4 with staggered rows
    for x in range(X0, X1 + 1):
        px[x, 48] = HL
        for y in range(49, 63):
            row = (y - 49) // 4
            inrow = (y - 49) % 4
            off = 4 if row % 2 else 0
            if inrow == 3 or (x + off) % 8 == 0:
                px[x, y] = MORTAR
            elif inrow == 0:
                px[x, y] = BRICK_HI
            else:
                px[x, y] = FACE
        px[x, 63] = BASE

    # floor: tile rows 4..9
    random.seed(7)
    for x in range(X0, X1 + 1):
        for y in range(64, 160):
            tx, ty = x // 16, y // 16
            par = (tx + ty) % 2
            if y == 64: col = LINE
            elif x % 16 == 0 or y % 16 == 0: col = LINE if y == 65 else GRID
            elif y == 65: col = SHADOW[par]
            else: col = TILE[par]
            px[x, y] = col
    # a few worn specks on the stone
    for _ in range(130):
        x = random.randrange(X0 + 2, X1 - 1); y = random.randrange(68, 158)
        if x % 16 in (0, 1, 15) or y % 16 in (0, 1, 15): continue
        par = (x // 16 + y // 16) % 2
        px[x, y] = SPECK[par]; px[x + 1, y] = SPECK[par]
    for y in range(64, 160):
        px[X0 - 1, y] = EDGE; px[X1 + 1, y] = EDGE
    for x in range(X0 - 1, X1 + 2):
        px[x, 160] = EDGE; px[x, 161] = LEDGE if X0 <= x <= X1 else EDGE; px[x, 162] = EDGE

    # doorway with the stairs up: the one from the dining room, at tile (5, 3)
    dr = Image.open(P + 'maps/DiningRoomLower.png').convert('RGBA')
    door = dr.crop((111, 45, 130, 64)); dp = door.load()
    for y in range(14, 19): dp[0, y] = dp[0, 6]
    im.paste(door, (5 * 16 - 1, 45))
    px = im.load()

    # ------------------------------------------------------------ store room: barrels and pizza boxes
    BAR = {
        'k': c('#2a1a10'), 'b': c('#8a5a2b'), 'B': c('#a9743a'), 'd': c('#6b4320'), 'm': c('#44434f'), 'M': c('#6a6978'), 't': c('#b9844a'), 'T': c('#d19a5c'), 's': (0, 0, 0, 60),
    }
    BARREL = [
        "....kkkkkk....",
        "..kkTTTTTTkk..",
        ".kTTttttttTTk.",
        ".kttttttttttk.",
        ".kkttttttttkk.",
        ".kMkkkkkkkkmk.",
        "kBMBBbBbbbdmdk",
        "kBBBBbBbbbdddk",
        "kBBBBbBbbbdddk",
        "kMMMMMMmmmmmmk",
        "kBBBBbBbbbdddk",
        "kBBBBbBbbbdddk",
        "kBBBBbBbbbdddk",
        ".kMMMMMmmmmmk.",
        ".kBBBbBbbbddk.",
        ".kkBBbBbbbdkk.",
        "..skkkkkkkks..",
        "...ssssssss...",
    ]
    def barrel(tx, ty):            # stands on tile (tx, ty), sticks up over the tile above
        stamp(BARREL, BAR, tx * 16 + 1, ty * 16 - 3)
    box = Image.open(P + 'characters/box.png').convert('RGBA').crop((8, 11, 24, 32))
    def crate(tx, ty, dx=0, dy=0):
        im.alpha_composite(box, (tx * 16 + dx, ty * 16 - 6 + dy))

    for tx in (1, 2, 3): barrel(tx, 4)
    barrel(1, 5)
    for tx in (8, 9, 10): barrel(tx, 4)
    # a row of boxes divides the store room from the laboratory, the gap in it is tile (10, 7)
    crate(10, 5); crate(10, 6); crate(10, 8); crate(10, 9)
    crate(1, 9); crate(2, 9)
    px = im.load()

    # ------------------------------------------------------------ laboratory
    K = c('#1f1420')                                  # dark outline of the lab things
    # chalkboard above the barrels: somebody has been working out a pizza
    rect(138, 21, 171, 42, c('#3a2413')); rect(139, 22, 170, 41, c('#6b4320')); rect(141, 24, 168, 39, c('#2f4a3a'))
    rect(139, 41, 170, 41, c('#55330f'))
    CHALK = c('#dfe5d8')
    for a in range(0, 360, 12):                       # a circle with three cuts through it
        px[147 + round(5.4 * math.cos(math.radians(a))), 31 + round(5.4 * math.sin(math.radians(a)))] = CHALK
    for d in range(-4, 5):
        px[147 + d, 31] = CHALK
        if abs(d) < 4: px[147 + round(d * 0.5), 31 + round(d * 0.87)] = CHALK; px[147 - round(d * 0.5), 31 + round(d * 0.87)] = CHALK
    for x0, y0, x1, y1 in ((155, 29, 158, 29), (155, 32, 158, 32), (161, 27, 164, 27), (165, 28, 165, 30), (163, 31, 164, 31), (163, 32, 163, 33), (163, 35, 163, 35),
                           (160, 37, 166, 37), (143, 38, 150, 38)):
        rect(x0, y0, x1, y1, CHALK)
    rect(150, 40, 154, 40, c('#f0f0f0'))              # a piece of chalk on the ledge

    # the big oven: tiles 11..15 of row 4, its mouth in the middle of tile 13
    OC = 215.5                                        # centre line
    BR, BR_HI, BR_SH, BR_M = c('#a8563c'), c('#c9755a'), c('#7d3a2a'), c('#5a2a22')
    ST, ST_HI, ST_SH = c('#8a8698'), c('#b3afc2'), c('#5f5b6e')
    # flue
    rect(207, 16, 224, 27, K); rect(208, 16, 223, 26, c('#6a6978'))
    rect(208, 16, 211, 26, c('#8f8ea0')); rect(220, 16, 223, 26, c('#4c4b58'))
    rect(207, 20, 224, 21, K); rect(208, 20, 223, 20, c('#9fa0b4'))
    # dome of bricks
    for y in range(20, 54):
        for x in range(176, 256):
            dx, dy = (x - OC) / 38.5, (y - 53) / 31.0
            r = dx * dx + dy * dy
            if r > 1: continue
            if r > 0.93: px[x, y] = K; continue
            row = (y - 22) // 5
            if (y - 22) % 5 == 4 or (x + (4 if row % 2 else 0)) % 9 == 0: col = BR_M
            else:
                light = -(dx * 0.7 + dy * 0.7)
                col = BR_HI if light > 0.55 else (BR_SH if light < -0.2 else BR)
            px[x, y] = col
    # stone base under it
    rect(176, 53, 255, 78, K); rect(177, 54, 254, 77, ST)
    rect(177, 54, 254, 55, ST_HI); rect(177, 74, 254, 77, ST_SH)
    for x in range(177, 255, 13): rect(x, 56, x, 73, ST_SH)
    # the mouth: an arch of pale stones, dark inside, a fire burning at the bottom
    for y in range(34, 76):
        for x in range(190, 242):
            d = math.hypot(x - OC, y - 56) if y < 56 else abs(x - OC)
            if d <= 21.5:
                if d > 20.5 or (y == 75 and d > 17): px[x, y] = K
                elif d > 17.5:
                    ang = math.degrees(math.atan2(56 - y, x - OC)) if y < 56 else (y - 56) * 9
                    px[x, y] = c('#a6a2b6') if int(ang // 20) % 2 else c('#c9c5d8')
                    if y >= 56 and (y - 56) % 6 == 5: px[x, y] = ST_SH
                elif d > 16.5: px[x, y] = K
                else:
                    px[x, y] = c('#1a0b0b') if y < 52 else c('#3a0f0b')
    for x in range(199, 233):                         # flames
        h = 9 + 4 * math.sin(x * 0.9) + 3 * math.sin(x * 0.37 + 1)
        for y in range(56, 75):
            if abs(x - OC) > 16.5: continue
            up = 74 - y
            if up < h * 0.35: px[x, y] = c('#ffe06a')
            elif up < h * 0.65: px[x, y] = c('#ff9a2e')
            elif up < h: px[x, y] = c('#d8431c')
            elif up < h + 3: px[x, y] = c('#7a1c10')
    rect(199, 75, 232, 75, K)
    # warning sign above the mouth, a dial on the left, a valve on the right
    for r in range(7):
        rect(215 - r, 24 + r, 216 + r, 24 + r, c('#ffd23f'))
    rect(208, 31, 223, 31, K)
    for r in range(8):
        px[214 - r if r < 7 else 208, 23 + r] = K; px[217 + r if r < 7 else 223, 23 + r] = K
    rect(215, 26, 216, 28, K); rect(215, 30, 216, 30, K)
    for (gx, gy) in ((185, 64),):
        for y in range(gy - 5, gy + 6):
            for x in range(gx - 5, gx + 6):
                d = math.hypot(x - gx, y - gy)
                if d <= 5.3: px[x, y] = K if d > 4.3 else c('#f0f0f0')
        rect(gx, gy, gx + 3, gy, c('#e0303a')); px[gx + 2, gy - 1] = c('#e0303a'); px[gx, gy] = K
        for a in (200, 250, 290, 340): px[gx + round(3.4 * math.cos(math.radians(a))), gy + round(3.4 * math.sin(math.radians(a)))] = c('#8e97ad')
    rect(243, 56, 247, 62, K); rect(244, 56, 246, 61, c('#8f8ea0'))
    for y in range(60, 71):
        for x in range(240, 251):
            d = math.hypot(x - 245, y - 65)
            if d <= 5.3 and d > 2.6: px[x, y] = K if (d > 4.4 or d < 3.3) else c('#e0303a')
    rect(244, 64, 246, 66, K); px[245, 65] = c('#f29d87')
    # warm light on the floor in front of the mouth
    for y in range(79, 92):
        for x in range(196, 236):
            a = max(0, 1 - math.hypot((x - OC) / 20, (y - 78) / 13)) * 0.45
            if a > 0.02: blend(x, y, c('#ff9a2e'), a)
    # control desk next to the oven, tile (16, 4), wired to it
    DESK = [
        ".kkkkkkkkkkkkk.",
        "kHHHHHHHHHHHHHk",
        "kHrHyHgHHHkkHHk",
        "kLLLLLLLLLkGkLk",
        "kLwwwwLLLLkkkLk",
        "kLwggwLkLLLLLLk",
        "kLwwwwLkkLLLLLk",
        "kkkkkkkkkkkkkkk",
        "kDDDDDDDDDDDDDk",
        "kDdddDDDDDdddDk",
        "kDDDDDDDDDDDDDk",
        "kDdddDDDDDdddDk",
        "kDDDDDDDDDDDDDk",
        "kddddddddddddk.",
        ".kkkkkkkkkkkk..",
        "..sssssssssss..",
    ]
    stamp(DESK, {'k': K, 'H': c('#b3afc2'), 'L': c('#8f8ea0'), 'D': c('#6a6978'), 'd': c('#4c4b58'), 'r': c('#e0303a'), 'y': c('#ffd23f'),
                 'g': c('#3ef126'), 'G': c('#8ff3ff'), 'w': c('#1e2151'), 's': (0, 0, 0, 60)}, 256, 62)
    rect(252, 70, 256, 70, K); rect(252, 71, 256, 71, c('#44434f'))
    # table with flasks along the right wall, tiles (20, 6) and (20, 7)
    rect(321, 95, 335, 124, K); rect(322, 96, 334, 119, c('#a9743a')); rect(322, 96, 334, 96, c('#d19a5c')); rect(322, 120, 334, 123, c('#6b4320'))
    for y in range(125, 127): rect(322, y, 335, y, tuple(int(v * 0.78) for v in px[322, y][:3]) + (255,))
    FLASK = ["..kk..", "..kk..", ".kwwk.", "kwLLwk", "kLLLLk", ".kkkk."]
    stamp(FLASK, {'k': K, 'w': c('#e9fbff'), 'L': c('#3ef126')}, 324, 98)
    stamp(FLASK, {'k': K, 'w': c('#e9fbff'), 'L': c('#ab2be4')}, 328, 106)
    rect(323, 111, 327, 116, c('#f0f0f0')); rect(324, 112, 326, 112, c('#8e97ad')); rect(324, 114, 326, 114, c('#8e97ad'))
    rect(331, 99, 332, 103, K); px[331, 100] = c('#ffd23f'); px[332, 100] = c('#ffd23f'); px[331, 102] = c('#e0303a'); px[332, 102] = c('#e0303a')

    up = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    up.paste(im.crop((79, 15, 98, 49)), (79, 15))

    if broken:
        # -------------------------------------------------------- the monster went through the back wall here
        random.seed(11)
        cx = HOLE_X * 16 + 7.5
        def in_hole(x, y):
            if y > 63: return False
            dx, dy = (x - cx) / 20.5, (63 - y) / 26.0
            ang = math.atan2(dy, dx)
            return math.hypot(dx, dy) <= 1 + 0.10 * math.sin(ang * 7 + 1.3) + 0.06 * math.sin(ang * 13)
        hole = {(x, y) for y in range(20, 64) for x in range(int(cx) - 28, int(cx) + 30) if in_hole(x, y)}
        for (x, y) in hole:
            depth = (63 - y) / 26.0
            px[x, y] = c('#0d0c13') if depth > 0.35 else c('#14181d')
        for (x, y) in hole:                           # broken edge: a dark rim with chipped brick showing
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                n = (x + dx, y + dy)
                if n not in hole and n[1] <= 62 and X0 <= n[0] <= X1:
                    px[n] = EDGE if random.random() < 0.7 else BRICK_HI
        # cracks running off from it
        for (sx, sy, dirx) in ((cx - 21, 46, -1), (cx + 21, 44, 1), (cx - 15, 36, -1), (cx + 14, 34, 1)):
            x, y = int(sx), sy
            for step in range(9):
                if (x, y) not in hole and 17 <= y <= 62: px[x, y] = EDGE
                x += dirx; y += random.choice((-1, 0, 0, 1))
        # rubble on the floor in front of it (the middle tile stays clear enough to walk through)
        for _ in range(26):
            x = int(cx + random.choice((-1, 1)) * random.randrange(9, 24)); y = random.randrange(66, 80)
            w, h = random.choice(((4, 3), (3, 2), (5, 3), (2, 2)))
            rect(x, y, x + w, y + h, EDGE); rect(x, y, x + w - 1, y + h - 1, random.choice((FACE, BRICK_HI, MORTAR)))
            rect(x, y, x + w - 1, y, BRICK_HI)
        for _ in range(10):
            x = int(cx) + random.randrange(-8, 9); y = random.randrange(64, 78)
            px[x, y] = EDGE; px[x + 1, y] = MORTAR
        # what dripped off the monster on its way from the oven to the wall
        CHEESE, CHEESE_HI, SAUCE = c('#e2b051'), c('#f1c25a'), c('#e35969')
        def splat(x, y, col, hi):
            for dx, dy in ((0, 0), (1, 0), (2, 0), (0, 1), (1, 1), (2, 1), (3, 1), (1, 2), (2, 2), (-1, 1), (4, 0)):
                if 64 <= y + dy < 160: px[x + dx, y + dy] = col
            px[x + 1, y] = hi
        for (x, y, kind) in ((214, 94, 0), (224, 88, 1), (236, 91, 0), (249, 87, 0), (262, 92, 1), (275, 88, 0), (287, 84, 0), (296, 76, 1), (293, 68, 0)):
            splat(x, y, CHEESE if kind == 0 else SAUCE, CHEESE_HI if kind == 0 else c('#f58a96'))
        # everything of the wall above the hole also goes into the upper picture: the monster squeezes in under it
        for y in range(15, 48):
            for x in range(int(cx) - 30, int(cx) + 32):
                if (x, y) not in hole:
                    up.putpixel((x, y), px[x, y])
    return im, up

lower, upper = render(False)
lower.save(P + 'maps/CellarLower.png'); upper.save(P + 'maps/CellarUpper.png')
lower, upper = render(True)
lower.save(P + 'maps/CellarBrokenLower.png'); upper.save(P + 'maps/CellarBrokenUpper.png')

# battle background: the dining room one in cellar colours
bt = Image.open(P + 'maps/DiningRoomBattle.png').convert('RGBA')
bp = bt.load()
for y in range(bt.height):
    for x in range(bt.width):
        r, g, b, a = bp[x, y]
        l = (r * 0.4 + g * 0.4 + b * 0.2) * 0.72
        bp[x, y] = (int(l * 0.93), int(l * 0.9), int(min(255, l * 1.08)), a)
bt.save(P + 'maps/CellarBattle.png')
print('images/maps/CellarLower.png, CellarUpper.png, CellarBrokenLower.png, CellarBrokenUpper.png, CellarBattle.png')
