# Kreslí komoru za domem DEMO (mapa DemoBack): images/maps/DemoBackLower.png a DemoBackUpper.png.
# Je to malá místnost za průchodem v zadní zdi domu DEMO; v podlaze má padací dvířka se žebříkem do stok.
# Spuštění z kořene projektu:  python3 tools/komora.py      (potřebuje Pillow; jde pouštět opakovaně)
#
# Místnost se skládá ze sloupců a řádků obrázku images/maps/DemoLower.png (zeď, dlažba, police, východ se šipkou),
# takže vypadá stejně jako dům, ke kterému patří. Přikreslují se jen bedny a padací dvířka.
# Rozměr 7 x 10 dlaždic: chodí se po sloupcích 1-5 a řádcích 4-7, východ je (3, 8), dvířka do stok (5, 6).
# Po změně rozmístění je potřeba upravit i mřížku zdí mapy DemoBack v OverWorldMap.js.
from PIL import Image
import os
P = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'images', 'maps') + os.sep
T = 16
demo = Image.open(P + 'DemoLower.png').convert('RGBA')
W, H = 7, 10
HATCH = (5, 6)

im = Image.new('RGBA', (W * T, H * T), (0, 0, 0, 0))
# rows 0-7 (walls and four rows of floor): the left edge, the two columns with the shelf, plain columns, the right edge
for new, old in enumerate((0, 3, 4, 1, 2, 1, 11)):
    im.paste(demo.crop((old * T, 0, old * T + T, 8 * T)), (new * T, 0))
# rows 8-9 (the bottom edge with the way out in the middle): rows 10-11 of the DEMO house
for new, old in enumerate((0, 1, 4, 5, 6, 1, 11)):
    im.paste(demo.crop((old * T, 10 * T, old * T + T, 12 * T)), (new * T, 8 * T))
px = im.load()


def c(h):
    return (int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16), 255)


def art(rows, pal, x, y):
    for j, row in enumerate(rows):
        assert len(row) == len(rows[0]), row
        for i, ch in enumerate(row):
            if ch != '.': px[x + i, y + j] = pal[ch]


def shadow(x0, x1, y, a=0.25):
    for x in range(x0, x1 + 1):
        for k, s in ((0, a), (1, a * 0.6)):
            r, g, b, al = px[x, y + k]
            if al: px[x, y + k] = (round(r * (1 - s) + 34 * s), round(g * (1 - s) + 32 * s), round(b * (1 - s) + 52 * s), 255)


# wooden crates (the same ones as in the back alleys): two on top of each other at (5, 4), one at (4, 4)
WOOD = {'k': c('#5c3b1f'), 'T': c('#e8c998'), 't': c('#d9b27c'), 'F': c('#b3854c'), 'f': c('#9a6f3c'), 'p': c('#c9a068')}
CRATE = ["kkkkkkkkkkkkkkkk", "kTTTTTTTTTTTTTTk", "kTttttTttttTtttk", "kTttttTttttTtttk", "kttttttttttttttk", "kkkkkkkkkkkkkkkk",
         "kppppppppppppppk", "kpkkkkkkkkkkkkpk", "kpkFFFFFFFFppkpk", "kpkFFFFFFFppFkpk", "kpkFFFFFFppFFkpk", "kpkFFFFFppFFFkpk",
         "kpkFFFFppFFFFkpk", "kpkFFFppFFFFFkpk", "kpkFFppFFFFFFkpk", "kpkFppFFFFFFFkpk", "kpkppFFFFFFFFkpk", "kpkkkkkkkkkkkkpk",
         "kffffffffffffffk", "kkkkkkkkkkkkkkkk"]
shadow(4 * T + 1, 6 * T - 1, 5 * T - 1)
art(CRATE[:19], WOOD, 5 * T, 4 * T + 15 - 20 - 13)
art(CRATE, WOOD, 5 * T, 4 * T + 15 - 20)
art(CRATE, WOOD, 4 * T, 4 * T + 15 - 20)

# the trapdoor in the floor: its lid stands open behind the hole, the top of the ladder shows inside
HPAL = {'k': c('#5c3b1f'), 'W': c('#d9b27c'), 'w': c('#b3854c'), 'F': c('#c9a068'), 'D': c('#1c1016'), 'r': c('#a9b4b0'), 'h': c('#f7d95a')}
TRAP = ["kkkkkkkkkkkkkkkk", "kWWWWWWhhWWWWWWk", "kwwwwwwwwwwwwwwk", "kkkkkkkkkkkkkkkk", "kFkkkkkkkkkkkkFk", "kFkDDDDDDDDDDkFk",
        "kFkDDrDDDDrDDkFk", "kFkDDrrrrrrDDkFk", "kFkDDrDDDDrDDkFk", "kFkDDrrrrrrDDkFk", "kFkDDrDDDDrDDkFk", "kFkDDrrrrrrDDkFk",
        "kFkDDDDDDDDDDkFk", "kFkkkkkkkkkkkkFk", "kFFFFFFFFFFFFFFk", "kkkkkkkkkkkkkkkk"]
art(TRAP, HPAL, HATCH[0] * T, HATCH[1] * T)

im.save(P + 'DemoBackLower.png')
Image.new('RGBA', im.size, (0, 0, 0, 0)).save(P + 'DemoBackUpper.png')
print('images/maps/DemoBackLower.png, DemoBackUpper.png')
