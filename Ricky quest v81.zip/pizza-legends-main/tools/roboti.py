# Kreslí testovací roboty z herny: npc20 (SAM-1), npc21 (EMMA-2), npc22 (JACK-3).
# Spuštění z kořene projektu:  python3 tools/roboti.py      (potřebuje Pillow: pip install pillow)
#
# Roboti se kreslí stejně jako postavy v tools/postavy.py, aby k ostatním ve hře seděli: tělo a chůze jsou
# z plešatého kuchaře (npc2), jen přebarvené do oceli (kůže = kov, tričko = barva robota), a hlava se kreslí
# tady znak po znaku. Mřížka hlavy je 24 znaků široká, sloupec i znamená x = 4 + i, "top" je y prvního řádku.
# Hlava začíná na y = 16, oči jsou na y = 21 a 22, brada na y = 23. Pohled doleva je zrcadlo pohledu doprava.
# Znaky: o obrys, 1 2 3 4 kov od nejsvětlejšího, c brada, ostatní písmena jsou v "pal" každého robota.
# Nový robot = další slovník jako SAM a řádek v seznamu ROBOTS na konci souboru.
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import postavy

postavy.SKINS['steel'] = dict(o='#2b3148', s1='#f6f8fc', s2='#d8deea', s3='#bcc4d6', s4='#939cb4', c='#808aa3', e='#1e2151', p='#bcc4d6')
VISOR = '#1e2151'       # the dark blue of the game's signs and doorways
CHEST = dict(top=26, art=["...........Y............"])     # a small light in the middle of the chest

# ---------------------------------------------------------------- SAM-1: modrý, anténka s kuličkou, dvě hranaté oči
SAM = dict(
    skin='steel',
    pal=dict(B='#6fb4f5', b='#3f7fd0', V=VISOR, E='#8ff3ff', Y='#ffd23f'),
    shirt=('#6fb4f5', '#3f7fd0', '#1f4a8f', '#122c5c'),
    pants='#4a5270', sock='#939cb4',
    down=dict(top=13, art=[
        "...........o............",
        "..........oYo...........",
        "...........o............",
        ".........ooooo..........",
        "........o11222o.........",
        ".......o1222222o........",
        ".......oBBBBBBbo........",
        ".......oVVVVVVVo........",
        "......oBVEEVEEVBo.......",
        "......obVEEVEEVbo.......",
        ".......oocccccoo........",
    ]),
    right=dict(top=13, art=[
        "............o...........",
        "...........oYo..........",
        "............o...........",
        "..........ooooo.........",
        ".........o11222o........",
        "........o1222222o.......",
        "........oBBBBBBbo.......",
        "........o333VVVVo.......",
        ".......oBB33VEEVo.......",
        ".......obb33VEEVo.......",
        "........oocccccoo.......",
    ]),
    up=dict(top=13, art=[
        "...........o............",
        "..........oYo...........",
        "...........o............",
        ".........ooooo..........",
        "........o11222o.........",
        ".......o1222222o........",
        ".......oBBBBBBbo........",
        ".......o3333333o........",
        "......oB3444443Bo.......",
        "......ob3333333bo.......",
        ".......oocccccoo........",
    ]),
    body_down=CHEST,
)

# ---------------------------------------------------------------- EMMA-2: červená přilba se dvěma tykadly, žluté oči
EMMA = dict(
    skin='steel',
    pal=dict(R='#f58a9c', r='#e0506a', d='#a82c48', V=VISOR, E='#ffe45c', Y='#8ff3ff'),
    shirt=('#f0607a', '#c93c5a', '#7a1c34', '#4a0f1f'),
    pants='#4a5270', sock='#939cb4',
    down=dict(top=13, art=[
        "......o.........o.......",
        ".....oRo.......oRo......",
        "......oo.......oo.......",
        ".......o.ooooo.o........",
        "........oRRrrro.........",
        ".......oRRrrrrro........",
        ".......oRrrrrrdo........",
        ".......o2222222o........",
        "......od2VE2EV2do.......",
        "......od2VE2EV2do.......",
        ".......oocccccoo........",
    ]),
    right=dict(top=13, art=[
        ".........o..............",
        "........oRo.............",
        ".........oo.............",
        "..........ooooo.........",
        ".........oRRrrro........",
        "........oRRrrrrro.......",
        "........oRrrrrrdo.......",
        "........or222222o.......",
        ".......odd222VE2o.......",
        ".......odd222VE2o.......",
        "........oocccccoo.......",
    ]),
    up=dict(top=13, art=[
        "......o.........o.......",
        ".....oRo.......oRo......",
        "......oo.......oo.......",
        ".......o.ooooo.o........",
        "........oRRrrro.........",
        ".......oRRrrrrro........",
        ".......oRrrrrrdo........",
        ".......orrrrrrdo........",
        "......odrrrdrrddo.......",
        "......od3333333do.......",
        ".......oocccccoo........",
    ]),
    body_down=CHEST,
)

# ---------------------------------------------------------------- JACK-3: zelený, hranatá hlava se dvěma šrouby, jeden červený průzor
JACK = dict(
    skin='steel',
    pal=dict(N='#8fd676', n='#5fae4a', d='#35782f', V=VISOR, E='#ff4a3a', g='#5a6480', Y='#ffd23f'),
    shirt=('#62b04c', '#3f8a35', '#1f5220', '#123312'),
    pants='#4a5270', sock='#939cb4',
    down=dict(top=13, art=[
        ".......oo.....oo........",
        ".......o2o...o2o........",
        "......ooooooooooo.......",
        "......oNNNnnnnnno.......",
        "......oNnnnnnnnno.......",
        "......onnnnnnnndo.......",
        "......onnnnnnnndo.......",
        "......oVVVVVVVVVo.......",
        "......oVEEEEEEEVo.......",
        "......o3g3g3g3g3o.......",
        ".......ooooooooo........",
    ]),
    right=dict(top=13, art=[
        "..........oo............",
        "..........o2o...........",
        ".......oooooooooo.......",
        ".......oNNNnnnnno.......",
        ".......oNnnnnnnno.......",
        ".......onnnnnnndo.......",
        ".......onnnnnnndo.......",
        ".......onnnVVVVVo.......",
        ".......ondnVEEEEo.......",
        ".......o333g3g3go.......",
        "........oooooooo........",
    ]),
    up=dict(top=13, art=[
        ".......oo.....oo........",
        ".......o2o...o2o........",
        "......ooooooooooo.......",
        "......oNNNnnnnnno.......",
        "......oNnnnnnnnno.......",
        "......onnnnnnnndo.......",
        "......onnnnnnnndo.......",
        "......onndddddnno.......",
        "......onnnnnnnndo.......",
        "......o333333333o.......",
        ".......ooooooooo........",
    ]),
    body_down=CHEST,
)

ROBOTS = [('npc20', SAM), ('npc21', EMMA), ('npc22', JACK)]

if __name__ == '__main__':
    sheets = []
    for name, robot in ROBOTS:
        sh = postavy.build(robot)
        sh.save(postavy.SRC + name + '.png')
        sheets.append(sh)
        print('images/characters/people/%s.png' % name)
    # náhled všech robotů vedle sebe (zvětšený), do složky tools
    postavy.preview(sheets, os.path.join(postavy.ROOT, 'tools', 'roboti-nahled.png'), bg=(193, 227, 227, 255))
