# Kreslí zlaté (shiny) verze všech pizz: images/characters/pizzas/<id>-shiny.png a náhled tools/zlate-nahled.png.
# Postup: z každé pizzy se vezme jas jednotlivých pixelů, roztáhne se přes celou pizzu a obarví zlatou stupnicí
# (tmavý obrys zůstane tmavě hnědý, drobné ozdoby se pořád poznají podle jasu), nad pizzu přijdou dvě třpytky.
# Spuštění z kořene projektu:  python3 tools/zlate.py      (potřebuje Pillow; jde pouštět opakovaně)
# Po přidání nové pizzy přidej její id do IDS.
from PIL import Image, ImageDraw, ImageFont
import os

HERE = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(os.path.dirname(HERE), 'images', 'characters', 'pizzas') + os.sep
IDS = ['s001', 's002', 'v001', 'c001', 'v002', 'f002', 'f001', 'd001', 'm001',
       'u001', 'u002', 'u003', 'u004', 'u005',
       'b001', 'b002', 'b003', 'b004', 'b005', 'b006', 'b007', 'b008', 'b009', 'b010']
NAMES = {'s001': 'Samuraj Kráječ', 's002': 'Slaninová brigáda', 'v001': 'Říkej mi Kadeřávek', 'c001': 'Studená Havaj',
         'v002': 'Zvadlá Zahrádka', 'f002': 'Včerejší Funghi', 'f001': 'Portobello Expres',
         'd001': 'Špinavá Margherita', 'm001': 'Bahnitá Šunkovka',
         'u001': 'Toulavá Tuňáková', 'u002': 'Sprejerka', 'u003': 'Betonová Funghi', 'u004': 'Plevelná Rukola', 'u005': 'Noční Kebabová',
         'b001': 'Sýrák', 'b002': 'Dvojitej Drtič', 'b003': 'Pálivej Pepa', 'b004': 'Špekoun', 'b005': 'Zelenej Podrazák',
         'b006': 'Žampionovej Kápo', 'b007': 'Mražák', 'b008': 'Křupavá Slepice', 'b009': 'Malej Sígr', 'b010': 'Královna Bulka'}

# zlatá stupnice od nejtmavší po nejsvětlejší
RAMP = [(74, 44, 6), (140, 92, 12), (201, 146, 20), (240, 190, 40), (255, 222, 90), (255, 244, 170)]
OUTLINE = (58, 32, 4)
GLINT = (255, 252, 220)


def gold(lum):
    """lum 0..1 -> barva na zlaté stupnici (plynulý přechod mezi sousedními barvami)."""
    t = max(0.0, min(1.0, lum)) * (len(RAMP) - 1)
    i = min(int(t), len(RAMP) - 2)
    f = t - i
    return tuple(int(RAMP[i][k] * (1 - f) + RAMP[i + 1][k] * f) for k in range(3))


def sparkle(px, cx, cy, big=True):
    """Čtyřcípá třpytka: kříž z bílých pixelů, ve velké je střed zlatobílý."""
    arm = 2 if big else 1
    for d in range(1, arm + 1):
        for x, y in ((cx - d, cy), (cx + d, cy), (cx, cy - d), (cx, cy + d)):
            if 0 <= x < 32 and 0 <= y < 32 and px[x, y][3] == 0:
                px[x, y] = GLINT + (255 if d == 1 else 200,)
    px[cx, cy] = GLINT + (255,)


def depth(px, w, h, x, y):
    """Jak hluboko je pixel pod okrajem pizzy: 0 = obrys, 1 = kůrka, 2 = vnitřek."""
    for d in range(3):
        for dx in range(-1, 2):
            for dy in range(-1, 2):
                nx, ny = x + dx * (d + 1), y + dy * (d + 1)
                if not (0 <= nx < w and 0 <= ny < h) or px[nx, ny][3] == 0:
                    return d
    return 2


def shiny(src):
    im = Image.open(P + src + '.png').convert('RGBA')
    px = im.load()
    orig = im.copy().load()
    inner = []
    for y in range(im.height):
        for x in range(im.width):
            if orig[x, y][3] > 0 and depth(orig, im.width, im.height, x, y) == 2:
                r, g, b = orig[x, y][:3]
                inner.append(0.30 * r + 0.59 * g + 0.11 * b)
    inner.sort()
    lo, hi = inner[int(len(inner) * 0.04)], inner[int(len(inner) * 0.96)]      # krajní pixely nerozhodují o kontrastu
    for y in range(im.height):
        for x in range(im.width):
            r, g, b, a = orig[x, y]
            if a == 0:
                continue
            dep = depth(orig, im.width, im.height, x, y)
            lum = 0.30 * r + 0.59 * g + 0.11 * b
            if dep == 0 or lum < 45:                      # obrys a nejtmavší skvrny
                px[x, y] = OUTLINE + (a,)
                continue
            t = max(0.0, min(1.0, (lum - lo) / max(1, hi - lo)))
            if dep == 1:                                  # kůrka je tmavší, zlatá jako upečená
                px[x, y] = gold(0.22 + 0.30 * t) + (a,)
            else:
                px[x, y] = gold(0.30 + 0.70 * t ** 0.9) + (a,)
    # třpytky v horní volné části čtverce 32 x 32 (pizza je dole, od řádku 12)
    sparkle(px, 25, 7, True)
    sparkle(px, 6, 4, False)
    im.save(P + src + '-shiny.png')


for pid in IDS:
    shiny(pid)

# ---------------------------------------------------------------- náhled: obyčejná a zlatá verze vedle sebe
SCALE = 6
CELL_W, CELL_H = 32 * SCALE + 30, 32 * SCALE + 34
cols = 3
rows = (len(IDS) + cols - 1) // cols
sheet = Image.new('RGBA', (cols * (2 * CELL_W // 2 + CELL_W), rows * CELL_H), (74, 88, 82, 255))
d = ImageDraw.Draw(sheet)
FONT = None
for cand in ('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', '/usr/share/fonts/dejavu/DejaVuSans.ttf',
             '/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf', '/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf'):
    if os.path.exists(cand):
        FONT = ImageFont.truetype(cand, 15)
        break
for n, pid in enumerate(IDS):
    cx, cy = (n % cols) * (CELL_W * 2), (n // cols) * CELL_H
    for k, name in enumerate((pid, pid + '-shiny')):
        pic = Image.open(P + name + '.png').convert('RGBA').resize((32 * SCALE, 32 * SCALE), Image.NEAREST)
        sheet.alpha_composite(pic, (cx + k * CELL_W + 15, cy + 6))
    d.text((cx + 15, cy + 32 * SCALE + 12), NAMES[pid], fill=(240, 240, 230, 255), font=FONT)
sheet.convert('RGB').save(os.path.join(HERE, 'zlate-nahled.png'))
print('hotovo:', ', '.join(i + '-shiny.png' for i in IDS), '+ tools/zlate-nahled.png')
