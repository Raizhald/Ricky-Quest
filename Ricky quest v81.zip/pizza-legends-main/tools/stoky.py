# Kreslí stoky pod sklepem: images/maps/SewerLower.png, SewerUpper.png a SewerBattle.png.
# Spuštění z kořene projektu:  python3 tools/stoky.py      (potřebuje Pillow)
# Kreslí se stejně jako sklep (tools/sklep.py), jen do zelena: nahoře cihlová zeď, pod ní chodník, kanál s vodou
# přes celou šířku (řádky 6 a 7), přes něj lávka na sloupci BRIDGE, dole druhý chodník a díra do sklepa na sloupci ENTRY.
# Po změně rozmístění je potřeba upravit i mřížku zdí mapy Sewer v OverWorldMap.js.
from PIL import Image
import math, os, random
P = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'images') + os.sep
TW, TH = 22, 12
W, H = TW * 16, TH * 16
X0, X1 = 16, W - 17
ENTRY = 4                            # tile column of the hole back to the cellar (row 10)
BRIDGE = 11                          # tile column of the planks over the channel
GRATE = 18                           # left tile column of the barred tunnel in the back wall (two tiles wide)
LADDER = 14                          # tile column of the ladder up to the back alleys
LADDER2 = 1                          # tile column of the ladder up to the room behind the DEMO house
def c(h, a=255): return (int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16), a)

EDGE_TOP = c('#1c2422'); EDGE = c('#161d1b'); LEDGE = c('#3a4643')
WALLTOP = c('#4f5d5a'); HL = c('#6f807b'); FACE = c('#455450'); MORTAR = c('#37433f'); BRICK_HI = c('#536560'); BASE = c('#2b3532')
LINE = c('#3d4845'); GRID = c('#58645f')
TILE = {1: c('#6d7a76'), 0: c('#778581')}
SHADOW = {1: c('#515d59'), 0: c('#586561')}
SPECK = {1: c('#647470'), 0: c('#6f7f7b')}
WATER, WATER_HI, WATER_SH, FOAM = c('#3f7a5c'), c('#5fa27a'), c('#2e5f48'), c('#a6d6b0')
MOSS, MOSS_HI = c('#5a8546'), c('#7fae5c')
IRON, IRON_HI, IRON_SH = c('#7d8884'), c('#a9b4b0'), c('#4d5754')
K = c('#121816')

im = Image.new('RGBA', (W, H), (0, 0, 0, 0))
px = im.load()
random.seed(23)
def rect(x0, y0, x1, y1, col):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            px[x, y] = col
def blend(x, y, col, a):
    r, g, b, _ = px[x, y]
    px[x, y] = (int(r * (1 - a) + col[0] * a), int(g * (1 - a) + col[1] * a), int(b * (1 - a) + col[2] * a), 255)

# upper wall and the wall face of bricks
for x in range(X0, X1 + 1):
    px[x, 15] = EDGE_TOP
    for y in range(16, 48): px[x, y] = WALLTOP
    px[x, 48] = HL
    for y in range(49, 63):
        row, inrow = (y - 49) // 4, (y - 49) % 4
        off = 4 if row % 2 else 0
        px[x, y] = MORTAR if inrow == 3 or (x + off) % 8 == 0 else (BRICK_HI if inrow == 0 else FACE)
    px[x, 63] = BASE
for y in range(15, 64):
    px[X0 - 1, y] = EDGE_TOP; px[X1 + 1, y] = EDGE_TOP

# floor slabs, rows 4..9
for x in range(X0, X1 + 1):
    for y in range(64, 160):
        par = (x // 16 + y // 16) % 2
        if y == 64: col = LINE
        elif x % 16 == 0 or y % 16 == 0: col = LINE if y == 65 else GRID
        elif y == 65: col = SHADOW[par]
        else: col = TILE[par]
        px[x, y] = col
for _ in range(150):
    x = random.randrange(X0 + 2, X1 - 1); y = random.randrange(68, 158)
    if x % 16 in (0, 1, 15) or y % 16 in (0, 1, 15): continue
    par = (x // 16 + y // 16) % 2
    px[x, y] = SPECK[par]; px[x + 1, y] = SPECK[par]
for _ in range(9):                                   # puddles
    x0 = random.randrange(X0 + 6, X1 - 12); y0 = random.choice((random.randrange(70, 90), random.randrange(134, 154)))
    for dy, (a, b) in enumerate(((2, 6), (0, 8), (1, 9), (3, 7))):
        for x in range(x0 + a, x0 + b + 1): blend(x, y0 + dy, WATER_SH, 0.35)
    blend(x0 + 3, y0 + 1, FOAM, 0.4); blend(x0 + 4, y0 + 1, FOAM, 0.4)
for y in range(64, 160):
    px[X0 - 1, y] = EDGE; px[X1 + 1, y] = EDGE
for x in range(X0 - 1, X1 + 2):
    px[x, 160] = EDGE; px[x, 161] = LEDGE if X0 <= x <= X1 else EDGE; px[x, 162] = EDGE

# the channel, rows 6 and 7: far wall of it, water, the near lip
CH0 = 96
for x in range(X0, X1 + 1):
    px[x, CH0] = K
    for y in range(CH0 + 1, CH0 + 7):
        px[x, y] = MORTAR if (y - CH0) % 3 == 0 or (x + (y // 3) * 4) % 8 == 0 else BASE
    px[x, CH0 + 7] = K
    for y in range(CH0 + 8, CH0 + 29):
        px[x, y] = WATER_SH if y < CH0 + 11 else WATER
    px[x, CH0 + 29] = K
    px[x, CH0 + 30] = c('#93a39e'); px[x, CH0 + 31] = c('#7f8f8a')
for _ in range(120):                                 # ripples: short light dashes drifting right
    x = random.randrange(X0 + 1, X1 - 6); y = random.randrange(CH0 + 11, CH0 + 28)
    n = random.randrange(2, 6)
    for i in range(n): px[x + i, y] = WATER_HI
    if random.random() < 0.3: px[x + n, y] = FOAM
for _ in range(40):
    x = random.randrange(X0 + 1, X1 - 3); y = random.randrange(CH0 + 12, CH0 + 28)
    px[x, y] = WATER_SH; px[x + 1, y] = WATER_SH
for _ in range(34):                                  # moss on the far wall of the channel and on the brick wall
    x = random.randrange(X0 + 1, X1 - 4); y = CH0 + random.randrange(1, 6)
    for i in range(random.randrange(2, 5)): px[x + i, y] = MOSS
for _ in range(22):
    x0 = random.randrange(X0 + 2, X1 - 8); y0 = random.randrange(50, 61)
    for i in range(random.randrange(3, 8)):
        px[x0 + i, y0] = MOSS
        if random.random() < 0.5: px[x0 + i, y0 + 1] = MOSS
        if random.random() < 0.25: px[x0 + i, y0 - 1] = MOSS_HI

# planks over the channel
bx = BRIDGE * 16
rect(bx - 1, CH0 - 3, bx + 16, CH0 + 34, K)
for y in range(CH0 - 2, CH0 + 34):
    plank = (y - (CH0 - 2)) // 4
    for x in range(bx, bx + 16):
        if (y - (CH0 - 2)) % 4 == 3: px[x, y] = c('#3a2413')
        else: px[x, y] = (c('#a9743a') if plank % 2 else c('#96652f')) if (y - (CH0 - 2)) % 4 else c('#c08a4c')
    px[bx + 2, y] = c('#6b4320'); px[bx + 13, y] = c('#6b4320')
for y in range(CH0 + 8, CH0 + 29):                   # its shadow on the water
    for x in range(bx + 17, bx + 20): blend(x, y, K, 0.35)

# two drain pipes in the back wall with water running out of them, down the wall and along a gutter into the channel
def pipe(tx):
    cx, cy = tx * 16 + 7.5, 47.5
    for y in range(38, 58):
        for x in range(tx * 16 - 3, tx * 16 + 19):
            d = math.hypot(x - cx, y - cy)
            if d <= 8.6: px[x, y] = K if d > 7.6 else (IRON_HI if d > 6.2 and y < cy - 1 else (IRON if d > 5.2 else (K if d > 4.4 else c('#0c1211'))))
    for y in range(49, 96):
        for x in range(int(cx) - 1, int(cx) + 3):
            if y < 52 and math.hypot(x - cx, y - cy) > 4.4: continue
            px[x, y] = WATER_HI if x == int(cx) - 1 and y < 64 else (WATER if y < 64 else WATER_SH if x in (int(cx) - 1, int(cx) + 2) else WATER)
    for y in range(64, 96):
        px[int(cx) - 2, y] = K if y > 64 else px[int(cx) - 2, y]; px[int(cx) + 3, y] = LINE
        if y % 7 == 3: px[int(cx), y] = FOAM
    for x in range(int(cx) - 3, int(cx) + 5): px[x, 63] = FOAM if x % 2 else WATER_HI
pipe(3); pipe(8)

# two ladders up the back wall: LADDER ends under the iron manhole lid of the back alleys, LADDER2 (on the left)
# under the wooden trapdoor of the little room behind the DEMO house
def ladder(col, lid, lid_shade):
    lx = col * 16
    rect(lx + 1, 16, lx + 14, 26, K); rect(lx + 2, 16, lx + 13, 25, c('#0c1211'))
    rect(lx + 3, 17, lx + 12, 18, lid_shade); rect(lx + 3, 17, lx + 12, 17, lid)
    for y in range(22, 64):
        px[lx + 3, y] = IRON; px[lx + 4, y] = IRON_SH; px[lx + 11, y] = IRON; px[lx + 12, y] = IRON_SH
        if y % 6 == 2: rect(lx + 4, y, lx + 11, y, IRON_HI); rect(lx + 4, y + 1, lx + 11, y + 1, IRON_SH)
ladder(LADDER, IRON, IRON_SH)
ladder(LADDER2, c('#b3854c'), c('#5c3b1f'))

# the barred tunnel the monster squeezed into: an arch two tiles wide, its middle bars bent apart
gcx = GRATE * 16 + 15.5
for y in range(22, 64):
    for x in range(GRATE * 16 - 2, GRATE * 16 + 34):
        d = math.hypot(x - gcx, y - 44) if y < 44 else abs(x - gcx)
        if d <= 16.5:
            if d > 15.5: px[x, y] = K
            elif d > 12.5:
                ang = math.degrees(math.atan2(44 - y, x - gcx)) if y < 44 else (y - 44) * 9
                px[x, y] = c('#8b9a95') if int(ang // 22) % 2 else c('#a3b2ad')
            elif d > 11.5: px[x, y] = K
            else: px[x, y] = c('#0c1211') if y < 56 else c('#12201c')
def bar(x_at):
    """x_at(y) -> x of the bar on that row."""
    for y in range(29, 64):
        x = round(x_at(y))
        if abs(x - gcx) > 11.5 or (y < 44 and math.hypot(x - gcx, y - 44) > 11.5): continue
        px[x, y] = IRON_HI if y % 5 else IRON
        if abs(x + 1 - gcx) <= 11.5: px[x + 1, y] = IRON_SH
for off in (-9, -5, 5, 9): bar(lambda y, o=off: gcx + o)
for side in (-1, 1):                                 # the two in the middle bow outwards
    bar(lambda y, s=side: gcx + s * (1.5 + 3.2 * math.sin(max(0, min(1, (y - 30) / 33)) * math.pi)))
rect(int(gcx) - 11, 34, int(gcx) + 11, 34, IRON); rect(int(gcx) - 11, 35, int(gcx) + 11, 35, IRON_SH)
CHEESE, CHEESE_HI, SAUCE, SAUCE_HI = c('#e2b051'), c('#f1c25a'), c('#e35969'), c('#f58a96')
for (x, y0, n) in ((int(gcx) - 4, 40, 6), (int(gcx) + 4, 43, 9), (int(gcx) + 5, 50, 4)):     # cheese left hanging on the bars
    for i in range(n): px[x, y0 + i] = CHEESE_HI
    px[x, y0 + n] = CHEESE

# the way in from the cellar: a ragged gap in the lower edge, tile (ENTRY, 10)
ex = ENTRY * 16
for y in range(160, 176):
    for x in range(ex, ex + 16):
        par = (x // 16 + y // 16) % 2
        px[x, y] = SHADOW[par] if y < 164 else TILE[par]
    px[ex - 1, y] = EDGE; px[ex + 16, y] = EDGE
rect(ex - 1, 176, ex + 16, 176, EDGE); rect(ex, 177, ex + 15, 177, LEDGE); rect(ex - 1, 178, ex + 16, 178, EDGE)
for _ in range(14):                                  # bricks that fell in with the wall
    x = ex + random.choice((-1, 1)) * random.randrange(4, 22) + 6; y = random.randrange(148, 158)
    if ex + 2 <= x <= ex + 10: continue
    w, h = random.choice(((4, 3), (3, 2), (5, 3)))
    rect(x, y, x + w, y + h, EDGE); rect(x, y, x + w - 1, y + h - 1, random.choice((c('#575365'), c('#625e71'), c('#48445a')))); rect(x, y, x + w - 1, y, c('#8a8698'))
for (x, y) in ((ex + 1, 161), (ex + 12, 163), (ex + 3, 170), (ex + 13, 172)):
    rect(x, y, x + 2, y + 1, c('#575365')); px[x, y] = c('#8a8698')

# the monster's trail of cheese and sauce: from the gap, over the planks, to the bars
def splat(x, y, kind):
    col, hi = (CHEESE, CHEESE_HI) if kind == 0 else (SAUCE, SAUCE_HI)
    for dx, dy in ((0, 0), (1, 0), (2, 0), (0, 1), (1, 1), (2, 1), (3, 1), (1, 2), (2, 2), (-1, 1), (4, 0)):
        px[x + dx, y + dy] = col
    px[x + 1, y] = hi
for (x, y, kind) in ((70, 150, 0), (84, 143, 1), (101, 147, 0), (118, 139, 0), (137, 146, 1), (155, 140, 0), (170, 134, 0),
                     (182, 122, 1), (180, 106, 0), (184, 90, 0), (198, 82, 1), (215, 86, 0), (233, 78, 0), (251, 83, 1), (268, 76, 0), (285, 80, 0), (298, 70, 1), (302, 66, 0)):
    splat(x, y, kind)

im.save(P + 'maps/SewerLower.png')
Image.new('RGBA', (W, H), (0, 0, 0, 0)).save(P + 'maps/SewerUpper.png')

# battle background: the cellar one, greener and darker
bt = Image.open(P + 'maps/CellarBattle.png').convert('RGBA')
bp = bt.load()
for y in range(bt.height):
    for x in range(bt.width):
        r, g, b, a = bp[x, y]
        l = (r + g + b) / 3 * 0.9
        bp[x, y] = (int(l * 0.86), int(l * 1.0), int(l * 0.95), a)
bt.save(P + 'maps/SewerBattle.png')
print('images/maps/SewerLower.png, SewerUpper.png, SewerBattle.png')
