# Kreslí obrázky herních hodin: images/ui/clock-plate.png (destička) a images/ui/clock-sky.png
# (tři okénka 14x14 vedle sebe: den, soumrak/svítání, noc).
# Spuštění z kořene projektu:  python3 tools/hodiny.py      (potřebuje Pillow)
from PIL import Image
import os
P = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'images', 'ui') + os.sep
def c(h): return (int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16), 255)

# ---- plate, in the colours of the pizza plates of the HUD
W, H = 46, 14
plate = Image.new('RGBA', (W, H), (0, 0, 0, 0)); px = plate.load()
for y in range(H):
    for x in range(W):
        edge = x in (0, W - 1) or y in (0, H - 1)
        px[x, y] = c('#a48465') if edge else c('#ffe8d2')
for x in range(1, W - 1): px[x, 1] = c('#fff1e3')
for y in range(1, H - 1): px[1, y] = c('#fff1e3')
plate.save(P + 'clock-plate.png')

# ---- three little windows to the sky
PAL = {
    'k': '#3a160d',
    # day
    'a': '#6fc1f7', 'b': '#93d3fb', 'd': '#bfe6ff', 'Y': '#ffd23f', 'H': '#fff6b0', 'y': '#f2a91c', 'o': '#c9760f', 'w': '#ffffff', 'v': '#dceefb',
    # dusk and dawn
    '1': '#5b4a9a', '2': '#a2558f', '3': '#e8704a', '4': '#f7a04b', '5': '#ffd27a', 'S': '#fff0a0', 's': '#ffc23f', 'h': '#3b2a52',
    # night
    'n': '#151a45', 'N': '#232a63', 'm': '#f6f3cf', 'M': '#ffffff', 'g': '#c5c29a', '*': '#fff6b0', '+': '#8f97d6',
}
DAY = [
    "kkkkkkkkkkkkkk",
    "kaaaaaaaaaaaak",
    "kaaaaaoooaaaak",
    "kaaaaoHHYoaaak",
    "kbbboHHYYYobbk",
    "kbbboHYYYYobbk",
    "kbbboYYYYyobbk",
    "kbbbboYyyobbbk",
    "kdwwdddooodddk",
    "kwwwwwdddddddk",
    "kvwwwwwvddwwdk",
    "kdvvvvvdddvvvk",
    "kddddddddddddk",
    "kkkkkkkkkkkkkk",
]
DUSK = [
    "kkkkkkkkkkkkkk",
    "k111111111111k",
    "k111111111111k",
    "k222222222222k",
    "k222222222222k",
    "k333333333333k",
    "k3333ssss3333k",
    "k444sSSSSs444k",
    "k44sSSSSSSs44k",
    "k55sSSSSSSs55k",
    "khhhhhhhhhhhhk",
    "khhhhhhhhhhhhk",
    "khhhhhhhhhhhhk",
    "kkkkkkkkkkkkkk",
]
NIGHT = [
    "kkkkkkkkkkkkkk",
    "knnnnnnnnn*nnk",
    "kn*nnnmmmnnnnk",
    "knnnnmMmnnnnnk",
    "knnnmMmnnnn+nk",
    "knnnmmgnnnnnnk",
    "kn+nmmgnnnnnnk",
    "kNNNmmmgNNNNNk",
    "kNNNNmmmggNNNk",
    "kNNNNNmmmmNN*k",
    "kNN*NNNNNNNNNk",
    "kNNNNNNNN+NNNk",
    "kNNNNNNNNNNNNk",
    "kkkkkkkkkkkkkk",
]
sky = Image.new('RGBA', (42, 14), (0, 0, 0, 0)); sp = sky.load()
for n, art in enumerate((DAY, DUSK, NIGHT)):
    for y, row in enumerate(art):
        assert len(row) == 14, row
        for x, ch in enumerate(row):
            sp[n * 14 + x, y] = c(PAL[ch])
sky.save(P + 'clock-sky.png')
