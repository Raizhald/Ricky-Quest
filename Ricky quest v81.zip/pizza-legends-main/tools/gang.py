# Kreslí 20 členů gangu Burger Queen ze Zadních uliček: images/characters/people/npc28.png až npc47.png
# a náhled tools/gang-nahled.png. Od v67 taky lidi z Burger Tower (seznam TOWER: npc53 až npc72, po pěti na patro),
# recepční, dva bodyguardy, Burger Queen a železáře (npc73 až npc77 v seznamu OTHERS); náhled tools/vez-lide-nahled.png.
# Spuštění z kořene projektu:  python3 tools/gang.py      (potřebuje Pillow: pip install pillow)
#
# Kreslí se stejně jako postavy v tools/postavy.py (načítá si ho): tělo a chůze z plešatého kuchaře (npc2),
# přebarvené na bundu gangu, hlava znak po znaku. Aby jich šlo udělat hodně a každý byl jiný, skládá se hlava
# z dílů: účes (HAIR), něco na hlavě (HAT: papírová koruna, kšiltovka, čelenka) a doplňky (EXTRA: brýle, knír,
# vousy, šátek přes pusu, páska přes oko). Mřížka je 24 znaků široká, sloupec i znamená x = 4 + i.
# Nový člen = další řádek v seznamu GANG dole (pořadí = čísla npc28, npc29, ...).
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import postavy
from postavy import compose, BALD_DOWN, BALD_RIGHT, BALD_UP

# ---------------------------------------------------------------- účesy (celá hlava; H vlasy, h stín, k obrys vlasů)
F_DOWN = ["......o222222222o.......", "......o333333333o.......", "......o34e333e34o.......", "......o13e313e31o.......", ".......oocccccoo........"]   # y 19-23
F_RIGHT = [".......okH333333o.......", ".......o443333e3o.......", ".......o433313e31o......", "........oocccccoo......."]                             # y 20-23
BACK = ["......kHHhHHHhHHk.......", "......kHHHHHHHHHk.......", "......oHHHHHHHHHo.......", "......o3HHHHHHH3o.......", ".......oocccccoo........"]      # y 19-23

HAIR = {
    'short': dict(
        down=(15, ["........kkkkkkk.........", ".......kHHHHHHHk........", "......kHHhHHHhHHk.......", "......kHH22222HHk......."] + F_DOWN),
        right=(15, [".........kkkkkk.........", "........kHHHHHHk........", ".......kHHhHHHHHk.......", ".......kHHHHH222o.......", ".......kHHH222222o......"] + F_RIGHT),
        up=(15, ["........kkkkkkk.........", ".......kHHHHHHHk........", "......kHHhHHHhHHk.......", "......kHHHHHHHHHk......."] + BACK)),
    'spiky': dict(
        down=(14, [".......k.k.k.k.k........", "......kHkHkHkHkHk.......", "......kHHHHHHHHHk.......", "......kHHhHHHhHHk.......", "......kH2222222Hk......."] + F_DOWN),
        right=(14, ["........k.k.k.k.........", ".......kHkHkHkHk........", ".......kHHHHHHHHk.......", ".......kHHhHHHHHk.......", ".......kHHHH2222o.......",
                    ".......kHH2222222o......"] + F_RIGHT),
        up=(14, [".......k.k.k.k.k........", "......kHkHkHkHkHk.......", "......kHHHHHHHHHk.......", "......kHHhHHHhHHk.......", "......kHHHHHHHHHk......."] + BACK)),
    'quiff': dict(
        down=(13, [".........kkkkk..........", ".......kkHHHHHkk........", "......kHHHHhHHHHk.......", "......kHHhHHHHhHk.......", "......kHHHHHHHHHk.......",
                   "......kHH22222HHk......."] + F_DOWN),
        right=(13, ["..........kkkkkk........", "........kkHHHHHHk.......", ".......kHHHHhHHHHk......", ".......kHHhHHHHHHk......", ".......kHHHHHHHkk.......",
                    ".......kHHHH2222o.......", ".......kHH2222222o......"] + F_RIGHT),
        up=(13, [".........kkkkk..........", ".......kkHHHHHkk........", "......kHHHHhHHHHk.......", "......kHHhHHHHhHk.......", "......kHHHHHHHHHk.......",
                 "......kHHHHHHHHHk......."] + BACK)),
    'long': dict(
        down=(15, ["........kkkkkkk.........", ".......kHHHHHHHk........", "......kHHHhHHHHHk.......", ".....kHHH22222HHHk......", ".....kHH2222222HHk......",
                   ".....kHH3333333HHk......", ".....kHh4e333e4hHk......", ".....kHh3e313e3hHk......", ".....kHHoocccooHHk......", "......kHk.....kHk......."]),
        right=(15, [".........kkkkkk.........", "........kHHHHHHk........", ".......kHHhHHHHHk.......", "......kHHHHHH222o.......", "......kHHHH222222o......",
                    "......kHHHH333333o......", "......kHHhH3333e3o......", "......kHHhH3313e31o.....", "......kHHHHoccccoo......", ".......kHHk............."]),
        up=(15, ["........kkkkkkk.........", ".......kHHHHHHHk........", "......kHHhHHHhHHk.......", ".....kHHHHHHHHHHHk......", ".....kHHhHHHHHhHHk......",
                 ".....kHHHHHHHHHHHk......", ".....kHHHhHHHhHHHk......", ".....kHHHHHHHHHHHk......", ".....kHHHHHHHHHHHk......", "......kkHHHHHHHkk......."])),
    'pigtails': dict(
        down=(15, ["........kkkkkkk.........", ".......kHHHHHHHk........", "......kHHhHHHhHHk.......", "...kkkkHH22222HHkkkk....", "..kHHko222222222okHHk...",
                   "..kHhko333333333okhHk...", "...kk.o34e333e34o.kk....", "......o13e313e31o.......", ".......oocccccoo........"]),
        right=(15, [".........kkkkkk.........", "........kHHHHHHk........", ".......kHHhHHHHHk.......", "....kkkkHHHH2222o.......", "...kHHkHHH2222222o......",
                    "...kHhkokH333333o.......", "....kk.o443333e3o.......", ".......o433313e31o......", "........oocccccoo......."]),
        up=(15, ["........kkkkkkk.........", ".......kHHHHHHHk........", "......kHHhHHHhHHk.......", "...kkkkHHHHHHHHHkkkk....", "..kHHkkHHhHHHhHHkkHHk...",
                 "..kHhkkHHHHHHHHHkkhHk...", "...kk.oHHHHHHHHHo.kk....", "......o3HHHHHHH3o.......", ".......oocccccoo........"])),
    'mohawk': dict(
        down=(12, ["..........kkk...........", ".........kHHHk..........", ".........kHhHk..........", ".........kHHHk..........", ".........oHhHo..........",
                   "........o1HHH2o.........", ".......o12HhH22o........", ".......o4222222o........", ".......o3333333o........", "......o34e333e34o.......",
                   "......o13e313e31o.......", ".......oocccccoo........"]),
        right=(12, [".........kkkkkkk........", "........kHHhHHHHk.......", "........kHHHHhHHk.......", ".........kHHHHHk........", "..........oHhHo.........",
                    ".........o1HHH2o........", "........o1222222o.......", "........o4222222o.......", "........o3333333o.......", ".......o143333e3o.......",
                    ".......o433313e31o......", "........oocccccoo......."]),
        up=(12, ["..........kkk...........", ".........kHHHk..........", ".........kHhHk..........", ".........kHHHk..........", ".........oHhHo..........",
                 "........o1HHH2o.........", ".......o12HhH22o........", ".......o42HHH22o........", ".......o3333333o........", "......o343333334o.......",
                 "......o133333331o.......", ".......oocccccoo........"])),
    'bald': dict(down=(16, BALD_DOWN), right=(16, BALD_RIGHT), up=(16, BALD_UP)),
}
# round bumpy hair (the helper Don Brokolini's broccoli is made with), with the face put back over it
_afro = postavy.trim_tip(postavy.afro(11, 15.0, R=4.6, bump=2.1, top=7, rows=15))
HAIR['afro'] = dict(
    down=compose((16, BALD_DOWN), (7, _afro), (18, ["........kj222jk.........", ".......k2222222k........", ".......o3333333o........", "......o34e333e34o.......",
                                                    "......o13e313e31o.......", ".......oocccccoo........"])),
    right=compose((16, BALD_RIGHT), (7, _afro), (19, ["............j222o.......", "...........j3333o.......", "..........j333e3o.......", "..........j313e31o......",
                                                      "..........occcccoo......"])),
    up=compose((16, BALD_UP), (7, _afro), (23, [".......oocccccoo........"])),
)
for key in ('down', 'right', 'up'):
    HAIR['afro'][key] = (HAIR['afro'][key]['top'], HAIR['afro'][key]['art'])

# ---------------------------------------------------------------- na hlavě (K obrys; y Y zlato, G kamínek; A a B kšiltovka; R r šátek)
HAT = {
    'crown': dict(
        down=(12, [".......K.K.K.K.K........", "......KyKyKyKyKyK.......", "......KyyyyyyyyyK.......", "......KYyGyyyGyYK.......", "......KKKKKKKKKKK......."]),
        right=(12, ["........K.K.K.K.K.......", ".......KyKyKyKyKyK......", ".......KyyyyyyyyyK......", ".......KYyyyyGyyYK......", ".......KKKKKKKKKKK......"]),
        up=(12, [".......K.K.K.K.K........", "......KyKyKyKyKyK.......", "......KyyyyyyyyyK.......", "......KYyyyyyyyYK.......", "......KKKKKKKKKKK......."])),
    'cap': dict(
        down=(15, ["........KKKKKKK.........", ".......KAAAAAAAK........", "......KAAAayaAAAK.......", ".....KBBBBBBBBBBBK......"]),
        right=(15, [".........KKKKKK.........", "........KAAAAAAK........", ".......KAAAAAyAAK.......", ".......KBBBBBBBBBBBK...."]),
        up=(15, ["........KKKKKKK.........", ".......KAAAAAAAK........", "......KAAAAAAAAAK.......", "......KAAAaaaAAAK......."])),
    'band': dict(
        down=(17, ["......KRRRRRRRRRK.......", "......KRrRRRRRrRK......."]),
        right=(17, [".......KRRRRRRRRK.......", ".....KRKRrRRRRRRRo......", ".....KrK................"]),
        up=(17, ["......KRRRRRRRRRK.......", "......KRRRRKRRRRK.......", ".........KRKRK.........."])),
}
# ---------------------------------------------------------------- doplňky (X brýle a páska, M vousy, R r šátek přes pusu)
EXTRA = {
    'shades': dict(down=(21, ["......oXXXX3XXXXo.......", "......o1XX313XX1o......."]), right=(21, ["............XXXX........", ".............XX........."])),
    'patch': dict(down=(21, ["......o34e33XXX4o.......", "......o13e31XXX1o......."]), right=(21, [".............XX.........", ".............XX........."])),
    'stache': dict(down=(23, [".......ooMMcMMoo........"]), right=(23, ["........oocccMMMo......."])),
    'beard': dict(down=(22, ["......oM3e313e3Mo.......", ".......oMMMMMMMo........", "........oMMMMMo........."]),
                  right=(22, ["........MM..............", "........oMMMMMMMo.......", ".........oMMMMMo........"])),
    'mask': dict(down=(22, ["......oRRRRRRRRRo.......", ".......oRrRRRrRo........"]), right=(22, ["...........RRRRRRo......", "...........RRrRRo......."])),
}
CHAIN = dict(top=25, art=[".........Y...Y..........", "..........YYY..........."])       # a gold chain on the chest

JACKETS = {                            # the gang's bomber jackets: light, dark, outline, darkest
    'red': ('#e0503f', '#b5322c', '#6e1a1c', '#3d0c10'),
    'orange': ('#f08a2e', '#c9661c', '#7a3a10', '#40200a'),
    'purple': ('#9b5fd0', '#6f3aa4', '#3a1a66', '#200c3a'),
    'black': ('#4a4a5a', '#33333f', '#1c1c26', '#0c0c12'),
    'overalls': ('#4fb3a8', '#2f8a80', '#17524c', '#0b2e2a'),      # not the gang: work clothes
    'shirt': ('#f3f0e8', '#d4d0c4', '#8a8678', '#4a463f'),         # a white shirt
    'yellow': ('#f6d86a', '#d9a93a', '#8a5a10', '#4a3008'),        # a fast food uniform
    'jersey': ('#4f8fe0', '#3566b8', '#1a3470', '#0e1c40'),        # a courier's cycling jersey
    'worker': ('#7f93a8', '#5f7389', '#2c3f5a', '#162233'),        # a grey-blue work coat (the store room of Burger Tower)
    'blazer': ('#3b4a8a', '#2c3870', '#1a2148', '#0e1228'),        # a navy blazer (the reception)
    'suit': ('#3a3a46', '#26262f', '#101016', '#050508'),          # a black suit (bodyguards)
    'robe': ('#b5322c', '#8a2420', '#4c1210', '#2a0808'),          # the Queen's red coat
}
HAIRCOL = {                            # H, h, k (and j for the afro)
    'red': ('#d8402f', '#a82a22', '#4c1210'), 'blond': ('#f6d86a', '#d9a93a', '#6e4a10'), 'green': ('#7fc241', '#4f9a2e', '#1f4a16'),
    'black': ('#3a3a46', '#22222c', '#0e0e14'), 'brown': ('#8a5a35', '#693f22', '#2e1a0c'), 'orange': ('#f08a2e', '#c9661c', '#5a2a08'),
    'pink': ('#f27ab0', '#c94a88', '#5a1838'), 'white': ('#f4f0e6', '#c9c4b6', '#5a5648'), 'blue': ('#5fa8f0', '#3a78c9', '#14306a'),
    'grey': ('#a9a79d', '#8c8a82', '#4a463f'), 'purple': ('#b06fd8', '#7f43a8', '#32124a'),
}

def member(style, skin, hair, jacket, hat=None, hatcol='#9b5fd0', extras=(), chain=False, pants='#3a3a46'):
    H, h, k = HAIRCOL[hair]
    pal = dict(H=H, h=h, k=k, j=h, M=k if hair not in ('white', 'grey', 'blond') else h, X='#101018',
               y='#ffd23f', Y='#e09a1c', G='#e35969', K='#7a4a08')
    if hat in ('cap', 'band'):
        r, g, b, _ = postavy.hexc(hatcol)
        dark = '#%02x%02x%02x' % (r * 6 // 10, g * 6 // 10, b * 6 // 10)
        darker = '#%02x%02x%02x' % (r * 3 // 10, g * 3 // 10, b * 3 // 10)
        pal.update(A=hatcol, a=dark, B=dark, R=hatcol, r=dark, K=darker)
    if 'mask' in extras:
        pal.update(R='#e0503f', r='#b5322c')
    char = dict(skin=skin, pal=pal, shirt=JACKETS[jacket], pants=pants, shoes='#1a1a1a', sock='#e8e3d4')
    for key in ('down', 'right', 'up'):
        layers = [HAIR[style][key]]
        if hat: layers.append(HAT[hat][key])
        for name in extras:
            if key in EXTRA[name]: layers.append(EXTRA[name][key])
        char[key] = compose(*layers)
    if chain: char['body_down'] = CHAIN
    return char

# jméno (jen pro přehled, ve hře jsou jména v OverWorldMap.js), a jak vypadá
GANG = [
    ('Ketchup',    member('short', 'light', 'red', 'red', hat='crown')),
    ('Mustard',  member('long', 'tan', 'blond', 'red', hat='crown')),
    ('Pickle',   member('pigtails', 'light', 'green', 'red', hat='cap', hatcol='#9b5fd0')),
    ('Onion',  member('bald', 'pale', 'brown', 'red', hat='band', hatcol='#9b5fd0', extras=('stache',))),
    ('Sesame',    member('afro', 'dark', 'black', 'orange', extras=('shades',))),
    ('Bun',    member('long', 'tan', 'brown', 'orange', hat='band', hatcol='#e0503f')),
    ('Cheddar',    member('spiky', 'light', 'orange', 'orange', chain=True)),
    ('Bacon',     member('mohawk', 'tan', 'pink', 'black', extras=('patch',))),
    ('Fries', member('pigtails', 'light', 'blond', 'orange', hat='crown')),
    ('Mayo',     member('quiff', 'pale', 'purple', 'black', extras=('shades',))),
    ('Tartar',  member('short', 'pale', 'black', 'black', extras=('mask',))),
    ('Nugget',   member('pigtails', 'dark', 'brown', 'purple', hat='crown')),
    ('Grinder',  member('short', 'tan', 'brown', 'orange', hat='cap', hatcol='#e0503f', extras=('beard',))),
    ('Grill',     member('bald', 'dark', 'black', 'black', extras=('shades', 'beard'), chain=True)),
    ('Chunk',     member('spiky', 'light', 'blue', 'red', extras=('mask',))),
    ('Cutlet',  member('long', 'tan', 'red', 'purple', extras=('shades',))),
    ('Straw',    member('mohawk', 'pale', 'green', 'red')),
    ('Shake',     member('quiff', 'dark', 'black', 'purple', extras=('stache',), chain=True)),
    ('Tray',    member('afro', 'tan', 'brown', 'orange', hat='band', hatcol='#ffd23f')),
    ('Double',     member('short', 'light', 'blond', 'purple', hat='crown', extras=('shades',), chain=True)),
]
FIRST = 28
# other people made of the same parts: (file name, how they look)
OTHERS = [
    ('npc48', member('short', 'light', 'brown', 'overalls', hat='cap', hatcol='#f08a2e', pants='#5b4d3c')),     # Billy, učeň ze železářství
    ('npc49', member('short', 'tan', 'black', 'shirt', hat='cap', hatcol='#b09cd9', extras=('stache',), pants='#413064')),   # Tony Boiii
    ('npc51', member('short', 'dark', 'black', 'yellow', hat='cap', hatcol='#c8443a')),                           # Otis s krabičkami na burger
    ('npc52', member('short', 'light', 'orange', 'jersey', hat='cap', hatcol='#ffd23f', pants='#2b2b36')),       # kurýr Spoke s kolem
]

# the people inside Burger Tower: npc53 to npc72, five to a floor, in the order they are met going up
# (their names, burgers and lines are in Content/enemies.js and OverWorldMap.js, in the same order)
CAP_RED, CAP_ORANGE = '#c8443a', '#f08a2e'
TOWER = [
    # 1 the entrance hall: part-timers in the yellow uniform
    ('Napkin',  member('short', 'pale', 'blond', 'yellow', hat='cap', hatcol=CAP_RED)),
    ('Skewer',   member('bald', 'tan', 'brown', 'yellow', hat='cap', hatcol=CAP_RED, extras=('stache',))),
    ('Salty',    member('pigtails', 'light', 'red', 'yellow', hat='cap', hatcol=CAP_RED)),
    ('Cup',   member('long', 'dark', 'black', 'yellow', hat='cap', hatcol=CAP_RED)),
    ('Dressing',   member('short', 'light', 'green', 'yellow', hat='cap', hatcol=CAP_RED, extras=('shades',))),
    # 2 the store room: warehouse hands in work coats
    ('Pallet',    member('short', 'tan', 'black', 'worker', hat='cap', hatcol=CAP_ORANGE, pants='#5b4d3c')),
    ('Crate',     member('bald', 'dark', 'black', 'worker', extras=('beard',), pants='#5b4d3c')),
    ('Freezer',    member('spiky', 'pale', 'blue', 'worker', extras=('mask',), pants='#5b4d3c')),
    ('Sack',     member('afro', 'dark', 'brown', 'worker', pants='#5b4d3c')),
    ('Forklift',  member('pigtails', 'light', 'orange', 'worker', hat='cap', hatcol=CAP_ORANGE, pants='#5b4d3c')),
    # 3 the corridors: clerks in white shirts
    ('Invoice',   member('long', 'pale', 'brown', 'shirt', pants='#2c3870')),
    ('Stamp',   member('short', 'light', 'grey', 'shirt', extras=('stache',), pants='#2c3870')),
    ('Binder',     member('quiff', 'tan', 'black', 'shirt', pants='#2c3870')),
    ('Bonus',     member('bald', 'pale', 'brown', 'shirt', extras=('shades',), pants='#2c3870')),
    ('Chart',   member('pigtails', 'dark', 'black', 'shirt', hat='band', hatcol='#5fa8f0', pants='#2c3870')),
    # 4 the hall with the pillar: the Queen's own people, purple jackets and gold
    ('Wagyu',     member('mohawk', 'tan', 'white', 'purple', chain=True)),
    ('Truffle',     member('quiff', 'dark', 'black', 'purple', extras=('shades',), chain=True)),
    ('Caviar',    member('long', 'pale', 'blue', 'purple', hat='crown')),
    ('Brioche',   member('pigtails', 'light', 'pink', 'purple', hat='crown')),
    ('Steak',     member('bald', 'tan', 'black', 'purple', extras=('patch', 'beard'), chain=True)),
]
FIRST_TOWER = 53
OTHERS += [
    ('npc73', member('long', 'light', 'blond', 'blazer', pants='#2c3870')),                                        # Penny, recepční v Burger Tower
    ('npc74', member('bald', 'pale', 'black', 'suit', extras=('shades',), pants='#26262f')),                       # bodyguard Lefty
    ('npc75', member('bald', 'dark', 'black', 'suit', extras=('shades', 'beard'), pants='#26262f')),               # bodyguard Righty
    ('npc76', member('long', 'light', 'red', 'robe', hat='crown', chain=True, pants='#4c1210')),                   # Burger Queen
    ('npc77', member('short', 'tan', 'grey', 'overalls', hat='cap', hatcol='#f08a2e', extras=('beard',), pants='#5b4d3c')),   # Hank, železář, majitel železářství
]

if __name__ == '__main__':
    sheets = []
    for n, (name, ch) in enumerate(GANG):
        sh = postavy.build(ch)
        sh.save(postavy.SRC + 'npc%d.png' % (FIRST + n))
        sheets.append(sh)
    for name, ch in OTHERS:
        postavy.build(ch).save(postavy.SRC + name + '.png')
    tower = []
    for n, (name, ch) in enumerate(TOWER):
        sh = postavy.build(ch)
        sh.save(postavy.SRC + 'npc%d.png' % (FIRST_TOWER + n))
        tower.append(sh)
    # náhled: po deseti nad sebou ve dvou sloupcích
    from PIL import Image
    tmp = os.path.join(postavy.ROOT, 'tools', '_gang_tmp.png')
    halves = []
    for part in (sheets[:10], sheets[10:]):
        postavy.preview(part, tmp, scale=4)
        halves.append(Image.open(tmp).convert('RGBA'))
    os.remove(tmp)
    out = Image.new('RGBA', (halves[0].width * 2 + 16, halves[0].height), (203, 170, 135, 255))
    out.alpha_composite(halves[0], (0, 0)); out.alpha_composite(halves[1], (halves[0].width + 16, 0))
    out.save(os.path.join(postavy.ROOT, 'tools', 'gang-nahled.png'))
    # the people of the tower: the twenty of the floors, then the reception, the two bodyguards, the Queen and the ironmonger
    extra = [Image.open(postavy.SRC + 'npc%d.png' % n).convert('RGBA') for n in (73, 74, 75, 76, 77)]
    halves = []
    for part in (tower[:10], tower[10:], extra):
        postavy.preview(part, tmp, scale=4)
        halves.append(Image.open(tmp).convert('RGBA'))
    os.remove(tmp)
    out = Image.new('RGBA', (halves[0].width * 3 + 32, halves[0].height), (203, 170, 135, 255))
    for k, half in enumerate(halves): out.alpha_composite(half, (k * (halves[0].width + 16), 0))
    out.save(os.path.join(postavy.ROOT, 'tools', 'vez-lide-nahled.png'))
    print('images/characters/people/npc%d.png až npc%d.png a npc73 až npc77, tools/vez-lide-nahled.png' % (FIRST_TOWER, FIRST_TOWER + len(TOWER) - 1))
    print('images/characters/people/npc%d.png až npc%d.png, tools/gang-nahled.png' % (FIRST, FIRST + len(GANG) - 1))
