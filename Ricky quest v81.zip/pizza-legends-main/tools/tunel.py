# Kreslí tunel ve stokách za mříží, kam uteklo pizzové monstrum (mapa SewerTunnel), a stoky s přeštípnutou mříží:
#   images/maps/SewerTunnelLower.png, SewerTunnelUpper.png      (chodba; tmavým průchodem vzadu se jde do doupěte, tools/doupe.py)
#   images/maps/SewerOpenLower.png, SewerOpenUpper.png          (mapa Sewer, když je mříž přeštípnutá kleštěmi)
#   Content/sewerTunnel.js  (mřížka a místa pro OverWorldMap.js - NEUPRAVOVAT RUČNĚ, přepíše se)
#   tools/tunel-nahled.png  (celá chodba, jen na koukání)
# Spuštění z kořene projektu:  python3 tools/tunel.py      (potřebuje Pillow; jde pouštět opakovaně)
# POZOR: stoky s otevřenou mříží se kreslí do hotového obrázku SewerLower.png, takže se tenhle skript pouští až po
# tools/stoky.py, tools/vychody.py a tools/rybar.py (v tomhle pořadí).
#
# Chodba je do L: od vchodu (dole vlevo, pod ním jsou stoky) nahoru a pak doprava. Po vnitřní straně teče stoka.
# Vzadu vpravo je ve zdi tmavý průchod do doupěte pizzového monstra (mapa SewerLair, kreslí tools/doupe.py, který si
# odsud bere room(), lamp(), drain(), way_out(), splat() a barvy). Rozmístění je v ROWS:
#   # zeď   . chodník   ~ voda (nedá se přes ni)   v zadní zdi:  A tmavý průchod dál   o roura, ze které teče voda   l lampa
from PIL import Image
import math, os, random, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P = os.path.join(ROOT, 'images', 'maps') + os.sep
T = 16
ROWS = [
    "###################",
    "###################",
    "###################",
    "###l#o###l#o#AA#l##",
    "#.................#",
    "#.................#",
    "#..~~~~~~~~~~~~~~~#",
    "#..~###############",
    "#..~###############",
    "#..~###############",
    "#..~###############",
    "#..~###############",
    "#..~###############",
    "#..~###############",
    "#..~###############",
    "#..~###############",
    "#..~###############",
    "#..~###############",
    "#..################",
    "###################",
]
W, H = len(ROWS[0]), len(ROWS)
FACE_ROW = 3                         # the row of the brick face of the back wall
EXIT_ROW = H - 2                     # stepping on its free tiles leads back into the sewers
def c(h, a=255): return (int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16), a)

# the colours of the sewers (tools/stoky.py)
EDGE_TOP = c('#1c2422'); EDGE = c('#161d1b'); LEDGE = c('#3a4643')
WALLTOP = c('#4f5d5a'); HL = c('#6f807b'); FACE = c('#455450'); MORTAR = c('#37433f'); BRICK_HI = c('#536560'); BASE = c('#2b3532')
LINE = c('#3d4845'); GRID = c('#58645f')
TILE = {1: c('#6d7a76'), 0: c('#778581')}
SHADOW = {1: c('#515d59'), 0: c('#586561')}
SPECK = {1: c('#647470'), 0: c('#6f7f7b')}
WATER, WATER_HI, WATER_SH, FOAM = c('#3f7a5c'), c('#5fa27a'), c('#2e5f48'), c('#a6d6b0')
MOSS, MOSS_HI = c('#5a8546'), c('#7fae5c')
IRON, IRON_HI, IRON_SH = c('#7d8884'), c('#a9b4b0'), c('#4d5754')
K = c('#121816')
CHEESE, CHEESE_HI, SAUCE, SAUCE_HI = c('#e2b051'), c('#f1c25a'), c('#e35969'), c('#f58a96')


def arch(px, gcx, bars):
    """The tunnel mouth of the sewers, two tiles wide, in a back wall whose face is tile row 3 (as in tools/stoky.py).
    bars: 'bent' = the grate the monster squeezed through, 'cut' = the two middle bars snipped off, None = no grate."""
    for y in range(22, 64):
        for x in range(int(gcx - 17.5), int(gcx + 18.5)):
            d = math.hypot(x - gcx, y - 44) if y < 44 else abs(x - gcx)
            if d <= 16.5:
                if d > 15.5: px[x, y] = K
                elif d > 12.5:
                    ang = math.degrees(math.atan2(44 - y, x - gcx)) if y < 44 else (y - 44) * 9
                    px[x, y] = c('#8b9a95') if int(ang // 22) % 2 else c('#a3b2ad')
                elif d > 11.5: px[x, y] = K
                else: px[x, y] = c('#0c1211') if y < 56 else c('#12201c')
    if not bars: return
    def bar(x_at, rows=range(29, 64)):
        for y in rows:
            x = round(x_at(y))
            if abs(x - gcx) > 11.5 or (y < 44 and math.hypot(x - gcx, y - 44) > 11.5): continue
            px[x, y] = IRON_HI if y % 5 else IRON
            if abs(x + 1 - gcx) <= 11.5: px[x + 1, y] = IRON_SH
    if bars == 'bent':
        for off in (-9, -5, 5, 9): bar(lambda y, o=off: gcx + o)
        for side in (-1, 1):                                        # the two in the middle bow outwards
            bar(lambda y, s=side: gcx + s * (1.5 + 3.2 * math.sin(max(0, min(1, (y - 30) / 33)) * math.pi)))
    else:                                                           # snipped: only the outer bars are left, of the others short stubs
        for off in (-9, 9): bar(lambda y, o=off: gcx + o)
        for off in (-5, -2, 2, 5):
            bar(lambda y, o=off: gcx + o, rows=range(29, 38 + abs(off) % 3))
            bar(lambda y, o=off: gcx + o, rows=range(62, 64))
    for x in range(int(gcx) - 11, int(gcx) + 12): px[x, 34] = IRON; px[x, 35] = IRON_SH
    for (x, y0, n) in ((int(gcx) - 9, 40, 6), (int(gcx) + 9, 43, 7)) + (((int(gcx) + 5, 50, 4),) if bars == 'bent' else ()):     # cheese left hanging on the bars
        for i in range(n): px[x, y0 + i] = CHEESE_HI
        px[x, y0 + n] = CHEESE


def sewer_with_open_grate():
    """The finished picture of the sewers with the grate cut open. Its arch is in tile columns 18 and 19."""
    lower = Image.open(P + 'SewerLower.png').convert('RGBA')
    upper = Image.open(P + 'SewerUpper.png').convert('RGBA')
    gcx = 18 * T + 15.5
    arch(lower.load(), gcx, 'cut')
    px = lower.load()
    # the cut bars lie on the ground in front of it
    for (x0, y0) in ((int(gcx) - 10, 66), (int(gcx) + 3, 68)):
        for i in range(8): px[x0 + i, y0] = IRON_HI; px[x0 + i, y0 + 1] = IRON_SH
    # what is over the heads of somebody walking in (the top of the arch and the dark under it) covers them
    box = (int(gcx - 17.5), 16, int(gcx + 18.5), 48)
    upper.alpha_composite(lower.crop(box), box[:2])
    lower.save(P + 'SewerOpenLower.png'); upper.save(P + 'SewerOpenUpper.png')


class Room:
    """The bare room of a sewer map drawn from its rows: walls with a brick face, the walkway, channels of water, dirt,
    puddles and moss. Everything that stands in it is drawn afterwards by whoever asked for it (tunnel() below and
    tools/doupe.py). In the rows '.' and whatever is listed in floor_chars is walkway, '~' is water, the rest is wall."""
    pass


def room(ROWS, floor_chars='.', ripples=170, specks=140, puddles=26, moss=40):
    W, H = len(ROWS[0]), len(ROWS)
    im = Image.new('RGBA', (W * T, H * T), (0, 0, 0, 0))
    px = im.load()
    at = lambda x, y: ROWS[y][x] if 0 <= x < W and 0 <= y < H else '#'
    floor = lambda x, y: at(x, y) in floor_chars
    water = lambda x, y: at(x, y) == '~'
    open_ = lambda x, y: floor(x, y) or water(x, y)
    wall = lambda x, y: not open_(x, y)
    def rect(x0, y0, x1, y1, col):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1): px[x, y] = col
    def blend(x, y, col, a):
        r, g, b, al = px[x, y]
        if al: px[x, y] = (int(r * (1 - a) + col[0] * a), int(g * (1 - a) + col[1] * a), int(b * (1 - a) + col[2] * a), 255)

    # which wall tiles are drawn at all: the brick face over open tiles, two tiles of wall top above it, and one tile of
    # wall top round everything else
    face = {(x, y) for y in range(H) for x in range(W) if wall(x, y) and open_(x, y + 1)}
    top = set()
    for y in range(H):
        for x in range(W):
            if not wall(x, y) or (x, y) in face: continue
            near = any(open_(x + dx, y + dy) for dx in (-1, 0, 1) for dy in (-1, 0, 1))
            above_face = (x, y + 1) in face or (x, y + 2) in face or any((x + dx, y + dy) in face for dx in (-1, 1) for dy in (0, 1, 2))
            if near or above_face: top.add((x, y))

    for (tx, ty) in top: rect(tx * T, ty * T, tx * T + 15, ty * T + 15, WALLTOP)
    for (tx, ty) in face:
        for y in range(T):
            for x in range(T):
                gx, gy = tx * T + x, ty * T + y
                if y == 0: col = HL
                elif y == 15: col = BASE
                else:
                    row, inrow = (y - 1) // 4, (y - 1) % 4
                    off = 4 if row % 2 else 0
                    col = MORTAR if inrow == 3 or (gx + off) % 8 == 0 else (BRICK_HI if inrow == 0 else FACE)
                px[gx, gy] = col
    # the walkway
    for y in range(H):
        for x in range(W):
            if not floor(x, y): continue
            for yy in range(T):
                for xx in range(T):
                    gx, gy = x * T + xx, y * T + yy
                    par = (x + y) % 2
                    under_face = (x, y - 1) in face
                    if under_face and yy == 0: col = LINE
                    elif xx == 0 or yy == 0: col = LINE if (under_face and yy == 1) else GRID
                    elif under_face and yy == 1: col = SHADOW[par]
                    else: col = TILE[par]
                    px[gx, gy] = col
    # the channel: dark far wall where it starts, water, a light lip on the near side
    for y in range(H):
        for x in range(W):
            if not water(x, y): continue
            gx, gy = x * T, y * T
            rect(gx, gy, gx + 15, gy + 15, WATER)
            if not water(x, y - 1):
                rect(gx, gy, gx + 15, gy, K)
                for yy in range(1, 6):
                    for xx in range(T): px[gx + xx, gy + yy] = MORTAR if yy % 3 == 0 or (gx + xx + (yy // 3) * 4) % 8 == 0 else BASE
                rect(gx, gy + 6, gx + 15, gy + 6, K); rect(gx, gy + 7, gx + 15, gy + 9, WATER_SH)
            if not water(x - 1, y): rect(gx, gy + (7 if not water(x, y - 1) else 0), gx, gy + 15, K); rect(gx + 1, gy + (7 if not water(x, y - 1) else 0), gx + 2, gy + 15, WATER_SH)
            if not water(x + 1, y): rect(gx + 15, gy, gx + 15, gy + 15, K)
            if not water(x, y + 1) and wall(x, y + 1): rect(gx, gy + 15, gx + 15, gy + 15, K)
    for _ in range(ripples):                                        # ripples
        x = random.randrange(T, W * T - 8); y = random.randrange(T, H * T - T)
        n = random.randrange(2, 5)
        if all(water((x + i) // T, y // T) and px[x + i, y] == WATER for i in range(n + 1)):
            for i in range(n): px[x + i, y] = WATER_HI
            if random.random() < 0.3: px[x + n, y] = FOAM
    # outlines: where the wall meets the dark outside, and where the wall top meets open tiles
    drawn = top | face
    for (tx, ty) in drawn:
        gx, gy = tx * T, ty * T
        if (tx, ty - 1) not in drawn and not open_(tx, ty - 1): rect(gx, gy, gx + 15, gy, EDGE_TOP)
        if (tx - 1, ty) not in drawn and not open_(tx - 1, ty): rect(gx, gy, gx, gy + 15, EDGE_TOP)
        if (tx + 1, ty) not in drawn and not open_(tx + 1, ty): rect(gx + 15, gy, gx + 15, gy + 15, EDGE_TOP)
        if (tx, ty + 1) not in drawn and not open_(tx, ty + 1): rect(gx, gy + 15, gx + 15, gy + 15, EDGE)
    for (tx, ty) in top:
        gx, gy = tx * T, ty * T
        if open_(tx - 1, ty): rect(gx, gy, gx, gy + 15, EDGE)
        if open_(tx + 1, ty): rect(gx + 15, gy, gx + 15, gy + 15, EDGE)
        if open_(tx, ty - 1): rect(gx, gy, gx + 15, gy, EDGE); rect(gx, gy + 1, gx + 15, gy + 1, LEDGE)
    # dirt on the floor, puddles, moss on the bricks
    for _ in range(specks):
        x = random.randrange(T, W * T - T); y = random.randrange(T * 4, H * T - T)
        if not (floor(x // T, y // T) and floor((x + 1) // T, y // T)) or x % 16 in (0, 1, 15) or y % 16 in (0, 1, 15): continue
        par = (x // 16 + y // 16) % 2
        px[x, y] = SPECK[par]; px[x + 1, y] = SPECK[par]
    for _ in range(puddles):
        x0 = random.randrange(T + 2, W * T - 2 * T); y0 = random.randrange(T * 4 + 4, H * T - 2 * T)
        if not all(floor((x0 + dx) // T, (y0 + dy) // T) for dx in (0, 9) for dy in (0, 3)): continue
        for dy, (a, b) in enumerate(((2, 6), (0, 8), (1, 9), (3, 7))):
            for x in range(x0 + a, x0 + b + 1): blend(x, y0 + dy, WATER_SH, 0.35)
        blend(x0 + 3, y0 + 1, FOAM, 0.4); blend(x0 + 4, y0 + 1, FOAM, 0.4)
    for _ in range(moss):
        tx, ty = random.choice(sorted(face))
        x0 = tx * T + random.randrange(0, 10); y0 = ty * T + random.randrange(3, 13)
        for i in range(random.randrange(3, 7)):
            if x0 + i >= (tx + 1) * T: break
            px[x0 + i, y0] = MOSS
            if random.random() < 0.5: px[x0 + i, y0 + 1] = MOSS
            if random.random() < 0.25: px[x0 + i, y0 - 1] = MOSS_HI

    r = Room()
    r.im, r.px, r.W, r.H, r.at, r.floor, r.water, r.wall, r.rect, r.blend, r.face, r.top = im, px, W, H, at, floor, water, wall, rect, blend, face, top
    return r


def lamp(r, tx, ty):
    """A caged lamp on the brick face of tile (tx, ty), with a weak yellow glow on the bricks round it."""
    px, rect, blend = r.px, r.rect, r.blend
    gx = tx * T
    lx, ly = gx + 5, ty * T + 2
    for y in range(ly - 6, ly + 14):
        for x in range(gx - 6, gx + 22):
            d = math.hypot(x - (lx + 2.5), y - (ly + 3))
            if d < 11 and px[x, y][3]: blend(x, y, c('#f7d95a'), 0.22 * (1 - d / 11))
    rect(lx, ly - 1, lx + 5, ly + 7, K); rect(lx + 1, ly, lx + 4, ly + 6, c('#f7d95a')); rect(lx + 2, ly + 1, lx + 3, ly + 4, c('#fff6c9'))
    rect(lx + 1, ly + 2, lx + 4, ly + 2, IRON_SH); rect(lx + 1, ly + 5, lx + 4, ly + 5, IRON_SH); rect(lx + 1, ly - 2, lx + 4, ly - 2, IRON)


def drain(r, tx, ty, until):
    """A drain pipe in the brick face of tile (tx, ty): water runs out of it down the wall and on to the row of pixels
    'until' (across the walkway into a channel, or straight into a channel right under the wall)."""
    px = r.px
    gx = tx * T
    cx, cy = gx + 7.5, ty * T - 0.5
    for y in range(int(cy) - 9, int(cy) + 11):
        for x in range(gx - 3, gx + 19):
            d = math.hypot(x - cx, y - cy)
            if d <= 8.6: px[x, y] = K if d > 7.6 else (IRON_HI if d > 6.2 and y < cy - 1 else (IRON if d > 5.2 else (K if d > 4.4 else c('#0c1211'))))
    floor_y = (ty + 1) * T
    for y in range(int(cy) + 2, until):
        for x in range(int(cx) - 1, int(cx) + 3):
            if y < cy + 5 and math.hypot(x - cx, y - cy) > 4.4: continue
            px[x, y] = WATER_HI if x == int(cx) - 1 and y < floor_y else (WATER if y < floor_y else WATER_SH if x in (int(cx) - 1, int(cx) + 2) else WATER)
    for y in range(floor_y, until):
        if y > floor_y: px[int(cx) - 2, y] = K
        px[int(cx) + 3, y] = LINE
        if y % 7 == 3: px[int(cx), y] = FOAM
    for x in range(int(cx) - 3, int(cx) + 5): px[x, floor_y - 1] = FOAM if x % 2 else WATER_HI


def way_out(r, exit_row):
    """The way back at the bottom: the walkway runs out of the picture, with the same arrows as the other ways out.
    Returns the columns of its tiles."""
    im, rect = r.im, r.rect
    sewer = Image.open(P + 'SewerLower.png').convert('RGBA')
    arrow_tile = sewer.crop((4 * T, 10 * T, 5 * T, 11 * T))            # the way out of the sewers into the cellar
    exits = [x for x in range(r.W) if r.floor(x, exit_row)]
    for tx in exits: im.paste(arrow_tile, (tx * T, exit_row * T))
    rect(exits[0] * T - 1, exit_row * T, exits[0] * T - 1, exit_row * T + T + 2, EDGE); rect(exits[-1] * T + T, exit_row * T, exits[-1] * T + T, exit_row * T + T + 2, EDGE)
    rect(exits[0] * T - 1, exit_row * T + T, exits[-1] * T + T, exit_row * T + T, EDGE); rect(exits[0] * T, exit_row * T + T + 1, exits[-1] * T + T - 1, exit_row * T + T + 1, LEDGE)
    rect(exits[0] * T - 1, exit_row * T + T + 2, exits[-1] * T + T, exit_row * T + T + 2, EDGE)
    return exits


def splat(px, x, y, kind):
    """A blob the monster left behind: kind 0 = cheese, 1 = sauce."""
    col, hi = (CHEESE, CHEESE_HI) if kind == 0 else (SAUCE, SAUCE_HI)
    for dx, dy in ((0, 0), (1, 0), (2, 0), (0, 1), (1, 1), (2, 1), (3, 1), (1, 2), (2, 2), (-1, 1), (4, 0)):
        px[x + dx, y + dy] = col
    px[x + 1, y] = hi


def tunnel():
    random.seed(41)
    r = room(ROWS)
    im, px, at, floor, water, rect, blend = r.im, r.px, r.at, r.floor, r.water, r.rect, r.blend

    # ---- things in the back wall
    spots = []
    channel_top = min(y for y in range(H) for x in range(W) if water(x, y)) * T
    for tx in range(W):
        ch = at(tx, FACE_ROW)
        gx = tx * T
        if ch == 'o':                                               # a drain pipe: water runs down the wall and across the walkway into the channel
            drain(r, tx, FACE_ROW, channel_top)
            spots.append((tx, FACE_ROW, 'o'))
        elif ch == 'l':                                             # a caged lamp
            lamp(r, tx, FACE_ROW)
        elif ch == 'A' and at(tx - 1, FACE_ROW) != 'A':             # the way on, to the monster's lair (tools/doupe.py)
            arch(px, gx + 15.5, None)

    # ---- the monster's trail of cheese and sauce, from the way in to the dark mouth
    mouth = [x for x in range(W) if at(x, FACE_ROW) == 'A']
    trail = [(26, 282, 0), (36, 262, 1), (24, 240, 0), (38, 221, 0), (27, 199, 1), (35, 178, 0), (25, 157, 0), (37, 136, 1), (28, 116, 0),
             (40, 98, 0), (60, 86, 1), (82, 90, 0), (104, 80, 0), (127, 88, 1), (150, 78, 0), (172, 84, 0), (192, 74, 1), (mouth[0] * T + 8, 70, 0), (mouth[0] * T + 14, 66, 0)]
    for (x, y, kind) in trail: splat(px, x, y, kind)

    # ---- the way back
    exits = way_out(r, EXIT_ROW)

    # ---- checks
    start = (exits[0], EXIT_ROW - 1)
    seen, todo = {start}, [start]
    while todo:
        x, y = todo.pop()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            n = (x + dx, y + dy)
            if n not in seen and floor(*n) and n[1] < EXIT_ROW: seen.add(n); todo.append(n)
    for x in mouth:
        if (x, FACE_ROW + 1) not in seen: print('k tmavému průchodu se nedá dojít'); sys.exit(1)

    im.save(P + 'SewerTunnelLower.png')
    # what is over the heads of somebody walking into the dark mouth (the top of the arch and the dark under it) covers them
    upper = Image.new('RGBA', im.size, (0, 0, 0, 0))
    gcx = mouth[0] * T + 15.5
    box = (int(gcx - 17.5), 16, int(gcx + 18.5), 48)
    upper.alpha_composite(im.crop(box), box[:2])
    upper.save(P + 'SewerTunnelUpper.png')
    with open(os.path.join(ROOT, 'Content', 'sewerTunnel.js'), 'w', encoding='utf-8') as f:
        f.write('//Tunel ve stokách za mříží (mapa SewerTunnel): mřížka a místa, která vypisuje tools/tunel.py spolu s obrázky.\n')
        f.write('//NEUPRAVOVAT RUČNĚ - rozmístění se mění v tools/tunel.py, ten tenhle soubor přepíše.   # zeď   . chodník\n')
        f.write('window.SewerTunnelGrid = {\n')
        f.write('  exit: [%s], //cesta zpátky do stok (pod mříž)\n' % ', '.join('[%d, %d]' % (x, EXIT_ROW) for x in exits))
        f.write('  mouth: [%s], //tmavý průchod v zadní zdi: dá se do něj vejít, vede do doupěte (mapa SewerLair)\n' % ', '.join('[%d, %d]' % (x, FACE_ROW) for x in mouth))
        f.write('  spots: [%s], //[x, y, druh]: o roura\n' % ', '.join('[%d, %d, "%s"]' % s for s in spots))
        f.write('  water: [%s], //voda (z chodníku vedle se na ni dá kouknout)\n' % ', '.join('[%d, %d]' % (x, y) for y in range(H) for x in range(W) if water(x, y)))
        f.write('  rows: [\n')
        for y in range(H): f.write('    "%s",\n' % ''.join('.' if floor(x, y) or (y == FACE_ROW and x in mouth) else '#' for x in range(W)))
        f.write('  ]\n}\n')
    bg = Image.new('RGBA', im.size, (12, 16, 15, 255)); bg.alpha_composite(im)
    hero = Image.open(os.path.join(ROOT, 'images', 'characters', 'people', 'hero.png')).convert('RGBA')
    shadow = Image.open(os.path.join(ROOT, 'images', 'characters', 'shadow.png')).convert('RGBA')
    for sprite_ in (shadow.crop((0, 0, 32, 32)), hero.crop((0, 64, 32, 96))):
        bg.alpha_composite(sprite_, (exits[0] * T - 8, (EXIT_ROW - 2) * T - 18))
    bg.resize((bg.width * 3, bg.height * 3), Image.NEAREST).save(os.path.join(ROOT, 'tools', 'tunel-nahled.png'))
    print('images/maps/SewerTunnelLower.png, SewerTunnelUpper.png, SewerOpenLower.png, SewerOpenUpper.png, Content/sewerTunnel.js, tools/tunel-nahled.png')
    print('volných dlaždic v tunelu:', len(seen))


if __name__ == '__main__':
    sewer_with_open_grate()
    tunnel()
