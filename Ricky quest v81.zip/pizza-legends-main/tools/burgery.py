# Kreslí hamburgery gangu Burger Queen (b001-b010), pouliční pizzy ze Zadních uliček (u001-u005) a ikonu druhu
# "burgerová":  images/characters/pizzas/b0xx.png, u00x.png, images/icons/burger.png a náhled tools/burgery-nahled.png.
# Spuštění z kořene projektu:  python3 tools/burgery.py      (potřebuje Pillow; jde pouštět opakovaně)
# Potom ještě  python3 tools/zlate.py  - nakreslí ke všem zlaté (shiny) verze.
#
# Hamburger se skládá z vrstev odshora dolů (houska, salát, sýr, maso...), viz BURGERS dole; obrys se dokreslí sám.
# Sedí na stejném místě jako pizzy (spodek na y = 29 ve čtverci 32 x 32), aby pod něj pasoval stín.
# Pouliční pizzy mají stejný kotouč jako ostatní pizzy (převzatý ze Zvadlé Zahrádky v002, jako v tools/bahno.py).
from PIL import Image
import os, random

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
P = os.path.join(ROOT, 'images', 'characters', 'pizzas') + os.sep


def c(h, a=255):
    return (int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16), a)


OUT = c('#3a160d')                    # the outline all pizzas have

# =====================================================================================================
# HAMBURGERY
# =====================================================================================================
BUN = dict(base=c('#d9953f'), hi=c('#f0b961'), sh=c('#b3732a'), seed=c('#fbe6b5'))
RYE = dict(base=c('#8a5a4a'), hi=c('#a8725c'), sh=c('#693f33'), seed=c('#d9c0a0'))
HOT = dict(base=c('#d9703f'), hi=c('#f09a5c'), sh=c('#a94c2a'), seed=c('#7a1c14'))
ICE = dict(base=c('#bfe3f5'), hi=c('#ffffff'), sh=c('#8fc3e3'), seed=c('#ffffff'))
OAT = dict(base=c('#c9a56a'), hi=c('#e3c48a'), sh=c('#9c7a45'), seed=c('#5f8f3a'))
GOLD = dict(base=c('#e3a53a'), hi=c('#ffd77a'), sh=c('#b3782a'), seed=c('#fff4c9'))
PATTY, PATTY_HI, PATTY_DK = c('#6b3a22'), c('#8a5031'), c('#4a2616')
CHEESE, CHEESE_SH = c('#f8c93a'), c('#e0a52a')
SWISS, SWISS_SH = c('#f6e7a8'), c('#d9c27a')
LET, LET_DK = c('#7fc241'), c('#4f9a2e')
CAB, CAB_DK = c('#a35fc4'), c('#743a94')
TOM, TOM_HI = c('#d8402f'), c('#ef6b55')
ONI, ONI_DK = c('#f1e3ef'), c('#b98ac7')
BAC, BAC_HI, BAC_DK = c('#c8443a'), c('#f2a08f'), c('#8f2a26')
PIC, PIC_DK = c('#6f9a3a'), c('#4e7426')
MAYO = c('#fff6e0')
KETCHUP = c('#c22a1e')
MUSH, MUSH_DK = c('#e6d2b0'), c('#a98b6a')
CRUMB, CRUMB_HI, CRUMB_DK = c('#e3a546'), c('#f4c873'), c('#b8782a')
VEG, VEG_DK, CARROT = c('#5f8f3a'), c('#456b28'), c('#f08a2e')


def span(inset):
    """Columns of a layer: the body is 14 px wide (x 2..15); inset -1 sticks out one pixel on both sides."""
    return range(2 + inset, 16 - inset)


class Burger:
    def __init__(self, narrow=0):
        self.rows = []                # every row: {x: colour}
        self.narrow = narrow          # a smaller burger: everything this much narrower on both sides

    def add(self, rows):
        start = len(self.rows)
        self.rows += rows
        return start

    def cols(self, inset):
        return span(inset + self.narrow)

    def bun_top(self, h, pal, seeds=True):
        profile = {3: [2, 1, 0], 4: [3, 1, 0, 0], 5: [4, 2, 1, 0, 0], 6: [5, 3, 1, 0, 0, 0]}[h]
        rows = []
        for r in range(h):
            row = {}
            xs = list(self.cols(profile[r]))
            for x in xs:
                col = pal['base']
                if r <= (h - 1) // 2 and x <= xs[0] + max(1, len(xs) // 3): col = pal['hi']
                if r == h - 1: col = pal['sh']
                if seeds and 0 < r < h - 1 and xs[0] < x < xs[-1] and (x * 3 + r * 5) % 7 == 0: col = pal['seed']
                row[x] = col
            rows.append(row)
        return self.add(rows)

    def bun_bottom(self, h, pal):
        rows = []
        for r in range(h):
            rows.append({x: (pal['sh'] if r == h - 1 else (pal['hi'] if r == 0 and x < 7 else pal['base'])) for x in self.cols(1 if r == h - 1 else 0)})
        return self.add(rows)

    def flat(self, col_a, col_b=None, inset=0, h=1, every=3, shift=0):
        """A plain layer; col_b shows up on every n-th pixel (texture)."""
        rows = []
        for r in range(h):
            rows.append({x: (col_b if col_b and (x + shift + r * 2) % every == 0 else col_a) for x in self.cols(inset)})
        return self.add(rows)

    def patty(self, h=3, base=PATTY, hi=PATTY_HI, dk=PATTY_DK, inset=0):
        rows = []
        for r in range(h):
            row = {}
            for x in self.cols(inset + (1 if h >= 3 and r == h - 1 else 0)):
                row[x] = hi if r == 0 and x % 4 != 1 else (dk if (x * 5 + r * 3) % 6 == 0 else base)
            rows.append(row)
        return self.add(rows)

    def drip(self, row, xs, col, n=1):
        """Something runs down from a layer over what lies under it."""
        for x in xs:
            for k in range(1, n + 1):
                if row + k < len(self.rows) and x in self.rows[row + k]:
                    self.rows[row + k][x] = col

    def render(self, extras=None):
        im = Image.new('RGBA', (32, 32), (0, 0, 0, 0))
        px = im.load()
        y0 = 29 - len(self.rows)
        for i, row in enumerate(self.rows):
            for x, col in row.items():
                px[7 + x, y0 + i] = col
        if extras:
            extras(px, y0)
        fill = [(x, y) for y in range(32) for x in range(32) if px[x, y][3]]
        for (x, y) in fill:
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                nx, ny = x + dx, y + dy
                if 0 <= nx < 32 and 0 <= ny < 32 and px[nx, ny][3] == 0:
                    px[nx, ny] = OUT
        return im


def b001():                           # Sýrák: the plain cheeseburger
    b = Burger()
    b.bun_top(5, BUN); b.flat(LET, LET_DK, inset=-1, h=2)
    b.flat(TOM, TOM_HI, inset=0, every=5)
    ch = b.flat(CHEESE, inset=-1); b.patty(3); b.drip(ch, (3, 8, 13), CHEESE, 1); b.drip(ch, (8,), CHEESE_SH, 2)
    b.bun_bottom(3, BUN)
    return b.render()

def b002():                           # Dvojitej Drtič: two patties, two slices of cheese
    b = Burger()
    b.bun_top(5, BUN)
    c1 = b.flat(CHEESE, inset=-1); b.patty(3); b.drip(c1, (4, 12), CHEESE, 1)
    b.flat(ONI, ONI_DK, inset=0, every=2)
    c2 = b.flat(CHEESE, inset=-1); b.patty(3); b.drip(c2, (6, 14), CHEESE, 2)
    b.bun_bottom(3, BUN)
    return b.render()

def b003():                           # Pálivej Pepa: chilli bun, jalapeños, hot sauce, a chilli on a pick
    b = Burger()
    b.bun_top(5, HOT)
    b.flat(PIC, PIC_DK, inset=0, every=3); s = b.flat(KETCHUP, c('#f08a2e'), inset=-1, every=4)
    b.patty(3); b.drip(s, (3, 7, 11, 14), KETCHUP, 2)
    b.flat(LET, LET_DK, inset=-1, h=2); b.bun_bottom(3, HOT)
    def extras(px, y0):
        for i, col in enumerate((c('#e3342a'), c('#e3342a'), c('#c22a1e'), c('#8f1c14'))):   # chilli pepper lying on top
            px[13 + i, y0 - 1 - (1 if i > 1 else 0)] = col
        px[12, y0 - 1] = c('#4f9a2e'); px[14, y0 - 2] = c('#ff7b5c')
    return b.render(extras)

def b004():                           # Špekoun: bacon sticking out on both sides
    b = Burger()
    b.bun_top(5, BUN)
    b.flat(BAC, BAC_HI, inset=-1, every=3); b.flat(BAC_DK, BAC, inset=-1, every=3, shift=1)
    ch = b.flat(CHEESE, inset=0); b.patty(3); b.drip(ch, (5, 11), CHEESE, 1)
    b.flat(BAC, BAC_HI, inset=-1, every=3, shift=2)
    b.bun_bottom(3, BUN)
    return b.render()

def b005():                           # Zelenej Podrazák: vegetable patty, lots of green, a leaf on top
    b = Burger()
    b.bun_top(5, OAT)
    b.flat(LET, LET_DK, inset=-1, h=2); b.flat(TOM, TOM_HI, inset=0, every=5)
    b.flat(PIC, c('#b6d98a'), inset=0, every=2)
    b.patty(3, base=VEG, hi=c('#7fae4c'), dk=CARROT); b.flat(LET_DK, LET, inset=-1, every=2)
    b.bun_bottom(3, OAT)
    def extras(px, y0):
        for (x, y) in ((15, -1), (16, -2), (17, -3), (16, -3), (17, -2)): px[x, y0 + y] = LET
        px[16, y0 - 2] = LET_DK
    return b.render(extras)

def b006():                           # Žampionovej Kápo: dark bun, mushrooms, cheese with holes
    b = Burger()
    b.bun_top(5, RYE)
    b.flat(MUSH, MUSH_DK, inset=-1, every=3); b.flat(MUSH_DK, MUSH, inset=0, every=3, shift=1)
    sw = b.flat(SWISS, SWISS_SH, inset=-1, every=4); b.patty(3); b.drip(sw, (4, 10, 15), SWISS, 1)
    b.flat(CAB, CAB_DK, inset=-1, every=2)
    b.bun_bottom(3, RYE)
    return b.render()

def b007():                           # Mražák: frozen fish burger with icicles
    b = Burger()
    top = b.bun_top(5, ICE)
    b.flat(MAYO, c('#cfe8c0'), inset=-1, every=4)
    b.patty(3, base=CRUMB, hi=CRUMB_HI, dk=CRUMB_DK); b.flat(LET, LET_DK, inset=-1)
    b.bun_bottom(3, ICE)
    b.drip(top + 4, (2, 6, 10, 14), c('#dff4ff'), 2); b.drip(top + 4, (4, 12), c('#9fd6f5'), 3)
    def extras(px, y0):
        for (x, y, col) in ((12, -1, '#dff4ff'), (12, -2, '#ffffff'), (13, -1, '#9fd6f5'), (18, -1, '#dff4ff'), (18, -2, '#9fd6f5'), (19, -1, '#ffffff')):
            px[x, y0 + y] = c(col)
    return b.render(extras)

def b008():                           # Křupavá Slepice: a big crispy chicken fillet, mayonnaise
    b = Burger()
    b.bun_top(5, BUN)
    m = b.flat(MAYO, inset=0)
    b.flat(CRUMB_HI, CRUMB, inset=-1, every=2); b.flat(CRUMB, CRUMB_DK, inset=-2, every=3); b.flat(CRUMB, CRUMB_HI, inset=-1, every=3, shift=1)
    b.flat(CRUMB_DK, CRUMB, inset=0, every=2); b.drip(m, (4, 9, 13), MAYO, 1)
    b.flat(LET, LET_DK, inset=-1); b.bun_bottom(3, BUN)
    return b.render()

def b009():                           # Malej Sígr: a little one with a pick and an olive
    b = Burger(narrow=2)
    b.bun_top(4, BUN); b.flat(LET, LET_DK, inset=-1)
    ch = b.flat(CHEESE, inset=-1); b.patty(2); b.drip(ch, (6, 11), CHEESE, 1)
    b.bun_bottom(2, BUN)
    def extras(px, y0):
        for y in range(-5, 0): px[16, y0 + y] = c('#c9a56a')
        for (x, y) in ((15, -7), (16, -7), (15, -6), (16, -6)): px[x, y0 + y] = c('#5f8f3a')
        px[16, y0 - 7] = c('#c8443a'); px[15, y0 - 7] = c('#7fae4c')
    return b.render(extras)

def b010():                           # Královna Bulka: three floors and a crown
    b = Burger()
    b.bun_top(5, GOLD)
    b.flat(CAB, CAB_DK, inset=-1, every=2)
    c1 = b.flat(CHEESE, inset=-1); b.patty(2); b.drip(c1, (5, 13), CHEESE, 1)
    b.flat(BUN['base'], BUN['sh'], inset=0, every=5)
    b.flat(BAC, BAC_HI, inset=-1, every=3)
    c2 = b.flat(CHEESE, inset=-1); b.patty(2); b.drip(c2, (3, 9), CHEESE, 1)
    b.flat(LET, LET_DK, inset=-1); b.flat(TOM, TOM_HI, inset=0, every=5)
    b.patty(2); b.bun_bottom(3, GOLD)
    def extras(px, y0):
        g, gd, gem = c('#ffd23f'), c('#e09a1c'), c('#e35969')
        for x in range(13, 20):
            px[x, y0 - 1] = gd; px[x, y0 - 2] = g
        for x in (13, 16, 19): px[x, y0 - 3] = g; px[x, y0 - 4] = c('#fff4c9')
        px[16, y0 - 2] = gem; px[14, y0 - 2] = c('#5fcde4'); px[18, y0 - 2] = c('#5fcde4')
    return b.render(extras)


BURGERS = [('b001', b001), ('b002', b002), ('b003', b003), ('b004', b004), ('b005', b005),
           ('b006', b006), ('b007', b007), ('b008', b008), ('b009', b009), ('b010', b010)]

# =====================================================================================================
# POULIČNÍ PIZZY
# =====================================================================================================
ref = Image.open(P + 'v002.png').convert('RGBA')
OX, OY, S = 7, 12, 18
DISC = {(x, y) for y in range(S) for x in range(S) if ref.getpixel((OX + x, OY + y))[3] > 0}


def pizza(draw_inside, crust, bite=None, seed=1):
    mask = set(DISC)
    if bite:                          # somebody already had a bite: a round piece missing from the edge
        bx, by, br = bite
        mask = {(x, y) for (x, y) in mask if (x - bx) ** 2 + (y - by) ** 2 > br * br}

    def ring(x, y):
        for depth in range(0, 3):
            for dx in range(-1, 2):
                for dy in range(-1, 2):
                    if (x + dx * (depth + 1), y + dy * (depth + 1)) not in mask:
                        return depth
        return 2
    inside = {t for t in mask if ring(*t) == 2}
    board = {}
    for (x, y) in mask:
        r = ring(x, y)
        if r == 0: board[(x, y)] = OUT
        elif r == 1: board[(x, y)] = crust[(x + y) % len(crust)]

    def put(x, y, col):
        if (x, y) in inside: board[(x, y)] = col

    def blob(cx, cy, r, low, high):
        for y in range(cy - r, cy + r + 1):
            for x in range(cx - r, cx + r + 1):
                if (x - cx) ** 2 + (y - cy) ** 2 <= r * r + 1: put(x, y, low if y >= cy else high)
    draw_inside(put, blob, inside, random.Random(seed))
    im = Image.new('RGBA', (32, 32), (0, 0, 0, 0))
    for (x, y), col in board.items(): im.putpixel((OX + x, OY + y), col)
    return im


def base(put, inside, cols):
    for (x, y) in inside: put(x, y, cols[(x * 3 + y * 5) % len(cols)])

def u001(put, blob, inside, rng):     # Toulavá Tuňáková: pale cheese, tuna, rings of red onion, a bite missing
    base(put, inside, [c('#f3e2a6'), c('#ecd896'), c('#f7eab8')])
    for (cx, cy) in ((5, 6), (10, 5), (7, 11), (12, 11), (4, 11)):
        blob(cx, cy, 1, c('#c98f7a'), c('#e6b7a2'))
    for (cx, cy) in ((8, 8), (12, 8), (5, 13)):
        for dx, dy in ((0, -1), (1, 0), (0, 1), (-1, 0)): put(cx + dx, cy + dy, c('#a35fc4'))
    for (x, y) in ((9, 13), (6, 4), (13, 13), (3, 8)): put(x, y, c('#4e7426'))

def u002(put, blob, inside, rng):     # Sprejerka: tomato base sprayed over in stripes of neon paint
    base(put, inside, [c('#c2412f'), c('#b83a2a'), c('#cc4f38')])
    paints = [c('#5fcde4'), c('#f25fc0'), c('#b6f03a'), c('#fbf236')]
    for (x, y) in inside:
        band = (x + y * 2) // 4
        if (x + y * 2) % 4 < 2 and band % 2 == 0: put(x, y, paints[(band // 2) % 4])
    for (x, y) in ((4, 5), (12, 4), (6, 12), (13, 10), (9, 8)): put(x, y, c('#ffffff'))
    for (x, y) in ((5, 9), (11, 13), (8, 4)): put(x, y, c('#1e2151')); put(x + 1, y, c('#1e2151'))

def u003(put, blob, inside, rng):     # Betonová Funghi: grey as the pavement, cracked, mushroom slices
    base(put, inside, [c('#a7b0b5'), c('#98a2a8'), c('#b3bbc0')])
    for (cx, cy) in ((5, 6), (11, 6), (8, 11), (13, 11), (4, 11)):
        blob(cx, cy, 1, c('#a98b6a'), c('#e6d2b0')); put(cx, cy, c('#7a6148'))
    x, y = 3, 9
    for step in range(12):            # a crack right across
        put(x, y, c('#4c5464')); x += 1; y += (1, 0, -1, 0, 1, -1, 0, -1, 1, 0, 0, -1)[step]
    for (x, y) in ((9, 4), (10, 14), (6, 9), (12, 9)): put(x, y, c('#6a7b8b'))

def u004(put, blob, inside, rng):     # Plevelná Rukola: weeds from the cracks, dandelions
    base(put, inside, [c('#efe0a0'), c('#e6d48e'), c('#f4e8b4')])
    for _ in range(26):
        x, y = rng.randrange(S), rng.randrange(S)
        put(x, y, c('#4f9a2e')); put(x + 1, y - 1, c('#7fc241')); put(x - 1, y + 1, c('#3b7a22'))
    for (cx, cy) in ((6, 6), (11, 9), (7, 12)):
        for dx, dy in ((0, -1), (1, 0), (0, 1), (-1, 0)): put(cx + dx, cy + dy, c('#fbf236'))
        put(cx, cy, c('#f0a52a'))

def u005(put, blob, inside, rng):     # Noční Kebabová: strips of meat, white sauce in a zigzag, chilli
    base(put, inside, [c('#b5532c'), c('#a94a26'), c('#c05f34')])
    for (x, y, n) in ((4, 5, 4), (9, 4, 4), (5, 9, 3), (10, 11, 4), (4, 13, 3), (11, 7, 3)):
        for i in range(n):
            put(x + i, y, c('#8a5031') if i % 2 else c('#6b3a22')); put(x + i, y + 1, c('#4a2616'))
    x = 3
    for i in range(13):
        put(x + i, 7 + (0, 1, 2, 1)[i % 4], c('#fff6e0'))
    for (x, y) in ((7, 6), (12, 13), (6, 12), (13, 9)): put(x, y, c('#e3342a'))
    for (x, y) in ((9, 9), (5, 11), (12, 5)): put(x, y, c('#a35fc4'))


PIZZAS = [
    ('u001', u001, [c('#d9a35a'), c('#c98f48'), c('#e0b06a')], (16, 2, 4)),
    ('u002', u002, [c('#e06a3a'), c('#c9562e'), c('#b6f03a')], None),
    ('u003', u003, [c('#7d8794'), c('#6a7482'), c('#8e98a4')], None),
    ('u004', u004, [c('#c98f48'), c('#b97f3c'), c('#7fae4c')], None),
    ('u005', u005, [c('#5c3a22'), c('#4a2c18'), c('#6e4a2c')], None),
]

if __name__ == '__main__':
    made = []
    for name, fn in BURGERS:
        im = fn(); im.save(P + name + '.png'); made.append(im)
    for name, fn, crust, bite in PIZZAS:
        im = pizza(fn, crust, bite, seed=len(name) + ord(name[-1])); im.save(P + name + '.png'); made.append(im)

    # ikona druhu "burgerová" (16 x 16, jako ostatní ikony druhů)
    ICON = ["................", "................", "................", "....kkkkkkkk....", "..kkBBBBBBBBkk..", ".kBBhBBsBBsBBBk.",
            ".kBBBBBBBBBBBBk.", ".kkkkkkkkkkkkkk.", "kLlLLlLLlLLlLLlk", ".kCCCCCCCCCCCCk.", ".kPPpPPPpPPPpPk.", ".kkkkCkkkkCkkkk.",
            ".kBBBBBBBBBBBBk.", "..kkkkkkkkkkkk..", "................", "................"]
    ipal = {'k': OUT, 'B': BUN['base'], 'h': BUN['hi'], 's': BUN['seed'], 'L': LET, 'l': LET_DK, 'C': CHEESE, 'P': PATTY, 'p': PATTY_HI}
    icon = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    for y, row in enumerate(ICON):
        assert len(row) == 16, row
        for x, ch in enumerate(row):
            if ch != '.': icon.putpixel((x, y), ipal[ch])
    icon.save(os.path.join(ROOT, 'images', 'icons', 'burger.png'))

    # náhled: všechno vedle sebe, 6x zvětšené, se stínem
    shadow = Image.open(P + 'pizza-shadow.png').convert('RGBA')
    sheet = Image.new('RGBA', (len(made) * 34 + 20, 36), (118, 136, 128, 255))
    for i, im in enumerate(made):
        sheet.alpha_composite(shadow, (i * 34 + 1, 2)); sheet.alpha_composite(im, (i * 34 + 1, 2))
    sheet.alpha_composite(icon, (len(made) * 34 + 2, 14))
    sheet.resize((sheet.width * 6, sheet.height * 6), Image.NEAREST).save(os.path.join(HERE, 'burgery-nahled.png'))
    print('hotovo:', ', '.join(n for n, _ in BURGERS), '+', ', '.join(p[0] for p in PIZZAS), '+ images/icons/burger.png, tools/burgery-nahled.png')
