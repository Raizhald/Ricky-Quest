# Angličtina: z tools/preklad-en.json udělá Content/en.js (slovník, který za běhu používá Lang.js) a vypíše,
# které české texty ve hře ještě překlad nemají.
# Spuštění z kořene projektu:  python3 tools/preklad.py           (nepotřebuje nic navíc)
#                              python3 tools/preklad.py --vse     (vypíše i texty bez háčků a čárek, které nenašel)
#
# Hra je napsaná česky přímo v kódu. Do angličtiny se přepíná za běhu (Nastavení v pauze a na úvodní obrazovce):
# Lang.js každý kousek textu, který se objeví na obrazovce, vyhledá v tomhle slovníku a vymění ho.
# tools/preklad-en.json má dvě části:
#   "exact":    { "český text": "anglický text", ... }       celé kousky textu, přesně jak jsou v kódu
#   "patterns": [ ["český vzor", "anglický vzor"], ... ]     texty s proměnnou částí: {0}, {1} je jakýkoli text (jméno...),
#                                                            {0:n} je číslo; co se do nich chytí, přeloží se taky
# PO KAŽDÉ ZMĚNĚ TEXTŮ VE HŘE: doplnit překlad do tools/preklad-en.json a pustit tenhle skript. Co chybí, vypíše
# (a ve hře to zůstane česky). Text složený v kódu ze dvou kusů (`${jmeno} zůstává...`) potřebuje vzor, ne přesný text.
import re, glob, json, os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
CZ = set('áčďéěíňóřšťúůýžÁČĎÉĚÍŇÓŘŠŤÚŮÝŽ')
FILES = [f for f in sorted(glob.glob('*.js') + glob.glob('Battle/*.js') + glob.glob('State/*.js') + glob.glob('Content/*.js'))
         if f not in ('Content/en.js', 'Lang.js')]


def scan(src):
    """Every string literal outside comments as (text, [the ${...} parts]); in template literals the ${...} parts are
    replaced by {0}, {1}... and the literals nested inside them come on their own."""
    out = []
    def template(i):
        buf, exprs = [], []
        i += 1
        while i < len(src) and src[i] != '`':
            if src[i] == '\\': buf.append('\n' if src[i + 1] == 'n' else src[i + 1]); i += 2; continue
            if src.startswith('${', i):
                j = code(i + 2, stop=True)
                exprs.append(src[i + 2:j].strip()); buf.append('{%d}' % (len(exprs) - 1)); i = j + 1; continue
            buf.append(src[i]); i += 1
        out.append((''.join(buf), exprs))
        return i + 1
    def code(i, stop=False):
        depth = 0
        while i < len(src):
            ch = src[i]
            if src.startswith('//', i):
                j = src.find('\n', i); i = len(src) if j < 0 else j; continue
            if src.startswith('/*', i):
                j = src.find('*/', i); i = len(src) if j < 0 else j + 2; continue
            if ch == '`': i = template(i); continue
            if ch in '"\'':
                j = i + 1; buf = []
                while j < len(src) and src[j] != ch and src[j] != '\n':
                    if src[j] == '\\': buf.append('\n' if src[j + 1] == 'n' else src[j + 1]); j += 2; continue
                    buf.append(src[j]); j += 1
                out.append((''.join(buf), [])); i = j + 1; continue
            if ch == '/' and re.search(r'[=(,:!&|?{};]\s*$', src[max(0, i - 20):i]):      # a regex literal
                j = i + 1
                while j < len(src) and src[j] != '/' and src[j] != '\n': j += 2 if src[j] == '\\' else 1
                i = j + 1; continue
            if stop:
                if ch == '{': depth += 1
                elif ch == '}':
                    if depth == 0: return i
                    depth -= 1
            i += 1
        return i
    code(0)
    return out

def pieces(text):
    """What a string puts on the screen as separate bits of text: what is between HTML tags, and between line breaks."""
    return [re.sub(r'\s+', ' ', p).strip() for p in re.split(r'<[^>]*>|\n', text)]

def compile_pattern(cs):
    rx = re.escape(cs)
    rx = re.sub(r'\\\{(\d):n\\\}', r'(\\d+)', rx)
    rx = re.sub(r'\\\{(\d)\\\}', r'(.+?)', rx)
    return re.compile('^' + rx + '$')

if __name__ == '__main__':
    data = json.load(open('tools/preklad-en.json', encoding='utf-8'))
    exact, patterns = data['exact'], data['patterns']
    compiled = [compile_pattern(cs) for cs, en in patterns]
    for cs, en in patterns:
        if sorted(set(re.findall(r'\{(\d)', cs))) != sorted(set(re.findall(r'\{(\d)', en))):
            print('vzor nemá na obou stranách stejné proměnné:', cs)
    missing, loose = [], []
    for f in FILES:
        for text, exprs in scan(open(f, encoding='utf-8').read()):
            if text.startswith('images/'): continue
            for t in pieces(text):
                core = re.sub(r'\{\d+\}', '', t)
                if not re.search(r'[A-Za-z%s]{2}' % ''.join(CZ), core): continue
                if t in exact: continue
                sample = re.sub(r'\{\d+\}', 'X', t)                    # a template: try it with something in its holes
                if any(rx.match(sample) or rx.match(re.sub(r'\{\d+\}', '7', t)) for rx in compiled): continue
                (missing if any(ch in CZ for ch in core) else loose).append((f, t))
    with open('Content/en.js', 'w', encoding='utf-8') as out:
        out.write('//Anglické texty hry. NEUPRAVOVAT RUČNĚ: píše to tools/preklad.py z tools/preklad-en.json.\n')
        out.write('//exact: český text -> anglický; patterns: texty s proměnnou částí ({0} cokoli, {0:n} číslo). Používá to Lang.js.\n')
        out.write('window.EN = ' + json.dumps(dict(exact=exact, patterns=patterns), ensure_ascii=False, indent=0) + ';\n')
    print('Content/en.js: %d textů, %d vzorů' % (len(exact), len(patterns)))
    seen = set()
    for f, t in missing:
        if t not in seen: seen.add(t); print('  CHYBÍ PŘEKLAD (%s): %s' % (f, t))
    if '--vse' in sys.argv:
        for f, t in loose:
            if t not in seen and ' ' in t: seen.add(t); print('  bez překladu (%s): %s' % (f, t))
    if not missing: print('Všechny české texty mají překlad.')
