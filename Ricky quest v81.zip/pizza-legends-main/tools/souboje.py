# Přehrává celé souboje podle pravidel hry a počítá, jak často je hráč vyhraje: na ladění obtížnosti.
# Spuštění z kořene projektu:  python3 tools/souboje.py      (nepotřebuje nic navíc; nic nezapisuje, jen vypíše tabulku)
#
# Hráč: tři pizzy z kamene (čerstvost 85 %) na daných úrovních, pořád jen útočí (Buch!, 10), padlou vystřídá další;
# neléčí se a nepoužívá předměty, takže je to ten nejhorší případ. Soupeř hraje dvěma způsoby:
#   first = vždy první útok (tak to bylo do v80)
#   mild  = jako SubmissionMenu.decide() od v81: většinou útočí (má-li víc útoků, vybírá náhodně), každý trik
#           (Rajčatový stisk, Olivový olej) nejvýš jednou za souboj na každého svého bojovníka, ne dvakrát po sobě,
#           jen když dává smysl, a i pak jen s pravděpodobností TRICK_CHANCE
# Výsledek: v průměru hráči zbude stejně životů jako dřív (trik stojí soupeře útok), jen souboje nejsou pokaždé stejné;
# kdo dřív vyhrával s posledními pár životy, může teď občas prohrát.
# Když se změní pravidla souboje (Battle/*.js) nebo útoky (Content/actions.js, pizzas.js), je potřeba to promítnout sem.
import random

TRICK_CHANCE = 0.5
KIND = {  # druh: (síly útoků, triky)
    'b001': ([10], ['saucy']), 'b002': ([13], ['clumsy']), 'b003': ([11], ['saucy']), 'b004': ([10], ['clumsy']), 'b005': ([10], ['saucy']),
    'b006': ([10], ['clumsy']), 'b007': ([11], ['clumsy']), 'b008': ([11], ['saucy']), 'b009': ([8], ['clumsy']), 'b010': ([13], ['saucy', 'clumsy']),
    'f001': ([10], []), 'v001': ([10], []), 's002': ([10], ['saucy', 'clumsy']), 'c001': ([10], ['clumsy']), 'v002': ([10], ['saucy']),
    'f002': ([10], ['clumsy', 'saucy']), 'x001': ([10], []), 'lair': ([14, 10], ['saucy', 'clumsy']),
}
def burger(kind, level, extra=0): return dict(kind=kind, level=level, hp=22 + 5 * level + extra)     # gang a věž (Content/enemies.js)
def pizza(kind, level, hp): return dict(kind=kind, level=level, hp=hp)

def fight(team, levels, policy, n=3000):
    """Vrací (% výher, průměrný počet kol, kolik % životů hráči po výhře zbude)."""
    wins = rounds_sum = left = 0
    for _ in range(n):
        mine = [dict(hp=61 + 5 * (l - 1), max=61 + 5 * (l - 1), atk=11 + l, df=11 + l, st=None) for l in levels]
        theirs = [dict(hp=t['hp'], max=t['hp'], atk=9 + t['level'], df=9 + t['level'], st=None, dmg=KIND[t['kind']][0], tricks=KIND[t['kind']][1],
                       used=set(), last=False) for t in team]
        over = lambda: all(x['hp'] <= 0 for x in theirs) or all(x['hp'] <= 0 for x in mine)
        rounds = 0
        while not over() and rounds < 400:
            rounds += 1
            for side in ('player', 'enemy'):
                me = next(x for x in (mine if side == 'player' else theirs) if x['hp'] > 0)
                other = next(x for x in (theirs if side == 'player' else mine) if x['hp'] > 0)
                act = 'dmg'
                if side == 'enemy' and policy == 'mild':
                    can = [t for t in me['tricks'] if t not in me['used'] and (
                        (not me['st'] and me['hp'] <= me['max'] - 15) if t == 'saucy' else (not other['st'] and other['hp'] > other['max'] / 3))]
                    if can and not me['last'] and random.random() < TRICK_CHANCE:
                        act = random.choice(can); me['used'].add(act)
                    me['last'] = act != 'dmg'
                if not (me['st'] and me['st'][0] == 'clumsy' and random.random() < 1 / 3):       # skluz: třetina tahů přijde nazmar
                    if act == 'dmg':
                        power = 10 if side == 'player' else (me['dmg'][0] if policy == 'first' else random.choice(me['dmg']))
                        other['hp'] -= max(1, round(power * me['atk'] / other['df']))
                    elif act == 'saucy': me['st'] = ['saucy', 3]
                    else: other['st'] = ['clumsy', 3]
                if over(): break
                if me['st'] and me['st'][0] == 'saucy': me['hp'] = min(me['max'], me['hp'] + 5)   # omáčka: +5 po vlastním tahu
                if me['st']:
                    me['st'][1] -= 1
                    if me['st'][1] == 0: me['st'] = None
        if all(x['hp'] <= 0 for x in theirs):
            wins += 1; left += sum(max(0, x['hp']) for x in mine) / sum(x['max'] for x in mine)
        rounds_sum += rounds
    return round(100 * wins / n), round(rounds_sum / n, 1), round(100 * left / max(1, wins))

CASES = [  # (kdo, jeho bojovníci, úrovně hráčových pizz)
    ('Erio', [pizza('f001', 1, 20), pizza('s002', 1, 30)], [1]),
    ('Don Broccolini', [pizza('f002', 5, 45), pizza('v002', 5, 50), pizza('v001', 6, 60)], [5, 3, 2]),
    ('Sesame (uličky 5)', [burger('b009', 4, -8), burger('b005', 4, -8), burger('b009', 4, -8)], [6, 4, 4]),
    ('Tray (uličky 19)', [burger('b003', 8), burger('b001', 8)], [9, 7, 7]),
    ('Double (uličky 20)', [burger('b004', 8), burger('b002', 9, 6), burger('b010', 9, 12)], [10, 7, 7]),
    ('Steak (věž 20)', [burger('b004', 14), burger('b002', 14, 6)], [13, 10, 9]),
    ('Burger Queen', [burger('b002', 16, 8), burger('b010', 17, 20)], [15, 12, 11]),
    ('Burger Queen', [burger('b002', 16, 8), burger('b010', 17, 20)], [16, 12, 12]),
    ('Pizzové monstrum v doupěti', [pizza('lair', 18, 180)], [14, 11, 10]),
    ('Pizzové monstrum v doupěti', [pizza('lair', 18, 180)], [16, 12, 12]),
]
if __name__ == '__main__':
    random.seed(5)
    print('%-28s %-13s %-34s %s' % ('soupeř', 'hráč (úrovně)', 'first: výher, kol, zbyde životů', 'mild: výher, kol, zbyde životů'))
    for name, team, levels in CASES:
        a, b = fight(team, levels, 'first'), fight(team, levels, 'mild')
        print('%-28s %-13s %3d %%  %5.1f  %3d %%                %3d %%  %5.1f  %3d %%' % (name, levels, *a, *b))
