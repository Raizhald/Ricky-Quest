# Kreslí dvě pizzy, které se dají vylovit jen ve stokách (rybaření): images/characters/pizzas/d001.png (Špinavá Margherita)
# a m001.png (Bahnitá Šunkovka). Tvar kotouče (18 x 18 px na pozici 7, 12 ve čtverci 32 x 32) je převzatý z Zvadlé Zahrádky (v002),
# takže sedí k ostatním pizzám a ke stínu pod nimi.
# Spuštění z kořene projektu:  python3 tools/bahno.py      (potřebuje Pillow; jde pouštět opakovaně, náhodu drží pevný semínko)
from PIL import Image
import os
import random

P = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'images', 'characters', 'pizzas') + os.sep


def c(h, a=255):
    return (int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16), a)


# kotouč převezmeme ze Zvadlé Zahrádky: co není průhledné, patří pizze
ref = Image.open(P + 'v002.png').convert('RGBA')
OX, OY, S = 7, 12, 18
mask = {(x, y) for y in range(S) for x in range(S) if ref.getpixel((OX + x, OY + y))[3] > 0}


def ring(x, y):
    """0 = obrys, 1 = kůrka, 2 = vnitřek (podle vzdálenosti od okraje kotouče)."""
    for depth in range(0, 3):
        for dx in range(-1, 2):
            for dy in range(-1, 2):
                if (x + dx * (depth + 1), y + dy * (depth + 1)) not in mask:
                    return depth
    return 2


def blob(rng, cx, cy, r, color_a, color_b, put):
    """Hrudka: kolečko s tmavším spodkem a světlejším vrškem (jako bahno na světle)."""
    for y in range(cy - r, cy + r + 1):
        for x in range(cx - r, cx + r + 1):
            if (x - cx) ** 2 + (y - cy) ** 2 <= r * r + 1 and (x, y) in mask and ring(x, y) == 2:
                put(x, y, color_a if y >= cy else color_b)


def make(name, draw_inside, crust, outline):
    im = Image.new('RGBA', (32, 32), (0, 0, 0, 0))
    px = im.load()
    board = {}

    def put(x, y, col):
        if (x, y) in mask:
            board[(x, y)] = col

    for (x, y) in mask:
        r = ring(x, y)
        if r == 0:
            board[(x, y)] = outline
        elif r == 1:
            board[(x, y)] = crust[(x + y) % len(crust)]
    draw_inside(put)
    for (x, y), col in board.items():
        px[OX + x, OY + y] = col
    im.save(P + name)


# ---------------------------------------------------------------- Špinavá Margherita: vybledlá, zašedlá, flek a tečky špíny
def dirty(put):
    rng = random.Random(7)
    base = [c('#d8d2a4'), c('#cfc89a'), c('#c4bd8e')]
    for (x, y) in mask:
        if ring(x, y) == 2:
            put(x, y, base[(x * 3 + y * 5) % 3])
    # tři rajčata, přidušená špínou
    for (cx, cy) in [(6, 6), (11, 8), (8, 12)]:
        blob(rng, cx, cy, 1, c('#8a2e26'), c('#b4463a'), put)
    # lístky bazalky, uvadlé
    for (x, y) in [(9, 5), (5, 10), (12, 12), (10, 10), (4, 7)]:
        put(x, y, c('#4d6b3a'))
        put(x + 1, y, c('#3a5230'))
    # velké hnědošedé fleky
    for (cx, cy, r) in [(5, 5, 2), (12, 6, 2), (9, 9, 2), (6, 13, 1)]:
        blob(rng, cx, cy, r, c('#6e6246'), c('#857a5a'), put)
    # drobná špína, jak by ji někdo rozsypal
    for _ in range(14):
        x, y = rng.randrange(S), rng.randrange(S)
        if (x, y) in mask and ring(x, y) == 2:
            put(x, y, rng.choice([c('#4a4234'), c('#5c523c'), c('#2f2a20')]))


# ---------------------------------------------------------------- Bahnitá Šunkovka: rajčatový základ, hnědé hrudky bahna s lesklými okraji
def muddy(put):
    rng = random.Random(21)
    base = [c('#c2542f'), c('#b84a28'), c('#cc6038')]
    for (x, y) in mask:
        if ring(x, y) == 2:
            put(x, y, base[(x * 5 + y * 3) % 3])
    # kousky šunky
    for (cx, cy) in [(5, 6), (12, 5), (7, 11), (12, 12)]:
        for dx in (0, 1):
            put(cx + dx, cy, c('#e58d8d'))
            put(cx + dx, cy + 1, c('#c96a6e'))
    # hrudky bahna: tmavý spodek, světlý hřbet, úplně nahoře lesklý bod
    for (cx, cy, r) in [(6, 8, 2), (11, 8, 2), (9, 5, 1), (8, 12, 2), (13, 11, 1), (4, 12, 1)]:
        blob(rng, cx, cy, r, c('#4d3a22'), c('#7d6137'), put)
        put(cx - 1, cy - 1, c('#b69a68'))
    # zelené chuchvalce řas na bahně
    for (x, y) in [(5, 7), (12, 7), (9, 13), (7, 5)]:
        put(x, y, c('#4e7a3a'))
        put(x + 1, y + 1, c('#3b5e2c'))
    # kapky a drobné hrudky okolo
    for _ in range(12):
        x, y = rng.randrange(S), rng.randrange(S)
        if (x, y) in mask and ring(x, y) == 2:
            put(x, y, rng.choice([c('#5c4527'), c('#7d6137'), c('#3b2c18')]))


OUT = c('#3a160d')
make('d001.png', dirty, [c('#6e5a3a'), c('#7b6641'), c('#5e4c2f')], OUT)
make('m001.png', muddy, [c('#8a5a2c'), c('#6d4521'), c('#7d4f27')], OUT)

# náhled: obě pizzy vedle ostatních, 4x zvětšené
names = ['v002', 'f002', 'c001', 'd001', 'm001']
sheet = Image.new('RGBA', (len(names) * 40, 40), (118, 136, 128, 255))
for i, n in enumerate(names):
    sheet.alpha_composite(Image.open(P + n + '.png').convert('RGBA'), (i * 40 + 4, 4))
sheet.resize((sheet.width * 4, sheet.height * 4), Image.NEAREST).save(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bahno-nahled.png'))
print('hotovo: d001.png, m001.png, tools/bahno-nahled.png')
