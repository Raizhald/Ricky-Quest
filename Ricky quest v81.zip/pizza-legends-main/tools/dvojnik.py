# Kreslí kuchaře, kteří vypadají skoro stejně jako hrdina a léčí pizzy a burgery:
#   images/characters/people/npc50.png   Nicky ze Zadních uliček (světlé vlasy, zelený obrys)
#   images/characters/people/npc78.png   Micky před Burger Tower (zrzavé vlasy, tmavomodrý obrys)
# a náhled tools/dvojnici-nahled.png (hrdina a oba vedle sebe).
# Spuštění z kořene projektu:  python3 tools/dvojnik.py      (potřebuje Pillow; jde pouštět opakovaně)
#
# Každý je obrázek hrdiny (images/characters/people/hero.png) s několika přebarvenými barvami: vlasy, obrys těla
# a stín čepice a oblečení. Všechno ostatní (tvar, chůze) je stejné. Další dvojník = další položka ve VARIANTS.
from PIL import Image
import os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, 'images', 'characters', 'people') + os.sep


def c(h):
    return (int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16))


HAIR = ('#8f563b', '#7f462b', '#6e402b', '#693116', '#4a1e09')       # the hero's hair, light to dark
OUTLINE = ('#4e0d1f', '#4e0e1f', '#501021')                          # the outline of the body (maroon)
SHADE = ('#e5e9ff', '#cbdbfc', '#bfc4e2', '#6c7196')                 # the shade of the hat and of the clothes (bluish)
VARIANTS = {
    'npc50': dict(hair=('#f0cf5e', '#e0b64a', '#d9a93a', '#b8862a', '#8a5a10'), outline='#0f4a34',         # Nicky: blond, green
                  shade=('#e5fff0', '#cbfce0', '#bfe2cc', '#6c9680')),
    'npc78': dict(hair=('#e8663a', '#d9532c', '#c24424', '#9a3018', '#5e1a0a'), outline='#1e2151',         # Micky: ginger, navy
                  shade=('#fff6e5', '#fce9cb', '#e2d6bf', '#96846c')),
}

hero = Image.open(SRC + 'hero.png').convert('RGBA')
made = []
for name, look in VARIANTS.items():
    swap = {}
    for a, b in zip(HAIR, look['hair']): swap[c(a)] = c(b)
    for a in OUTLINE: swap[c(a)] = c(look['outline'])
    for a, b in zip(SHADE, look['shade']): swap[c(a)] = c(b)
    im = hero.copy()
    px = im.load()
    for y in range(im.height):
        for x in range(im.width):
            r, g, b, a = px[x, y]
            if a and (r, g, b) in swap: px[x, y] = swap[(r, g, b)] + (a,)
    im.save(SRC + name + '.png')
    made.append(im)

# náhled: hrdina a dvojníci, pohled dolů a doprava
sheets = [hero] + made
prev = Image.new('RGBA', (len(sheets) * 64 + 8, 40), (181, 193, 195, 255))
for n, sheet in enumerate(sheets):
    prev.alpha_composite(sheet.crop((0, 0, 32, 32)), (4 + n * 64, 4))
    prev.alpha_composite(sheet.crop((0, 32, 32, 64)), (4 + n * 64 + 30, 4))
prev.resize((prev.width * 6, prev.height * 6), Image.NEAREST).save(os.path.join(ROOT, 'tools', 'dvojnici-nahled.png'))
print('images/characters/people/npc50.png, npc78.png, tools/dvojnici-nahled.png')
