# Kreslí nápis na titulní obrazovce do images/logo.png: nahoře malé slovo, pod ním velké (teď RICKY a QUEST).
# Spuštění z kořene projektu:  python3 tools/logo.py      (potřebuje Pillow)
# Kuchař s pálkou pod nápisem zůstává, jak je; překresluje se jen horní část obrázku (řádky 0 až 32).
# Písmo je stejné jako v původním nápisu PIZZA LEGENDS: malé 5x7 s tahem 1 px, velké 7x11 s tahem 3 px.
# Jiný nápis = změnit SMALL a BIG dole; písmena, která ve slovnících chybí, je potřeba dokreslit.
from PIL import Image
import os
PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'images', 'logo.png')
def c(h): return (int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16), 255)
OUTLINE = c('#222034')

SMALL_FONT = {   # 7 rows; the top row is white, the rest pale, and a blue line runs under the bottom row
    'P': ["XXXXX", "X...X", "X...X", "XXXXX", "X....", "X....", "X...."],
    'I': ["X", "X", "X", "X", "X", "X", "X"],
    'Z': ["XXXXX", "....X", "...X.", "..X..", ".X...", "X....", "XXXXX"],
    'A': ["XXXXX", "X...X", "X...X", "XXXXX", "X...X", "X...X", "X...X"],
    'R': ["XXXXX", "X...X", "X...X", "XXXXX", "X.X..", "X..X.", "X...X"],
    'C': ["XXXXX", "X....", "X....", "X....", "X....", "X....", "XXXXX"],
    'K': ["X...X", "X..X.", "X.X..", "XX...", "X.X..", "X..X.", "X...X"],
    'Y': ["X...X", "X...X", "X...X", "XXXXX", "..X..", "..X..", "..X.."],
}
BIG_FONT = {     # 11 rows, yellow at the top and orange at the bottom; Q has a tail of two more rows
    'L': ["XXX...."] * 8 + ["XXXXXXX"] * 3,
    'E': ["XXXXXX"] * 3 + ["XXX..."] + ["XXXXXX"] * 3 + ["XXX..."] + ["XXXXXX"] * 3,
    'G': ["XXXXXXX"] * 3 + ["XXX...."] * 2 + ["XXX.XXX"] * 3 + ["XXXXXXX"] * 3,
    'N': ["XXXXXX."] + ["XXXXXXX"] * 2 + ["XXX.XXX"] * 8,
    'D': ["XXXXXX."] + ["XXXXXXX"] * 2 + ["XXX.XXX"] * 5 + ["XXXXXXX"] * 3,
    'S': ["XXXXXXX"] * 3 + ["XXX...."] + ["XXXXXXX"] * 3 + ["....XXX"] + ["XXXXXXX"] * 3,
    'Q': ["XXXXXXX"] * 3 + ["XXX.XXX"] * 5 + ["XXXXXXX"] * 3 + [".....XXX", ".....XXX"],
    'U': ["XXX.XXX"] * 8 + ["XXXXXXX"] * 3,
    'T': ["XXXXXXX"] * 3 + ["..XXX.."] * 8,
}
SMALL_ROWS = [c('#ffffff')] + [c('#cdd8db')] * 6
BIG_ROWS = [c('#f9d339')] + [c('#fafda4')] * 2 + [c('#f9d339')] * 3 + [c('#f39646')] * 4 + [c('#f9d339')] + [c('#f39646')] * 2

SMALL, BIG = 'RICKY', 'QUEST'
SMALL_Y, BIG_Y = 8, 19               # top row of each word

im = Image.open(PATH).convert('RGBA')
px = im.load()
for y in range(0, 33):
    for x in range(im.width):
        px[x, y] = (0, 0, 0, 0)

def width(text, font, gap):
    return sum(min(len(r) for r in font[ch]) for ch in text) + gap * (len(text) - 1)
def write(text, font, rows, y0, gap):
    x = (im.width - width(text, font, gap)) // 2
    drawn = set()
    for ch in text:
        for r, row in enumerate(font[ch]):
            for i, on in enumerate(row):
                if on == 'X':
                    px[x + i, y0 + r] = rows[r]; drawn.add((x + i, y0 + r))
        x += min(len(r) for r in font[ch]) + gap
    return drawn

small = write(SMALL, SMALL_FONT, SMALL_ROWS, SMALL_Y, 1)
for (x, y) in list(small):           # the blue line under the small word
    if y == SMALL_Y + 6:
        px[x, y + 1] = c('#347f93'); small.add((x, y + 1))
big = write(BIG, BIG_FONT, BIG_ROWS, BIG_Y, 2)

def outline(pixels, extra_below=0):
    """A dark line around the letters (corners included); the big word gets a second row below it."""
    edge = set()
    for (x, y) in pixels:
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                edge.add((x + dx, y + dy))
                for e in range(1, extra_below + 1):
                    if y == BIG_Y + 10: edge.add((x + dx, y + dy + e))
    for (x, y) in edge - pixels:
        if 0 <= x < im.width and 0 <= y < 33 and px[x, y][3] == 0:
            px[x, y] = OUTLINE
outline(small)
outline(big, extra_below=1)
im.save(PATH)
print('images/logo.png')
