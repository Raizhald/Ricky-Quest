# Kreslí vnitřek železářství na náměstíčku pod Burger Tower (mapa Hardware):
#   images/maps/HardwareLower.png, HardwareUpper.png, HardwareBattle.png
#   Content/hardware.js  (mřížka a místa pro OverWorldMap.js - NEUPRAVOVAT RUČNĚ, přepíše se)
#   tools/zelezarstvi-nahled.png (celá místnost i s Hankem, jen na koukání)
# Spuštění z kořene projektu:  python3 tools/zelezarstvi.py      (potřebuje Pillow; jde pouštět opakovaně)
#
# Malý krám: modrošedé stěny jako dům zvenku, prkenná podlaha, vzadu dlouhý pult a za ním Hank (stojí v koutě, kam se
# hrdina nedostane, mluví se s ním přes pult). Rozmístění je v ROWS jako text, jeden znak = jedna dlaždice:
#   # zeď   . podlaha   C pult   S regál s barvami (tři dlaždice vedle sebe = jeden kus)   T stůl se zbožím (dvě dlaždice)
#   t kbelík s lopatou a hráběmi   b sud s hřebíky   k bedna   L štafle
#   v zadní zdi:  P děrovaná deska s nářadím   W okno   K hodiny
# První verze (v70) se uživateli nelíbila, věci v ní vypadaly useknuté. Proto platí:
#   - každá věc je nakreslená celá a s okrajem uvnitř svých dlaždic (nic nekončí na hraně obrázku),
#   - věci nestojí těsně nad sebou (spodní by horní zakryla), skript to hlídá,
#   - před deskou, oknem a hodinami na zdi nic nestojí, takže jsou vidět celé (jen Hank stojí pod deskou).
from PIL import Image
import os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P = os.path.join(ROOT, 'images', 'maps') + os.sep
T = 16
ROWS = [
    "#PPPP#WW#K####",
    "#.......C.SSS#",
    "#CCCCCCCC....#",
    "#...........L#",
    "#........TT..#",
    "#............#",
    "#bb........tk#",
    "######.#######",
]
ROW0 = 3
W, H = len(ROWS[0]), ROW0 + len(ROWS) + 1
OWNER = (3, 4, 'down')                 # Hank, behind the counter
WALKABLE = '.'
SPOTS = 'CPWKSTtbkL'                   # things with a line of text (the texts are in OverWorldMap.js)

def c(h, a=255): return (int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16), a)
OUT = c('#1f3f4a')                     # the outline of the store outside
K = c('#222034')
WALL_TOP, WALL_HI, WALL_FACE, WALL_RIB, WALL_BASE = c('#cfe0e6'), c('#e6f1f4'), c('#8fb3c1'), c('#7fa5b4'), c('#557d8e')
PLANK = (c('#c79f72'), c('#bd9468'), c('#a67d54'))
WOOD = dict(out=c('#5c3b1f'), top=c('#d9b27c'), hi=c('#e8c998'), face=c('#b3854c'), dk=c('#9a6f3c'))
METAL = {'k': K, 'L': c('#d4dbe3'), 'M': c('#a3afbd'), 's': c('#75808f')}

def sprite(rows, pal):
    im = Image.new('RGBA', (len(rows[0]), len(rows)), (0, 0, 0, 0))
    p = im.load()
    for y, row in enumerate(rows):
        assert len(row) == len(rows[0]), row
        for x, ch in enumerate(row):
            if ch != '.': p[x, y] = pal[ch]
    return im
def R(im, x0, y0, x1, y1, col):
    p = im.load()
    for y in range(max(0, y0), min(im.height - 1, y1) + 1):
        for x in range(max(0, x0), min(im.width - 1, x1) + 1): p[x, y] = col
def boxed(w, h, body, top=None, top_h=0, out=K):
    im = Image.new('RGBA', (w, h), out)
    R(im, 1, 1, w - 2, h - 2, body)
    if top: R(im, 1, 1, w - 2, top_h, top); R(im, 1, top_h + 1, w - 2, top_h + 1, out)
    return im

# ---------------------------------------------------------------- věci
DARK, BOARD, BOARD_HI, BACK = c('#5c3b1f'), c('#b3854c'), c('#d9b27c'), c('#7a5230')
CANS = (c('#c8443a'), c('#5b6ee1'), c('#f7d95a'), c('#7fc241'), c('#f3f0e8'), c('#f08a2e'), c('#5fa8f0'), c('#a3afbd'))
def can(im, x, y, col):
    """A paint can 5 wide and 6 tall, its lid on top."""
    R(im, x, y, x + 4, y + 5, K); R(im, x + 1, y + 1, x + 3, y + 4, col); R(im, x + 1, y, x + 3, y, c('#d4dbe3')); R(im, x + 3, y + 1, x + 3, y + 4, tuple(int(v * 0.8) for v in col[:3]) + (255,))
# the shelf unit, three tiles wide in one piece: two shelves of paint cans and a row of boxes at the bottom
S_SHELF = Image.new('RGBA', (46, 30), (0, 0, 0, 0))
R(S_SHELF, 0, 0, 45, 29, DARK); R(S_SHELF, 1, 1, 44, 2, BOARD_HI); R(S_SHELF, 2, 4, 43, 27, BACK); R(S_SHELF, 1, 28, 44, 28, BOARD)
for y in (11, 20): R(S_SHELF, 1, y, 44, y, BOARD_HI); R(S_SHELF, 1, y + 1, 44, y + 1, DARK)
for row, y in enumerate((5, 14)):
    for i in range(7): can(S_SHELF, 3 + i * 6, y, CANS[(i * 3 + row * 5) % len(CANS)])
for i, (w, col) in enumerate(((9, c('#d9b27c')), (11, c('#c8443a')), (8, c('#d9b27c')), (10, c('#5b6ee1')))):     # boxes
    x = 3 + sum((9, 11, 8, 10)[:i]) + i
    R(S_SHELF, x, 22, x + w - 1, 27, K); R(S_SHELF, x + 1, 23, x + w - 2, 26, col); R(S_SHELF, x + 2, 24, x + w - 3, 24, c('#f3f0e8'))
# a table with goods on it, two tiles wide: a red tool box, a coil of rope, two cans
S_TABLE = Image.new('RGBA', (30, 21), (0, 0, 0, 0))
R(S_TABLE, 0, 8, 29, 13, DARK); R(S_TABLE, 1, 9, 28, 12, BOARD_HI); R(S_TABLE, 1, 12, 28, 12, BOARD)
R(S_TABLE, 1, 14, 28, 17, DARK); R(S_TABLE, 2, 14, 27, 16, BOARD)
for x in (2, 25): R(S_TABLE, x, 18, x + 2, 20, DARK)
R(S_TABLE, 3, 2, 12, 9, K); R(S_TABLE, 4, 4, 11, 8, c('#c8443a')); R(S_TABLE, 4, 5, 11, 5, c('#8a2420')); R(S_TABLE, 6, 0, 9, 2, K); R(S_TABLE, 7, 1, 8, 2, (0, 0, 0, 0)); R(S_TABLE, 7, 6, 8, 6, c('#f7d95a'))
R(S_TABLE, 14, 4, 20, 9, K); R(S_TABLE, 15, 5, 19, 8, c('#e2b051')); R(S_TABLE, 16, 6, 18, 7, K); R(S_TABLE, 15, 6, 19, 6, c('#c9963a'))
can(S_TABLE, 22, 4, CANS[1]); can(S_TABLE, 24, 3, CANS[3])
# a bucket with a shovel and a rake standing in it
TP = {'k': K, 'W': c('#d9b27c'), 'g': c('#a3afbd'), 'G': c('#d4dbe3'), 'M': c('#75808f'), 'm': c('#5c6675')}
S_BUCKET = sprite([
    "..kkkkk.......", ".kGGGGGk......", ".kGgggGk.kkkkk", ".kGgggGk.kgkgk", ".kkgggkk.kgkgk", "..kkgkk..kkkkk", "...kWk....kWk.",
    "...kWk....kWk.", "...kWk....kWk.", "...kWk....kWk.", "...kWk....kWk.", "...kWk....kWk.", "...kWk....kWk.", "...kWk....kWk.",
    "...kWk....kWk.", "...kWk....kWk.", "..kkkkkkkkkkk.", ".kGGGGGGGGGGGk", ".kgggggggggggk", ".kkgggggggggkk", "..kgMgggggMgk.",
    "..kgMgggggMgk.", "..kgggggggggk.", "..kkmmmmmmmkk.", "...kkkkkkkkk.."], TP)
# a barrel full of nails
BP = {'k': c('#3a2413'), 'A': c('#b3854c'), 'a': c('#96652f'), 'i': c('#75808f'), 'I': c('#a3afbd'), 'n': c('#d4dbe3'), 'N': c('#8a9aa0')}
S_BARREL = sprite([
    "...kkkkkkkk...", ".kkNnNnNnNnkk.", "kANnNnNnNnNnAk", "kAAnNnNnNnNAAk", "kkAAAAAAAAAAkk", "kIkkkkkkkkkkIk", "kiIIIIIIIIIIik",
    "kAaAAaAAaAAaAk", "kAaAAaAAaAAaAk", "kAaAAaAAaAAaAk", "kAaAAaAAaAAaAk", "kAaAAaAAaAAaAk", "kiIIIIIIIIIIik", "kkiiiiiiiiiikk",
    ".kAaAAaAAaAAk.", ".kkaAAaAAaAkk.", "...kkkkkkkk..."], BP)
# a closed wooden crate
CR = {'k': c('#5c3b1f'), 'T': c('#e8c998'), 't': c('#d9b27c'), 'F': c('#b3854c'), 'f': c('#9a6f3c')}
S_CRATE = sprite([
    "kkkkkkkkkkkkkk", "kTTTTTTTTTTTTk", "kttttttttttttk", "kkkkkkkkkkkkkk", "kFFFFFkkFFFFFk", "kFfFFFkkFFFfFk", "kFFFFFkkFFFFFk",
    "kFFFFFkkFFFFFk", "kFFFFFkkFFFFFk", "kFfFFFkkFFFfFk", "kFFFFFkkFFFFFk", "kffffffkfffffk", "kkkkkkkkkkkkkk"], CR)
# a stepladder
LP = {'k': K, 'y': c('#f7d95a'), 'Y': c('#e09a1c'), 'g': c('#a3afbd')}
S_LADDER = sprite([
    "....kkkkkk....", "....kyyyyk....", "...kkkkkkkk...", "...kYk..kYk...", "...kYkkkkYk...", "...kYyyyyYk...", "..kkYkkkkYkk..",
    "..kYk....kYk..", "..kYk....kYk..", "..kYkkkkkkYk..", "..kYyyyyyyYk..", ".kkYkkkkkkYkk.", ".kYk......kYk.", ".kYk......kYk.",
    ".kYkkkkkkkkYk.", ".kYyyyyyyyyYk.", "kkYkkkkkkkkYkk", "kYk........kYk", "kYk........kYk", "kYk........kYk", "kgk........kgk", "kkk........kkk"], LP)
ARROW = sprite(["...kkkkkk...", "...kWWWWk...", "...kWWWWk...", "kkkkWWWWkkkk", "kWWWWWWWWWWk", ".kWWWWWWWWk.", "..kWWWWWWk..", "...kWWWWk...",
                "....kWWk....", ".....kk....."], {'k': c('#a39c8e'), 'W': c('#f4f1ea')})
# the tools on the pegboard (silhouettes like in the shop window outside, in colour)
TOOL = {'k': K, 'g': c('#a3afbd'), 'G': c('#d4dbe3'), 'w': c('#b3854c'), 'W': c('#d9b27c'), 'r': c('#c8443a'), 'R': c('#e35969'), 'y': c('#f7d95a'), 'b': c('#5b6ee1')}
HAMMER = sprite(["kkkkkkk.", "kGGGGGk.", "kgggggk.", "kkkWkkk.", "..kWk...", "..kWk...", "..kwk...", "..kwk...", "..kwk...", "..kkk..."], TOOL)
WRENCH = sprite(["kk.kk", "kGkGk", "kGGGk", ".kgk.", ".kgk.", ".kgk.", ".kgk.", ".kgk.", ".kgk.", ".kkk."], TOOL)
PLIERS = sprite(["kk...kk", "kGk.kGk", ".kGkGk.", "..kGk..", ".kgkgk.", ".krkrk.", "kRk.kRk", "krk.krk", "krk.krk", "kkk.kkk"], TOOL)
SAW = sprite(["kkkkkkkkkkkkk.", "kGGGGGGGGGGGkk", "kgkgkgkgkgkWWk", ".k.k.k.k.kkWWk", "..........kkkk"], TOOL)
DRIVER = sprite([".kk.", "kyyk", "kyyk", "kyyk", ".kk.", ".kg.", ".kg.", ".kg.", ".kg.", ".kk."], TOOL)
TAPE = sprite([".kkkkk.", "kbbbbbk", "kbkkkbk", "kbkGkbk", "kbkkkbk", "kbbbbbk", ".kkkkk."], TOOL)
PLIERS_FLAT = sprite(["kkk...kkkkk", "kGGkk.krrrk", ".kkGGkkkkkk", "...kGGk....", ".kkGGkkkkkk", "kGGkk.krrrk", "kkk...kkkkk"], TOOL)     # lying on the counter


def draw():
    lower = Image.new('RGBA', (W * T, H * T), (0, 0, 0, 0))
    upper = Image.new('RGBA', (W * T, H * T), (0, 0, 0, 0))
    px = lower.load()
    at = lambda x, y: ROWS[y - ROW0][x] if 0 <= x < W and 0 <= y - ROW0 < len(ROWS) else '#'
    free = lambda x, y: at(x, y) in WALKABLE and y > ROW0
    cells = {(x, y): at(x, y) for y in range(ROW0, ROW0 + len(ROWS)) for x in range(W)}
    last = ROW0 + len(ROWS) - 1
    def rect(x0, y0, x1, y1, col): R(lower, x0, y0, x1, y1, col)
    def blend(x, y, col, a):
        if not (0 <= x < W * T and 0 <= y < H * T): return
        r, g, b, al = px[x, y]
        if al: px[x, y] = (round(r * (1 - a) + col[0] * a), round(g * (1 - a) + col[1] * a), round(b * (1 - a) + col[2] * a), 255)
    def commit(tmp, footprint):
        """Whatever of a drawn thing lies over a tile the hero can stand on goes to the upper layer."""
        tp = tmp.load(); up = upper.load()
        box = tmp.getbbox()
        if not box: return
        for y in range(box[1], box[3]):
            for x in range(box[0], box[2]):
                if tp[x, y][3] == 0: continue
                tile = (x // T, y // T)
                if tile not in footprint and free(*tile): up[x, y] = tp[x, y]
                else: px[x, y] = tp[x, y]
    def stamp(sp, tx, ty, wide=1, dy=0):
        tmp = Image.new('RGBA', lower.size, (0, 0, 0, 0))
        x = tx * T + (wide * T - sp.width) // 2
        y = ty * T + T - sp.height + dy
        assert x >= tx * T and x + sp.width <= (tx + wide) * T, 'věc je širší než její dlaždice'
        for i in range(x + 1, x + sp.width - 1): blend(i, ty * T + T - 1 + dy, K, 0.22)
        tmp.alpha_composite(sp, (x, y))
        commit(tmp, {(tx + i, ty) for i in range(wide)})

    # ---- the plank floor
    A, B, seam = PLANK
    for (tx, ty), ch in cells.items():
        if ty == ROW0 or ch == '#': continue
        for y in range(T):
            for x in range(T):
                gx, gy = tx * T + x, ty * T + y
                board = gy // 8
                px[gx, gy] = seam if gy % 8 == 0 or (gx + board * 11) % 32 == 0 else (A, B)[board % 2]
    # ---- the walls: the top (two tiles), the ribbed face (one tile), the outline of the room
    x0, x1 = T, (W - 1) * T - 1
    rect(x0, T, x1, 3 * T - 1, WALL_TOP); rect(x0, 3 * T, x1, 4 * T - 1, WALL_FACE)
    for y in range(3 * T + 3, 4 * T - 2, 4): rect(x0, y, x1, y, WALL_RIB)
    rect(x0, 3 * T, x1, 3 * T, WALL_HI); rect(x0, 4 * T - 2, x1, 4 * T - 2, WALL_BASE); rect(x0, 4 * T - 1, x1, 4 * T - 1, OUT)
    rect(x0 - 1, T - 1, x1 + 1, T - 1, OUT)
    rect(x0 - 1, T - 1, x0 - 1, last * T + 2, OUT); rect(x1 + 1, T - 1, x1 + 1, last * T + 2, OUT)
    for x in range(x0, x1 + 1): blend(x, 4 * T, K, 0.3); blend(x, 4 * T + 1, K, 0.15)
    exits = [x for x in range(W) if at(x, last) in WALKABLE]
    for x in range(x0, x1 + 1):
        if x // T in exits: continue
        px[x, last * T] = WALL_HI; px[x, last * T + 1] = WALL_BASE; px[x, last * T + 2] = OUT
    for tx in exits:
        for y in range(last * T, last * T + T - 3):                 # a door mat with the arrow on it
            for x in range(tx * T, tx * T + T): px[x, y] = c('#8f9a8a') if (x + y) % 2 else c('#839080')
        lower.alpha_composite(ARROW, (tx * T + 2, last * T + 2))
        for x in range(tx * T, tx * T + T): px[x, last * T + T - 3] = WALL_HI; px[x, last * T + T - 2] = WALL_BASE; px[x, last * T + T - 1] = OUT
        for y in range(last * T, last * T + T): px[tx * T - 1, y] = OUT; px[tx * T + T, y] = OUT

    # ---- things on the back wall
    board = [x for x in range(W) if at(x, ROW0) == 'P']
    if board:                                                       # the pegboard: holes in rows, two rows of tools hanging on it
        bx0, bx1 = board[0] * T + 2, board[-1] * T + T - 3
        by0, by1 = T + 4, 3 * T - 2
        rect(bx0, by0, bx1, by1, c('#5c3b1f')); rect(bx0 + 1, by0 + 1, bx1 - 1, by1 - 1, c('#d9b27c')); rect(bx0 + 1, by1 - 1, bx1 - 1, by1 - 1, c('#b3854c'))
        for y in range(by0 + 3, by1 - 1, 4):
            for x in range(bx0 + 3, bx1 - 1, 4): px[x, y] = c('#b3854c')
        for sp, dx in ((HAMMER, 3), (WRENCH, 13), (PLIERS, 20), (SAW, 30), (DRIVER, 47), (TAPE, 52)):
            lower.alpha_composite(sp, (bx0 + dx, by0 + 2 + (3 if sp is SAW else 0)))
        for sp, dx in ((DRIVER, 4), (DRIVER, 10), (HAMMER, 16), (PLIERS, 26), (WRENCH, 36), (TAPE, 43), (WRENCH, 53)):
            lower.alpha_composite(sp, (bx0 + dx, by0 + 14))
    win = [x for x in range(W) if at(x, ROW0) == 'W']
    if win:                                                         # one wide window with the daylight of the square in it
        wx0, wx1 = win[0] * T + 2, win[-1] * T + T - 3
        wy0, wy1 = T + 5, 3 * T + 3
        rect(wx0, wy0, wx1, wy1, K); rect(wx0 + 1, wy0 + 1, wx1 - 1, wy1 - 1, c('#f3f0e8'))
        for y in range(wy0 + 2, wy1 - 1):
            for x in range(wx0 + 2, wx1 - 1): px[x, y] = (c('#c4f7ff'), c('#95f0ff'), c('#7ee7f7'), c('#6de1f4'))[((x + y) // 4) % 4]
        mid = (wx0 + wx1) // 2
        rect(mid, wy0 + 2, mid, wy1 - 2, c('#f3f0e8'))
        rect(wx0 - 1, wy1 + 1, wx1 + 1, wy1 + 2, c('#5c3b1f')); rect(wx0 - 1, wy1 + 1, wx1 + 1, wy1 + 1, c('#d9b27c'))
    for tx in range(W):
        if at(tx, ROW0) == 'K':                                     # a round clock
            cx, cy = tx * T + 8, T + 18
            for y in range(cy - 7, cy + 8):
                for x in range(cx - 7, cx + 8):
                    d = ((x - cx + 0.5) ** 2 + (y - cy + 0.5) ** 2) ** 0.5
                    if d <= 7: px[x, y] = K if d > 6 else c('#f3f0e8')
            rect(cx, cy - 4, cx, cy, K); rect(cx, cy, cx + 3, cy, K); px[cx, cy] = c('#c8443a')

    # ---- the counter (a run of tiles), and what lies on it
    tiles = {t for t, ch in cells.items() if ch == 'C'}
    tmp = Image.new('RGBA', lower.size, (0, 0, 0, 0)); tp = tmp.load()
    rise, face_h = 4, 9
    for (tx, ty) in sorted(tiles, key=lambda t: (t[1], t[0])):
        n, s_, w_, e = (tx, ty - 1) in tiles, (tx, ty + 1) in tiles, (tx - 1, ty) in tiles, (tx + 1, ty) in tiles
        gx, gy = tx * T, ty * T
        top = gy - (0 if n else rise); bottom = gy + T - 1
        for y in range(top, bottom + 1):
            for x in range(gx, gx + T):
                col = WOOD['top']
                if not s_ and y > bottom - face_h: col = WOOD['face'] if y < bottom - 1 else WOOD['dk']
                if not s_ and y == bottom - face_h: col = WOOD['out']
                if (not n and y == top) or (not s_ and y == bottom) or (not w_ and x == gx) or (not e and x == gx + T - 1): col = WOOD['out']
                elif not n and y == top + 1: col = WOOD['hi']
                tp[x, y] = col
        if not s_:
            for x in range(gx, gx + T): blend(x, bottom + 1, K, 0.25)
    commit(tmp, tiles)
    # What lies on the counter is drawn the same way as the counter itself: the back edge of the counter top reaches over the
    # tiles behind it and is in the upper layer there, so anything put only into the lower layer would lose its top.
    front = sorted(t for t in tiles if (t[0], t[1] + 1) not in tiles and (t[0], t[1] - 1) not in tiles)     # the long part of the counter
    if front:
        on_top = Image.new('RGBA', lower.size, (0, 0, 0, 0))
        def put(x0, y0, x1, y1, col): R(on_top, x0, y0, x1, y1, col)
        gy = front[0][1] * T
        gx = front[-1][0] * T                                       # the till, near the right end
        put(gx + 2, gy - 8, gx + 13, gy + 3, K); put(gx + 3, gy - 7, gx + 12, gy + 2, c('#75808f')); put(gx + 3, gy - 7, gx + 12, gy - 4, c('#2c3870'))
        put(gx + 5, gy - 6, gx + 10, gy - 5, c('#95f0ff'))
        for i in range(3):
            for j in range(2): put(gx + 4 + i * 3, gy - 2 + j * 2, gx + 5 + i * 3, gy - 2 + j * 2, c('#d4dbe3'))
        gx = front[0][0] * T                                        # a box of screws at the left end
        put(gx + 4, gy - 2, gx + 12, gy + 3, K); put(gx + 5, gy - 1, gx + 11, gy + 2, c('#c8443a')); put(gx + 6, gy, gx + 10, gy, c('#f3f0e8'))
        gx = front[len(front) // 2 + 1][0] * T                      # the pliers Hank has put out, red handles
        on_top.alpha_composite(PLIERS_FLAT, (gx + 2, gy - 2))
        commit(on_top, tiles)

    props = {t for t, ch in cells.items() if ch in 'STtbkL' and t[1] > ROW0}
    for (tx, ty), ch in sorted(cells.items(), key=lambda kv: (kv[0][1], kv[0][0])):
        if ty == ROW0: continue
        if ch == 'S' and at(tx - 1, ty) != 'S': stamp(S_SHELF, tx, ty, wide=3)
        elif ch == 'T' and at(tx - 1, ty) != 'T': stamp(S_TABLE, tx, ty, wide=2, dy=-1)
        elif ch == 't': stamp(S_BUCKET, tx, ty, dy=-1)
        elif ch == 'b': stamp(S_BARREL, tx, ty, dy=-1)
        elif ch == 'k': stamp(S_CRATE, tx, ty, dy=-1)
        elif ch == 'L': stamp(S_LADDER, tx, ty, dy=-1)
    for (tx, ty) in props:                                          # nothing right above another thing: the lower one would cut it off
        if (tx, ty + 1) in props or at(tx, ty + 1) == 'C': print('věc na %s stojí těsně nad jinou' % ((tx, ty),)); sys.exit(1)

    # ---- checks: the way out is there, Hank stands on the floor and cannot be walked up to
    if len(exits) != 1 or not free(exits[0], last - 1): print('východ musí být jeden a mít nad sebou volno'); sys.exit(1)
    start = (exits[0], last - 1)
    seen, todo = {start}, [start]
    while todo:
        x, y = todo.pop()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            n = (x + dx, y + dy)
            if n not in seen and free(*n): seen.add(n); todo.append(n)
    if not free(*OWNER[:2]) or OWNER[:2] in seen: print('Hank má stát za pultem, kam se hrdina nedostane'); sys.exit(1)

    lower.save(P + 'HardwareLower.png')
    upper.save(P + 'HardwareUpper.png')
    # battle background (nobody fights here, but every map has one): the wall and the planks
    bt = Image.new('RGBA', (176, 99), (0, 0, 0, 255)); bp = bt.load()
    for y in range(99):
        for x in range(176):
            if y < 14: col = WALL_TOP
            elif y == 14: col = WALL_HI
            elif y < 17: col = WALL_FACE if y < 16 else OUT
            else:
                gy = y - 17; board = gy // 8
                col = seam if gy % 8 == 0 or (x + board * 11) % 32 == 0 else (A, B)[board % 2]
            bp[x, y] = col
    bt.save(P + 'HardwareBattle.png')

    with open(os.path.join(ROOT, 'Content', 'hardware.js'), 'w', encoding='utf-8') as f:
        f.write('//Vnitřek železářství (mapa Hardware): mřížka a místa, která vypisuje tools/zelezarstvi.py spolu s obrázky.\n')
        f.write('//NEUPRAVOVAT RUČNĚ - rozmístění se mění v tools/zelezarstvi.py, ten tenhle soubor přepíše.\n')
        f.write('window.HardwareGrid = {\n')
        f.write('  exit: [%d, %d], //dveře ven na náměstíčko\n' % (exits[0], last))
        f.write('  owner: [%d, %d, "%s"], //Hank za pultem\n' % OWNER)
        f.write('  spots: [%s], //[x, y, druh věci] s textem\n' % ', '.join('[%d, %d, "%s"]' % (x, y, ch) for (x, y), ch in sorted(cells.items(), key=lambda kv: (kv[0][1], kv[0][0])) if ch in SPOTS))
        f.write('  rows: [\n')
        for y in range(H):
            f.write('    "%s",\n' % ''.join('.' if (ROW0 < y <= last and at(x, y) in WALKABLE) else '#' for x in range(W)))
        f.write('  ]\n}\n')

    both = lower.copy()
    sheet = Image.open(os.path.join(ROOT, 'images', 'characters', 'people', 'npc77.png')).convert('RGBA')
    both.alpha_composite(sheet.crop((0, 0, 32, 32)), (OWNER[0] * T - 8, OWNER[1] * T - 18))
    both.alpha_composite(upper)
    bg = Image.new('RGBA', both.size, (34, 32, 52, 255)); bg.alpha_composite(both)
    bg.resize((bg.width * 3, bg.height * 3), Image.NEAREST).save(os.path.join(ROOT, 'tools', 'zelezarstvi-nahled.png'))
    print('images/maps/HardwareLower.png, HardwareUpper.png, HardwareBattle.png, Content/hardware.js, tools/zelezarstvi-nahled.png')

if __name__ == '__main__':
    draw()
