# Kreslí hernu a plácek před ní: průčelí a ceduli s pálkami na ulici (přímo do images/maps/StreetLower.png,
# kus nad dveřmi a vršek cedule i do StreetUpper.png) a vnitřek
# images/maps/HernaLower.png, HernaUpper.png a HernaBattle.png.
# Spuštění z kořene projektu:  python3 tools/herna.py      (potřebuje Pillow)
# Skript jde pouštět opakovaně: průčelí i dlaždice na plácku pokaždé překreslí celé.
# Vnitřek drží styl původních místností hry (Kitchen): jedna pastelová barva, hladká zeď, šachovnicová dlažba,
# nábytek s měkkým šedým obrysem. Barvy místnosti jsou nahoře v části "vnitřek".
# Automaty a ostatní zařízení se rozmisťují dole voláním cabinet(tx, ...), claw(tx), plant(tx), pad(tx, ty, ...)
# a mat(tx, ty, n) v dlaždicích; po změně je potřeba upravit i mřížku zdí a hotspoty mapy Herna v OverWorldMap.js.
from PIL import Image
import os
P = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'images') + os.sep
def c(h, a=255): return (int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16), a)

def stamp(px, art, pal, x, y):
    """art: rows of characters, '.' is see-through; colours with alpha below 255 are blended in."""
    for r, row in enumerate(art):
        for i, ch in enumerate(row):
            if ch == '.': continue
            col = pal[ch]
            if col[3] < 255:
                bg = px[x + i, y + r]; a = col[3] / 255
                col = tuple(int(bg[k] * (1 - a) + col[k] * a) for k in range(3)) + (255,)
            px[x + i, y + r] = col

# The lettering of the game's own signs (SHOP, TONY BOIII'S, KITCHEN): 3 x 5 pixels, one pixel apart
FONT = {
    'A': ["XXX", "X.X", "XXX", "X.X", "X.X"],
    'R': ["XXX", "X.X", "XX.", "X.X", "X.X"],
    'C': ["XXX", "X..", "X..", "X..", "XXX"],
    'D': ["XX.", "X.X", "X.X", "X.X", "XX."],
    'E': ["XXX", "X..", "XXX", "X..", "XXX"],
}
def word(px, text, x, y, rows, scale=1):
    """rows: the colour of each of the five letter rows, top to bottom."""
    for ch in text:
        for r, row in enumerate(FONT[ch]):
            for i, on in enumerate(row):
                if on != 'X': continue
                for dy in range(scale):
                    for dx in range(scale):
                        px[x + i * scale + dx, y + r * scale + dy] = rows[r]
        x += 4 * scale
NAVY = c('#1e2151')

# ================================================================ průčelí na ulici
# Červený dům mezi schody a hrdinovým domem: čelní stěna x 242..349, y 82..126, dveře na dlaždici (18, 7).
st = Image.open(P + 'maps/StreetLower.png').convert('RGBA')
sp = st.load()
BRICK = c('#cc6e6e'); BRICK_D = c('#ac4343'); BRICK_M = c('#b75252'); LIGHT = c('#f29d87'); OUT = c('#4c1818')
AWN_O = c('#5e2a2a'); AWN_E = c('#592525'); AWN_L = c('#ffc0af'); AWN_S = c('#e1836b'); SILL = c('#ffd8ce')

def srect(x0, y0, x1, y1, col):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            sp[x, y] = col

# the edge of the roof (an older version of the sign reached over it)
srect(256, 76, 350, 79, c('#e37878')); srect(256, 80, 350, 80, OUT); srect(256, 81, 350, 81, LIGHT)
# bare wall (left of the slanted line is the side wall, which stays)
for y in range(82, 127):
    for x in range(max(242, 255 - (y - 82)), 350):
        sp[x, y] = BRICK
srect(242, 97, 349, 97, LIGHT)                                   # ledge
for x0 in (242, 281, 306, 345):                                  # mortar line between the openings
    srect(x0, 112, x0 + 4, 112, BRICK_M)
for bx, by in ((252, 90), (256, 88), (262, 85), (270, 87), (318, 87), (326, 85), (332, 88), (340, 90), (344, 87)):   # loose bricks
    srect(bx, by, bx + 3, by, BRICK_D); srect(bx, by + 1, bx + 3, by + 1, BRICK_M)

# windows: the two the house always had, moved apart to make room for the door
GLASS = [
    "BBBBBBBBBBBBBCCCCCCCCCCCCC", "BDDDDCCCCCEEEEEEEFFFFFGGGG", "BDDDCCCCCEEEEEEFFFFFGGGGGG", "BDCCCCCEEEEEEEFFFFFGGGGGCC",
    "BCCCCCEEEEEEFFFFFFGGGGCCCC", "BCCCEEEEEEEFFFFFGGGGCCCDDD", "BCCEEEEEEFFFFFFGGGCCCCDDDD", "BCCCEEEEEEEFFFFFGGGGCCCDDD",
    "BDDDCCCCCEEEEEEFFFFFGGGGGG", "BDCCCCCEEEEEEEFFFFFGGGGGCC", "BCCCCCEEEEEEFFFFFFGGGGCCCC", "BDDDCCCCCEEEEEEFFFFFGGGGGG",
    "BDCCCCCEEEEEEEFFFFFGGGGGCC", "BCCCCCEEEEEEFFFFFFGGGGCCCC", "BCCCEEEEEEEFFFFFGGGGCCCDDD", "BCCEEEEEEFFFFFFGGGCCCCDDDD",
    "BCCCEEEEEEEFFFFFGGGGCCCDDD", "BCCEEEEEEFFFFFFGGGCCCCDDDD",
]
GLASS_PAL = {'B': c('#e2f9fd'), 'C': c('#95f0ff'), 'D': c('#b3f4ff'), 'E': c('#c4f7ff'), 'F': c('#7ee7f7'), 'G': c('#6de1f4')}
def shop_window(x):
    srect(x + 1, 94, x + 30, 94, AWN_O)
    for y in range(95, 100):
        srect(x + 2, y, x + 28, y, LIGHT)
        sp[x + 1, y] = AWN_E; sp[x + 29, y] = AWN_S; sp[x + 30, y] = AWN_E
    srect(x + 2, 95, x + 27, 95, AWN_L); srect(x + 2, 96, x + 3, 96, AWN_L); sp[x + 2, 97] = AWN_L; sp[x + 2, 98] = AWN_L
    srect(x, 100, x + 31, 100, SILL); sp[x, 100] = OUT; sp[x + 31, 100] = AWN_E
    srect(x, 101, x + 31, 122, OUT); srect(x + 1, 101, x + 30, 121, LIGHT); srect(x + 2, 101, x + 29, 120, OUT)
    srect(x, 123, x + 31, 123, BRICK_M)                            # shadow under the frame
    stamp(sp, GLASS, GLASS_PAL, x + 3, 102)
shop_window(248)
shop_window(312)

# door: the same one the red house next door has (a small canopy over a dark doorway), on tile (18, 7)
DOOR_X = 289                                                      # canopy 14 wide, doorway 12 wide
srect(241, 127, 350, 127, c('#8a3939'))                           # the foot of the wall (an older, bigger door cut into it)
sp[DOOR_X, 106] = c('#8a3939'); sp[DOOR_X + 13, 106] = c('#8a3939')
srect(DOOR_X, 107, DOOR_X + 13, 114, OUT)
srect(DOOR_X + 1, 107, DOOR_X + 12, 108, c('#f7b9a8')); srect(DOOR_X + 1, 109, DOOR_X + 12, 109, LIGHT)
srect(DOOR_X + 1, 110, DOOR_X + 12, 113, BRICK)
srect(DOOR_X + 1, 115, DOOR_X + 12, 127, c('#3d1414'))
for r in range(9):                                                # darker corner, top right
    srect(DOOR_X + 4 + r, 115 + r, DOOR_X + 12, 115 + r, c('#2a0c0c'))
# sign right above the door, made like the SHOP one: white letters on a dark blue plate
SIGN_X, SIGN_Y = 283, 98                                          # plate 25 x 7
srect(SIGN_X, SIGN_Y, SIGN_X + 24, SIGN_Y + 6, NAVY)
word(sp, 'ARCADE', SIGN_X + 1, SIGN_Y + 1, [c('#ffffff'), c('#ffffff'), c('#fffee0'), c('#ffffff'), c('#e8e69c')])

PAVE = {0: c('#a7b5b7'), 1: c('#b5c1c3')}; SEAM = c('#98abae')
def pave(x0, y0, x1, y1):
    """Plain paving again (for rows below the shaded strip along the houses, y >= 130)."""
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            sp[x, y] = SEAM if x % 16 == 0 or y % 16 == 0 else PAVE[(x // 16 + y // 16) % 2]
# no doormats: not in front of the arcade, and the one in front of the hero's house is gone too
pave(288, 130, 303, 137)
pave(368, 130, 383, 137)

# the practice mats I, II, III are inside now: back to plain paving, with the red line running through
for tx in (19, 21, 23):
    for y in range(176, 192):
        for x in range(tx * 16, tx * 16 + 16):
            if y == 190: sp[x, y] = c('#b9331a')
            elif y == 191: sp[x, y] = c('#a6260f')
            elif y == 176 or x % 16 == 0: sp[x, y] = SEAM
            else: sp[x, y] = PAVE[(tx + 11) % 2]

# the board with the two crossed pizza peels is back in the corner of the plaza (the same one stands in the dining room)
SIGN = [
    ".ffffffffffffffffffffffffff.",
    "fggggggggggggggggggggggggggf",
    "fggggggggggggggggggggggggggf",
    "fggggggggggggggggggggggggggf",
    "fggggggggggggggggggggggggggf",
    "fhhhhhhhhhhhhhhhhhhhhhhhhhhf",
    "ijjjjjjjjjjjjjjjjjjjjjjjjjji",
    "ijjjjjkkkkjjjjjjjjkkkkjjjjji",
    "ijjjjkllmmkjjjjjjkmmllkjjjji",
    "ijjjkllllmmkjjjjkmmllllkjjji",
    "ijjkllmmllmmkjjkmmllmmllkjji",
    "ijjklllmlllmkjjkmlllmlllkjji",
    "ijjkmlllmlllkjjklllmlllmkjji",
    "ijjklmlllmlkjjjjklmlllmlkjji",
    "ijjjklmmlllkjjjjklllmmlkjjji",
    "ijjjjkllmkklkjjklkkmllkjjjji",
    "ijjjjjkkkjjklkklkjjkkkjjjjji",
    "ijjjjjjjjjjjkklkjjjjjjjjjjji",
    "ijjjjjjjjjjjnlknjjjjjjjjjjji",
    "iiiiiiiiiiiiiiiiiiiiiiiiiiii",
]
SIGN_PAL = {'f': c('#6e5549'), 'g': c('#dfc2b4'), 'h': c('#f4e0d6'), 'i': c('#4a2918'), 'j': c('#b99f93'), 'k': c('#4a1e09'), 'l': c('#825946'), 'm': c('#966650'), 'n': c('#431a06')}
SIGN_AT = (288, 171)                                              # 28 x 20, on tiles (18, 11) and (19, 11)
stamp(sp, SIGN, SIGN_PAL, *SIGN_AT)
st.save(P + 'maps/StreetLower.png')
# the wall over the doorway goes into the upper picture as well, so that the hero walks in under the canopy
# and the sign instead of over them (the other doors on the street work the same way)
up = Image.open(P + 'maps/StreetUpper.png').convert('RGBA')
up.paste(st.crop((SIGN_X, 97, SIGN_X + 25, 115)), (SIGN_X, 97))
# the top of the board too: whoever stands right behind it has the feet hidden by it
up.paste(st.crop((SIGN_AT[0], SIGN_AT[1], SIGN_AT[0] + 28, 176)), SIGN_AT)
up.save(P + 'maps/StreetUpper.png')

# ================================================================ vnitřek
TW, TH = 13, 12
W, H = TW * 16, TH * 16
X0, X1 = 16, W - 17                  # interior columns 16..191
EXIT = 6                             # tile column of the way out (row 10)
# the room's own colour (Kitchen is lavender, Neon Greens green, this one is turquoise)
EDGE_T = c('#091d32'); EDGE = c('#0b243d')
WALL = c('#a5e2df'); WALL_HI = c('#d3f6f3'); FACE = c('#7dc8c9'); FACE_BASE = c('#62b0b7')
LINE = c('#b1dadb'); T_LIGHT = c('#dbf1ee'); T_DARK = c('#c1e3e3')
BOTTOM_HI = c('#d6f4f1'); BOTTOM_D = c('#5b99a8'); ARROW = c('#86b7bd')
def floor(x, y, y0=0):
    """Checkered tiles the way the kitchen has them: the light ones are framed, the dark ones are not."""
    light = (x // 16 + (y - y0) // 16) % 2 == 0
    if x % 16 == 0: return LINE
    if light: return LINE if (y - y0) % 16 in (0, 15) else T_LIGHT
    return T_DARK

im = Image.new('RGBA', (W, H), (0, 0, 0, 0))
px = im.load()
def rect(x0, y0, x1, y1, col):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            px[x, y] = col
def shade(x0, y0, x1, y1, alpha=40):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            r, g, b, a = px[x, y]
            if a: px[x, y] = (r * (255 - alpha) // 255, g * (255 - alpha) // 255, b * (255 - alpha) // 255, 255)

for x in range(X0, X1 + 1):
    px[x, 15] = EDGE_T
    for y in range(16, 48): px[x, y] = WALL                       # upper wall
    px[x, 48] = WALL_HI
    for y in range(49, 63): px[x, y] = FACE                       # wall face
    px[x, 63] = FACE_BASE
    for y in range(64, 160): px[x, y] = floor(x, y)
    px[x, 160] = BOTTOM_HI; px[x, 161] = BOTTOM_D; px[x, 162] = EDGE
for y in range(15, 163):
    px[X0 - 1, y] = EDGE_T; px[X1 + 1, y] = EDGE
# way out: one tile below the room with an arrow on it, as in the kitchen
ex = EXIT * 16
for y in range(160, 176):
    px[ex - 1, y] = EDGE; px[ex + 16, y] = EDGE; px[ex, y] = LINE
    for x in range(ex + 1, ex + 16): px[x, y] = T_DARK
rect(ex - 1, 176, ex + 16, 176, EDGE); rect(ex, 177, ex + 15, 177, BOTTOM_D); px[ex - 1, 177] = EDGE; px[ex + 16, 177] = EDGE
rect(ex, 178, ex + 15, 178, EDGE)
ARROW_ART = ["...gggg...", "...gccg...", "...gccg...", "...gccg...", "ggggccgggg", "gccccccccg", ".gccccccg.", "..gccccg..", "...gccg...", "....gg...."]
stamp(px, ARROW_ART, {'g': ARROW, 'c': T_LIGHT}, ex + 3, 163)

K = c('#3f3838'); K2 = c('#525e5b')                 # the soft outlines of the kitchen furniture
WHITE = c('#ffffff'); OFF = c('#f0f0f0'); GREY = c('#cac9c9'); GREY_D = c('#aca4a4')
SHADOW = (0, 0, 0, 40)

# ---------------------------------------------------------------- on the wall
def plate(x, y, w, h):                               # white board with a border, like the KITCHEN sign
    rect(x, y, x + w - 1, y + h - 1, K); rect(x, y, x + w - 1, y, K2)
    rect(x + 1, y + 1, x + w - 2, y + h - 2, c('#d9daf0'))
    rect(x + 1, y + 1, x + w - 2, y + 1, c('#eff0ff')); rect(x + 1, y + 2, x + w - 2, y + 2, WHITE)
    rect(x, y + h - 1, x + w - 1, y + h - 1, EDGE_T)
    shade(x + 1, y + h, x + w - 1, y + h, 50)

def level_board(x, y):                               # which robot is how hard: I, II, III and a bar for each
    plate(x, y, 44, 25)
    rows = ((1, 9, c('#58c463')), (2, 18, c('#f2b53a')), (3, 27, c('#e0303a')))
    for n, (strokes, length, col) in enumerate(rows):
        ry = y + 5 + n * 6
        for s in range(strokes):
            rect(x + 4 + s * 2, ry, x + 4 + s * 2, ry + 4, EDGE_T)
        rect(x + 12, ry + 1, x + 11 + length, ry + 3, col)
        rect(x + 12 + length, ry + 3, x + 39, ry + 3, c('#b4b6df'))     # the empty rest of the bar

def name_plate(x, y):                                # the room's name, as the kitchen has it
    plate(x, y, 27, 10)
    word(px, 'ARCADE', x + 2, y + 3, [EDGE_T] * 5)

# ---------------------------------------------------------------- on the floor
PAD = [
    "....KKKKKKKK....",
    "..KKggggggggKK..",
    ".KggCCCCCCCCggK.",
    "KggCccccccccCggK",
    "KgCccccccccccCgK",
    "KgCccccccccccCgK",
    "KggCccccccccCggK",
    ".KggCCCCCCCCggK.",
    "..KKhhhhhhhhKK..",
    "....KKKKKKKK....",
]
def pad(tx, ty, col):                                # round stand a robot stands on
    stamp(px, PAD, {'K': K, 'g': GREY, 'h': GREY_D, 'C': col, 'c': c('#9fb9be')}, tx * 16, ty * 16 + 5)

def mat(tx, ty, n):                                  # the numbered mats from the street: n strokes
    h, i, j, k = c('#6e1c22'), c('#a02c32'), c('#b0343a'), c('#fade78')
    x, y = tx * 16, ty * 16
    rect(x, y, x + 15, y + 15, h); rect(x + 1, y + 1, x + 14, y + 14, i); rect(x + 2, y + 2, x + 13, y + 13, j)
    for s in {1: (7,), 2: (5, 9), 3: (3, 7, 11)}[n]:
        rect(x + s, y + 4, x + s + 1, y + 11, k)

# One cabinet model in two colours, the way the kitchen repeats its stoves and fridges: a plain box seen a little
# from above (light top), a marquee strip, a screen like the other screens in the game, a deck with a stick and
# two buttons, a coin door.
CAB = [
    ".kkkkkkkkkkkkkk.",
    "KTTTTTTTTTTTTTTK",
    "KTTTTTTTTTTTTTTK",
    "KKKKKKKKKKKKKKKK",
    "KMMMMMMMMMMMMMMK",
    "KMMMMMMMMMMMMMMK",
    "KBBBBBBBBBBBBBBK",
    "KBKKKKKKKKKKKKBK",
    "KBK..........KBK",
    "KBK..........KBK",
    "KBK..........KBK",
    "KBK..........KBK",
    "KBK..........KBK",
    "KBK..........KBK",
    "KBKKKKKKKKKKKKBK",
    "KKKKKKKKKKKKKKKK",
    "KPPPPPPPPPPPPPPK",
    "KPPRPPPPPPYPCPPK",
    "KpprpppppppppppK",
    "KKKKKKKKKKKKKKKK",
    "KBBBBBBBBBBBBBBK",
    "KBBBBKKKKKKBBBBK",
    "KBBBBKddddKBBBBK",
    "KBBBBKdYYdKBBBBK",
    "KBBBBKKKKKKBBBBK",
    "KbbbbbbbbbbbbbbK",
    "KKKKKKKKKKKKKKKK",
    "ssssssssssssssss",
]
SCREEN_GLASS = ["ACCCCCEEEE", "ACCCCEEEEF", "ACCCEEEEFF", "ACCEEEEFFF", "ACEEEEFFFG", "AEEEEFFFGG"]
SCREENS = {   # what is on (10 x 6): '.' leaves the glass, 'n' is dark blue, 'w' white
    'pong':  ["..........", ".n........", ".n...w....", "........n.", "........n.", ".........."],
    'stars': [".w.....w..", "..........", "....w.....", "..........", "....n.....", "...nnn...."],
}
def cabinet(tx, body, body_d, body_l, marquee, screen):   # stands on tile (tx, 4), sticks up over the wall face
    pal = {'K': K, 'k': K2, 'B': c(body), 'b': c(body_d), 'T': c(body_l), 'M': c(marquee), 'P': OFF, 'p': GREY,
           'R': c('#e0303a'), 'r': c('#594f4f'), 'Y': c('#ffd23f'), 'C': c('#58c463'), 'd': c('#594f4f'), 's': SHADOW}
    x, y = tx * 16, 49
    stamp(px, [row.replace('.', '_') if 8 <= r <= 13 else row for r, row in enumerate(CAB)], {**pal, '_': K}, x, y)
    stamp(px, SCREEN_GLASS, {'A': c('#e2f9fd'), 'C': c('#95f0ff'), 'E': c('#c4f7ff'), 'F': c('#7ee7f7'), 'G': c('#6de1f4')}, x + 3, y + 8)
    stamp(px, SCREENS[screen], {'n': NAVY, 'w': WHITE}, x + 3, y + 8)

# The prize machine is the same box with a glass case instead of the screen.
CLAW = [
    ".kkkkkkkkkkkkkk.",
    "KTTTTTTTTTTTTTTK",
    "KTTTTTTTTTTTTTTK",
    "KKKKKKKKKKKKKKKK",
    "KHGGGGGrrGGGGGGK",
    "KHGGGGGrrGGGGGGK",
    "KHGGGGrrrrGGGGGK",
    "KHGGGGrGGrGGGGGK",
    "KHGGGGGGGGGGGGGK",
    "KHGGGGGGGGGGGGGK",
    "KHGGGGGGGGGGGGGK",
    "KHGyyGGGGGuuGGGK",
    "KHyyyyGGGuuuuGGK",
    "KyyyuyyGuuuyuuGK",
    "KyuyyyyyuuyuuuuK",
    "KKKKKKKKKKKKKKKK",
    "KPPPPPPPPPPPPPPK",
    "KPPRPPPPPPPPYPPK",
    "KpprpppppppppppK",
    "KKKKKKKKKKKKKKKK",
    "KBBBBBBBBBBBBBBK",
    "KBBBBBBBKKKKKKBK",
    "KBBBBBBBKddddKBK",
    "KBBBBBBBKddddKBK",
    "KBBBBBBBKKKKKKBK",
    "KbbbbbbbbbbbbbbK",
    "KKKKKKKKKKKKKKKK",
    "ssssssssssssssss",
]
def claw(tx, body, body_d, body_l):                  # prize machine full of plush pizza slices, on tile (tx, 4)
    pal = {'K': K, 'k': K2, 'B': c(body), 'b': c(body_d), 'T': c(body_l), 'P': OFF, 'p': GREY,
           'G': c('#c4f7ff'), 'H': c('#e2f9fd'), 'y': c('#ffd86b'), 'u': c('#e0303a'),
           'R': c('#e0303a'), 'r': c('#594f4f'), 'Y': c('#ffd23f'), 'd': c('#594f4f'), 's': SHADOW}
    stamp(px, CLAW, pal, tx * 16, 49)

def plant(tx):                                       # the potted plant from the hero's house, on tile (tx, 4)
    x, y = tx * 16 + 1, 60
    G1, G2, G3 = c('#58c463'), c('#31933f'), c('#17521f')
    leaves = [(5, 8), (3, 10), (2, 11), (1, 12), (1, 12), (2, 11), (1, 12), (2, 11), (3, 10), (5, 8)]
    for r, (a, b) in enumerate(leaves):
        rect(x + a, y + r, x + b, y + r, G3)
        if b - a > 2: rect(x + a + 1, y + r, x + b - 1, y + r, G2)
    for lx, ly in ((4, 2), (5, 3), (8, 1), (9, 2), (3, 5), (6, 6), (9, 5), (10, 6), (5, 8), (7, 4)):
        px[x + lx, y + ly] = G1
    rect(x + 3, y + 10, x + 10, y + 11, K); rect(x + 4, y + 10, x + 9, y + 10, c('#e08a5a'))
    rect(x + 4, y + 11, x + 9, y + 16, K); rect(x + 5, y + 11, x + 8, y + 15, c('#c9683f')); rect(x + 8, y + 11, x + 8, y + 15, c('#a04e2c'))
    shade(x + 4, y + 17, x + 10, y + 17, 40)

level_board(82, 19)
name_plate(150, 26)
ROBOT_COL = {4: c('#5fa8f0'), 6: c('#f0607a'), 8: c('#62b04c')}       # SAM-1, EMMA-2, JACK-3
for n, (tx, col) in enumerate(ROBOT_COL.items()):
    pad(tx, 6, col)
    mat(tx, 7, n + 1)
RED = ('#e37878', '#b95656', '#f29d87'); BLUE = ('#9c9fd9', '#7275ba', '#d4d6fd')      # the colours of the houses on the street
cabinet(1, *RED, '#ffd23f', 'pong')
cabinet(2, *BLUE, '#ffd23f', 'stars')
claw(3, *RED)
plant(9)
cabinet(10, *BLUE, '#ffd23f', 'pong')
cabinet(11, *RED, '#ffd23f', 'stars')

im.save(P + 'maps/HernaLower.png')
Image.new('RGBA', (W, H), (0, 0, 0, 0)).save(P + 'maps/HernaUpper.png')

# ---------------------------------------------------------------- battle background: the wall and the tiles, laid out like the kitchen one
bt = Image.new('RGBA', (176, 99), (0, 0, 0, 255))
bp = bt.load()
for x in range(176):
    for y in range(99):
        if y == 0: col = WALL_HI
        elif y < 15: col = FACE
        elif y == 15: col = FACE_BASE
        elif y < 18: col = c('#9cc7ca')
        else: col = floor(x, y, 16)
        bp[x, y] = col
bt.save(P + 'maps/HernaBattle.png')
print('images/maps/StreetLower.png, HernaLower.png, HernaUpper.png, HernaBattle.png')
