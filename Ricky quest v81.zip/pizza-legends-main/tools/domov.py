# Kreslí interiér hrdinova domu: images/maps/HomeLower.png a HomeUpper.png.
# Spuštění z kořene projektu:  python3 tools/domov.py      (potřebuje Pillow)
# Po přesunutí nábytku je potřeba upravit i mřížku zdí a hotspoty mapy Home v OverWorldMap.js.
from PIL import Image
import os
P = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'images') + os.sep
TW, TH = 11, 12
W, H = TW * 16, TH * 16
X0, X1 = 16, W - 17                  # interior columns 16..159
def c(h, a=255): return (int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16), a)

EDGE = c('#4a2f18'); EDGE_TOP = c('#6b4a26')
PAPER = c('#f0dcae'); PAPER_STRIPE = c('#e9d19c'); PAPER_DOT = c('#e3c68a')
RAIL_HI = c('#e0b27a'); PANEL = c('#c08c52'); PANEL_HI = c('#cf9c62'); GROOVE = c('#a67440'); BASE = c('#7d5328')
PLANK = [c('#d2a56e'), c('#c99b63')]; SEAM = c('#ab7d48'); FLOOR_SHADOW = c('#a17543'); KNOT = c('#b98a54')

im = Image.new('RGBA', (W, H), (0, 0, 0, 0))
px = im.load()
def rect(x0, y0, x1, y1, col):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            px[x, y] = col
def shade(x0, y0, x1, y1, alpha=70):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            r, g, b, a = px[x, y]
            if a: px[x, y] = (r * (255 - alpha) // 255, g * (255 - alpha) // 255, b * (255 - alpha) // 255, 255)

# wallpaper
for x in range(X0, X1 + 1):
    px[x, 15] = EDGE_TOP
    for y in range(16, 48):
        col = PAPER_STRIPE if x % 8 == 0 else PAPER
        if x % 8 == 4 and y % 8 == 4: col = PAPER_DOT
        px[x, y] = col
# wood panelling (the wall face)
for x in range(X0, X1 + 1):
    px[x, 48] = RAIL_HI; px[x, 49] = PANEL_HI
    for y in range(50, 63):
        px[x, y] = GROOVE if x % 8 == 0 else (PANEL_HI if x % 8 == 1 else PANEL)
    px[x, 63] = BASE
# plank floor
def floor_px(x, y):
    row = (y - 64) // 8
    if (y - 64) % 8 == 0: return SEAM
    if (x + (16 if row % 2 else 0)) % 32 == 0: return SEAM
    plank = (x + (16 if row % 2 else 0)) // 32
    return PLANK[(row + plank) % 2]
for x in range(X0, X1 + 1):
    for y in range(64, 160):
        px[x, y] = floor_px(x, y)
    px[x, 64] = FLOOR_SHADOW; shade(x, 65, x, 66, 28)
for kx, ky in ((30, 101), (70, 75), (118, 139), (140, 84), (52, 150), (100, 110)):
    px[kx, ky] = KNOT; px[kx + 1, ky] = KNOT
# way out: one tile below the room, with a doormat
for x in range(80, 96):
    for y in range(160, 176):
        px[x, y] = floor_px(x, y)
# outline
for y in range(16, 160):
    px[X0 - 1, y] = EDGE; px[X1 + 1, y] = EDGE
for x in range(X0 - 1, X1 + 2):
    if not 80 <= x <= 95:
        px[x, 160] = EDGE
for y in range(160, 177):
    px[79, y] = EDGE; px[96, y] = EDGE
for x in range(79, 97): px[x, 176] = EDGE
px[X0 - 1, 15] = (0, 0, 0, 0)

# ---------------------------------------------------------------- furniture
K = c('#3a2412')                                   # outline
WOOD = c('#a9713a'); WOOD_HI = c('#c58c50'); WOOD_D = c('#855426')

def shadow_under(x0, x1, y):
    shade(x0, y, x1, y, 60); shade(x0 + 1, y + 1, x1 - 1, y + 1, 30)

def bed(x, y):                                     # 16 wide, 36 tall; head against the wall
    rect(x, y, x + 15, y + 34, K)
    rect(x + 1, y + 1, x + 14, y + 5, WOOD); rect(x + 1, y + 1, x + 14, y + 1, WOOD_HI); rect(x + 1, y + 5, x + 14, y + 5, WOOD_D)
    rect(x + 1, y + 6, x + 14, y + 13, c('#f4f1ea'))                    # sheet
    rect(x + 3, y + 7, x + 12, y + 11, c('#ffffff')); rect(x + 3, y + 11, x + 12, y + 11, c('#d9d6e0'))
    px[x + 3, y + 7] = c('#f4f1ea'); px[x + 12, y + 7] = c('#f4f1ea')   # pillow corners
    rect(x + 1, y + 13, x + 14, y + 13, c('#d9d6e0'))
    rect(x + 1, y + 14, x + 14, y + 29, c('#d8443c'))                   # blanket
    rect(x + 1, y + 14, x + 14, y + 15, c('#f0d9a8'))                   # folded edge
    rect(x + 1, y + 16, x + 14, y + 16, c('#ee6a55'))
    rect(x + 12, y + 17, x + 14, y + 29, c('#b8332e'))
    rect(x + 1, y + 28, x + 14, y + 29, c('#b8332e'))
    # a slice of pizza stitched on the blanket
    for r, (a, b) in enumerate(((5, 9), (5, 9), (6, 8), (6, 8), (7, 7))):
        rect(x + a, y + 19 + r, x + b, y + 19 + r, c('#ffd86b'))
    rect(x + 5, y + 19, x + 9, y + 19, c('#c98a3a'))
    px[x + 6, y + 21] = c('#d8443c'); px[x + 8, y + 20] = c('#d8443c')
    rect(x + 1, y + 30, x + 14, y + 33, WOOD); rect(x + 1, y + 30, x + 14, y + 30, WOOD_HI); rect(x + 1, y + 33, x + 14, y + 33, WOOD_D)
    shadow_under(x + 1, x + 15, y + 35)

def nightstand(x, y):                              # 14 x 15, a lamp and a note on top
    rect(x, y, x + 13, y + 14, K)
    rect(x + 1, y + 1, x + 12, y + 4, WOOD_HI)                           # top
    rect(x + 1, y + 5, x + 12, y + 13, WOOD); rect(x + 1, y + 9, x + 12, y + 9, WOOD_D)
    px[x + 6, y + 7] = c('#ffd86b'); px[x + 7, y + 7] = c('#ffd86b'); px[x + 6, y + 11] = c('#ffd86b'); px[x + 7, y + 11] = c('#ffd86b')
    # lamp
    rect(x + 2, y - 7, x + 7, y - 3, c('#ffe9a8')); rect(x + 2, y - 3, x + 7, y - 3, c('#e8b85a'))
    rect(x + 3, y - 8, x + 6, y - 8, c('#fff6d6'))
    for yy in range(y - 8, y - 2): px[x + 1, yy] = K; px[x + 8, yy] = K
    rect(x + 2, y - 9, x + 7, y - 9, K); rect(x + 2, y - 2, x + 7, y - 2, K)
    rect(x + 4, y - 1, x + 5, y + 2, c('#6a6978')); rect(x + 3, y + 2, x + 6, y + 2, c('#44434f'))
    # note
    rect(x + 9, y + 1, x + 11, y + 3, c('#ffffff')); px[x + 10, y + 2] = c('#9aa0b8')
    shadow_under(x + 1, x + 13, y + 15)

def rug(x0, y0, x1, y1):
    A, B, Cc = c('#3f7fb8'), c('#e9d19c'), c('#2c5f93')
    rect(x0, y0, x1, y1, Cc); rect(x0 + 1, y0 + 1, x1 - 1, y1 - 1, B); rect(x0 + 2, y0 + 2, x1 - 2, y1 - 2, A)
    rect(x0 + 4, y0 + 4, x1 - 4, y1 - 4, Cc); rect(x0 + 5, y0 + 5, x1 - 5, y1 - 5, A)
    for x in range(x0 + 7, x1 - 6, 6):
        cy = (y0 + y1) // 2
        px[x, cy] = B; px[x + 1, cy] = B; px[x, cy + 1] = B; px[x + 1, cy + 1] = B
    for x in range(x0 + 1, x1, 2):                                      # fringe
        px[x, y0 - 1] = B; px[x, y1 + 1] = B

def table(x, y):                                   # round table, 16 x 16, a pizza box on it
    top = [(4, 11), (2, 13), (1, 14), (0, 15), (0, 15), (0, 15), (1, 14), (2, 13), (4, 11)]
    for r, (a, b) in enumerate(top):
        rect(x + a, y + r, x + b, y + r, K)
    for r, (a, b) in enumerate(top[1:-1]):
        rect(x + a + 1, y + 1 + r, x + b - 1, y + 1 + r, WOOD_HI if r < 5 else WOOD)
    rect(x + 6, y + 9, x + 9, y + 13, K); rect(x + 7, y + 9, x + 8, y + 12, WOOD_D)
    rect(x + 4, y + 13, x + 11, y + 14, K)
    rect(x + 5, y + 2, x + 11, y + 6, c('#f3d9b1')); rect(x + 5, y + 6, x + 11, y + 6, c('#d0a871'))
    px[x + 8, y + 4] = c('#d8443c')
    shadow_under(x + 4, x + 12, y + 15)

def plant(x, y):                                   # 14 wide, about 22 tall, pot at the bottom
    G1, G2, G3 = c('#58c463'), c('#31933f'), c('#17521f')
    leaves = [(5, 8), (3, 10), (2, 11), (1, 12), (1, 12), (2, 11), (1, 12), (2, 11), (3, 10), (5, 8)]
    for r, (a, b) in enumerate(leaves):
        rect(x + a, y + r, x + b, y + r, G3)
        if b - a > 2: rect(x + a + 1, y + r, x + b - 1, y + r, G2)
    for lx, ly in ((4, 2), (5, 3), (8, 1), (9, 2), (3, 5), (6, 6), (9, 5), (10, 6), (5, 8), (7, 4)):
        px[x + lx, y + ly] = G1
    rect(x + 3, y + 10, x + 10, y + 11, K); rect(x + 4, y + 10, x + 9, y + 10, c('#e08a5a'))
    rect(x + 4, y + 11, x + 9, y + 16, K); rect(x + 5, y + 11, x + 8, y + 15, c('#c9683f')); rect(x + 8, y + 11, x + 8, y + 15, c('#a04e2c'))
    shadow_under(x + 4, x + 10, y + 17)

def window(x, y, w=26, h=20):
    rect(x, y, x + w - 1, y + h - 1, K)
    rect(x + 1, y + 1, x + w - 2, y + h - 2, c('#fff6e0'))
    rect(x + 3, y + 3, x + w - 4, y + h - 4, c('#9fd8f5'))
    rect(x + 3, y + h - 8, x + w - 4, y + h - 4, c('#bfe9ff'))
    for i in range(5):                                                   # glare
        px[x + 6 + i, y + 9 - i] = c('#e4f6ff'); px[x + 12 + i, y + 12 - i] = c('#e4f6ff')
    rect(x + w // 2 - 1, y + 3, x + w // 2, y + h - 4, c('#fff6e0'))
    rect(x - 1, y + h, x + w, y + h + 1, K); rect(x, y + h, x + w - 1, y + h, c('#fff6e0'))   # sill
    # curtains
    for side in (0, 1):
        for r in range(h - 2):
            wd = 5 - (r // 4) if r < 12 else 2
            for k in range(wd):
                xx = x + 1 + k if side == 0 else x + w - 2 - k
                px[xx, y + 1 + r] = c('#e2574c') if (k + r // 3) % 2 == 0 else c('#c4403a')

def clock(x, y):                                   # 11 x 11 wall clock
    disc = [(3, 7), (1, 9), (1, 9), (0, 10), (0, 10), (0, 10), (0, 10), (0, 10), (1, 9), (1, 9), (3, 7)]
    for r, (a, b) in enumerate(disc):
        rect(x + a, y + r, x + b, y + r, K)
    for r, (a, b) in enumerate(disc[1:-1]):
        rect(x + a + 1, y + 1 + r, x + b - 1, y + 1 + r, c('#ffffff'))
    rect(x + 5, y + 2, x + 5, y + 5, c('#d8443c')); rect(x + 5, y + 5, x + 8, y + 5, K)
    for dx, dy in ((5, 1), (9, 5), (5, 9), (1, 5)): px[x + dx, y + dy] = c('#9aa0b8')

def poster(x, y):                                  # 14 x 18, a pizza on a poster
    rect(x, y, x + 13, y + 17, K); rect(x + 1, y + 1, x + 12, y + 16, c('#fff3d6'))
    disc = [(5, 8), (3, 10), (2, 11), (2, 11), (2, 11), (2, 11), (3, 10), (5, 8)]
    for r, (a, b) in enumerate(disc):
        rect(x + a, y + 3 + r, x + b, y + 3 + r, c('#c98a3a'))
    for r, (a, b) in enumerate(disc[1:-1]):
        rect(x + a + 1, y + 4 + r, x + b - 1, y + 4 + r, c('#ffd86b'))
    for dx, dy in ((5, 5), (8, 6), (6, 8), (9, 8), (4, 7)): px[x + dx, y + dy] = c('#d8443c')
    rect(x + 3, y + 13, x + 10, y + 13, c('#d8443c')); rect(x + 4, y + 15, x + 9, y + 15, c('#9aa0b8'))

window(52, 22)
clock(98, 24)
poster(118, 22)
# bookshelf from the red house, tiles 7-8 against the wall
demo = Image.open(P + 'maps/DemoLower.png').convert('RGBA')
im.paste(demo.crop((48, 46, 80, 72)), (112, 46))
px = im.load()
shadow_under(113, 143, 72)
bed(16, 58)
nightstand(33, 62)
plant(145, 60)
rug(54, 92, 105, 123)
table(128, 110)
# doormat at the way out
rect(82, 163, 93, 171, c('#7d5328')); rect(83, 164, 92, 170, c('#a67440'))
for x in range(84, 92, 2): px[x, 167] = c('#7d5328')

im.save(P + 'maps/HomeLower.png')
Image.new('RGBA', (W, H), (0, 0, 0, 0)).save(P + 'maps/HomeUpper.png')
