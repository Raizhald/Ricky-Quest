# Kreslí kolo kurýra Ráfka: images/characters/bike.png (políčko 32 x 32 jako u postav, kolo stojí bokem a kouká doprava),
# jeho stín images/characters/bike-shadow.png a náhled tools/kolo-nahled.png.
# Spuštění z kořene projektu:  python3 tools/kolo.py      (potřebuje Pillow: pip install pillow)
#
# Kolo je ve hře objekt Bike (Bike.js). Stojí na náměstíčku pod Burger Tower a před domem hrdiny a vozí mezi nimi.
# Kola jsou znak po znaku, rám se kreslí z úseček; dlaždice, na které kolo stojí, je v políčku od x = 8 do 23, zem je na y = 30.
import os
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'images', 'characters')

PAL = {
    'k': '#222034',   # obrys, pláště
    'g': '#8f93a3',   # ráfek, dráty
    'w': '#d8dbe6',   # lesk na ráfku, řídítka
    'R': '#d8402f',   # rám
    'r': '#9a2620',   # stín rámu
    's': '#3a2a22',   # sedlo
    'b': '#c79a5b',   # krabice od pizzy na nosiči
    'B': '#8a6234',   # stín krabice
    'y': '#ffd23f',   # odrazka, zvonek
}

def hexc(h):
    return (int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16), 255)

def wheel(px, cx, cy):
    """Kolo o průměru 11: plášť, ráfek, dráty do kříže a střed."""
    ring = ["...kkkkk...", "..kkgggkk..", ".kk..g..kk.", "kk...g...kk", "kg...g...gk", "kgggggggggk",
            "kg...g...gk", "kk...g...kk", ".kk..g..kk.", "..kkgggkk..", "...kkkkk..."]
    for dy, row in enumerate(ring):
        for dx, ch in enumerate(row):
            if ch != '.':
                px[cx - 5 + dx, cy - 5 + dy] = hexc(PAL[ch])

def line(px, pts, col):
    for (x, y) in pts:
        px[x, y] = hexc(PAL[col])

def draw():
    im = Image.new('RGBA', (32, 32), (0, 0, 0, 0))
    px = im.load()
    BACK, FRONT, AXLE = 8, 23, 25            # středy kol, výška os
    wheel(px, BACK, AXLE)
    wheel(px, FRONT, AXLE)

    def seg(x0, y0, x1, y1):
        """Body na úsečce (pro trubky rámu)."""
        n = max(abs(x1 - x0), abs(y1 - y0))
        return [(round(x0 + (x1 - x0) * i / n), round(y0 + (y1 - y0) * i / n)) for i in range(n + 1)]

    crank = (15, 25)                         # šlapací střed
    seat = (13, 18)                          # vršek sedlovky
    head = (21, 18)                          # hlava rámu
    tubes = [seg(BACK, AXLE, *seat), seg(BACK, AXLE, *crank), seg(*seat, *crank), seg(*seat, *head),
             seg(*crank, *head), seg(*head, FRONT, AXLE)]
    # tmavý obrys kolem trubek, pak trubky samotné
    for tube in tubes:
        for (x, y) in tube:
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                if px[x + dx, y + dy][3] == 0:
                    px[x + dx, y + dy] = hexc(PAL['k'])
    for tube in tubes:
        line(px, tube, 'R')
    line(px, seg(BACK, AXLE, *crank), 'r')
    line(px, seg(*crank, *head)[:4], 'r')
    # sedlovka a sedlo
    line(px, [(13, 17), (13, 16)], 'k')
    line(px, [(x, 15) for x in range(10, 16)], 'k')
    line(px, [(x, 14) for x in range(11, 15)], 's')
    line(px, [(10, 14), (15, 14)] + [(x, 13) for x in range(11, 15)], 'k')
    # představec a řídítka
    line(px, [(21, 17), (21, 16), (21, 15)], 'k')
    line(px, [(20, 14), (21, 14), (22, 14), (23, 14), (24, 15)], 'k')
    line(px, [(21, 13), (22, 13), (23, 13)], 'w')
    line(px, [(20, 13), (24, 13), (24, 14), (21, 12), (22, 12), (23, 12)], 'k')
    px[20, 15] = hexc(PAL['y'])              # zvonek
    px[19, 15] = hexc(PAL['k'])
    # šlapky
    line(px, [(14, 25), (15, 25), (16, 25)], 'k')
    line(px, [(15, 26), (15, 27), (16, 28), (14, 28), (15, 28), (17, 28)], 'k')
    # nosič s krabicí od pizzy nad zadním kolem
    line(px, [(x, 18) for x in range(3, 13)], 'k')
    line(px, [(5, 19), (5, 20)], 'k')
    for x in range(3, 12):
        px[x, 15] = hexc(PAL['k']); px[x, 17] = hexc(PAL['B']); px[x, 16] = hexc(PAL['b'])
    px[3, 16] = px[3, 17] = hexc(PAL['k']); px[11, 16] = px[11, 17] = hexc(PAL['k'])
    px[7, 16] = hexc(PAL['R'])               # červená nálepka na krabici
    # odrazka vzadu
    px[2, 25] = hexc(PAL['y'])
    return im

def shadow():
    """Širší stín než u postav (kolo je delší než dlaždice), stejná barva a průhlednost jako shadow.png."""
    im = Image.new('RGBA', (32, 32), (0, 0, 0, 0))
    px = im.load()
    rows = {28: (5, 27), 29: (3, 29), 30: (2, 30), 31: (4, 28)}
    for y, (x0, x1) in rows.items():
        for x in range(x0, x1 + 1):
            px[x, y] = (34, 32, 52, 75)
    return im

if __name__ == '__main__':
    bike = draw()
    bike.save(os.path.join(OUT, 'bike.png'))
    sh = shadow()
    sh.save(os.path.join(OUT, 'bike-shadow.png'))
    prev = Image.new('RGBA', (32, 32), (169, 181, 181, 255))
    prev.alpha_composite(sh); prev.alpha_composite(bike)
    prev = prev.resize((32 * 8, 32 * 8), Image.NEAREST)
    prev.save(os.path.join(ROOT, 'tools', 'kolo-nahled.png'))
    print('images/characters/bike.png, bike-shadow.png, tools/kolo-nahled.png')
