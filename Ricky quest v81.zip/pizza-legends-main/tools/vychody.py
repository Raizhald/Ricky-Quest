"""Šipka na dlaždici u východu: všude stejná jako v herně (Herna) a v SHOPu (Kitchen).

Barvy se odvodí z podlahy dané místnosti (výplň světlejší, obrys tmavší).
Kitchen a Herna zůstávají, jak jsou (vzor). Jde pouštět opakovaně.
Pouští se z kořene projektu:  python3 tools/vychody.py
"""
from collections import Counter
from PIL import Image

ARROW_ART = ["...gggg...", "...gccg...", "...gccg...", "...gccg...", "ggggccgggg",
             "gccccccccg", ".gccccccg.", "..gccccg..", "...gccg...", "....gg...."]

# mapa: (dlaždice východu x, y, čistit celou dlaždici?)
EXITS = {
    'Home':         (5, 10),
    'Demo':         (5, 10),
    'GreenKitchen': (5, 12),
    'PizzaShop':    (5, 12),
    'StreetNorth':  (7, 16),
    'Sewer':        (4, 10),
}


def lighten(c, k=0.45):
    return tuple(int(v + (255 - v) * k) for v in c[:3]) + (255,)


def darken(c, k=0.74):
    return tuple(int(v * k) for v in c[:3]) + (255,)


for name, (tx, ty) in EXITS.items():
    path = f'images/maps/{name}Lower.png'
    im = Image.open(path).convert('RGBA')
    px = im.load()
    x0, y0 = tx * 16, ty * 16

    # podlahová barva dlaždice = nejčastější barva v jejím jádru (bez okrajů)
    if name == 'Home':
        base = (210, 165, 110, 255)           # dřevo, rohožka pryč
        rows = range(1, 16)
    else:
        core = [px[x, y] for x in range(x0 + 1, x0 + 15) for y in range(y0 + 1, y0 + 15)]
        base = Counter(core).most_common(1)[0][0]
        rows = range(1, 15)
    cols = range(0, 16) if name == 'Home' else range(1, 15)
    if name == 'Sewer':
        base = (119, 133, 129, 255)

    for dy in rows:
        for dx in cols:
            px[x0 + dx, y0 + dy] = base

    fill, line = lighten(base), darken(base)
    for j, row in enumerate(ARROW_ART):
        for i, ch in enumerate(row):
            if ch == 'g':
                px[x0 + 3 + i, y0 + 3 + j] = line
            elif ch == 'c':
                px[x0 + 3 + i, y0 + 3 + j] = fill
    im.save(path)
    print('hotovo', name, (tx, ty), 'podlaha', base[:3])
