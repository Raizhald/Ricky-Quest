# Kreslí doupě pizzového monstra ve stokách (mapa SewerLair), kam se jde tmavým průchodem na konci tunelu za mříží:
#   images/maps/SewerLairLower.png, SewerLairUpper.png          (doupě s hnízdem, ve kterém sedí monstrum)
#   images/maps/SewerLairDoneLower.png                          (po souboji: v hnízdě zbyla jen louže sýra)
#   Content/sewerLair.js    (mřížka a místa pro OverWorldMap.js - NEUPRAVOVAT RUČNĚ, přepíše se)
#   tools/doupe-nahled.png  (obě podoby vedle sebe, jen na koukání)
# Spuštění z kořene projektu:  python3 tools/doupe.py      (potřebuje Pillow; jde pouštět opakovaně)
# Zdi, chodník, vodu, lampy, roury, východ a barvy si bere z tools/tunel.py (room, lamp, drain, way_out, splat).
#
# Rozmístění je v ROWS:
#   # zeď   . chodník   ~ stoka (nedá se přes ni)   v zadní zdi:  o roura, ze které teče voda do stoky   l lampa
#   N hnízdo z krabic a ztuhlého sýra (zeď)   M dlaždice uprostřed hnízda, na které sedí monstrum
#   B hromádka krabic od pizzy   C hrouda ztuhlého sýra   R hromada okousaných kůrek      (všechny tři jsou zeď a mají text)
# Každá věc je celá ve své dlaždici a žádné dvě nejsou hned nad sebou (jinak vypadají useknutě, viz železářství).
from PIL import Image
import math, os, random, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from tunel import (room, lamp, drain, way_out, splat, c, T, P, ROOT, K, CHEESE, CHEESE_HI, SAUCE, SAUCE_HI,
                   WATER_SH, FOAM, MORTAR, BASE)

ROWS = [
    "#####################",
    "#####################",
    "#####################",
    "#o##l###l###l###l##o#",
    "#~.B.............C.~#",
    "#~......NNNNN......~#",
    "#~.C....NNMNN...B..~#",
    "#~.................~#",
    "#~.................~#",
    "#~..R...........B..~#",
    "#~.B...........R...~#",
    "#########...#########",
    "#########...#########",
    "#########...#########",
    "#########...#########",
    "#########...#########",
    "#####################",
]
W, H = len(ROWS[0]), len(ROWS)
FACE_ROW = 3                         # the row of the brick face of the back wall
EXIT_ROW = H - 2                     # stepping on its free tiles leads back into the tunnel
TRIGGER_ROW = 8                      # stepping on this row wakes the monster (the whole row is free)
THINGS = 'BCR'

OUT = c('#3a160d')                                                   # the outline of the monster's own picture
BOX_OUT, BOX_SIDE, BOX_TOP, BOX_HI, RED = c('#2e1f10'), c('#b27f43'), c('#d9aa6a'), c('#ecc88d'), c('#d93a3a')
CH_SH, CH_LIGHT = c('#b98a35'), c('#ffd986')
CRUST, CRUST_HI, CRUST_SH = c('#c98a4b'), c('#e6b577'), c('#96602f')
PIT, PIT_HI = c('#631f0e'), c('#8e3c2a')
SHADE = c('#515d59')


def draw(done):
    """done = False: the nest waits for the monster to be drawn into it by the game. True: after the fight."""
    random.seed(77)
    r = room(ROWS, floor_chars='.M' + THINGS + 'N', ripples=120, specks=150, puddles=14, moss=36)
    px, at, rect, blend = r.px, r.at, r.rect, r.blend
    spots = []

    def ellipse(cx, cy, rx, ry, col, test=None):
        for y in range(int(cy - ry) - 1, int(cy + ry) + 2):
            for x in range(int(cx - rx) - 1, int(cx + rx) + 2):
                if ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2 <= 1 and (test is None or test(x, y)):
                    px[x, y] = col

    # ---- the back wall: pipes over the two channels, lamps, cheese running down the bricks, claw marks
    for tx in range(W):
        ch = at(tx, FACE_ROW)
        if ch == 'o':
            drain(r, tx, FACE_ROW, (FACE_ROW + 1) * T + 9)
            spots.append((tx, FACE_ROW, 'o'))
        elif ch == 'l':
            lamp(r, tx, FACE_ROW)
    for (x0, n, wide) in ((38, 9, 2), (44, 5, 1), (88, 11, 2), (93, 6, 1), (106, 4, 1), (150, 12, 3), (156, 7, 1), (181, 10, 2), (187, 5, 1),
                          (214, 8, 2), (236, 12, 2), (241, 6, 1), (280, 9, 2), (286, 4, 1)):
        for i in range(n):
            for w in range(wide): px[x0 + w, FACE_ROW * T + 1 + i] = CHEESE_HI if w == 0 else CHEESE
        for w in range(wide): px[x0 + w, FACE_ROW * T + 1 + n] = CHEESE
        if wide > 1: px[x0, FACE_ROW * T + 2 + n] = CHEESE
    for (x0, y0) in ((118, 53), (262, 52)):                             # three scratches each
        for k in range(3):
            for i in range(7): px[x0 + k * 3 + i // 2, y0 + i] = MORTAR if i % 6 else BASE

    # ---- what the monster dropped on the floor: blobs of cheese and sauce, bigger puddles, gnawed crusts
    def puddle(cx, cy, rx, ry, kind):
        col, hi = (CHEESE, CHEESE_HI) if kind == 0 else (SAUCE, SAUCE_HI)
        ellipse(cx, cy, rx, ry, col)
        ellipse(cx - rx * 0.3, cy - ry * 0.35, rx * 0.35, max(1, ry * 0.3), hi)
        for (dx, dy) in ((rx + 1, 0), (-rx - 1, 1), (rx * 0.5, ry + 1)): px[int(cx + dx), int(cy + dy)] = col
    def crust(x, y, flip):
        pts = ((0, 2), (1, 1), (2, 0), (3, 0), (4, 0), (5, 1), (6, 2))
        for (dx, dy) in pts:
            px[x + dx, y + (dy if not flip else 2 - dy)] = CRUST
            px[x + dx, y + (dy if not flip else 2 - dy) + 1] = CRUST_SH
        px[x + 3, y + (0 if not flip else 2)] = CRUST_HI
    for (cx, cy, rx, ry, kind) in ((70, 122, 7, 3, 0), (252, 120, 6, 3, 1), (104, 150, 5, 2, 1), (214, 152, 7, 3, 0), (120, 72, 5, 2, 0),
                                   (232, 76, 5, 2, 1), (168, 132, 8, 3, 0)):
        puddle(cx, cy, rx, ry, kind)
    for (x, y, flip) in ((86, 138, 0), (196, 126, 1), (240, 140, 0), (132, 166, 1), (58, 86, 0), (268, 100, 1), (150, 150, 0), (284, 164, 0)):
        crust(x, y, flip)
    trail = [(166, 232, 0), (174, 214, 1), (162, 196, 0), (172, 180, 0), (160, 164, 1), (176, 150, 0), (164, 118, 1), (48, 150, 0),
             (286, 134, 1), (40, 110, 1), (300, 84, 0), (92, 104, 0), (224, 104, 0)]
    for (x, y, kind) in trail: splat(px, x, y, kind)

    # ---- things standing about (each whole inside its tile)
    def boxes(tx, ty, three):
        X, Y = tx * T, ty * T
        def box(x0, y0, w, h):
            rect(X + x0, Y + y0, X + x0 + w - 1, Y + y0 + h - 1, BOX_OUT)
            rect(X + x0 + 1, Y + y0 + 1, X + x0 + w - 2, Y + y0 + 2, BOX_TOP)
            rect(X + x0 + 1, Y + y0 + 1, X + x0 + w - 2, Y + y0 + 1, BOX_HI)
            if h > 4: rect(X + x0 + 1, Y + y0 + 3, X + x0 + w - 2, Y + y0 + h - 2, BOX_SIDE)
            px[X + x0 + w // 2, Y + y0 + h - 2] = RED; px[X + x0 + w // 2 - 1, Y + y0 + h - 2] = RED
        rect(X + 1, Y + 14, X + 15, Y + 15, SHADE)
        box(1, 9, 14, 5)
        box(2, 5, 12, 5)
        if three: box(3, 1, 11, 5)
        px[X + 6, Y + (2 if three else 6)] = c('#a8793f'); px[X + 7, Y + (2 if three else 6)] = c('#a8793f')
    def cheese_lump(tx, ty):
        X, Y = tx * T, ty * T
        rect(X + 2, Y + 14, X + 14, Y + 15, SHADE)
        shape = {1: (6, 9), 2: (5, 10), 3: (4, 10), 4: (4, 11), 5: (3, 11), 6: (3, 12), 7: (2, 12), 8: (2, 12), 9: (2, 13), 10: (1, 13), 11: (1, 13),
                 12: (1, 14), 13: (2, 14), 14: (3, 13)}
        for y, (x0, x1) in shape.items():
            for x in range(x0, x1 + 1):
                edge = x in (x0, x1) or y in (1, 14) or not (shape.get(y - 1, (99, -99))[0] <= x <= shape.get(y - 1, (99, -99))[1])
                px[X + x, Y + y] = OUT if edge else (CHEESE_HI if x < (x0 + x1) // 2 else CHEESE)
        for (x, y) in ((6, 3), (5, 5), (5, 6), (4, 8), (4, 9)): px[X + x, Y + y] = CH_LIGHT
        for (x, y) in ((9, 6), (10, 6), (9, 7), (6, 10), (7, 10), (11, 11), (10, 9)): px[X + x, Y + y] = CH_SH
    def crusts(tx, ty):
        X, Y = tx * T, ty * T
        rect(X + 1, Y + 14, X + 15, Y + 15, SHADE)
        for (x0, y0, w) in ((1, 10, 13), (3, 6, 11), (5, 2, 7)):
            for i in range(w):
                arc = round(2.2 * math.sin(math.pi * i / (w - 1)))
                for dy, col in ((0, OUT), (1, CRUST_HI), (2, CRUST), (3, CRUST_SH), (4, OUT)):
                    px[X + x0 + i, Y + y0 - arc + dy] = col
            px[X + x0, Y + y0 + 1] = OUT; px[X + x0 + w - 1, Y + y0 + 1] = OUT
            px[X + x0, Y + y0 + 2] = OUT; px[X + x0 + w - 1, Y + y0 + 2] = OUT
    for ty in range(H):
        for tx in range(W):
            ch = at(tx, ty)
            if ch == 'B': boxes(tx, ty, (tx + ty) % 2 == 0)
            elif ch == 'C': cheese_lump(tx, ty)
            elif ch == 'R': crusts(tx, ty)
            if ch in THINGS: spots.append((tx, ty, ch))

    # ---- the nest: a ring of pizza boxes glued together with cheese, a dark hollow inside
    nest = [(x, y) for y in range(H) for x in range(W) if at(x, y) in 'NM']
    mx, my = next((x, y) for y in range(H) for x in range(W) if at(x, y) == 'M')
    x0, x1 = min(x for x, _ in nest) * T, (max(x for x, _ in nest) + 1) * T - 1
    y1 = (max(y for _, y in nest) + 1) * T - 1
    cx, cy = (x0 + x1) / 2, y1 - 14.5
    RX, RY = (x1 - x0) / 2 - 1, 13
    ring = lambda x, y, rx, ry: ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2
    for y in range(int(cy - RY) - 1, y1 + 1):
        for x in range(x0, x1 + 1):
            d = ring(x, y, RX, RY)
            if d > 1: continue
            if d > 0.9: px[x, y] = BOX_OUT; continue
            inner = ring(x, y, RX - 9, RY - 5)
            if inner > 1:                                               # the rim: boxes lying round in a circle
                ang = math.atan2((y - cy) / RY, (x - cx) / RX)
                seg = int((ang + math.pi) / (2 * math.pi) * 14)
                frac = (ang + math.pi) / (2 * math.pi) * 14 - seg
                if frac < 0.08: px[x, y] = BOX_OUT
                else: px[x, y] = BOX_HI if d < 0.62 and y < cy else (BOX_TOP if (seg % 2 == 0) == (y < cy) else BOX_SIDE)
                if seg % 3 == 1 and 0.4 < frac < 0.6 and 0.55 < d < 0.8: px[x, y] = RED
            elif inner > 0.86: px[x, y] = BOX_OUT
            else: px[x, y] = PIT if ((x * 7 + y * 13) % 11) else PIT_HI
    for (ax, n) in ((x0 + 9, 6), (x0 + 22, 4), (x0 + 50, 7), (x1 - 12, 5), (x1 - 27, 3)):           # cheese over the front of the rim
        ytop = next(y for y in range(int(cy), y1 + 1) if ring(ax, y, RX - 9, RY - 5) > 1)
        for i in range(n + 3):
            if ring(ax, ytop + i, RX, RY) > 0.88: break
            px[ax, ytop + i] = CHEESE_HI; px[ax + 1, ytop + i] = CHEESE
    for (ax, ay) in ((x0 + 14, cy - 7), (x1 - 16, cy - 8), (x0 + 5, cy + 1), (x1 - 6, cy + 2)):       # and lumps of it on top
        ellipse(ax, ay, 3, 2, CHEESE); px[int(ax) - 1, int(ay) - 1] = CH_LIGHT
    if done:                                                            # what is left of the monster: a puddle with two olives and a slice of salami
        ellipse(cx, cy + 0.5, RX - 13, RY - 8, OUT)
        ellipse(cx, cy + 0.5, RX - 14, RY - 9, CHEESE)
        ellipse(cx - 6, cy - 0.5, RX - 24, 1.6, CHEESE_HI)
        ellipse(cx - 9, cy - 1, 5, 1, CH_LIGHT)
        for ox in (-5, 4):
            rect(int(cx) + ox, int(cy), int(cx) + ox + 1, int(cy) + 1, c('#2f3d1f')); px[int(cx) + ox, int(cy)] = c('#5d7a3a')
        ellipse(cx + 13, cy + 1.5, 2.6, 1.6, c('#d43535')); px[int(cx) + 12, int(cy) + 1] = c('#f58a96')
        for (bx, by) in ((cx - 17, cy + 3), (cx + 19, cy - 1)): px[int(bx), int(by)] = CH_LIGHT

    exits = way_out(r, EXIT_ROW)

    # ---- checks: every tile of the trigger row is free, the hero gets from the way in to the tile under the monster,
    # and no two things stand right above one another
    free = lambda x, y: at(x, y) == '.'
    start = (exits[len(exits) // 2], EXIT_ROW - 1)
    seen, todo = {start}, [start]
    while todo:
        x, y = todo.pop()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            n = (x + dx, y + dy)
            if n not in seen and free(*n) and n[1] < EXIT_ROW: seen.add(n); todo.append(n)
    if (mx, my + 1) not in seen: print('k monstru se nedá dojít'); sys.exit(1)
    trigger = [x for x in range(W) if free(x, TRIGGER_ROW)]
    if any(at(x, TRIGGER_ROW) not in '.~#' for x in range(W)) or not all((x, TRIGGER_ROW) in seen for x in trigger):
        print('v řadě, která budí monstrum, něco stojí'); sys.exit(1)
    if any((x, y) in seen for (x, y) in seen if y < TRIGGER_ROW and not any((x2, TRIGGER_ROW) in seen for x2 in range(W))): sys.exit(1)
    for ty in range(H - 1):
        for tx in range(W):
            if at(tx, ty) in THINGS + 'N' and at(tx, ty + 1) in THINGS: print('dvě věci nad sebou na', tx, ty); sys.exit(1)
    return r, spots, exits, (mx, my), trigger, len(seen)


def main():
    r, spots, exits, monster, trigger, count = draw(False)
    r.im.save(P + 'SewerLairLower.png')
    Image.new('RGBA', r.im.size, (0, 0, 0, 0)).save(P + 'SewerLairUpper.png')
    done = draw(True)[0]
    done.im.save(P + 'SewerLairDoneLower.png')
    at = r.at
    with open(os.path.join(ROOT, 'Content', 'sewerLair.js'), 'w', encoding='utf-8') as f:
        f.write('//Doupě pizzového monstra ve stokách (mapa SewerLair): mřížka a místa, která vypisuje tools/doupe.py spolu s obrázky.\n')
        f.write('//NEUPRAVOVAT RUČNĚ - rozmístění se mění v tools/doupe.py, ten tenhle soubor přepíše.   # zeď   . chodník\n')
        f.write('window.SewerLairGrid = {\n')
        f.write('  exit: [%s], //cesta zpátky do tunelu (pod tmavý průchod)\n' % ', '.join('[%d, %d]' % (x, EXIT_ROW) for x in exits))
        f.write('  monster: [%d, %d], //dlaždice uprostřed hnízda, na které sedí monstrum (po souboji louže sýra)\n' % monster)
        f.write('  trigger: [%s], //kdo sem šlápne, vzbudí monstrum\n' % ', '.join('[%d, %d]' % (x, TRIGGER_ROW) for x in trigger))
        f.write('  spots: [%s], //[x, y, druh]: o roura, B krabice, C hrouda sýra, R kůrky\n' % ', '.join('[%d, %d, "%s"]' % s for s in spots))
        f.write('  rows: [\n')
        for y in range(H): f.write('    "%s",\n' % ''.join('.' if at(x, y) in '.M' else '#' for x in range(W)))
        f.write('  ]\n}\n')

    # the preview: before the fight (with the monster and the hero) and after it
    hero = Image.open(os.path.join(ROOT, 'images', 'characters', 'people', 'hero.png')).convert('RGBA')
    shadow = Image.open(os.path.join(ROOT, 'images', 'characters', 'shadow.png')).convert('RGBA')
    beast = Image.open(os.path.join(ROOT, 'images', 'characters', 'pizza-monster.png')).convert('RGBA')
    beast_shadow = Image.open(os.path.join(ROOT, 'images', 'characters', 'pizza-monster-shadow.png')).convert('RGBA')
    sheet = Image.new('RGBA', (r.im.width * 2 + 8, r.im.height), (12, 16, 15, 255))
    for i, room_ in enumerate((r, done)):
        bg = Image.new('RGBA', r.im.size, (12, 16, 15, 255)); bg.alpha_composite(room_.im)
        if i == 0:
            bg.alpha_composite(beast_shadow.crop((0, 0, 48, 48)), (monster[0] * T - 16, monster[1] * T - 34))
            bg.alpha_composite(beast.crop((0, 0, 48, 48)), (monster[0] * T - 16, monster[1] * T - 34))
        hx, hy = (monster[0], TRIGGER_ROW) if i == 0 else (monster[0], monster[1] + 1)
        for sprite_ in (shadow.crop((0, 0, 32, 32)), hero.crop((0, 64, 32, 96))):
            bg.alpha_composite(sprite_, (hx * T - 8, hy * T - 18))
        sheet.alpha_composite(bg, (i * (r.im.width + 8), 0))
    sheet.resize((sheet.width * 3, sheet.height * 3), Image.NEAREST).save(os.path.join(ROOT, 'tools', 'doupe-nahled.png'))
    print('images/maps/SewerLairLower.png, SewerLairUpper.png, SewerLairDoneLower.png, Content/sewerLair.js, tools/doupe-nahled.png')
    print('volných dlaždic v doupěti:', count)


if __name__ == '__main__':
    main()
