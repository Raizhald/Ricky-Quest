# Kreslí značku "tenhle druh už jsi měl": images/icons/owned.png (9 x 9, krabička se zelenou fajfkou).
# V souboji se ukazuje vlevo od jména toho, co vyskočilo z krabice (Battle/Combatant.js, styles/Combatant.css).
# Spuštění z kořene projektu:  python3 tools/znacka.py      (potřebuje Pillow)
from PIL import Image
import os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ART = [
    ".kkkkkkk.",
    "kccccccck",
    "kcccccgck",
    "kccccggck",
    "kgcccgcck",
    "kggcggcck",
    "kcgggccck",
    "kccgcccck",
    ".kkkkkkk.",
]
PAL = {'k': (92, 59, 31, 255), 'c': (243, 233, 210, 255), 'g': (47, 138, 58, 255)}
im = Image.new('RGBA', (9, 9), (0, 0, 0, 0))
for y, row in enumerate(ART):
    assert len(row) == 9, row
    for x, ch in enumerate(row):
        if ch != '.': im.putpixel((x, y), PAL[ch])
im.save(os.path.join(ROOT, 'images', 'icons', 'owned.png'))
print('images/icons/owned.png')
