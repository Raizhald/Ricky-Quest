# Kreslí pizzové monstrum ze sklepa (boss):
#   images/characters/pizza-monster.png         list pro mapu, 2 políčka 48x48 vedle sebe (monstrum se vlní)
#   images/characters/pizza-monster-shadow.png  stín pod ním na mapě (48x48)
#   images/characters/pizzas/x001.png           obrázek do souboje (48x48, první políčko)
# Spuštění z kořene projektu:  python3 tools/monstrum.py      (potřebuje Pillow)
# Barvy jsou vzaté z ostatních pizz ve hře, aby k nim monstrum sedělo. Tvar se skládá ve funkci draw():
# tělo je kolo s korpusem, omáčkou a sýrem, na něm rohy z připálené kůrky, oči, tlama se zuby, feferonky,
# po stranách dvě ruce z roztaveného sýra a dole kapky.
from PIL import Image
import math, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'images', 'characters') + os.sep
S = 48
def c(h, a=255): return (int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16), a)

LINE = c('#3a160d')                                   # the outline of every pizza in the game
CRUST, CRUST_HI, CRUST_SH, BURNT = c('#b7573f'), c('#d57f5c'), c('#8e3c2a'), c('#631f0e')
SAUCE, SAUCE_HI = c('#e35969'), c('#f58a96')
CHEESE, CHEESE_HI, CHEESE_TOP = c('#e2b051'), c('#f1c25a'), c('#ffd986')
PEP, PEP_SH, PEP_LINE = c('#d43535'), c('#b63a42'), c('#6e2425')
MAW, MAW_HI = c('#2b0000'), c('#4f0f16')
EYE, PUPIL = c('#fff6c8'), c('#d43535')
LEAF, LEAF_HI = c('#104309'), c('#3ef126')

def draw(bob=0, lift=0):
    """bob: how many pixels the body has sunk, lift: how far the arms are raised."""
    im = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    px = im.load()
    def put(x, y, col):
        if 0 <= x < S and 0 <= y < S: px[x, y] = col
    def disc(cx, cy, rx, ry, col):
        for y in range(int(cy - ry - 1), int(cy + ry + 2)):
            for x in range(int(cx - rx - 1), int(cx + rx + 2)):
                if ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2 <= 1: put(x, y, col)
    def stroke(points, width, col):
        """A thick line through the points (used for the arms)."""
        for (x0, y0), (x1, y1) in zip(points, points[1:]):
            steps = int(max(abs(x1 - x0), abs(y1 - y0)) * 3) + 1
            for s in range(steps + 1):
                t = s / steps
                disc(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, width / 2, width / 2, col)

    cx, cy, rx, ry = 23.5, 26.5 + bob, 16.5, 15.5 - bob * 0.5

    # arms of molten cheese, behind the body, each ending in three claws
    for side in (-1, 1):
        ax = lambda x: cx + side * x
        pts = [(ax(14), cy + 4), (ax(19), cy - 1), (ax(20.5), cy - 8 - lift), (ax(18.5), cy - 13 - lift)]
        stroke(pts, 4.4, CHEESE)
        stroke([(p[0] - side * 0.6, p[1] - 0.6) for p in pts[1:]], 1.6, CHEESE_HI)
        tipx, tipy = pts[-1]
        for dx, dy in ((-2.2, -2.5), (0, -3.5), (2.2, -2.5)):
            stroke([(tipx, tipy), (tipx + dx, tipy + dy)], 1.2, CHEESE_TOP)

    # horns of burnt crust
    for side in (-1, 1):
        base_l, base_r, tip = (cx + side * 13.5, cy - 9), (cx + side * 8, cy - 13.5), (cx + side * 15.5, cy - 19.5)
        for y in range(S):
            for x in range(S):
                # point in triangle
                def sign(p, a, b): return (p[0] - b[0]) * (a[1] - b[1]) - (a[0] - b[0]) * (p[1] - b[1])
                p = (x, y)
                d1, d2, d3 = sign(p, base_l, base_r), sign(p, base_r, tip), sign(p, tip, base_l)
                if not ((d1 < 0 or d2 < 0 or d3 < 0) and (d1 > 0 or d2 > 0 or d3 > 0)):
                    put(x, y, BURNT if (x - cx) * side > 12.5 else CRUST_SH)

    # the body: crust, a dark baked ring, sauce, cheese
    for y in range(S):
        for x in range(S):
            dx, dy = (x - cx) / rx, (y - cy) / ry
            ang = math.atan2(dy, dx)
            r = math.hypot(dx, dy) / (1 + 0.035 * math.sin(6 * ang + 0.7))
            if r > 1: continue
            light = -(dx * 0.6 + dy * 0.8)                       # lit from the upper left
            if r > 0.88:
                col = CRUST_HI if light > 0.45 else (CRUST_SH if light < -0.45 else CRUST)
            elif r > 0.83: col = BURNT
            elif r > 0.77: col = SAUCE_HI if light > 0.5 else SAUCE
            else:
                n = math.sin(x * 0.9 + y * 0.35) + math.sin(y * 0.8 - x * 0.3 + 1.7)
                col = CHEESE_TOP if n > 1.45 else (CHEESE_HI if n > 0.2 else CHEESE)
            put(x, y, col)

    # toppings: pepperoni and a few leaves
    for (ox, oy) in ((0, -12), (-12.5, 2.5), (12.5, 2.5)):
        x0, y0 = cx + ox, cy + oy
        disc(x0, y0, 3.1, 3.1, PEP_LINE); disc(x0, y0, 2.3, 2.3, PEP); disc(x0 + 0.7, y0 + 0.8, 1.2, 1.1, PEP_SH)
        put(int(x0 - 1), int(y0 - 1), SAUCE_HI)
    for (ox, oy) in ((-6, -13), (6, -12), (-11, -5), (10, -6)):
        x0, y0 = int(cx + ox), int(cy + oy)
        put(x0, y0, LEAF); put(x0 + 1, y0, LEAF); put(x0, y0 + 1, LEAF_HI); put(x0 + 1, y0 + 1, LEAF)

    # eyes: pale and glowing, cut off at an angle by the brows
    EYE_ART = ["kkkk.....", "kYYYkk...", "kYYYYYkk.", "kYYYRRYYk", ".kYYRrYk.", "..kkkkk.."]
    for side in (-1, 1):
        for r, row in enumerate(EYE_ART):
            for i, ch in enumerate(row):
                if ch == '.': continue
                x = int(cx - 0.5) + side * (11 - i) + (1 if side == 1 else 0)
                put(x, int(cy - 8.5) + r, {'k': LINE, 'Y': EYE, 'R': PUPIL, 'r': PEP_LINE}[ch])

    # the maw: dark inside, a tongue of sauce, teeth of baked cheese, two strings of cheese across it
    mx, my, mrx, mry = cx, cy + 6, 9.5, 5.8
    disc(mx, my, mrx + 1, mry + 1, LINE)
    for y in range(S):
        for x in range(S):
            if ((x - mx) / mrx) ** 2 + ((y - my) / mry) ** 2 <= 1:
                put(x, y, MAW_HI if y < my - 1 else MAW)
    disc(mx, my + 3.8, 5, 2.2, SAUCE); disc(mx - 1.5, my + 3.3, 2, 0.8, SAUCE_HI)
    def inside_maw(x, y): return ((x - mx) / mrx) ** 2 + ((y - my) / mry) ** 2 <= 1
    for tx in (-6, -2, 2, 6):                                     # upper teeth hang down
        x0 = int(mx + tx)
        top = next(y for y in range(S) if inside_maw(x0, y))
        for r, w in enumerate((3, 3, 1)):
            for i in range(w):
                x = x0 - w // 2 + i
                if inside_maw(x, top + r): put(x, top + r, EYE if i == 0 and w > 1 else CHEESE_TOP)
    for tx in (-4, 0, 4):                                            # lower teeth point up
        x0 = int(mx + tx)
        bottom = next(y for y in range(S - 1, 0, -1) if inside_maw(x0, y))
        for r, w in enumerate((3, 1)):
            for i in range(w):
                x = x0 - w // 2 + i
                if inside_maw(x, bottom - r): put(x, bottom - r, CHEESE_TOP)
    for sx in (7,):
        x0 = int(mx + sx)
        for y in range(S):
            if inside_maw(x0, y) and px[x0, y] in (MAW, MAW_HI): put(x0, y, CHEESE_HI)

    # cheese dripping off the lower edge
    for (ox, length) in ((-9, 3 + bob), (1, 4), (9, 2 + bob)):
        x0 = int(cx + ox)
        edge = max(y for y in range(S) if px[x0, y][3])
        for r in range(1, length + 1):
            put(x0, edge + r, CHEESE_HI); put(x0 + 1, edge + r, CHEESE)
        put(x0, edge + length + 1, CHEESE)

    # one dark outline around everything
    solid = [[px[x, y][3] > 0 for x in range(S)] for y in range(S)]
    for y in range(S):
        for x in range(S):
            if solid[y][x]: continue
            if any(0 <= x + dx < S and 0 <= y + dy < S and solid[y + dy][x + dx] for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                px[x, y] = LINE
    return im

if __name__ == '__main__':
    frames = [draw(0, 0), draw(1, 1.5)]
    sheet = Image.new('RGBA', (S * len(frames), S), (0, 0, 0, 0))
    for i, fr in enumerate(frames): sheet.paste(fr, (i * S, 0))
    sheet.save(OUT + 'pizza-monster.png')
    frames[0].save(OUT + 'pizzas' + os.sep + 'x001.png')
    shadow = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    sp = shadow.load()
    for y in range(S):
        for x in range(S):
            if ((x - 23.5) / 17) ** 2 + ((y - 44) / 3.4) ** 2 <= 1: sp[x, y] = (23, 17, 57, 64)
    shadow.save(OUT + 'pizza-monster-shadow.png')
    # náhled (zvětšený), do složky tools
    prev = Image.new('RGBA', (S * 2 + 6, S + 4), (127, 125, 140, 255))
    for i, fr in enumerate(frames):
        prev.alpha_composite(shadow, (2 + i * (S + 2), 2)); prev.alpha_composite(fr, (2 + i * (S + 2), 2))
    prev.resize((prev.width * 6, prev.height * 6), Image.NEAREST).save(os.path.join(ROOT, 'tools', 'monstrum-nahled.png'))
    print('images/characters/pizza-monster.png, pizza-monster-shadow.png, pizzas/x001.png')
