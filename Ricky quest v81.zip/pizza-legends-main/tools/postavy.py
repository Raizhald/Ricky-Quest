# Kreslí postavy npc12-npc17 (Máta, Kopr, Rukola, Fenykl, Pažitka, Don Brokolini), npc23 (Emma)
# a npc24, npc25 (vědci ze sklepa: Kvasnička a Kůrková) a npc26 (bezdomovec ze stok) a npc27 (hlídač z Tony Boii's).
# Spuštění z kořene projektu:  python3 tools/postavy.py      (potřebuje Pillow: pip install pillow)
#
# List postavy má 128x128 px, 4x4 políčka po 32 px: řádky = dolů, doprava, nahoru, doleva.
# Tělo a chůze se berou z plešatého kuchaře (npc2) a přebarví se; hlava se kreslí tady znak po znaku.
# Mřížka hlavy je 24 znaků široká, sloupec i znamená x = 4 + i, "top" je y prvního řádku.
# Holá hlava začíná na y = 16, oči jsou na y = 21 a 22, brada na y = 23. Pohled doleva je zrcadlo pohledu doprava.
# Nová postava = další slovník jako MATA a řádek v seznamu CHARS na konci souboru.
from PIL import Image
import math, os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, 'images', 'characters', 'people') + os.sep
BASE = Image.open(SRC + 'npc2.png').convert('RGBA')

def hexc(h):
    h = h.lstrip('#')
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), 255)

SKINS = {
    'light': dict(o='#4e0d1f', s1='#ffeed9', s2='#f6d7b1', s3='#f3d9b8', s4='#d5ab90', c='#ffc2aa', e='#08275e', p='#f27a96'),
    'pale':  dict(o='#43213a', s1='#fff4ea', s2='#f4e0d2', s3='#ead0c2', s4='#c9a79e', c='#e9bdb0', e='#2b1840', p='#e98aa8'),
    'tan':   dict(o='#3e290c', s1='#f7e1c4', s2='#dfc199', s3='#c9a97e', s4='#b88a55', c='#c29a64', e='#32110b', p='#d98a6a'),
    'dark':  dict(o='#2a1208', s1='#b88560', s2='#a06c48', s3='#8f5c3c', s4='#74452b', c='#7f4d31', e='#170802', p='#b5604a'),
}

# npc2 body colours -> role
BODY_ROLES = {
    '#3e290c': 'o', '#3e290d': 'o', '#40290e': 'o',
    '#c9a97e': 's3', '#dfc199': 's2', '#f4d9b5': 's1', '#f7e1c4': 's1', '#d09b53': 's4',
    '#c29a64': 'c', '#c29a65': 'c', '#c29965': 'c',
    '#c64dc4': 'shirtL', '#08275e': 'shirtL', '#aa16a7': 'shirtD', '#6c1f6a': 'shirtO', '#2f002e': 'shirtX',
    '#4e0d1f': 'shirtX', '#303559': 'shirtO',
    '#4e5459': 'pants', '#4d5357': 'pants', '#000400': 'shoes', '#bfc4e2': 'sock',
}

def body_frame(r, c, pal):
    """Body of frame (row r, col c) of the base sheet, recoloured; everything above the neck removed."""
    neck = 24 if c in (0, 2) else 25
    fr = Image.new('RGBA', (32, 32), (0, 0, 0, 0))
    for y in range(neck, 32):
        for x in range(32):
            p = BASE.getpixel((c * 32 + x, r * 32 + y))
            if p[3] < 200:
                continue
            key = '#%02x%02x%02x' % p[:3]
            role = BODY_ROLES.get(key)
            if role is None:
                raise SystemExit('unknown body colour ' + key)
            fr.putpixel((x, y), hexc(pal[role]))
    return fr

def paste_art(fr, art, pal, top, dy, dx=0):
    """art: list of 24-char rows, column i is x = 4 + i, first row is y = top."""
    for r, row in enumerate(art):
        assert len(row) == 24, (len(row), row)
        for i, ch in enumerate(row):
            if ch == '.':
                continue
            if ch == '_':  # eraser
                fr.putpixel((4 + i + dx, top + r + dy), (0, 0, 0, 0))
                continue
            if ch not in pal:
                raise SystemExit('no colour for %r in row %r' % (ch, row))
            fr.putpixel((4 + i + dx, top + r + dy), hexc(pal[ch]))

def build(char):
    skin = SKINS[char['skin']]
    pal = dict(char['pal'])
    pal.update({'o': skin['o'], '1': skin['s1'], '2': skin['s2'], '3': skin['s3'], '4': skin['s4'],
                'c': skin['c'], 'e': char.get('eye', skin['e']), 'p': skin['p']})
    bodypal = dict(o=skin['o'], s1=skin['s1'], s2=skin['s2'], s3=skin['s3'], s4=skin['s4'], c=skin['c'],
                   shirtL=char['shirt'][0], shirtD=char['shirt'][1], shirtO=char['shirt'][2], shirtX=char['shirt'][3],
                   pants=char.get('pants', '#4d5357'), shoes=char.get('shoes', '#000400'), sock=char.get('sock', '#bfc4e2'))
    sheet = Image.new('RGBA', (128, 128), (0, 0, 0, 0))
    for r, key in ((0, 'down'), (1, 'right'), (2, 'up')):
        for c in range(4):
            dy = 0 if c in (0, 2) else 1
            fr = body_frame(r, c, bodypal)
            extra = char.get('body_' + key)
            if extra:
                paste_art(fr, extra['art'], pal, extra['top'], dy)
            head = char[key]
            paste_art(fr, head['art'], pal, head['top'], dy)
            sheet.paste(fr, (c * 32, r * 32))
            if key == 'right':
                sheet.paste(fr.transpose(Image.FLIP_LEFT_RIGHT), (c * 32, 3 * 32))
    return sheet

def preview(sheets, path, scale=8, bg=(203, 170, 135, 255)):
    """Standing frames of every direction plus one step, side by side."""
    cells = [(0, 0), (1, 0), (2, 0), (3, 0), (0, 1), (1, 1)]
    W = 24
    out = Image.new('RGBA', (len(cells) * W * scale, len(sheets) * 26 * scale), bg)
    for n, sh in enumerate(sheets):
        for k, (r, c) in enumerate(cells):
            fr = sh.crop((c * 32 + 4, r * 32 + 6, c * 32 + 28, r * 32 + 32))
            out.alpha_composite(fr.resize((W * scale, 26 * scale), Image.NEAREST), (k * W * scale, n * 26 * scale))
    out.save(path)


# ---------------------------------------------------------------- Máta: two buns, mint hair
MATA = dict(
    skin='light',
    pal=dict(H='#d6fff3', h='#86e6c8', j='#49b796', k='#1c6b58'),
    shirt=('#ffffff', '#cfe6ee', '#3b6f8f', '#1d3f57'),
    down=dict(top=12, art=[
        ".....kkk.......kkk......",
        "....kHHhk.....kHHhk.....",
        "....khhjk.....khhjk.....",
        ".....kkkkkkkkkkkkk......",
        ".......kHHhhhhhk........",
        "......kHhhhhhhhhk.......",
        "......khhhhhhhhhk.......",
        "......khjh222hjhk.......",
        "......kj2222222jk.......",
        "......op2e222e2po.......",
        "......op2e2p2e2po.......",
        ".......oocccccoo........",
    ]),
    right=dict(top=12, art=[
        ".........kkk............",
        "........kHHhk...........",
        "........khhjk...........",
        ".........kkkkkk.........",
        "........kHHhhhhk........",
        ".......kHhhhhhhhk.......",
        ".......khhhhhhhhk.......",
        ".......khhhjhh22o.......",
        ".......khhj22222o.......",
        ".......khj2222e2o.......",
        ".......kjj4p22e2po......",
        "........kocccccoo.......",
    ]),
    up=dict(top=12, art=[
        ".....kkk.......kkk......",
        "....kHHhk.....kHHhk.....",
        "....khhjk.....khhjk.....",
        ".....kkkkkkkkkkkkk......",
        ".......kHHhhhhhk........",
        "......kHhhhhhhhhk.......",
        "......khhhhhhhhhk.......",
        "......khhhhhhhhhk.......",
        "......khhhhjhhhhk.......",
        "......kjhhhjhhhjk.......",
        "......kjjhhjhhjjk.......",
        ".......kkjjjjjkk........",
    ]),
)

# ---------------------------------------------------------------- Kopr: baseball cap
KOPR = dict(
    skin='dark',
    pal=dict(A='#ffc36b', a='#f28c28', b='#b9590f', B='#5a2707', W='#ffffff', j='#1a110b'),
    shirt=('#5aa0f2', '#2f6fd0', '#1c3f86', '#0f2350'),
    down=dict(top=15, art=[
        "........BBBBBBB.........",
        ".......BAAaaaaaB........",
        "......BAAaaaaaaaB.......",
        "......BaaaWWWaaaB.......",
        ".....BbbbbbbbbbbbB......",
        "......oj3333333jo.......",
        "......o34e333e34o.......",
        "......o13e313e31o.......",
        ".......oocccccoo........",
    ]),
    right=dict(top=15, art=[
        ".........BBBBBB.........",
        "........BAAaaaaB........",
        ".......BAAaaaaaaB.......",
        ".......BaaaaaaWaB.......",
        ".......BaaaaaaaabbbB....",
        "........oj333333oBB.....",
        ".......oj43333e3o.......",
        ".......o433313e31o......",
        "........oocccccoo.......",
    ]),
    up=dict(top=15, art=[
        "........BBBBBBB.........",
        ".......BAAaaaaaB........",
        "......BAAaaaaaaaB.......",
        "......BaaaaaaaaaB.......",
        "......BaaabbbaaaB.......",
        "......Bbbbj3jbbbB.......",
        "......o3jjjjjjj3o.......",
        "......o133333331o.......",
        ".......oocccccoo........",
    ]),
)

# ---------------------------------------------------------------- Rukola: top bun, glasses
RUKOLA = dict(
    skin='light',
    pal=dict(H='#ff9a66', h='#de5a31', j='#a8341c', k='#5a170d', g='#2b2b3a', G='#d8f3ff'),
    shirt=('#58c463', '#31933f', '#17521f', '#0c3312'),
    down=dict(top=12, art=[
        "..........kkk...........",
        ".........kHHhk..........",
        ".........khhjk..........",
        "........kkkkkkk.........",
        ".......kHHhhhhhk........",
        "......kHhhhhhhhhk.......",
        "......khhhhjhhhhk.......",
        "......khhj222jhhk.......",
        "......kj2222222jk.......",
        "......opgGg2gGgpo.......",
        "......op2e2p2e2po.......",
        ".......oocccccoo........",
    ]),
    right=dict(top=12, art=[
        "...........kkk..........",
        "..........kHHhk.........",
        "..........khhjk.........",
        ".........kkkkkk.........",
        "........kHHhhhhk........",
        ".......kHhhhhhhhk.......",
        ".......khhhhhhhhk.......",
        ".......khhhjhh22o.......",
        ".......khhj22222o.......",
        ".......khj222gGgo.......",
        ".......kjj4p22e2po......",
        "........kocccccoo.......",
    ]),
    up=dict(top=12, art=[
        "..........kkk...........",
        ".........kHHhk..........",
        ".........khhjk..........",
        "........kkkkkkk.........",
        ".......kHHhhhhhk........",
        "......kHhhhhhhhhk.......",
        "......khhhhhhhhhk.......",
        "......khhhhhhhhhk.......",
        "......khhhhjhhhhk.......",
        "......kjhhhjhhhjk.......",
        "......okjjhjhjjko.......",
        ".......ookkkkkoo........",
    ]),
)

# ---------------------------------------------------------------- Fenykl: old man, big white beard
FENYKL = dict(
    skin='tan',
    pal=dict(H='#ffffff', h='#cfd6e6', k='#6c7196'),
    shirt=('#c9935a', '#9a6835', '#55330f', '#331c06'),
    down=dict(top=16, art=[
        ".........ooooo..........",
        "........o11222o.........",
        ".......o1222222o........",
        "......ko2222222ok.......",
        ".....kHo3HH3HH3oHk......",
        ".....kHh3e333e3hHk......",
        ".....kHHHe3p3eHHHk......",
        "......kHHhHHHhHHk.......",
        "......kHHHhHhHHHk.......",
        ".......kHHhHhHHk........",
        "........kkHhHkk.........",
        "..........kkk...........",
    ]),
    right=dict(top=16, art=[
        "..........ooooo.........",
        ".........o11222o........",
        "........o1222222o.......",
        ".......kH2222222o.......",
        "......kHHh333HH3o.......",
        "......kHHh3333e3o.......",
        "......kHHh3313e31o......",
        ".......kHhHHHHHHHk......",
        "..........kHHhHHHk......",
        "...........kHHhHHk......",
        "............kHHHk.......",
        ".............kkk........",
    ]),
    up=dict(top=16, art=[
        ".........ooooo..........",
        "........o11222o.........",
        ".......o1222222o........",
        "......ko2222222ok.......",
        ".....kHH3333333HHk......",
        ".....kHHHh333hHHHk......",
        ".....kHHHHHhHHHHHk......",
        "......kkHHHHHHHkk.......",
    ]),
)

# ---------------------------------------------------------------- Pažitka: mohawk
PAZITKA = dict(
    skin='pale',
    pal=dict(H='#f0b8ff', h='#b85cf0', j='#7d2fc4', k='#3a126b', s='#c9b4bd', y='#ffd23f'),
    shirt=('#d14a5a', '#96283a', '#4a0f1c', '#2b0810'),
    down=dict(top=9, art=[
        "...........k............",
        "..........kHk...........",
        "..........kHk...........",
        ".........kHHhk..........",
        ".........kHhhk..........",
        ".........kHhhk..........",
        ".........kHhjk..........",
        ".........kHhjk..........",
        "........osHhjso.........",
        ".......ossHhjsso........",
        ".......os22j22so........",
        ".......o3333333o........",
        "......o34e333e34o.......",
        "......oy3e313e31o.......",
        ".......oocccccoo........",
    ]),
    right=dict(top=9, art=[
        ".........k..k..k........",
        "........kHkkHkkHk.......",
        ".......kHHhHHhHHhk......",
        ".......kHhhhhhhhhk......",
        ".......khhhhhhhhjk......",
        "........khhhhhhjk.......",
        "........kjhhhhjjk.......",
        ".........kjjjjjk........",
        ".........oss222o........",
        "........osss2222o.......",
        "........o4ss2222o.......",
        "........o3333333o.......",
        ".......o143333e3o.......",
        ".......o433313e31o......",
        "........oocccccoo.......",
    ]),
    up=dict(top=9, art=[
        "...........k............",
        "..........kHk...........",
        "..........kHk...........",
        ".........kHHhk..........",
        ".........kHhhk..........",
        ".........kHhhk..........",
        ".........kHhjk..........",
        ".........kHhjk..........",
        "........osHhjso.........",
        ".......ossHhjsso........",
        ".......ossHhjsso........",
        ".......o3shhjs3o........",
        "......o343hjj343o.......",
        "......o1333j3331o.......",
        ".......oocccccoo........",
    ]),
)

# ---------------------------------------------------------------- Don Brokolini: broccoli afro, sunglasses, moustache
def afro(cx, cy, R=5.6, bump=2.5, top=7, rows=17):
    """Bumpy round hair as art rows (24 wide, first row y = top). cx is given as column index."""
    bumps = []
    for deg in (150, 180, 210, 240, 270, 300, 330, 0, 30):
        a = math.radians(deg)
        bumps.append((cx + R * math.cos(a), cy + R * math.sin(a)))
    def inside(i, y):
        if (i - cx) ** 2 + (y - cy) ** 2 <= (R + 0.6) ** 2:
            return True
        return any((i - bx) ** 2 + (y - by) ** 2 <= bump ** 2 for bx, by in bumps)
    art = []
    for r in range(rows):
        y = top + r
        row = ''
        for i in range(24):
            if not inside(i, y):
                row += '.'
                continue
            edge = not (inside(i - 1, y) and inside(i + 1, y) and inside(i, y - 1) and inside(i, y + 1))
            if edge:
                row += 'k'
                continue
            # light on the upper left of every floret, dark towards the lower right and in the creases
            lit = any((i - (bx - 0.9)) ** 2 + (y - (by - 0.9)) ** 2 <= 1.3 ** 2 for bx, by in bumps) \
                or (i - (cx - 1.5)) ** 2 + (y - (cy - 2.5)) ** 2 <= 1.6 ** 2
            crease = min(abs(math.hypot(i - bx, y - by) - bump) for bx, by in bumps) < 0.45 \
                and (i - cx) ** 2 + (y - cy) ** 2 <= (R + 0.6) ** 2
            shade = (i - cx) * 0.7 + (y - cy) * 0.7 > 3.6
            row += 'H' if lit else ('j' if (crease or shade) else 'h')
        art.append(row)
    return art

def trim_tip(art):
    """A row with a single pixel on top of the hair looks like a stray dot: remove it."""
    out = list(art)
    for r, row in enumerate(out):
        n = len(row.replace('.', ''))
        if n == 0:
            continue
        if n == 1:
            out[r] = '.' * 24
            # the pixel below it was interior, make it outline
            i = row.index(row.replace('.', ''))
            nxt = list(out[r + 1]); nxt[i] = 'k'; out[r + 1] = ''.join(nxt)
        break
    return out

def compose(*layers):
    """Layers of (top, art), later ones on top. Returns dict(top, art)."""
    top = min(t for t, _ in layers)
    bottom = max(t + len(a) for t, a in layers)
    rows = [list('.' * 24) for _ in range(bottom - top)]
    for t, art in layers:
        for r, line in enumerate(art):
            assert len(line) == 24, line
            for i, ch in enumerate(line):
                if ch != '.':
                    rows[t + r - top][i] = '.' if ch == '_' else ch
    return dict(top=top, art=[''.join(r) for r in rows])

BALD_DOWN = [
    ".........ooooo..........",
    "........o11222o.........",
    ".......o1222222o........",
    ".......o4222222o........",
    ".......o3333333o........",
    "......o34e333e34o.......",
    "......o13e313e31o.......",
    ".......oocccccoo........",
]
BALD_RIGHT = [
    "..........ooooo.........",
    ".........o11222o........",
    "........o1222222o.......",
    "........o4222222o.......",
    "........o3333333o.......",
    ".......o143333e3o.......",
    ".......o433313e31o......",
    "........oocccccoo.......",
]
BALD_UP = [
    ".........ooooo..........",
    "........o11222o.........",
    ".......o1222222o........",
    ".......o4222222o........",
    ".......o3333333o........",
    "......o343333334o.......",
    "......o133333331o.......",
    ".......oocccccoo........",
]
BROK_FACE_DOWN = [
    "........kj222jk.........",  # 18
    ".......k2222222k........",  # 19
    ".......o3333333o........",  # 20
    "......o3GXXXGXX3o.......",  # 21
    "......o1XXX3XXX1o.......",  # 22
    ".......ooMMcMMoo........",  # 23
]
BROK_FACE_RIGHT = [
    "............j222o.......",  # 19
    "...........j3333o.......",  # 20
    "..........jXXXGXo.......",  # 21
    "..........j33XXX1o......",  # 22
    "..........occcMMMo......",  # 23
]
BROKOLINI = dict(
    skin='tan',
    pal=dict(H='#b6f07a', h='#6fc044', j='#3f8a2c', k='#1c4a1a', X='#101018', G='#9fb4dc', M='#241408', W='#ffffff', r='#ffd23f'),
    shirt=('#8a5cc4', '#5f3a94', '#2c1650', '#1a0b33'),
    pants='#2a2a34',
    down=compose((16, BALD_DOWN), (6, trim_tip(afro(11, 14.5, R=5.2, bump=2.4, top=6, rows=16))), (18, BROK_FACE_DOWN)),
    right=compose((16, BALD_RIGHT), (6, trim_tip(afro(11, 14.5, R=5.2, bump=2.4, top=6, rows=16))), (19, BROK_FACE_RIGHT)),
    up=compose((16, BALD_UP), (6, trim_tip(afro(11, 14.5, R=5.2, bump=2.4, top=6, rows=16)))),
    body_down=dict(top=25, art=[
        "..........WrW...........",
        "...........r............",
    ]),
)

# ---------------------------------------------------------------- Emma: red hair, ponytail to one side, yellow headband
EMMA = dict(
    skin='light',
    pal=dict(H='#ff9a7a', h='#e2503c', j='#a82a20', k='#5a100d', y='#ffd23f'),
    shirt=('#ffc24a', '#e58a1f', '#8a470c', '#552a06'),
    down=dict(top=12, art=[
        "...............kk.......",
        "..............kHhk......",
        "..............khhjk.....",
        ".........kkkkkkhjk......",
        "........kHHhhhhjk.......",
        ".......kHhhhhhhhk.......",
        ".......kyyyyyyyyk.......",
        ".......khhjhhjhhk.......",
        ".......kj3j333jjk.......",
        "......o34e333e34o.......",
        "......o13e313e31o.......",
        ".......oocccccoo........",
    ]),
    right=dict(top=12, art=[
        ".......kk...............",
        "......kHhk..............",
        ".....khhjk..............",
        "......kjhkkkkkk.........",
        ".......kkHHhhhhk........",
        "........kHhhhhhhk.......",
        "........kyyyyyyyk.......",
        "........khhhhjh2o.......",
        "........khhhj333o.......",
        ".......okhj333e3o.......",
        ".......o4j3313e31o......",
        "........oocccccoo.......",
    ]),
    up=dict(top=12, art=[
        ".......kk...............",
        "......kHhk..............",
        ".....khhjk..............",
        "......kjhkkkkkk.........",
        ".......kkHHhhhhk........",
        ".......kHhhhhhhhk.......",
        ".......kyyyyyyyyk.......",
        ".......khhhhhhhjk.......",
        ".......khhhhhhhjk.......",
        "......okhhhjhhjjko......",
        "......okjjhjhjjjko......",
        ".......ookkkkkoo........",
    ]),
)

# ---------------------------------------------------------------- Kvasnička: old scientist, bald on top, white tufts, glasses, moustache
COAT = ('#ffffff', '#dfe5f0', '#8e97ad', '#5a6278')        # the white lab coat both scientists wear
KVASNICKA = dict(
    skin='light',
    pal=dict(H='#ffffff', h='#cfd6e6', k='#6c7196', g='#2b2b3a', G='#d8f3ff', r='#e0303a'),
    shirt=COAT, pants='#3b4058',
    down=dict(top=16, art=[
        ".........ooooo..........",
        ".....kkko11222okkk......",
        "....kHHo1222222oHHk.....",
        "....kHhH4222222HhHk.....",
        ".....kHh3333333hHk......",
        "......o3gGg3gGg3o.......",
        "......o13e313e31o.......",
        ".......ooHHcHHoo........",
    ]),
    right=dict(top=16, art=[
        "..........ooooo.........",
        ".......kko11222o........",
        "......kHH1222222o.......",
        ".....kHhH4222222o.......",
        "......kHh3333333o.......",
        ".......o14333gGgo.......",
        ".......o433313e31o......",
        "........oocccHHHo.......",
    ]),
    up=dict(top=16, art=[
        ".........ooooo..........",
        ".....kkko11222okkk......",
        "....kHHo1222222oHHk.....",
        "....kHhHHHhHHHhHhHk.....",
        ".....kHhHhhHhHhhHk......",
        "......okhHhhhHhko.......",
        "......o133333331o.......",
        ".......oocccccoo........",
    ]),
    body_down=dict(top=25, art=[
        "..........rrr...........",
        "...........r............",
    ]),
)

# ---------------------------------------------------------------- Kůrková: scientist with a dark bob and goggles pushed up on the forehead
KURKOVA = dict(
    skin='pale',
    pal=dict(H='#9a80e0', h='#5f45ad', j='#3c267c', k='#1e1140', g='#3b3b46', G='#8ff3ff', b='#39c0a8'),
    shirt=COAT, pants='#3b4058',
    down=dict(top=15, art=[
        "........kkkkkkk.........",
        ".......kHHhhhhhk........",
        "......kHhhhhhhhhk.......",
        "......khgGGgGGghk.......",
        "......khh22222hhk.......",
        "......kh3333333hk.......",
        "......kh4e333e4hk.......",
        "......kj3e313e3jk.......",
        ".......kjcccccjk........",
    ]),
    right=dict(top=15, art=[
        ".........kkkkkkk........",
        "........kHHhhhhhk.......",
        ".......kHhhhhhhhhk......",
        ".......khhhhggGGgk......",
        ".......khhhh2222o.......",
        ".......khhhj3333o.......",
        ".......khhj333e3o.......",
        ".......kjhj313e31o......",
        "........kkjccccoo.......",
    ]),
    up=dict(top=15, art=[
        "........kkkkkkk.........",
        ".......kHHhhhhhk........",
        "......kHhhhhhhhhk.......",
        "......khggggggghk.......",
        "......khhhhhhhhjk.......",
        "......khhhhhhhhjk.......",
        "......khhhjhhhjjk.......",
        "......kjhjjhjjhjk.......",
        ".......kkjjjjjkk........",
    ]),
    body_down=dict(top=26, art=[
        ".............b..........",
    ]),
)

# ---------------------------------------------------------------- Bezdomovec ze stok: červená čepice, šedé strniště a vousy, obnošený kabát
HOBO = dict(
    skin='tan',
    pal=dict(B='#9c4a3c', F='#c0675a', f='#7e3329', G='#c4c2b8', g='#8c8a82', h='#a9a79d', k='#4a463f'),
    shirt=('#8f7f58', '#6e6140', '#4a3f26', '#2e2615'), pants='#5b4d3c', shoes='#2a211a', sock='#8c8a82',
    down=dict(top=14, art=[
        ".........kkkkk..........",
        "........kBBBBBk.........",
        ".......kBBBBBBBk........",
        "......kFFFFFFFFFk.......",
        "......kFfFfFfFfFk.......",
        "......ko2222222ok.......",
        ".....kGo3333333oGk......",
        ".....kGh3e333e3hGk......",
        "......o33e3p3e33o.......",
        "......okGgGGGgGko.......",
        ".......kGGgGgGGk........",
        "........kGgGgGk.........",
        ".........kkGkk..........",
    ]),
    right=dict(top=14, art=[
        "..........kkkkk.........",
        ".........kBBBBBk........",
        "........kBBBBBBBk.......",
        ".......kFFFFFFFFFk......",
        ".......kFfFfFfFfFk......",
        ".......kG2222222o.......",
        "......kGGh333GG3o.......",
        "......kGGh3333e3o.......",
        "......kGGh3313e31o......",
        ".......kGgGGGgGGGk......",
        "..........kGGgGGGk......",
        "...........kGgGGk.......",
        "............kkGk........",
    ]),
    up=dict(top=14, art=[
        ".........kkkkk..........",
        "........kBBBBBk.........",
        ".......kBBBBBBBk........",
        "......kFFFFFFFFFk.......",
        "......kFfFfFfFfFk.......",
        "......kGGGGGGGGGk.......",
        ".....kGGGGGGGGGGGk......",
        ".....kGGgGGGGGgGGk......",
        ".....kGGGGgGGgGGGk......",
        "......kkGGGGGGGkk.......",
    ]),
)

# ---------------------------------------------------------------- Hlídač: ochranka z Tony Boii's (tmavé sako, brýle, přísná pusa)
HLIDAC = dict(
    skin='light',
    pal=dict(H='#3a3a46', h='#22222c', k='#0e0e14', S='#12121a', s='#6a7aa0'),
    shirt=('#3a3a46', '#262630', '#14141b', '#0a0a0e'), pants='#1d1d26', shoes='#0a0a0a', sock='#555566',
    down=dict(top=15, art=[
        "........kkkkkkk.........",
        ".......kHHHHHHHk........",
        "......kHHhHHHhHHk.......",
        "......kHH22222HHk.......",
        "......o222222222o.......",
        "......o333333333o.......",
        "......oSsSS3SsSSo.......",
        "......o33333o333o.......",
        ".......oocccccoo........",
    ]),
    right=dict(top=15, art=[
        ".........kkkkkk.........",
        "........kHHHHHHk........",
        ".......kHHhHHHHHk.......",
        ".......kHHHHH222o.......",
        ".......kHHH222222o......",
        ".......o4H333333o.......",
        ".......o43SSSSsSSo......",
        ".......o43333p31o.......",
        "........oocccccoo.......",
    ]),
    up=dict(top=15, art=[
        "........kkkkkkk.........",
        ".......kHHHHHHHk........",
        "......kHHhHHHhHHk.......",
        "......kHHHHHHHHHk.......",
        "......kHHhHHHhHHk.......",
        "......kHHHHHHHHHk.......",
        "......oHHHHHHHHHo.......",
        "......o3HHHHHHH3o.......",
        ".......oocccccoo........",
    ]),
)

CHARS = [('npc12', MATA), ('npc13', KOPR), ('npc14', RUKOLA), ('npc15', FENYKL), ('npc16', PAZITKA), ('npc17', BROKOLINI), ('npc23', EMMA),
         ('npc24', KVASNICKA), ('npc25', KURKOVA), ('npc26', HOBO), ('npc27', HLIDAC)]

if __name__ == '__main__':
    sheets = []
    for name, ch in CHARS:
        sh = build(ch)
        sh.save(SRC + name + '.png')
        sheets.append(sh)
        print('images/characters/people/%s.png' % name)
    # náhled všech postav vedle sebe (zvětšený), do složky tools
    preview(sheets, os.path.join(ROOT, 'tools', 'postavy-nahled.png'))
