# Kreslí Zadní uličky (mapa BackAlleys), kam se vyleze žebříkem ze stok:
#   images/maps/BackAlleysLower.png, BackAlleysUpper.png, BackAlleysBattle.png
#   images/maps/BackAlleysOpenLower.png, BackAlleysOpenUpper.png (totéž bez zábrany na severu)
#   Content/backAlleys.js  (mřížka mapy pro OverWorldMap.js - NEUPRAVOVAT RUČNĚ, přepíše se)
#   tools/ulicky-nahled.png (celá mapa zmenšená na polovinu, jen na koukání)
# Spuštění z kořene projektu:  python3 tools/ulicky.py      (potřebuje Pillow)
#
# Všechno rozmístění je tady nahoře v části ROZVRŽENÍ: carve() vyřízne chodník do zástavby, pod tím jsou
# popelnice, bedny, zídky na seskok (ledge), krabice se zapomenutými pizzami (boxes) a další věci.
# Domy se z toho, co zbylo, poskládají samy (střecha + dvě dlaždice vysoká zadní zeď dole).
# Skript na konci zkontroluje, že se dá všude dojít a odevšad zase zpátky k poklopu (kvůli zídkám, přes které
# se dá jen dolů). Kostky a krabice si bere z images/maps/StreetLower.png, takže ulice musí zůstat na místě.
#
# Znaky v mřížce (Content/backAlleys.js):  # zeď   . volno   v zídka, přes kterou se seskakuje dolů
#                                          b krabice od pizzy (náhodné souboje s pizzami)
#                                          B krabičky od burgerů (náhodné souboje s burgery, jen ve dvorku nahoře)
# Do Content/backAlleys.js se zapisuje i rozestavení gangu Burger Queen (trainer() v části ROZVRŽENÍ).
from PIL import Image
import os, random, math, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P = os.path.join(ROOT, 'images', 'maps') + os.sep
W, H = 55, 51                         # tiles
T = 16


def c(h, a=255):
    return (int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16), a)


# =====================================================================================================
# ROZVRŽENÍ (layout)
# =====================================================================================================
floor = {}                            # (x, y) -> 'd' dark alley slabs, 'l' light pavement, 'a' asphalt
def carve(x0, y0, x1, y1, kind):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            floor[(x, y)] = kind

# --- the bottom: the nook with the manhole and the first alley, with a jog south in the middle
carve(5, 39, 7, 41, 'd')              # nook with the manhole
carve(5, 42, 22, 44, 'd')             # bottom alley, west part
carve(21, 44, 36, 46, 'd')            # ... middle part, two rows lower
carve(35, 42, 48, 44, 'd')            # ... east part
carve(39, 38, 43, 41, 'a')            # back yard full of boxes (dead end)
carve(46, 32, 48, 41, 'd')            # passage north at the east end
# --- second alley back to the west, with a jog south in the middle
carve(31, 32, 48, 34, 'd')
carve(17, 35, 32, 37, 'd')
carve(5, 32, 18, 34, 'd')
carve(11, 35, 12, 41, 'd')            # shortcut down to the manhole (one way, over a ledge)
carve(5, 28, 7, 31, 'd')              # passage north at the west end
# --- the car park and the alleys winding east from it
carve(5, 20, 20, 27, 'a')             # car park
carve(14, 16, 18, 19, 'a')            # loading bay
carve(21, 20, 31, 22, 'd')
carve(29, 23, 31, 28, 'd')
carve(29, 26, 40, 28, 'd')
carve(41, 26, 45, 28, 'd')            # dead end with boxes
carve(38, 20, 40, 25, 'd')
carve(38, 20, 48, 22, 'd')
# --- terraces on the east side: up around the ends of the ledges, down straight over them
carve(42, 5, 50, 19, 'l')
# --- top alley to the west, with a jog north in the middle, and a courtyard south of it
carve(32, 5, 41, 7, 'd')
carve(21, 3, 33, 5, 'd')
carve(13, 5, 22, 7, 'd')
carve(26, 6, 27, 10, 'd')
carve(23, 11, 31, 15, 'd')            # courtyard
# --- the little square at the end with the closed way out, and the shortcut from it down to the car park
carve(5, 5, 13, 10, 'l')
carve(8, 0, 9, 4, 'l')
carve(10, 11, 11, 19, 'd')

MANHOLE = (6, 40)                     # the way back down into the sewers (hero arrives one tile below it)
GATE = [(8, 3), (9, 3)]               # barrier across the way out to the north (the next part of the town)

props = {}                            # (x, y) -> kind; every tile here is a wall
def put(kind, x, y):
    assert (x, y) in floor, (kind, x, y)
    assert (x, y) not in props, (kind, x, y)
    props[(x, y)] = kind
def dumpster(x, y): put('dumpster', x, y); put('_', x + 1, y)
def crate(x, y): put('crate', x, y)
def crates(x, y): put('crate2', x, y)             # two on top of each other
def can(x, y): put('can', x, y)
def stack(x, y): put('stack', x, y)
def lamp(x, y): put('lamp', x, y)
def bush(x, y): put('bush', x, y)
def planter(x, y):                                 # 2 x 3 tiles, like the ones on the main street
    put('planter', x, y)
    for dy in range(3):
        for dx in range(2):
            if dx or dy: put('_', x + dx, y + dy)
def fence(x0, x1, y):
    for x in range(x0, x1 + 1): put('fence', x, y)

ledges = {}                           # (x, y) -> 'down': a wall, but the hero hops over it when walking down
def ledge(x0, x1, y):
    for x in range(x0, x1 + 1):
        assert (x, y) in floor and (x, y) not in props
        ledges[(x, y)] = 'down'

# Boxes always lie right across the passage, from wall to wall, so they cannot be walked around (the script counts
# the patches that can be avoided on the way to the barrier: only those in dead ends should be).
boxes = set()                         # tiles littered with pizza boxes = forgotten pizzas (random fights)
def patch(x0, y0, x1, y1):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            assert (x, y) in floor and (x, y) not in props and (x, y) not in ledges, (x, y)
            boxes.add((x, y))

burger_boxes = set()                  # tiles littered with burger boxes = stray hamburgers (the courtyard only)
def bpatch(x0, y0, x1, y1):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            assert (x, y) in floor and (x, y) not in props and (x, y) not in ledges and (x, y) not in boxes, (x, y)
            burger_boxes.add((x, y))

# nook and bottom alley
can(5, 39)
dumpster(9, 42); patch(14, 42, 19, 44); stack(21, 42)
crates(25, 44); crate(25, 45); crate(29, 45); crates(29, 46); patch(31, 44, 34, 46)
can(37, 42); can(38, 42); dumpster(44, 42)
# back yard
patch(39, 38, 43, 39); dumpster(39, 40); crate(43, 41)
# east passage: a fence with a gap
fence(46, 47, 38)
# second alley
patch(41, 32, 44, 34); dumpster(36, 32); crate(34, 33); crates(34, 34)
crates(28, 35); crate(28, 36); crate(24, 36); crates(24, 37); can(20, 35)
patch(13, 32, 16, 34); stack(9, 32); lamp(18, 32)
ledge(11, 12, 38)
can(5, 31)
# car park
planter(8, 22); planter(15, 22); lamp(12, 23)
dumpster(14, 16); dumpster(17, 16); crates(18, 18)
# alleys east of the car park
crates(24, 20); crate(24, 21); crate(27, 21); crates(27, 22)
patch(29, 24, 31, 25)
dumpster(33, 26); can(36, 28); can(37, 28)
crate(41, 26); crates(41, 28); patch(43, 26, 45, 28)
stack(40, 23)
# terraces
ledge(42, 48, 17); patch(44, 14, 47, 16)
ledge(44, 50, 13); patch(45, 10, 47, 12)
ledge(42, 48, 9)
planter(45, 5); lamp(50, 5); lamp(42, 19); lamp(50, 16)
# top alley
dumpster(37, 5); crate(35, 6); crates(35, 7)
patch(28, 3, 31, 5); can(23, 3); can(24, 3)
dumpster(16, 5); crates(19, 6); crate(19, 7)
# courtyard
dumpster(29, 11); crates(31, 15); can(23, 11)
bpatch(23, 13, 30, 15); bpatch(31, 13, 31, 14)
# square at the end
planter(6, 7); lamp(5, 10); lamp(13, 10)
ledge(10, 11, 14)

# Gang Burger Queen: where its members stand, in the order of the way from the manhole to the barrier
# (x, y, the way they look, how many tiles they see, and for those who keep turning the other way they look).
# Who they are (name, picture, burgers, what they say) is in OverWorldMap.js, in the same order.
trainers = []
def trainer(x, y, direction, sight, also=None):
    assert (x, y) in floor and (x, y) not in props and (x, y) not in ledges and (x, y) not in boxes and (x, y) not in burger_boxes, (x, y)
    trainers.append((x, y, direction, sight, also))
trainer(12, 42, 'down', 2)
trainer(27, 46, 'up', 2, 'left')
trainer(48, 36, 'down', 2)
trainer(39, 32, 'down', 2, 'right')
trainer(26, 35, 'down', 2)
trainer(10, 34, 'up', 2, 'left')
trainer(5, 30, 'right', 2)
trainer(9, 26, 'left', 4, 'down')
trainer(19, 23, 'up', 3)
trainer(25, 20, 'down', 2, 'right')
trainer(35, 26, 'down', 2)
trainer(38, 24, 'right', 2, 'up')
trainer(45, 18, 'down', 4)
trainer(48, 14, 'down', 2, 'left')
trainer(48, 10, 'down', 2)
trainer(43, 5, 'down', 3, 'right')
trainer(33, 7, 'up', 2)
trainer(26, 3, 'down', 2, 'left')
trainer(15, 5, 'down', 2)
trainer(8, 5, 'down', 3)
TRAINER_TILES = {(t[0], t[1]) for t in trainers}
# Nicky, the cook who looks almost like the hero and heals pizzas: in the loading bay off the car park, between the dumpsters
HEALER = (16, 16)
assert HEALER in floor and HEALER not in props and HEALER not in boxes
TRAINER_TILES.add(HEALER)             # somebody stands there: a wall for the checks below
# Olda, who sells burger boxes: in the courtyard with the burger boxes, by the way in
SELLER = (25, 11)
assert SELLER in floor and SELLER not in props and SELLER not in boxes and SELLER not in burger_boxes
TRAINER_TILES.add(SELLER)

# washing lines over the narrow passages: (tile x of the left roof edge, tile x of the right one, pixel y)
LINES = [(4, 8, 29 * T + 6), (45, 49, 35 * T + 4), (28, 32, 23 * T + 2), (37, 41, 24 * T + 8), (9, 12, 17 * T + 4),
         (10, 13, 39 * T + 6), (25, 28, 8 * T + 8)]


# =====================================================================================================
# kontrola a mřížka (checks and the grid for the game)
# =====================================================================================================
def is_floor(x, y): return (x, y) in floor
def is_free(x, y):                                 # the hero can stand here
    return (x, y) in floor and (x, y) not in props and (x, y) not in ledges and (x, y) not in GATE and (x, y) not in TRAINER_TILES

START = (MANHOLE[0], MANHOLE[1] + 1)
DIRS = ((1, 0), (-1, 0), (0, 1), (0, -1))
def steps(x, y):
    for dx, dy in DIRS:
        nx, ny = x + dx, y + dy
        if is_free(nx, ny):
            yield nx, ny
        elif ledges.get((nx, ny)) == 'down' and (dx, dy) == (0, 1) and is_free(nx, ny + 1):
            yield nx, ny + 1
def reach(start, graph):
    seen, todo = {start: 0}, [start]
    while todo:
        cur = todo.pop(0)
        for nxt in graph(*cur):
            if nxt not in seen:
                seen[nxt] = seen[cur] + 1; todo.append(nxt)
    return seen
forward = reach(START, steps)
back_edges = {}
for a in forward:
    for b in steps(*a):
        back_edges.setdefault(b, []).append(a)
backward = reach(START, lambda x, y: back_edges.get((x, y), []))
beyond = {t for t in floor if is_free(*t) and t not in forward}          # floor nobody can get to
problems = []
for t in sorted(beyond):
    if not (t[1] < GATE[0][1]):
        problems.append('nedostupná dlaždice %s' % (t,))
for t in sorted(forward):
    if t not in backward:
        problems.append('z dlaždice %s se nedá vrátit k poklopu' % (t,))
for x in range(W):                                                       # houses need a roof row and two rows of wall
    y = 0
    while y < H:
        if (x, y) in floor: y += 1; continue
        y0 = y
        while y < H and (x, y) not in floor: y += 1
        if y - y0 < 3: problems.append('dům ve sloupci %d, řádky %d-%d je nižší než 3 dlaždice' % (x, y0, y - 1))
for y in range(H):                                                       # ... and should be at least two tiles wide
    x = 0
    while x < W:
        if (x, y) in floor: x += 1; continue
        x0 = x
        while x < W and (x, y) not in floor: x += 1
        if x - x0 < 2: problems.append('dům v řádku %d, sloupec %d je široký jen jednu dlaždici' % (y, x0))
if problems:
    print('\n'.join(problems)); sys.exit(1)

def grid_char(x, y):
    if (x, y) in ledges: return 'v'
    if (x, y) in TRAINER_TILES: return '.'             # people are walls only while they stand there (the game adds them)
    if not is_free(x, y) or (x, y) in beyond: return '#'
    if (x, y) in boxes: return 'b'
    if (x, y) in burger_boxes: return 'B'
    return '.'
GRID = [''.join(grid_char(x, y) for x in range(W)) for y in range(H)]
gate_front = (GATE[0][0], GATE[0][1] + 1)

# what every gang member sees, and whether the hero can get to the barrier without crossing it
STEP = {'up': (0, -1), 'down': (0, 1), 'left': (-1, 0), 'right': (1, 0)}
def seen_by(t, direction):
    x, y, _, sight, _ = t
    tiles = []
    for _ in range(sight):
        x, y = x + STEP[direction][0], y + STEP[direction][1]
        if not is_free(x, y): break
        tiles.append((x, y))
    return tiles
unavoidable = 0
for t in trainers:
    watched = set(seen_by(t, t[2]))
    if not watched: print('člen gangu na %s nic nevidí' % (t[:2],)); sys.exit(1)
    if START in watched: print('člen gangu na %s vidí až k poklopu' % (t[:2],)); sys.exit(1)
    def sneak(x, y, watched=watched):
        return (n for n in steps(x, y) if n not in watched)
    if not t[4] and gate_front not in reach(START, sneak): unavoidable += 1


# =====================================================================================================
# KRESLENÍ (drawing)
# =====================================================================================================
rnd = random.Random(7)
lower = Image.new('RGBA', (W * T, H * T), (0, 0, 0, 0))
upper = Image.new('RGBA', (W * T, H * T), (0, 0, 0, 0))
LP, UP = lower.load(), upper.load()

def setp(px, x, y, col):
    if 0 <= x < W * T and 0 <= y < H * T: px[x, y] = col
def rect(px, x0, y0, x1, y1, col):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1): setp(px, x, y, col)
def blend(px, x, y, col, a):
    if not (0 <= x < W * T and 0 <= y < H * T): return
    r, g, b, al = px[x, y]
    if al == 0: return
    px[x, y] = (round(r * (1 - a) + col[0] * a), round(g * (1 - a) + col[1] * a), round(b * (1 - a) + col[2] * a), 255)
def sprite(rows, pal):
    """Picture from rows of text; '.' is see-through, other characters are looked up in pal."""
    im = Image.new('RGBA', (len(rows[0]), len(rows)), (0, 0, 0, 0))
    p = im.load()
    for y, row in enumerate(rows):
        assert len(row) == len(rows[0]), row
        for x, ch in enumerate(row):
            if ch != '.': p[x, y] = pal[ch]
    return im

K = c('#222034')                                   # the dark outline used all over the game
# ---------------------------------------------------------------- floors
FLOORS = {
    'l': dict(fill=(c('#b5c1c3'), c('#a7b5b7')), line=c('#98abae'), shadow=(c('#76838b'), c('#8a9299'))),
    'd': dict(fill=(c('#7e8a9c'), c('#748292')), line=c('#6a7b8b'), shadow=(c('#4c4f63'), c('#4c4f63'))),
    'a': dict(fill=(c('#575757'), c('#575757')), line=None, shadow=(c('#3f3f44'), c('#4a4a4d'))),
}
for (tx, ty), kind in floor.items():
    f = FLOORS[kind]
    par = (tx + ty) % 2
    for y in range(T):
        for x in range(T):
            col = f['fill'][par]
            if f['line'] and (x == 0 or y == 0): col = f['line']
            LP[tx * T + x, ty * T + y] = col
    if kind == 'a':                                 # asphalt: a few lighter and darker grains
        for _ in range(7):
            x, y = rnd.randrange(T), rnd.randrange(T)
            LP[tx * T + x, ty * T + y] = rnd.choice((c('#5f5f5f'), c('#505050'), c('#5c5c5c')))
# where two kinds of floor meet, a thin darker joint
for (tx, ty), kind in floor.items():
    for dx, dy in ((1, 0), (0, 1)):
        other = floor.get((tx + dx, ty + dy))
        if other and other != kind:
            for i in range(T):
                x, y = (tx * T + T, ty * T + i) if dx else (tx * T + i, ty * T + T)
                setp(LP, x, y, c('#4c5464') if 'a' not in (kind, other) else c('#3f3f44'))

# ---------------------------------------------------------------- houses
STYLES = {
    'brick':  dict(roof='#5a4d68', hi='#6c5b69', sh='#4f435c', out='#2a2233', weight=2),
    'salmon': dict(roof='#e37878', hi='#f29d87', sh='#d46f6f', out='#4c1818', wall='#cc6e6e', mark='#b95656', base='#a94c4c', weight=2),
    'lilac':  dict(roof='#dbcbfb', hi='#ece4fd', sh='#c9b8ee', out='#413064', wall='#b09cd9', mark='#9f89cc', base='#8973b5', weight=2),
    'peri':   dict(roof='#b7baf1', hi='#d9dbff', sh='#a9ace6', out='#1f4062', wall='#9c9fd9', mark='#8a8dcb', base='#7a7dbd', weight=1.5),
    'green':  dict(roof='#abd291', hi='#c6e4b1', sh='#9cc482', out='#263c17', wall='#88ac71', mark='#779a61', base='#67894f', weight=1.2),
    'brown':  dict(roof='#875837', hi='#9c775d', sh='#7a4d2e', out='#4b2000', wall='#d9c096', mark='#c8a76e', base='#b08f5c', weight=1.5),
}
BRICK = dict(cap=(c('#5a4d68'), c('#3a3046'), c('#3a3046'), c('#1e2151')), hi=c('#8e7c88'), a=c('#6c5b69'), b=c('#7d6b78'), mortar=c('#52434f'))

solid = lambda x, y: 0 <= x < W and 0 <= y < H and (x, y) not in floor
# vertical runs of solid tiles; columns next to each other with the same run make one rectangle
runs = {}
for x in range(W):
    y = 0
    while y < H:
        if not solid(x, y): y += 1; continue
        y0 = y
        while y < H and solid(x, y): y += 1
        runs.setdefault((y0, y - 1), []).append(x)
blocks = []
for (y0, y1), xs in runs.items():
    start = prev = xs[0]
    for x in xs[1:] + [None]:
        if x is None or x != prev + 1:
            blocks.append((start, prev, y0, y1))
            start = x
        prev = x
blocks.sort(key=lambda b: (b[2], b[0]))
buildings = []                                      # dict(x0, x1, y0, y1, face: bool, style)
for (x0, x1, y0, y1) in blocks:
    cuts = [x0]                                     # wide blocks become a row of houses
    while x1 + 1 - cuts[-1] > 8:
        cuts.append(cuts[-1] + rnd.randrange(4, 8))
    if len(cuts) > 1 and x1 + 1 - cuts[-1] < 3: cuts.pop()
    cuts.append(x1 + 1)
    for i in range(len(cuts) - 1):
        bx0, bx1 = cuts[i], cuts[i + 1] - 1
        rows = [y1 + 1]                             # tall blocks: the bottom house shows its wall, roofs behind it
        while rows[-1] - y0 > 8:
            rows.append(rows[-1] - rnd.randrange(4, 8))
        if len(rows) > 1 and rows[-1] - y0 < 3: rows.pop()
        rows.append(y0)
        for j in range(len(rows) - 1):
            buildings.append(dict(x0=bx0, x1=bx1, y0=rows[j + 1], y1=rows[j] - 1, face=(j == 0)))
names = list(STYLES)
owner = {}
for b in buildings:
    near = set()                                    # no two houses of one colour side by side
    for x in range(b['x0'], b['x1'] + 1): near |= {owner.get((x, b['y0'] - 1)), owner.get((x, b['y1'] + 1))}
    for y in range(b['y0'], b['y1'] + 1): near |= {owner.get((b['x0'] - 1, y)), owner.get((b['x1'] + 1, y))}
    pick = [n for n in names if n not in near] or names
    b['style'] = rnd.choices(pick, weights=[STYLES[n]['weight'] for n in pick])[0]
    for y in range(b['y0'], b['y1'] + 1):
        for x in range(b['x0'], b['x1'] + 1): owner[(x, y)] = b['style']

def draw_roof(b):
    s = STYLES[b['style']]
    roof, hi, sh, out = c(s['roof']), c(s['hi']), c(s['sh']), c(s['out'])
    px0, py0 = b['x0'] * T, b['y0'] * T
    px1, py1 = b['x1'] * T + T - 1, (b['y1'] - (2 if b['face'] else 0)) * T + T - 1
    rect(LP, px0, py0, px1, py1, roof)
    rect(LP, px0, py0, px1, py0, out); rect(LP, px0, py1, px1, py1, out)
    rect(LP, px0, py0, px0, py1, out); rect(LP, px1, py0, px1, py1, out)
    rect(LP, px0 + 1, py0 + 1, px1 - 1, py0 + 1, hi)                 # light along the top edge, like the houses on the street
    rect(LP, px0 + 1, py0 + 2, px0 + 1, py1 - 1, hi)
    rect(LP, px0 + 2, py1 - 1, px1 - 1, py1 - 1, sh)
    rect(LP, px1 - 1, py0 + 2, px1 - 1, py1 - 1, sh)
    # the low wall around a flat roof: one more line a little way in
    if px1 - px0 > 20 and py1 - py0 > 20:
        for x in range(px0 + 4, px1 - 3):
            setp(LP, x, py0 + 4, sh); setp(LP, x, py1 - 4, hi)
        for y in range(py0 + 4, py1 - 3):
            setp(LP, px0 + 4, y, sh); setp(LP, px1 - 4, y, hi)
    return px0, py0, px1, py1

def draw_face(b):
    s = STYLES[b['style']]
    px0, py0 = b['x0'] * T, (b['y1'] - 1) * T
    px1, py1 = b['x1'] * T + T - 1, b['y1'] * T + T - 1
    if b['style'] == 'brick':
        for y in range(py0, py1 + 1):
            r = y - py0
            for x in range(px0, px1 + 1):
                if r < 4: col = BRICK['cap'][r]
                else:
                    row, inrow = (r - 4) // 5, (r - 4) % 5
                    if inrow == 4: col = BRICK['mortar']
                    else:
                        bx = (x + (5 if row % 2 else 0))
                        if bx % 10 == 9: col = BRICK['mortar']
                        elif inrow == 0: col = BRICK['hi']
                        else: col = BRICK['b'] if ((bx // 10) * 7 + row * 3) % 5 in (1, 3) else BRICK['a']
                LP[x, y] = col
        for y in range(py0, py1 + 1):
            LP[px0, y] = BRICK['cap'][1]; LP[px1, y] = BRICK['cap'][1]
    else:
        wall, mark, base, out = c(s['wall']), c(s['mark']), c(s['base']), c(s['out'])
        rect(LP, px0, py0, px1, py1, wall)
        rect(LP, px0, py0, px1, py0, out)
        rect(LP, px0, py0, px0, py1, out); rect(LP, px1, py0, px1, py1, out)
        rect(LP, px0 + 1, py0 + 1, px1 - 1, py0 + 1, mark)           # shade under the roof edge
        rect(LP, px0 + 1, py1 - 1, px1 - 1, py1, base)               # dirty foot of the wall
        for _ in range(max(1, (px1 - px0) // 22)):                    # a few bare bricks, like the arcade wall
            x, y = rnd.randrange(px0 + 4, max(px0 + 5, px1 - 12)), rnd.randrange(py0 + 4, py0 + 22)
            for dx, dy in rnd.choice((((0, 0), (5, 2)), ((0, 2), (4, 0), (9, 2)), ((0, 0), (6, 0), (3, 2)))):
                if x + dx + 3 < px1 - 1: rect(LP, x + dx, y + dy, x + dx + 3, y + dy + 1, mark)
    return px0, py0, px1, py1

for b in buildings:
    b['roof_px'] = draw_roof(b)
for b in buildings:
    if b['face']: b['face_px'] = draw_face(b)

# shadow of the wall on the pavement below it
for b in buildings:
    if not b['face']: continue
    for x in range(b['x0'], b['x1'] + 1):
        kind = floor.get((x, b['y1'] + 1))
        if not kind: continue
        par = (x + b['y1'] + 1) % 2
        for i in range(T):
            setp(LP, x * T + i, (b['y1'] + 1) * T, FLOORS[kind]['shadow'][0])
            setp(LP, x * T + i, (b['y1'] + 1) * T + 1, FLOORS[kind]['shadow'][par if kind == 'l' else 1])

# ---------------------------------------------------------------- things on the roofs
METAL = {'k': K, 'L': c('#d4dbe3'), 'M': c('#a3afbd'), 's': c('#75808f'), 'D': c('#2a2a33'), 'd': c('#454f61')}
R_AC = sprite(["kkkkkkkkkkkk", "kLLLLLLLLLLk", "kLMMkkkkMMLk", "kLMkDdDdkMLk", "kLMkdDdDkMLk", "kLMkDdDdkMLk",
               "kLMkdDdDkMLk", "kLMMkkkkMMLk", "kMMMMMMMMMMk", "kssssssssssk", "kkkkkkkkkkkk"], METAL)
R_VENT = sprite([".kkkk.", "kLLLMk", "kLDDMk", "kLDDMk", "kMMMsk", ".kkkk."], METAL)
R_HATCH = sprite(["kkkkkkkkkk", "kLLLLLLLLk", "kLMMMMMMsk", "kLMMkkMMsk", "kLMMMMMMsk", "kLMMMMMMsk", "kLsssssssk",
                  "kkkkkkkkkk"], METAL)
GLASS = {'k': K, 'L': c('#d4dbe3'), '1': c('#c4f7ff'), '2': c('#95f0ff'), '3': c('#7ee7f7'), '4': c('#6de1f4')}
R_SKY = sprite(["kkkkkkkkkkkkkkkk", "kLLLLLLLLLLLLLLk", "kLk1223k12233kLk", "kLk2233k22334kLk",
                "kLk2334k23344kLk", "kLk3344k33441kLk", "kLk3441k34412kLk",
                "kLkkkkkkkkkkkkLk", "kLLLLLLLLLLLLLLk", "kkkkkkkkkkkkkkkk"], GLASS)
CHIM = {'k': c('#3a1d14'), 'a': c('#b8603f'), 'b': c('#9a4b30'), 'h': c('#d48566'), 'D': c('#1c1016')}
R_CHIM = sprite(["kkkkkkkk", "khhhhhhk", "khDDDDak", "khDDDDak", "khaaaaak", "kkkkkkkk", "kababbak", "kbabaabk", "kkkkkkkk"], CHIM)
def roof_things(b):
    px0, py0, px1, py1 = b['roof_px']
    w, h = px1 - px0 + 1, py1 - py0 + 1
    if w < 28 or h < 14: return
    placed = []
    want = max(1, (w * h) // 2600)
    tries = 0
    while len(placed) < want + 1 and tries < 40:
        tries += 1
        sp = rnd.choices((R_AC, R_VENT, R_HATCH, R_SKY, R_CHIM), weights=(3, 4, 1.5, 2, 2))[0]
        if w - 16 - sp.width <= 0 or h - 14 - sp.height <= 0: continue
        x = px0 + 8 + rnd.randrange(w - 16 - sp.width); y = py0 + 7 + rnd.randrange(h - 14 - sp.height)
        if any(x < ox + ow + 5 and ox < x + sp.width + 5 and y < oy + oh + 5 and oy < y + sp.height + 5 for ox, oy, ow, oh in placed): continue
        placed.append((x, y, sp.width, sp.height))
        for i in range(sp.width):                                   # its shadow, down and to the right
            blend(LP, x + i + 2, y + sp.height, K, 0.28); blend(LP, x + i + 2, y + sp.height + 1, K, 0.28)
        for j in range(2, sp.height):
            blend(LP, x + sp.width, y + j, K, 0.28); blend(LP, x + sp.width + 1, y + j, K, 0.28)
        lower.alpha_composite(sp, (x, y))
for b in buildings: roof_things(b)

# ---------------------------------------------------------------- things on the back walls
def door_sprite(fill, shade, frame):
    pal = {'k': K, 'F': frame, 'D': fill, 'd': shade, 'w': c('#95f0ff'), 'W': c('#c4f7ff'), 'h': c('#f7d95a'), 's': c('#b5c1c3'), 't': c('#8a9299')}
    return sprite(["kkkkkkkkkkkkkk", "kFFFFFFFFFFFFk", "kFkkkkkkkkkkFk", "kFkDDDDDDDDkFk", "kFkDkkkkkkDkFk", "kFkDkWwwwkDkFk",
                   "kFkDkwwwWkDkFk", "kFkDkkkkkkDkFk", "kFkDDDDDDDDkFk", "kFkDDDDDDDDkFk", "kFkDDDDDDhhkFk", "kFkDDDDDDhhkFk",
                   "kFkDDDDDDDDkFk", "kFkddddddddkFk", "kFkDDDDDDDDkFk", "kFkDkkkkkkDkFk", "kFkDkddddkDkFk", "kFkDkkkkkkDkFk",
                   "kFkDDDDDDDDkFk", "kFkddddddddkFk", "kssssssssssssk", "tttttttttttttt"], pal)
DOORS = [(c('#5a687a'), c('#4c5464')), (c('#7a3b3b'), c('#5f2b2b')), (c('#3f6b57'), c('#325646')), (c('#3b4a8a'), c('#2c3870')), (c('#8a6a45'), c('#6e5234'))]
def window_sprite(frame, lit):
    g = (c('#c4f7ff'), c('#95f0ff'), c('#7ee7f7'), c('#6de1f4')) if lit else (c('#3b4a8a'), c('#2c3870'), c('#2c3870'), c('#1e2151'))
    im = Image.new('RGBA', (12, 12), (0, 0, 0, 0)); p = im.load()
    for y in range(11):
        for x in range(12):
            edge = min(x, y, 11 - x, 10 - y)
            p[x, y] = K if edge == 0 or edge == 2 else (frame if edge == 1 else g[((x + y) // 2) % 4 if (x - y) % 5 else 0])
    for x in (5, 8): rect(p, x, 3, x, 7, K)         # bars
    for x in range(1, 11): p[x, 11] = (0, 0, 0, 70)
    return im
W_AC = sprite(["kkkkkkkkkkkkk", "kLLLLLLLLLLLk", "kLMkMkMkMkMLk", "kLMMMMMMMMMLk", "kLMkMkMkMkMLk", "kLMMMMMMMMMLk",
               "kLMkMkMkMkMLk", "kMMMMMMMMMMsk", "kkkkkkkkkkkkk", ".k.........k."], METAL)
W_VENT = sprite(["kkkkkkkk", "kMMMMMMk", "kDDDDDDk", "kMMMMMMk", "kDDDDDDk", "kMMMMMMk", "kkkkkkkk"], METAL)
W_METER = sprite(["..k....", "..k....", "kkkkkkk", "kLLLLMk", "kLkkLMk", "kLkDLMk", "kLkkLMk", "kLMMMsk", "kMkMkMk", "kkkkkkk"], METAL)
W_LAMP = sprite([".kkkk.", "kMMMMk", ".kYYk.", ".kYWk.", "..kk.."], {**METAL, 'Y': c('#f7d95a'), 'W': c('#fff6c9')})
GRAF = [
    (["....yy....", "...yrry...", "...yyyy...", "..yryyry..", "..yyyyyy..", ".yyrryyyy.", ".yyyyyyry.", "cccccccccc", ".cccccccc."], {'y': c('#f1c25a'), 'r': c('#c8443a'), 'c': c('#b8703a')}),
    ([".aa....aa....a", "a..a..a..a..a.", "...a.a....aa..", "....a........a", "aaaaaaaaaaaaa."], {'a': c('#6de1f4')}),
    (["m.m.m.m", "mmmmmmm", "mmmmmmm", ".mmmmm."], {'m': c('#f1c25a')}),
    ([".pp.pp.", "ppppppp", "ppppppp", ".ppppp.", "..ppp..", "...p..."], {'p': c('#e35969')}),
    (["g.....g..gg.", ".g...g..g..g", "..g.g...g..g", "...g.....gg.", "ggggggggggg."], {'g': c('#c6e4b1')}),
]
try:
    street = Image.open(P + 'StreetLower.png').convert('RGBA')
except FileNotFoundError:
    print('chybí images/maps/StreetLower.png'); sys.exit(1)
POSTER = street.crop((168, 131, 184, 157))

def face_things(b):
    px0, py0, px1, py1 = b['face_px']
    s = STYLES[b['style']]
    n = b['x1'] - b['x0'] + 1
    frame = c(s['hi']) if b['style'] != 'brick' else c('#8e7c88')
    below = [floor.get((b['x0'] + i, b['y1'] + 1)) and (b['x0'] + i, b['y1'] + 1) not in props for i in range(n)]
    used = [None] * n
    # a drain pipe down one corner
    if n >= 2 and rnd.random() < 0.55:
        x = px0 + 3 if rnd.random() < 0.5 else px1 - 6
        for y in range(py0 + 1, py1 - 1):
            LP[x, y] = K; LP[x + 1, y] = METAL['L']; LP[x + 2, y] = METAL['s']; LP[x + 3, y] = K
            if (y - py0) % 11 == 6: rect(LP, x - 1, y, x + 4, y + 1, K)
        rect(LP, x, py1 - 1, x + 3, py1 - 1, K)
        used[0 if x < px0 + 8 else n - 1] = 'pipe'
    # one back door, if the house is wide enough and something can stand in front of it
    spots = [i for i in range(n) if below[i] and used[i] is None and (n < 3 or 0 < i < n - 1 or rnd.random() < 0.3)]
    if spots and rnd.random() < 0.7:
        i = rnd.choice(spots)
        fill, shade = rnd.choice(DOORS)
        d = door_sprite(fill, shade, frame)
        lower.alpha_composite(d, (px0 + i * T + 1, py1 - d.height + 3))
        if rnd.random() < 0.6: lower.alpha_composite(W_LAMP, (px0 + i * T + 5, py1 - d.height - 4))
        used[i] = 'door'
    for i in range(n):
        if used[i]: continue
        x = px0 + i * T
        r = rnd.random()
        if r < 0.42:
            lower.alpha_composite(window_sprite(frame, rnd.random() < 0.55), (x + 2, py0 + 8)); used[i] = 'window'
        elif r < 0.52:
            lower.alpha_composite(W_AC, (x + 1, py0 + 7)); used[i] = 'ac'
            for y in range(py0 + 17, py1 - 1):                     # where it drips
                if rnd.random() < 0.8: blend(LP, x + 4, y, K, 0.18)
        elif r < 0.58:
            lower.alpha_composite(W_VENT, (x + 4, py0 + 9)); used[i] = 'vent'
        elif r < 0.64:
            lower.alpha_composite(W_METER, (x + 4, py0 + 12)); used[i] = 'meter'
        elif r < 0.74:
            rows, pal = rnd.choice(GRAF)
            g = sprite(rows, pal)
            if x + 1 + g.width < px1 - 1:
                lower.alpha_composite(g, (x + 1, py0 + rnd.randrange(12, 19))); used[i] = 'graffiti'
        elif r < 0.78 and b['style'] == 'brick':
            lower.alpha_composite(POSTER, (x, py0 + 5)); used[i] = 'poster'
            rect(LP, x + 12, py0 + 5, x + 15, py0 + 7, LP[x + 7, py0 + 4])   # torn corner
    for _ in range(n):                                              # grime creeping up from the ground
        x = rnd.randrange(px0 + 2, px1 - 4)
        for i in range(rnd.randrange(2, 6)):
            blend(LP, x + i, py1 - 2 - (i % 2), K, 0.15)
for b in buildings:
    if b['face']: face_things(b)

# ---------------------------------------------------------------- things painted on the ground
def free_floor(x, y): return is_free(x, y) and (x, y) not in boxes and (x, y) not in burger_boxes and (x, y) != MANHOLE
# car park: white bays along the south wall, yellow hatching in front of the loading bay
WHITE, YELLOW = c('#e9e9e4'), c('#fbf236')
for tx in range(5, 18, 2):
    for y in range(25 * T + 6, 27 * T + 14):
        setp(LP, tx * T, y, WHITE)
    for x in range(tx * T - 2, tx * T + 3): setp(LP, x, 25 * T + 6, WHITE)
for x in range(14 * T, 19 * T):
    for y in range(20 * T + 2, 20 * T + 14):
        if y in (20 * T + 2, 20 * T + 13) or (x + y) % 8 == 0: setp(LP, x, y, YELLOW)
for (ox, oy) in ((6, 23), (11, 26), (13, 21), (16, 26), (19, 21), (16, 18), (40, 40), (42, 41)):       # oil
    for dy, (a, e) in enumerate(((2, 7), (0, 9), (1, 10), (3, 8))):
        for x in range(a, e + 1): blend(LP, ox * T + 3 + x, oy * T + 6 + dy, K, 0.3)
# puddles, cracks and litter in the alleys
dark_tiles = sorted(t for t, kind in floor.items() if kind == 'd' and free_floor(*t))
for (tx, ty) in rnd.sample(dark_tiles, len(dark_tiles) // 9):
    x0, y0 = tx * T + rnd.randrange(1, 5), ty * T + rnd.randrange(4, 10)
    for dy, (a, e) in enumerate(((2, 6), (0, 8), (1, 9), (3, 7))):
        for x in range(a, e + 1): blend(LP, x0 + x, y0 + dy, c('#3d5a7a'), 0.4)
    blend(LP, x0 + 3, y0 + 1, c('#d9ecff'), 0.5); blend(LP, x0 + 4, y0 + 1, c('#d9ecff'), 0.5)
walk_tiles = sorted(t for t, kind in floor.items() if free_floor(*t))
for (tx, ty) in rnd.sample(walk_tiles, len(walk_tiles) // 7):                  # cracks
    x, y = tx * T + rnd.randrange(3, 10), ty * T + rnd.randrange(3, 10)
    for _ in range(rnd.randrange(3, 7)):
        blend(LP, x, y, K, 0.3)
        x += rnd.choice((1, 1, 0)); y += rnd.choice((1, 0, -1, 1))
for (tx, ty) in rnd.sample(walk_tiles, len(walk_tiles) // 8):                  # scraps of paper, cans, crusts
    x, y = tx * T + rnd.randrange(2, 12), ty * T + rnd.randrange(3, 12)
    kind = rnd.choice((0, 0, 0, 1, 2, 2, 3, 3))
    if kind == 0: rect(LP, x, y, x + 2, y + 1, c('#e8e3d4')); setp(LP, x + 2, y + 1, c('#bdb7a6'))
    elif kind == 1: rect(LP, x, y, x + 2, y + 1, c('#a94c4c')); setp(LP, x, y, c('#d4dbe3')); setp(LP, x, y + 1, c('#a3afbd'))
    elif kind == 2: rect(LP, x, y, x + 3, y, c('#b8703a')); setp(LP, x + 1, y - 1, c('#f1c25a')); setp(LP, x + 2, y - 1, c('#f1c25a'))
    else: rect(LP, x, y, x + 1, y + 1, c('#dcb882')); setp(LP, x + 1, y + 1, c('#5c3b1f'))
# drains by the walls and a few closed manhole covers
IRONP = {'k': K, 'i': c('#75808f'), 'h': c('#a3afbd'), 'D': c('#14161f'), 'r': c('#a3afbd'), 'm': c('#5d6877')}
DRAIN = sprite(["kkkkkkkkkk", "kDmDmDmDmk", "kDmDmDmDmk", "kDmDmDmDmk", "kDmDmDmDmk", "kkkkkkkkkk"], IRONP)
COVER = sprite(["....kkkk....", "..kkhhhhkk..", ".khiiiiiiik.", ".kiimiimiik.", "khimiimiimik", "khiiimiiimik", "khimiimiimik",
                "khiiimiiimik", ".kiimiimiik.", ".kiiiiiimmk.", "..kkmmmmkk..", "....kkkk...."], IRONP)
HOLE = sprite(["................", "....kkkkkkkk....", "..kkhhhhhhhhkk..", ".khikkkkkkkkiik.", ".kikDDDDDDDDkik.", "khkDDrDDDDrDDkik",
               "khkDDrrrrrrDDkik", "khkDDrDDDDrDDkik", "khkDDrrrrrrDDkik", "khkDDrDDDDrDDkik", "khkDDrrrrrrDDkik", ".kikDDDDDDDDkik.",
               ".kiikkkkkkkkimk.", "..kkiiiiiimmkk..", "....kkkkkkkk....", "................"], IRONP)
for (tx, ty) in ((16, 34), (30, 32), (45, 44), (27, 46), (6, 30), (35, 28), (25, 22), (39, 6), (24, 5), (29, 13), (47, 40), (19, 37)):
    if free_floor(tx, ty): lower.alpha_composite(DRAIN, (tx * T + 3, ty * T + 3))
for (tx, ty) in ((12, 43), (40, 33), (22, 36), (33, 6), (47, 21), (9, 9), (48, 7)):
    if free_floor(tx, ty): lower.alpha_composite(COVER, (tx * T + 2, ty * T + 2))
# the open manhole with the top of the ladder, its lid pushed aside
lower.alpha_composite(HOLE, (MANHOLE[0] * T, MANHOLE[1] * T))
lower.alpha_composite(COVER, (MANHOLE[0] * T + 17, MANHOLE[1] * T + 4))
for i in range(2, 11): blend(LP, MANHOLE[0] * T + 17 + i, MANHOLE[1] * T + 16, K, 0.3)

# ---------------------------------------------------------------- ledges you can hop down
LEDGE = {
    'd': dict(hi=c('#a6b1c0'), lip=c('#8e9aab'), out=c('#3a4353'), face=c('#5a6577'), face_hi=c('#677286'), joint=c('#4a5466'), shadow=c('#4c4f63')),
    'l': dict(hi=c('#e3eaeb'), lip=c('#c9d3d5'), out=c('#55626b'), face=c('#8696a0'), face_hi=c('#97a7b0'), joint=c('#71808a'), shadow=c('#76838b')),
    'a': dict(hi=c('#8a8a8a'), lip=c('#747474'), out=c('#2c2c30'), face=c('#444448'), face_hi=c('#4f4f54'), joint=c('#38383c'), shadow=c('#3f3f44')),
}
for (tx, ty) in ledges:
    L = LEDGE[floor[(tx, ty)]]
    x0, y0 = tx * T, ty * T
    left_open = (tx - 1, ty) not in ledges and is_floor(tx - 1, ty)
    right_open = (tx + 1, ty) not in ledges and is_floor(tx + 1, ty)
    a, e = (2 if left_open else 0), (13 if right_open else 15)
    for x in range(a, e + 1):
        LP[x0 + x, y0 + 2] = L['hi']; LP[x0 + x, y0 + 3] = L['lip']; LP[x0 + x, y0 + 4] = L['lip']; LP[x0 + x, y0 + 5] = L['out']
        LP[x0 + x, y0 + 6] = L['face_hi']
        for y in range(7, 12): LP[x0 + x, y0 + y] = L['joint'] if (tx * T + x + (4 if y < 9 else 0)) % 8 == 0 else L['face']
        LP[x0 + x, y0 + 12] = L['out']
        blend(LP, x0 + x, y0 + 13, L['shadow'], 0.8); blend(LP, x0 + x, y0 + 14, L['shadow'], 0.45)
    if left_open:                                   # rounded ends
        for y in range(3, 12): LP[x0 + 1, y0 + y] = L['out']
        LP[x0 + 2, y0 + 2] = L['out']; LP[x0 + 2, y0 + 12] = L['out']
    if right_open:
        for y in range(3, 12): LP[x0 + 14, y0 + y] = L['out']
        LP[x0 + 13, y0 + 2] = L['out']; LP[x0 + 13, y0 + 12] = L['out']

# ---------------------------------------------------------------- pizza boxes on the ground (taken from the side alley of the main street)
BOXCOL = {c(h) for h in ('#5c3b1f', '#e8c998', '#d9b27c', '#c8443a', '#b3854c', '#dcb882', '#c9a068', '#f0d9a8', '#ecd9b5', '#b8703a', '#9a6f3c')}
def keep(im, colours):
    im = im.copy(); p = im.load()
    for y in range(im.height):
        for x in range(im.width):
            if p[x, y] not in colours: p[x, y] = (0, 0, 0, 0)
    return im
litter = keep(street.crop((544, 97, 624, 144)), BOXCOL)
def components(im):
    p = im.load(); seen = set(); out = []
    for y in range(im.height):
        for x in range(im.width):
            if p[x, y][3] == 0 or (x, y) in seen: continue
            todo, cells = [(x, y)], []
            seen.add((x, y))
            while todo:
                cx, cy = todo.pop()
                cells.append((cx, cy))
                for dx, dy in DIRS:
                    nx, ny = cx + dx, cy + dy
                    if 0 <= nx < im.width and 0 <= ny < im.height and p[nx, ny][3] and (nx, ny) not in seen:
                        seen.add((nx, ny)); todo.append((nx, ny))
            xs, ys = [q[0] for q in cells], [q[1] for q in cells]
            out.append(im.crop((min(xs), min(ys), max(xs) + 1, max(ys) + 1)))
    return out
FLAT = [b for b in components(litter) if 9 <= b.width <= 20 and 8 <= b.height <= 16]
for (tx, ty) in sorted(boxes, key=lambda t: (t[1], t[0])):
    sp = rnd.choice(FLAT)
    x = tx * T + (T - sp.width) // 2 + rnd.randrange(-1, 2); y = ty * T + (T - sp.height) // 2 + rnd.randrange(-1, 3)
    for i in range(sp.width): blend(LP, x + i, y + sp.height, K, 0.22)
    lower.alpha_composite(sp, (x, y))

# ---------------------------------------------------------------- burger boxes on the ground: little clamshell boxes, some of them open
BB = {'k': c('#7a3a10'), 'Y': c('#f8c93a'), 'y': c('#e0a52a'), 'r': c('#c8443a'), 'R': c('#a8322a'), 'w': c('#fff6e0'), 'g': c('#7fc241'), 'c': c('#fbe6b5')}
BURGER_BOXES = [
    sprite(["kkkkkkkkkkk", "kYYYYYYYYYk", "kYYrrrrrYYk", "kYYrwrwrYYk", "kYYrrrrrYYk", "kYYYYYYYYYk", "kkkkkkkkkkk", "kyyyyyyyyyk", "kkkkkkkkkkk"], BB),
    sprite(["kkkkkkkkkkk", "krrrrrrrrrk", "krrYYYYYrrk", "krrYwYwYrrk", "krrYYYYYrrk", "krrrrrrrrrk", "kkkkkkkkkkk", "kRRRRRRRRRk", "kkkkkkkkkkk"], BB),
    sprite(["kkkkkkkkkkk", "kccccccccck", "kcYYYYYYYck", "kccccccccck", "kkkkkkkkkkk", "kYYgYYYgYYk", "kYYYYYYYYYk",
            "kkkkkkkkkkk", "kyyyyyyyyyk", "kkkkkkkkkkk"], BB),
]
for (tx, ty) in sorted(burger_boxes, key=lambda t: (t[1], t[0])):
    sp = rnd.choice(BURGER_BOXES)
    x = tx * T + (T - sp.width) // 2 + rnd.randrange(-2, 3); y = ty * T + (T - sp.height) // 2 + rnd.randrange(-1, 3)
    for i in range(sp.width): blend(LP, x + i, y + sp.height, K, 0.22)
    lower.alpha_composite(sp, (x, y))

# ---------------------------------------------------------------- things standing in the way
def stamp(sp, x, y, ty):
    """Draws a standing thing: what sticks out above its tile goes to the upper layer when somebody can walk behind it."""
    cut = ty * T - y
    behind = any(is_free(tx, ty - 1) for tx in range(x // T, (x + sp.width - 1) // T + 1))
    if cut > 0 and behind:
        upper.alpha_composite(sp.crop((0, 0, sp.width, cut)), (x, y))
        lower.alpha_composite(sp.crop((0, cut, sp.width, sp.height)), (x, ty * T))
    else:
        lower.alpha_composite(sp, (x, y))
def ground_shadow(x0, x1, y, strength=0.3):
    for x in range(x0, x1 + 1):
        blend(LP, x, y, K, strength); blend(LP, x, y + 1, K, strength * 0.6)

DUMPCOL = {c(h) for h in ('#16261f', '#72ab93', '#58917a', '#4f8069', '#3f6b57', '#325646', '#2a2a33')}
S_DUMP = keep(street.crop((592, 72, 624, 94)), DUMPCOL)
S_STACK = keep(street.crop((544, 65, 560, 96)), BOXCOL)
WOOD = {'k': c('#5c3b1f'), 'T': c('#e8c998'), 't': c('#d9b27c'), 'F': c('#b3854c'), 'f': c('#9a6f3c'), 'p': c('#c9a068')}
S_CRATE = sprite([
    "kkkkkkkkkkkkkkkk", "kTTTTTTTTTTTTTTk", "kTttttTttttTtttk", "kTttttTttttTtttk", "kttttttttttttttk", "kkkkkkkkkkkkkkkk",
    "kppppppppppppppk", "kpkkkkkkkkkkkkpk", "kpkFFFFFFFFppkpk", "kpkFFFFFFFppFkpk", "kpkFFFFFFppFFkpk", "kpkFFFFFppFFFkpk",
    "kpkFFFFppFFFFkpk", "kpkFFFppFFFFFkpk", "kpkFFppFFFFFFkpk", "kpkFppFFFFFFFkpk", "kpkppFFFFFFFFkpk", "kpkkkkkkkkkkkkpk",
    "kffffffffffffffk", "kkkkkkkkkkkkkkkk"], WOOD)
S_CRATE2 = Image.new('RGBA', (16, 33), (0, 0, 0, 0))
S_CRATE2.alpha_composite(S_CRATE, (0, 13)); S_CRATE2.alpha_composite(S_CRATE.crop((0, 0, 16, 19)), (0, 0))
S_CAN = sprite([
    "....kkkkk...", "..kkLLLLLkk.", ".kLLLLMMMMMk", ".kLLMMMMMMsk", ".kkMMMMMsskk", ".kLkkkkkkksk", ".kLMLMMsMssk", ".kLMLMMsMssk",
    ".kLMLMMsMssk", ".kLMLMMsMssk", ".kkkkkkkkkkk", ".kLMLMMsMssk", ".kLMLMMsMssk", ".kLMLMMsMssk", ".kLMLMMsMssk", ".kkMLMMsMskk",
    "...kkkkkkk.."], METAL)
S_LAMP = sprite([
    "...kkkkkkkk...", "..kMMMMMMMMk..", ".kkkkkkkkkkkk.", "..kYYYWWYYYk..", "..kYYWWWWYYk..", "..kYYWWWWYYk..", "...kYYWWYYk...",
    "....kkkkkk....", ".....kMsk.....", ".....kMsk.....", ".....kMsk.....", ".....kMsk.....", ".....kMsk.....", ".....kMsk.....",
    ".....kMsk.....", ".....kMsk.....", ".....kMsk.....", ".....kMsk.....", ".....kMsk.....", ".....kMsk.....", ".....kMsk.....",
    ".....kMsk.....", ".....kMsk.....", ".....kMsk.....", ".....kMsk.....", ".....kMsk.....", ".....kMsk.....", ".....kMsk.....",
    ".....kMsk.....", ".....kMsk.....", ".....kMsk.....", ".....kMsk.....", ".....kMsk.....", ".....kMsk.....", ".....kMsk.....",
    "....kkMskk....", "...kLMMMssk...", "...kLMMMssk...", "...kkkkkkkk..."], {**METAL, 'Y': c('#f7d95a'), 'W': c('#fff6c9')})
planter_img = street.crop((256, 144, 288, 192))
# one shrub in a bed, the same way tools/baracek.py makes the ones at the west end of the main street
shrub = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
for yy in range(123, 135):
    for xx in range(208, 224):
        r, g, b_, al = street.getpixel((xx, yy))
        if g > r + 20 and g > b_ + 20: shrub.putpixel((xx - 208, yy - 123), (r, g, b_, 255))
S_BUSH = Image.new('RGBA', (16, 16), c('#804a40')); bp = S_BUSH.load()
for x in range(16):
    bp[x, 0] = c('#71362b'); bp[x, 14] = c('#663128'); bp[x, 15] = c('#71362b')
    for y in (3, 7, 11):
        if x % 4: bp[x, y] = c('#90574c')
S_BUSH.alpha_composite(shrub, (0, 3))

def fence_sprite(first, last):
    im = Image.new('RGBA', (16, 22), (0, 0, 0, 0)); p = im.load()
    for y in range(3, 19):
        for x in range(16):
            if (x + y) % 4 == 0 or (x - y) % 4 == 0: p[x, y] = c('#a3afbd')
    for x in range(16):
        p[x, 2] = K; p[x, 3] = METAL['L']; p[x, 4] = METAL['s']; p[x, 5] = K
        p[x, 18] = METAL['s']; p[x, 19] = K
    for x0, on in ((0, first), (12, last)):
        if not on: continue
        for y in range(0, 22):
            p[x0, y] = K; p[x0 + 1, y] = METAL['L']; p[x0 + 2, y] = METAL['s']; p[x0 + 3, y] = K
        for x in range(4): p[x0 + x, 0] = K; p[x0 + x, 21] = K
    return im

order = sorted(props.items(), key=lambda kv: (kv[0][1], kv[0][0]))
for (tx, ty), kind in order:
    x0, y0 = tx * T, ty * T
    if kind == 'dumpster':
        ground_shadow(x0 + 2, x0 + 31, y0 + 14)
        stamp(S_DUMP, x0, y0 + 14 - S_DUMP.height, ty)
    elif kind == 'crate':
        ground_shadow(x0 + 1, x0 + 16, y0 + 15, 0.25)
        stamp(S_CRATE, x0, y0 + 15 - S_CRATE.height, ty)
    elif kind == 'crate2':
        ground_shadow(x0 + 1, x0 + 16, y0 + 15, 0.25)
        stamp(S_CRATE2, x0, y0 + 15 - S_CRATE2.height, ty)
    elif kind == 'can':
        ground_shadow(x0 + 3, x0 + 14, y0 + 14, 0.25)
        stamp(S_CAN, x0 + 2, y0 + 15 - S_CAN.height, ty)
    elif kind == 'stack':
        ground_shadow(x0 + 1, x0 + 15, y0 + 14, 0.25)
        stamp(S_STACK, x0, y0 + 15 - S_STACK.height, ty)
    elif kind == 'lamp':
        ground_shadow(x0 + 4, x0 + 12, y0 + 14, 0.25)
        stamp(S_LAMP, x0 + 1, y0 + 15 - S_LAMP.height, ty)
    elif kind == 'bush':
        lower.paste(S_BUSH, (x0, y0))
    elif kind == 'planter':
        lower.paste(planter_img, (x0, y0))
        ground_shadow(x0, x0 + 31, y0 + 48, 0.3)
    elif kind == 'fence':
        first = props.get((tx - 1, ty)) != 'fence'
        last = props.get((tx + 1, ty)) != 'fence'
        ground_shadow(x0, x0 + 15, y0 + 16, 0.2)
        stamp(fence_sprite(first, last), x0, y0 + 16 - 22, ty)

# ---------------------------------------------------------------- washing lines (always above the hero)
CLOTH = [c('#f3f0e8'), c('#c8443a'), c('#5b6ee1'), c('#f1c25a'), c('#99e550'), c('#d77bba'), c('#5fcde4')]
for (ta, tb, y) in LINES:
    xa, xb = ta * T + 12, tb * T + 3
    n = xb - xa
    sag = lambda x: y + round(3 * math.sin(math.pi * (x - xa) / n))
    for x in range(xa, xb + 1): setp(UP, x, sag(x), c('#e8e3d4'))
    rect(UP, xa - 1, y - 1, xa, y + 1, K); rect(UP, xb, y - 1, xb + 1, y + 1, K)
    x = xa + 4
    while x + 7 < xb - 2:
        w, h, col = rnd.choice(((5, 7), (6, 5), (4, 8), (7, 6))) + (rnd.choice(CLOTH),)
        shade = tuple(int(v * 0.8) for v in col[:3]) + (255,)
        for i in range(w):
            top = sag(x + i) + 1
            for j in range(h):
                setp(UP, x + i, top + j, shade if i == w - 1 or j == h - 1 else col)
        setp(UP, x, sag(x), K); setp(UP, x + w - 1, sag(x + w - 1), K)        # pegs
        x += w + rnd.randrange(2, 6)

# the way north open (Dabl has been beaten and pulled the barrier away): the same pictures without the barrier
lower.save(P + 'BackAlleysOpenLower.png')
upper.save(P + 'BackAlleysOpenUpper.png')
# the barrier across the way out: two red and white boards on trestles
bx, by = GATE[0][0] * T, GATE[0][1] * T
bar = Image.new('RGBA', (32, 22), (0, 0, 0, 0)); p = bar.load()
RED, WHT = c('#c8443a'), c('#f3f0e8')
for (y0, y1) in ((2, 7), (11, 16)):
    for y in range(y0, y1 + 1):
        for x in range(32):
            p[x, y] = K if y in (y0, y1) or x in (0, 31) else (RED if ((x + y) // 4) % 2 else WHT)
for x0 in (3, 14, 26):
    for y in range(0, 22):
        if p[x0, y][3] == 0 or y in (0, 21):
            p[x0, y] = K; p[x0 + 1, y] = METAL['M'] if 0 < y < 21 else K; p[x0 + 2, y] = METAL['s'] if 0 < y < 21 else K; p[x0 + 3, y] = K
ground_shadow(bx + 2, bx + 30, by + 15, 0.25)
stamp(bar, bx, by + 15 - 22, GATE[0][1])

lower.save(P + 'BackAlleysLower.png')
upper.save(P + 'BackAlleysUpper.png')

# ---------------------------------------------------------------- battle background: the brick wall and the dark slabs
bt = Image.new('RGBA', (176, 99), (0, 0, 0, 255)); bp = bt.load()
for y in range(99):
    for x in range(176):
        if y < 18:
            if y < 3: col = BRICK['cap'][y + 1]
            elif y >= 17: col = c('#4c4f63')
            else:
                row, inrow = (y - 3) // 5, (y - 3) % 5
                bxx = x + (5 if row % 2 else 0)
                col = BRICK['mortar'] if inrow == 4 or bxx % 10 == 9 else (BRICK['hi'] if inrow == 0 else (BRICK['b'] if ((bxx // 10) * 7 + row * 3) % 5 in (1, 3) else BRICK['a']))
        else:
            gx, gy = x, y - 18
            col = FLOORS['d']['line'] if gx % 16 == 0 or gy % 16 == 0 else FLOORS['d']['fill'][(gx // 16 + gy // 16) % 2]
            if gy == 1 and gx % 16: col = c('#626b7f')
        bp[x, y] = col
bt.save(P + 'BackAlleysBattle.png')

# ---------------------------------------------------------------- preview and the grid for the game
both = lower.copy(); both.alpha_composite(upper)
both.resize((W * T // 2, H * T // 2), Image.LANCZOS).save(os.path.join(ROOT, 'tools', 'ulicky-nahled.png'))
with open(os.path.join(ROOT, 'Content', 'backAlleys.js'), 'w', encoding='utf-8') as f:
    f.write('//Zadní uličky (mapa BackAlleys): mřížka, kterou vypisuje tools/ulicky.py spolu s obrázky mapy.\n')
    f.write('//NEUPRAVOVAT RUČNĚ - rozmístění se mění v tools/ulicky.py, ten tenhle soubor přepíše.\n')
    f.write('//  # zeď   . volno   v zídka, přes kterou hrdina seskočí dolů   b krabice od pizzy   B krabičky od burgerů\n')
    f.write('window.BackAlleysGrid = {\n')
    f.write('  manhole: [%d, %d], //poklop zpátky do stok\n' % MANHOLE)
    f.write('  start: [%d, %d], //kde hrdina stojí, když vyleze ze stok\n' % START)
    f.write('  gate: [%s], //zábrana na konci (cesta dál)\n' % ', '.join('[%d, %d]' % g for g in GATE))
    f.write('  beyond: [%s], //chodník za zábranou až k hornímu okraji (volný, až když je zábrana pryč)\n' % ', '.join('[%d, %d]' % t for t in sorted(beyond)))
    f.write('  healer: [%d, %d], //Nicky, který léčí pizzy\n' % HEALER)
    f.write('  seller: [%d, %d], //Olda, který prodává krabičky na burger\n' % SELLER)
    f.write('  //gang Burger Queen: [x, y, kam kouká, na kolik dlaždic vidí, kam se ještě otáčí]\n')
    f.write('  trainers: [\n')
    for (x, y, direction, sight, also) in trainers:
        f.write('    [%d, %d, "%s", %d, %s],\n' % (x, y, direction, sight, '"%s"' % also if also else 'null'))
    f.write('  ],\n')
    f.write('  rows: [\n')
    for row in GRID: f.write('    "%s",\n' % row)
    f.write('  ]\n}\n')
print('images/maps/BackAlleysLower.png, BackAlleysUpper.png, BackAlleysBattle.png, Content/backAlleys.js')
print('%d x %d dlaždic, volných %d, krabic od pizzy %d, krabiček od burgerů %d, zídek %d' % (W, H, len(forward), len(boxes), len(burger_boxes), len(ledges)))
print('od poklopu k zábraně %d kroků, zpátky %d' % (forward[gate_front], reach(gate_front, steps)[START]))
print('gang: %d členů, %d z nich se nedá obejít, %d se otáčí' % (len(trainers), unavoidable, sum(1 for t in trainers if t[4])))
# patches of boxes: which of them can be avoided on the way from the manhole to the barrier
todo, patches = set(boxes), []
while todo:
    group, stack_ = set(), [todo.pop()]
    while stack_:
        t = stack_.pop(); group.add(t)
        for dx, dy in DIRS:
            n = (t[0] + dx, t[1] + dy)
            if n in todo: todo.discard(n); stack_.append(n)
    patches.append(group)
avoidable = [min(g) for g in patches if gate_front in reach(START, lambda x, y, g=g: (n for n in steps(x, y) if n not in g))]
print('krabice: %d hnízd, přes %d se cestou k zábraně musí; obejít jdou jen ta ve slepých koutech: %s' % (len(patches), len(patches) - len(avoidable), sorted(avoidable)))
