//A spot on the map you can use with the action key, without anything drawn on it
//(the thing itself is part of the map picture, e.g. a counter). Give it "talking" like a person.
class Hotspot extends GameObject {
  constructor(config) {
    super(config);
    this.sprite = {
      draw() { },
      setAnimation() { },
      updateAnimationProgress() { },
    };
  }
}
