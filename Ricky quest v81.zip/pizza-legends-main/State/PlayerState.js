class PlayerState {
  constructor() {
    //The pizza the player starts with is not quite fresh (see STARTER_FRESHNESS)
    const starter = PlayerState.freshStats(PlayerState.STARTER_FRESHNESS);
    this.pizzas = {
      "p1": {
        pizzaId: "s001",
        hp: starter.maxHp,
        maxHp: starter.maxHp,
        xp: 0,
        maxXp: 100,
        level: 1,
        status: null,
        attack: starter.attack,
        defense: starter.defense,
        shiny: PlayerState.rollShiny(),
        freshness: PlayerState.STARTER_FRESHNESS,
        addons: [],
        growthApplied: true,
      },
      // "p2": {
      //   pizzaId: "v001",
      //   hp: 50,
      //   maxHp: 50,
      //   xp: 75,
      //   maxXp: 100,
      //   level: 1,
      //   status: null,
      // },
      // "p3": {
      //   pizzaId: "f001",
      //   hp: 50,
      //   maxHp: 50,
      //   xp: 75,
      //   maxXp: 100,
      //   level: 1,
      //   status: null,
      // }
    }
    this.lineup = ["p1"];
    //Pizzas left at the counter in the shop building (the box). The hero carries only the lineup, three at most;
    //there is no reserve any more (it went in v74), a fourth one caught goes straight here.
    this.storage = [];
    //Recipes (shown like a pizza-dex): which kinds of pizza the player has met in a fight ("seen") or had ("owned")
    this.dex = { "s001": "owned" };
    if (this.pizzas["p1"].shiny) {
      this.dex["s001_shiny"] = "owned";
    }
    this.items = [
      { actionId: "item_recoverHp", instanceId: "item1" },
      { actionId: "item_recoverHp", instanceId: "item2" },
      { actionId: "item_recoverHp", instanceId: "item3" },
    ]
    this.storyFlags = {
    };
    //(The hero had a level and experience of his own until v74; it did nothing, so it is gone. Pizzas still level up.)
    this.money = 0;
    //Real seconds spent in the game, and the game's own clock in minutes since midnight of day 1
    //(one game minute passes every real second, see GameClock.js). The adventure starts on day 1 at 8:00.
    this.playTime = 0;
    this.gameMinutes = PlayerState.START_MINUTES;
  }

  static get START_MINUTES() {
    return 8 * 60;
  }

  //Hours one sleep in the bed at home takes
  static get SLEEP_HOURS() {
    return 6;
  }

  //{ day: 1, hours: 8, minutes: 5, text: "08:05" }
  getClock() {
    const total = Math.floor(this.gameMinutes || 0);
    const hours = Math.floor(total / 60) % 24;
    const minutes = total % 60;
    return {
      day: Math.floor(total / (24 * 60)) + 1,
      hours,
      minutes,
      text: `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`,
    };
  }

  advanceMinutes(amount) {
    this.gameMinutes = (this.gameMinutes || 0) + amount;
    utils.emitEvent("ClockChanged");
  }

  //Night lasts from 20:00 to 5:00. Some forgotten pizzas only come out then.
  isNight() {
    const { hours } = this.getClock();
    return hours >= 20 || hours < 5;
  }

  //Which picture the clock shows: "night", "dusk" (also used for dawn: 5:00-7:00 and 18:00-20:00) or "day"
  getSky() {
    const { hours } = this.getClock();
    if (this.isNight()) { return "night" }
    return (hours < 7 || hours >= 18) ? "dusk" : "day";
  }

  //Colour laid over the map for the time of day, as [red, green, blue, alpha]; alpha 0 in full daylight.
  //Evening goes warm first and then dark blue, morning comes back through pink.
  getDaylightTint() {
    const night = [10, 14, 60, 0.5];
    const keys = [
      [0, night],
      [4.5 * 60, night],
      [5.5 * 60, [255, 150, 130, 0.16]],
      [7 * 60, [255, 150, 130, 0]],
      [17.5 * 60, [255, 120, 40, 0]],
      [19 * 60, [255, 120, 40, 0.2]],
      [20.5 * 60, night],
      [24 * 60, night],
    ];
    const minute = (this.gameMinutes || 0) % (24 * 60);
    const next = keys.findIndex(key => key[0] > minute);
    const [fromMinute, from] = keys[next - 1];
    const [toMinute, to] = keys[next];
    const progress = (minute - fromMinute) / (toMinute - fromMinute);
    return from.map((value, index) => value + (to[index] - value) * progress);
  }

  //A sleep in the bed at home moves the clock six hours ahead
  sleep() {
    this.advanceMinutes(PlayerState.SLEEP_HOURS * 60);
  }

  //Every pizza back to full health (Mia does this, and so does waking up at home after a lost fight)
  healPizzas() {
    Object.values(this.pizzas).forEach(pizza => {
      pizza.hp = pizza.maxHp;
      pizza.status = null;
    })
    utils.emitEvent("PlayerStateUpdated");
  }

  //Seconds as "1:05:09"
  static formatPlayTime(seconds) {
    const total = Math.floor(seconds || 0);
    const pad = number => String(number).padStart(2, "0");
    return `${Math.floor(total / 3600)}:${pad(Math.floor(total / 60) % 60)}:${pad(total % 60)}`;
  }

  markSeen(pizzaId) {
    this.dex = this.dex || {};
    //Kinds that are not in the recipe list (the pizza monster) are not written down
    if (!this.dex[pizzaId] && !Pizzas[pizzaId]?.hidden) {
      this.dex[pizzaId] = "seen";
    }
  }

  markOwned(pizzaId, shiny) {
    this.dex = this.dex || {};
    this.dex[pizzaId] = "owned";
    //The golden version is remembered in the recipes under its own key, so a saved game keeps it
    if (shiny) {
      this.dex[pizzaId + "_shiny"] = "owned";
    }
  }

  //A pizza's own name if it was renamed, otherwise the name of its kind
  static nameOf(pizza) {
    return (pizza.shiny ? "★ " : "") + (pizza.name || Pizzas[pizza.pizzaId].name);
  }

  //The player carries pizzas and burgers. Texts about one of them pick the right word with this (Czech says
  //"ta pizza" but "ten burger"):  PlayerState.word(pizza, "tuhle pizzu", "tenhle burger")
  //Texts about all of them say "sestava" or leave the noun out.
  static isBurger(pizza) {
    return Pizzas[pizza.pizzaId]?.type === "burger";
  }

  static word(pizza, forPizza, forBurger) {
    return PlayerState.isBurger(pizza) ? forBurger : forPizza;
  }

  //Golden pizza: every forgotten pizza, fished pizza and the baked one has this tiny chance (PlayerState.SHINY_CHANCE, below)
  static rollShiny() {
    return Math.random() < PlayerState.SHINY_CHANCE;
  }

  //Empty text gives the pizza its original name back. Characters that could break the menus are dropped.
  renamePizza(id, text) {
    const name = String(text || "").replace(/[<>&"'`\\]/g, "").trim().slice(0, 18);
    if (name) {
      this.pizzas[id].name = name;
    } else {
      delete this.pizzas[id].name;
    }
    utils.emitEvent("LineupChanged");
    return PlayerState.nameOf(this.pizzas[id]);
  }

  //The attacks of a pizza in the order its owner gave them (the storage counter, "Pořadí útoků").
  //A pizza without its own order, or with one that no longer fits its kind, has them the way the kind lists them.
  static actionsOf(pizza) {
    const base = Pizzas[pizza.pizzaId].actions;
    const own = pizza.actions;
    const fits = Array.isArray(own) && own.length === base.length
      && base.every(key => own.includes(key)) && own.every(key => base.includes(key));
    return fits ? own : base;
  }

  //Moves the attack in slot "index" one slot up (step -1) or down (step 1). Returns the slot it is in afterwards.
  moveAction(id, index, step) {
    const pizza = this.pizzas[id];
    const order = [...PlayerState.actionsOf(pizza)];
    const target = index + step;
    if (target < 0 || target >= order.length) {
      return index;
    }
    [order[index], order[target]] = [order[target], order[index]];
    pizza.actions = order;
    return target;
  }

  //The warming lamp outside a fight: a knocked out one gets back a share of its health
  revivePizza(id, share) {
    const pizza = this.pizzas[id];
    pizza.hp = Math.max(1, Math.round(pizza.maxHp * share));
    pizza.status = null;
    utils.emitEvent("PlayerStateUpdated");
  }

  //Is there a pizza in the lineup that can still fight?
  hasHealthyPizza() {
    return this.lineup.some(id => this.pizzas[id].hp > 0);
  }

  //What the hero has with them: the lineup, three at most. (Until v74 there was a reserve of three more.)
  getCarriedIds() {
    return [...this.lineup];
  }

  //--- Levels ---
  //Every level above the first adds this much to a pizza
  static get GROWTH() {
    return { maxHp: 5, attack: 1, defense: 1 };
  }

  //Experience needed to leave a level: 100 for level 1, 200 for level 2, ...
  //An enemy pizza gives 20 x its level, so it is always five wins against pizzas of your own level.
  static xpForLevel(level) {
    return 100 * level;
  }

  //Attack and defense of a pizza that has nothing but its level (also used for enemies)
  static statForLevel(level) {
    return 10 + PlayerState.GROWTH.attack * ((level || 1) - 1);
  }

  //Health of a level 1 pizza with baseHp, grown to the given level (a tenth more per level)
  static hpForLevel(baseHp, level) {
    return Math.round(baseHp * (1 + 0.1 * ((level || 1) - 1)));
  }

  //Level of the pizza at the front of the lineup; training and forgotten pizzas adjust to it
  getLeadLevel() {
    return this.pizzas[this.lineup[0]]?.level || 1;
  }

  //Pizzas from save files made before levels changed stats get the growth they missed
  migratePizzas() {
    //Save files from before v74 may have pizzas in the reserve (carried, but not in the lineup): those are in storage now
    this.storage = this.storage || [];
    Object.keys(this.pizzas).forEach(id => {
      if (this.lineup.indexOf(id) === -1 && this.storage.indexOf(id) === -1) {
        this.storage.push(id);
      }
    })
    //Save files of versions 14 and 15 kept a plain list of known recipes: those were all owned
    Object.keys(this.recipes || {}).forEach(pizzaId => this.markOwned(pizzaId));
    delete this.recipes;
    //Save files made before every pizza had a freshness: the first pizza and the baked ones get theirs now,
    //together with what it adds to their stats (the same amount a new one of that freshness starts with)
    Object.keys(this.pizzas).forEach(id => {
      const pizza = this.pizzas[id];
      if (pizza.freshness || pizza.caught) {
        return;
      }
      pizza.freshness = id === "p1" ? PlayerState.STARTER_FRESHNESS : PlayerState.BAKED_FRESHNESS;
      const fresh = PlayerState.freshStats(pizza.freshness);
      const plain = PlayerState.freshStats(0);
      pizza.maxHp += fresh.maxHp - plain.maxHp;
      pizza.hp = pizza.hp > 0 ? pizza.hp + fresh.maxHp - plain.maxHp : pizza.hp;
      pizza.attack = (pizza.attack || 10) + fresh.attack - plain.attack;
      pizza.defense = (pizza.defense || 10) + fresh.defense - plain.defense;
    })
    Object.values(this.pizzas).forEach(pizza => {
      this.markOwned(pizza.pizzaId); //older save files have no such list at all
      if (pizza.growthApplied) {
        return;
      }
      const levelsGained = (pizza.level || 1) - 1;
      pizza.maxHp += PlayerState.GROWTH.maxHp * levelsGained;
      pizza.hp += PlayerState.GROWTH.maxHp * levelsGained;
      pizza.attack = (pizza.attack || 10) + PlayerState.GROWTH.attack * levelsGained;
      pizza.defense = (pizza.defense || 10) + PlayerState.GROWTH.defense * levelsGained;
      pizza.maxXp = PlayerState.xpForLevel(pizza.level || 1);
      pizza.addons = pizza.addons || [];
      pizza.growthApplied = true;
    })
  }

  //Stats grow a little with freshness: 0 % adds nothing, 100 % adds a quarter
  static freshnessBonus(freshness) {
    return 1 + 0.25 * (freshness || 0) / 100;
  }

  //Every pizza has a freshness. Caught ones get theirs by chance (1 to 100 %), these two are fixed:
  //the pizza the player starts with, and a pizza baked on a pizza stone.
  static get STARTER_FRESHNESS() {
    return 70;
  }

  static get BAKED_FRESHNESS() {
    return 85;
  }

  //Health, attack and defense of a level 1 pizza of the given freshness, before any ingredients
  static freshStats(freshness) {
    const bonus = PlayerState.freshnessBonus(freshness);
    return {
      maxHp: Math.round(50 * bonus),
      attack: Math.round(PlayerState.statForLevel(1) * bonus),
      defense: Math.round(PlayerState.statForLevel(1) * bonus),
    };
  }

  //A new pizza goes to the lineup, and when the three places there are taken, to storage
  addPizza(pizzaId, overrides = {}) {
    const newId = `p${Date.now()}` + Math.floor(Math.random() * 99999);
    this.pizzas[newId] = {
      pizzaId,
      hp: 50,
      maxHp: 50,
      xp: 0,
      maxXp: 100,
      level: 1,
      status: null,
      attack: 10,
      defense: 10,
      addons: [],
      growthApplied: true,
      ...overrides,
    }
    this.markOwned(pizzaId, this.pizzas[newId].shiny);
    if (this.lineup.length < 3) {
      this.lineup.push(newId)
    } else {
      this.storage.push(newId);
    }
    utils.emitEvent("LineupChanged");
    return newId;
  }

  removePizza(id) {
    delete this.pizzas[id];
    this.lineup = this.lineup.filter(lineupId => lineupId !== id);
    this.storage = this.storage.filter(storedId => storedId !== id);
    utils.emitEvent("LineupChanged");
  }

  //The last pizza of the lineup has to stay with the player
  isLastOfLineup(id) {
    return this.lineup.length === 1 && this.lineup[0] === id;
  }

  storePizza(id) {
    if (this.isLastOfLineup(id)) {
      return false;
    }
    this.lineup = this.lineup.filter(lineupId => lineupId !== id);
    this.storage.push(id);
    utils.emitEvent("LineupChanged");
    return true;
  }

  withdrawPizza(id) {
    if (this.lineup.length >= 3) {
      return false;
    }
    this.storage = this.storage.filter(storedId => storedId !== id);
    this.lineup.push(id);
    utils.emitEvent("LineupChanged");
    return true;
  }

  countItems(actionId) {
    return this.items.filter(item => item.actionId === actionId).length;
  }

  addItem(actionId) {
    this.items.push({
      actionId,
      instanceId: `item${Date.now()}` + Math.floor(Math.random() * 99999),
    })
    utils.emitEvent("PlayerStateUpdated");
  }

  removeItem(actionId) {
    const index = this.items.findIndex(item => item.actionId === actionId);
    if (index > -1) {
      this.items.splice(index, 1);
    }
  }

  //Use up one ingredient on a pizza: its stats go up for good. Three ingredients per pizza at most.
  applyAddon(pizzaId, actionId) {
    const pizza = this.pizzas[pizzaId];
    const bonus = Actions[actionId].addon;
    pizza.addons = pizza.addons || [];
    if (!bonus || pizza.addons.length >= 3 || this.countItems(actionId) === 0) {
      return false;
    }
    pizza.addons.push(actionId);
    pizza.maxHp += bonus.maxHp || 0;
    pizza.hp += bonus.maxHp || 0;
    pizza.attack = (pizza.attack || 10) + (bonus.attack || 0);
    pizza.defense = (pizza.defense || 10) + (bonus.defense || 0);
    this.removeItem(actionId);
    utils.emitEvent("PlayerStateUpdated");
    return true;
  }

  moveToFront(futureFrontId) {
    this.lineup = this.lineup.filter(id => id !== futureFrontId);
    this.lineup.unshift(futureFrontId);
    utils.emitEvent("LineupChanged");
  }

}
//One in 500 (0.2 %). To try it out, type PlayerState.SHINY_CHANCE = 1 into the browser console.
PlayerState.SHINY_CHANCE = 1 / 500;

window.playerState = new PlayerState();
