class PauseMenu {
  constructor({ progress, onComplete }) {
    this.progress = progress;
    this.onComplete = onComplete;
    this.panelKey = null;
  }

  getOptions(pageKey) {

    //Case 1: Show the first page of options
    if (pageKey === "root") {
      const hasSaveFile = !!this.progress.getSaveFile();
      return [
        {
          label: "Menu",
          description: "Prohlédni si pizzy a burgery, které máš u sebe, a uprav menu",
          onFocus: () => this.showPanel("pizzas"),
          handler: () => {
            this.showPage("pizzas");
          }
        },
        {
          label: "Předměty",
          description: "Co máš u sebe. Většina je do souboje, některé věci jdou použít hned odsud",
          onFocus: () => this.showPanel("items"),
          handler: () => {
            if (this.getFieldItems().length + this.getReviveItems().length > 0) {
              this.showPage("items");
            }
          }
        },
        {
          label: "Recepty",
          description: "Druhy pizz a burgerů: které jsi viděl a které už ti patřily",
          onFocus: () => this.showPanel("dex"),
          handler: () => {
            this.showPage("dex");
          }
        },
        {
          label: "Úkoly",
          description: "Co je potřeba udělat",
          onFocus: () => this.showPanel("objectives"),
          handler: () => { }
        },
        {
          label: "Nastavení",
          description: "Jazyk, záloha uložené hry a přehled kláves",
          onFocus: () => this.showPanel("controls"),
          handler: () => {
            this.showPage("settings");
          }
        },
        {
          label: "Uložit",
          description: "Ulož svůj postup",
          onFocus: () => this.showPanel("pizzas"),
          handler: () => {
            this.progress.save();
            this.close();
          }
        },
        {
          label: "Načíst",
          description: "Vrať se k uložené hře",
          disabled: !hasSaveFile,
          onFocus: () => this.showPanel("pizzas"),
          handler: () => {
            this.progress.load();
            this.close(true);
          }
        },
        {
          label: "Zavřít",
          description: "Zavře pauzu",
          onFocus: () => this.showPanel("pizzas"),
          handler: () => {
            this.close();
          }
        }
      ]
    }

    //Recipes (a pizza-dex): every kind of pizza, in the order of Content/pizzas.js
    //Things that can be used outside a fight (Actions with "fieldUse", e.g. the escape rope). Using one closes the
    //menu; the pause event (OverworldEvent.pause) then plays the item's "fieldEvents".
    if (pageKey === "items") {
      const fainted = this.getFaintedIds();
      return [
        //The warming lamp: works here too, on anybody carried who is knocked out (it asks who)
        ...this.getReviveItems().map(actionId => {
          const action = Actions[actionId];
          return {
            label: `Použít: ${action.name}`,
            description: fainted.length ? action.description : "Nikdo, koho máš u sebe, není na kaši",
            disabled: fainted.length === 0,
            right: () => `${playerState.countItems(actionId)}x`,
            onFocus: () => this.showPanel("items"),
            handler: () => {
              this.reviveAction = actionId;
              this.showPage("revive");
            }
          }
        }),
        ...this.getFieldItems().map(actionId => {
          const action = Actions[actionId];
          const isUseless = action.notOnMap === this.progress.mapId;
          return {
            label: `Použít: ${action.name}`,
            description: isUseless ? "Tady by ti k ničemu nebylo, už jsi doma" : action.description,
            disabled: isUseless,
            right: () => `${playerState.countItems(actionId)}x`,
            onFocus: () => this.showPanel("items"),
            handler: () => {
              playerState.removeItem(actionId);
              this.fieldAction = actionId;
              this.close();
            }
          }
        }),
        {
          label: "Zpět",
          description: "Zpět na začátek pauzy",
          onFocus: () => this.showPanel("items"),
          handler: () => {
            this.showPage("root");
          }
        }
      ]
    }

    //Settings: the language of the game (Lang.js) and the saved game as a file, out and in (Progress.getBackupOptions).
    //The panel next to it shows the keys.
    if (pageKey === "settings") {
      const backup = this.progress.getBackupOptions({
        note: this.backupNote,
        show: note => {
          if (!this.element.isConnected) { return; } //the pause was closed in the meantime
          this.backupNote = note;
          this.showPage("settings", note.index + 1); //the highlight stays on the line that was used
        },
        //a saved game that was just taken in is loaded right away, like "Načíst"
        onUploaded: () => {
          if (!this.element.isConnected) { return; }
          this.progress.load();
          this.close(true);
        },
      }).map(option => ({ ...option, onFocus: () => this.showPanel("controls") }));
      return [
        {
          label: Lang.label(),
          description: Lang.describe(),
          onFocus: () => this.showPanel("controls"),
          handler: () => {
            Lang.toggle();
            this.backupNote = null;
            this.showPage("settings"); //the line itself now names the other language
          }
        },
        ...backup,
        {
          label: "Zpět",
          description: "Zpět na začátek pauzy",
          onFocus: () => this.showPanel("controls"),
          handler: () => {
            this.backupNote = null;
            this.showPage("root");
          }
        }
      ]
    }

    //Who the warming lamp should wake
    if (pageKey === "revive") {
      const action = Actions[this.reviveAction];
      return [
        ...this.getFaintedIds().map(id => {
          const pizza = playerState.pizzas[id];
          return {
            label: PlayerState.nameOf(pizza),
            description: "Na kaši. Vrátí se s polovinou životů",
            onFocus: () => this.showPanel("pizzas", id),
            handler: () => {
              playerState.removeItem(this.reviveAction);
              playerState.revivePizza(id, action.revives);
              //back to the items; with no lamp or nobody left to wake that page says so
              this.showPage(playerState.countItems(this.reviveAction) && this.getFaintedIds().length ? "revive" : "items");
              this.showPanel("pizzas", id);
            }
          }
        }),
        {
          label: "Zpět",
          description: "Zpět na předměty",
          onFocus: () => this.showPanel("items"),
          handler: () => {
            this.showPage("items");
          }
        }
      ]
    }

    if (pageKey === "dex") {
      //The list is cut into pages of DEX_PAGE_SIZE kinds; "Další strana" goes round them
      const ids = Object.keys(Pizzas);
      const pages = this.getDexPages();
      this.dexPage = Math.min(this.dexPage || 0, pages - 1);
      const first = this.dexPage * PauseMenu.DEX_PAGE_SIZE;
      const entries = ids.slice(first, first + PauseMenu.DEX_PAGE_SIZE).map((pizzaId, offset) => {
        const index = first + offset;
        const status = (playerState.dex || {})[pizzaId];
        const isBurger = Pizzas[pizzaId].type === "burger";
        const seenText = isBurger ? "Tenhle burger už znáš, ale ještě ti nepatřil" : "Tuhle pizzu už znáš, ale ještě ti nepatřila";
        return {
          label: `${this.getDexNumber(index)} ${status ? Pizzas[pizzaId].name : "???"}`,
          description: status === "owned" ? Pizzas[pizzaId].description : (status === "seen" ? seenText : "Tenhle druh zatím neznáš"),
          onFocus: () => this.showPanel("dexEntry", pizzaId),
          handler: () => { }
        }
      })
      return [
        ...entries,
        ...(pages > 1 ? [{
          label: `Další strana (${this.dexPage + 1}/${pages})`,
          description: "Další druhy v seznamu",
          onFocus: () => this.showPanel("dex"),
          handler: () => {
            this.dexPage = (this.dexPage + 1) % pages;
            this.showPage("dex");
          }
        }] : []),
        {
          label: "Zpět",
          description: "Zpět na začátek pauzy",
          onFocus: () => this.showPanel("dex"),
          handler: () => {
            this.showPage("root");
          }
        }
      ]
    }

    //Case 2: Show the pizzas in the lineup
    if (pageKey === "pizzas") {
      const lineupPizzas = playerState.lineup.map(id => {
        const { pizzaId } = playerState.pizzas[id];
        const base = Pizzas[pizzaId];
        return {
          label: PlayerState.nameOf(playerState.pizzas[id]),
          description: base.description,
          onFocus: () => this.showPanel("pizzas", id),
          handler: () => {
            this.showPage(id);
          }
        }
      })
      return [
        ...lineupPizzas,
        {
          label: "Zpět",
          description: "Zpět na začátek pauzy",
          onFocus: () => this.showPanel("pizzas"),
          handler: () => {
            this.showPage("root");
          }
        }
      ]
    }

    //Case 3: Show the options for just one pizza (by id)
    return [
      {
        label: "Přesunout dopředu",
        description: PlayerState.word(playerState.pizzas[pageKey], "Přesune tuto pizzu na začátek menu", "Přesune tento burger na začátek menu"),
        onFocus: () => this.showPanel("pizzas", pageKey),
        handler: () => {
          playerState.moveToFront(pageKey);
          this.showPage("pizzas");
        }
      },
      {
        label: "Zpět",
        description: "Zpět na menu",
        onFocus: () => this.showPanel("pizzas", pageKey),
        handler: () => {
          this.showPage("pizzas");
        }
      }
    ];
  }

  //One line of the right panel: dark label on the left, light value on the right
  getRowMarkup(label, value, modifier = "") {
    return (`
      <div class="PauseMenu_row ${modifier}">
        <span class="PauseMenu_label">${label}</span>
        <span class="PauseMenu_value">${value}</span>
      </div>
    `)
  }

  getSlotMarkup(id, highlightedId) {
    const pizza = playerState.pizzas[id];
    if (!pizza) {
      return (`
        <div class="PauseMenu_slot PauseMenu_slot--empty">
          <div class="PauseMenu_slotTop">
            <span class="PauseMenu_label">Prázdné</span>
            <span class="PauseMenu_value">Prázdné</span>
          </div>
          <div class="PauseMenu_bar"></div>
        </div>
      `)
    }
    const base = Pizzas[pizza.pizzaId];
    const hpPercent = Math.max(0, Math.min(100, pizza.hp / pizza.maxHp * 100));
    const typeName = window.PizzaTypeNames?.[base.type] || base.type;
    return (`
      <div class="PauseMenu_slot ${id === highlightedId ? "PauseMenu_slot--highlighted" : ""}">
        <div class="PauseMenu_slotTop">
          <span class="PauseMenu_label">${PlayerState.nameOf(pizza)}</span>
          <span class="PauseMenu_value">
            <img class="PauseMenu_typeIcon" src="${base.icon}" alt="" />
            ${pizza.hp <= 0 ? "na kaši" : typeName}, úr. ${pizza.level}${pizza.freshness ? `, ${pizza.freshness} %` : ""}
          </span>
        </div>
        <div class="PauseMenu_bar"><div class="PauseMenu_barFill" style="width: ${hpPercent}%"></div></div>
      </div>
    `)
  }

  getPanelMarkup(panelKey, highlightedId) {

    if (panelKey === "items") {
      let quantities = {};
      playerState.items.forEach(item => {
        quantities[item.actionId] = (quantities[item.actionId] || 0) + 1;
      })
      const rows = Object.keys(quantities).map(actionId => {
        return this.getRowMarkup(Actions[actionId].name, `${quantities[actionId]}x`, "PauseMenu_row--wideLabel");
      }).join("");
      return (`
        <h2>Předměty</h2>
        ${rows || `<p class="PauseMenu_note">Nemáš žádné předměty.</p>`}
      `)
    }

    //Recipes overview: how many kinds are seen and owned, and the whole list at a glance
    if (panelKey === "dex") {
      const counts = this.getDexCounts();
      const pages = this.getDexPages();
      const first = (this.dexPage || 0) * PauseMenu.DEX_PAGE_SIZE;
      const rows = Object.keys(Pizzas).slice(first, first + PauseMenu.DEX_PAGE_SIZE).map((pizzaId, offset) => {
        const index = first + offset;
        const status = (playerState.dex || {})[pizzaId];
        const label = `${this.getDexNumber(index)} ${status ? Pizzas[pizzaId].name : "???"}`;
        const value = status === "owned" ? "získáno" : (status === "seen" ? "viděno" : "neznámá");
        return this.getRowMarkup(label, value, "PauseMenu_row--wideLabel" + (status === "owned" ? "" : " PauseMenu_row--pending"));
      }).join("");
      return (`
        <h2>Recepty${pages > 1 ? ` (${(this.dexPage || 0) + 1}/${pages})` : ""}</h2>
        <div class="PauseMenu_stats">
          ${this.getRowMarkup("Viděno", `${counts.seen} / ${counts.total}`)}
          ${this.getRowMarkup("Získáno", `${counts.owned} / ${counts.total}`)}
        </div>
        ${rows}
      `)
    }

    //Recipes, one kind (highlightedId is the pizza kind here). The more you know it, the more it tells.
    if (panelKey === "dexEntry") {
      const base = Pizzas[highlightedId];
      const number = this.getDexNumber(Object.keys(Pizzas).indexOf(highlightedId));
      const status = (playerState.dex || {})[highlightedId];
      if (!status) {
        return (`
          <h2>${number} ???</h2>
          <div class="PauseMenu_recipeTop">
            <div class="PauseMenu_recipePicture PauseMenu_recipePicture--unknown">?</div>
            <div class="PauseMenu_recipeFacts">
              ${this.getRowMarkup("Stav", "neznámá")}
            </div>
          </div>
          <p class="PauseMenu_note">Tenhle druh zatím neznáš. Objeví se tu, jakmile ho potkáš v souboji.</p>
        `)
      }
      const typeName = window.PizzaTypeNames?.[base.type] || base.type;
      const isOwned = status === "owned";
      const hasShiny = (playerState.dex || {})[highlightedId + "_shiny"] === "owned";
      const inHand = Object.values(playerState.pizzas).filter(pizza => pizza.pizzaId === highlightedId).length;
      return (`
        <h2>${number} ${base.name}</h2>
        ${isOwned ? `<p class="PauseMenu_tagline">${base.description}</p>` : ""}
        <div class="PauseMenu_recipeTop">
          <div class="PauseMenu_recipePicture"><img src="${hasShiny ? base.shinySrc : base.src}" alt="" /></div>
          <div class="PauseMenu_recipeFacts">
            ${this.getRowMarkup("Stav", isOwned ? "získáno" : "viděno")}
            ${this.getRowMarkup("Typ", typeName)}
            ${isOwned ? this.getRowMarkup("Kde", base.origin || "neznámo") : ""}
            ${isOwned ? this.getRowMarkup("Máš jich", inHand) : ""}
            ${hasShiny ? this.getRowMarkup("Zlatá", "★ získána") : ""}
          </div>
        </div>
        ${isOwned ? (`
          <h3>Útoky</h3>
          <div class="PauseMenu_chips">
            ${base.actions.map(key => `<span class="PauseMenu_chip">${Actions[key].name}</span>`).join("")}
          </div>
        `) : `<p class="PauseMenu_note">Viděno v souboji. Získej ji a dozvíš se víc.</p>`}
      `)
    }

    if (panelKey === "objectives") {
      //So that the list does not give the story away, only what is done and the one task to do now can be read.
      //Everything after that is "???" until its turn comes (the next one shows up when the current one is done).
      let currentShown = false;
      const rows = (window.Objectives || []).map(objective => {
        //One flag, or several of them (then the row also says how many are done)
        const flags = objective.flags || [objective.flag];
        const doneCount = flags.filter(flag => playerState.storyFlags[flag]).length;
        const isDone = doneCount === flags.length;
        const text = flags.length > 1 ? `${objective.text} (${doneCount}/${flags.length})` : objective.text;
        if (isDone) {
          return this.getRowMarkup("Splněno", text);
        }
        if (!currentShown) {
          currentShown = true;
          return this.getRowMarkup("Teď", text, "PauseMenu_row--current");
        }
        return this.getRowMarkup("Čeká", "???", "PauseMenu_row--pending");
      }).join("");
      return (`
        <h2>Úkoly</h2>
        <div class="PauseMenu_objectives">${rows}</div>
      `)
    }

    if (panelKey === "controls") {
      return (`
        <h2>Nastavení</h2>
        ${this.getRowMarkup("Jazyk", Lang.current === "en" ? "English" : "čeština", "PauseMenu_row--wideLabel")}
        <h3>Ovládání</h3>
        ${this.getRowMarkup("W A S D / šipky", "Pohyb a výběr v nabídkách", "PauseMenu_row--wideLabel")}
        ${this.getRowMarkup("E / Enter", "Mluvit, potvrdit, další text", "PauseMenu_row--wideLabel")}
        ${this.getRowMarkup("Esc", "Otevřít a zavřít pauzu", "PauseMenu_row--wideLabel")}
      `)
    }

    //Default: hero overview with the pizzas
    const { money, lineup } = playerState;
    const clock = playerState.getClock();
    const dexCounts = this.getDexCounts();
    const slots = ids => [0, 1, 2].map(index => this.getSlotMarkup(ids[index], highlightedId)).join("");
    return (`
      <h2>Hrdina</h2>
      <div class="PauseMenu_stats">
        ${this.getRowMarkup("Peníze", money)}
        ${this.getRowMarkup("Recepty", `${dexCounts.owned} / ${dexCounts.total}`)}
        ${this.getRowMarkup("Odehráno", PlayerState.formatPlayTime(playerState.playTime))}
        ${this.getRowMarkup("Herní čas", `Den ${clock.day}, ${clock.text}`)}
      </div>
      <div class="PauseMenu_teams">
        <h3>V menu</h3>
        ${slots(lineup)}
      </div>
    `)
  }

  //Kinds of items in the bag that can be used from this menu
  getFieldItems() {
    return [...new Set(playerState.items.map(item => item.actionId))].filter(actionId => Actions[actionId].fieldUse);
  }

  //Items that wake somebody knocked out (the warming lamp), and who of those carried is knocked out
  getReviveItems() {
    return [...new Set(playerState.items.map(item => item.actionId))].filter(actionId => Actions[actionId].revives);
  }

  getFaintedIds() {
    return playerState.getCarriedIds().filter(id => playerState.pizzas[id].hp <= 0);
  }

  getDexPages() {
    return Math.max(1, Math.ceil(Object.keys(Pizzas).length / PauseMenu.DEX_PAGE_SIZE));
  }

  //Recipe numbers: "#001", "#002", ...
  getDexNumber(index) {
    return "#" + String(index + 1).padStart(3, "0");
  }

  getDexCounts() {
    const dex = playerState.dex || {};
    const ids = Object.keys(Pizzas);
    return {
      total: ids.length,
      seen: ids.filter(id => dex[id]).length,
      owned: ids.filter(id => dex[id] === "owned").length,
    };
  }

  //Swap the option list on the left. Pages below the first one use smaller text, their labels are longer
  //focusIndex: which line gets the highlight (see KeyboardMenu.setOptions); without it the first one
  showPage(pageKey, focusIndex = null) {
    this.sideElement.setAttribute("data-page", pageKey === "root" ? "root" : (pageKey === "dex" ? "dex" : "sub"));
    this.keyboardMenu.setOptions(this.getOptions(pageKey), focusIndex);
  }

  showPanel(panelKey, highlightedId = null) {
    this.panelKey = panelKey;
    this.panelElement.innerHTML = this.getPanelMarkup(panelKey, highlightedId);
  }

  createElement() {
    this.element = document.createElement("div");
    this.element.classList.add("PauseMenu");
    this.element.innerHTML = (`
      <div class="PauseMenu_side">
        <h2>Pauza</h2>
      </div>
      <div class="PauseMenu_panel"></div>
    `)
    this.sideElement = this.element.querySelector(".PauseMenu_side");
    this.panelElement = this.element.querySelector(".PauseMenu_panel");
  }

  close(didLoad = false) {
    this.esc?.unbind();
    this.keyboardMenu.end();
    this.element.remove();
    this.onComplete(didLoad);
  }

  async init(container) {
    this.createElement();
    this.keyboardMenu = new KeyboardMenu({
      descriptionContainer: this.element
    })
    this.keyboardMenu.init(this.sideElement);
    this.showPanel("pizzas");
    this.showPage("root");

    container.appendChild(this.element);

    utils.wait(200);
    this.esc = new KeyPressListener("Escape", () => {
      this.close();
    })
  }

}

//How many kinds fit on one page of the recipes (with "Další strana" and "Zpět" it makes ten rows, no more fit)
PauseMenu.DEX_PAGE_SIZE = 8;
