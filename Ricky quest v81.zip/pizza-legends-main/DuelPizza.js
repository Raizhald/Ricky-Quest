//A pizza lying on the ground as part of a duel staged between two trainers (the plaza on the main street).
//It only looks like a battle: the two pizzas take turns, one makes a short lunge at the other and the one
//that got hit hops. Give each of the pair the direction of its opponent and half a period between them:
//  new DuelPizza({ x, y, src, towards: 1 })                 lunges to the right first
//  new DuelPizza({ x, y, src, towards: -1, delay: 90 })     answers half a period later
class DuelPizza extends GameObject {
  constructor(config) {
    super(config);
    this.sprite = new Sprite({
      gameObject: this,
      src: config.src,
      shadowSrc: "images/characters/pizzas/pizza-shadow.png",
      animations: {
        "idle-down": [[0, 0]],
      },
    });
    this.towards = config.towards || 1; //1 = the opponent is to the right, -1 = to the left
    this.delay = config.delay || 0;     //frames by which its turn comes later
    this.period = 180;                  //frames for one exchange (both pizzas attack once)
    this.tick = 0;
    //Read by Sprite.draw: how far from its tile the picture is drawn right now
    this.spriteOffsetX = 0;
    this.spriteOffsetY = 0;
  }

  update() {
    this.tick = (this.tick + 1) % this.period;
    const mine = (this.tick - this.delay + this.period) % this.period;      //frames since my attack began
    const theirs = (mine + this.period / 2) % this.period;                  //frames since the opponent's began

    //My attack: 20 frames out and back
    this.spriteOffsetX = mine < 20
      ? Math.round(Math.sin(Math.PI * mine / 20) * 5) * this.towards
      : 0;
    //Getting hit: a small hop when the opponent's lunge lands (its frames 10 to 26)
    this.spriteOffsetY = theirs >= 10 && theirs < 26
      ? -Math.round(Math.sin(Math.PI * (theirs - 10) / 16) * 3)
      : 0;
  }
}
