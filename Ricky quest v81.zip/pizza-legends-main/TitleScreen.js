class TitleScreen {
  constructor({ progress }) {
    this.progress = progress;
  }

  getOptions(resolve) {
    const safeFile = this.progress.getSaveFile();
    return [
      {
        label: "Nová hra",
        description: `Začni nové pizzové dobrodružství! \n (Na mobilech nefunguje)`,
        handler: () => {
          this.close();
          resolve();
        }
      },
      safeFile ? {
        label: "Pokračovat",
        description: typeof safeFile?.playerState?.playTime === "number"
          ? `Pokračuj ve svém dobrodružství (odehráno ${PlayerState.formatPlayTime(safeFile.playerState.playTime)})`
          : "Pokračuj ve svém dobrodružství",
        handler: () => {
          this.close();
          resolve(safeFile);
        }
      } : null,
      {
        label: "Nastavení",
        description: "Jazyk hry a záloha uložené hry",
        handler: () => {
          this.backupNote = null;
          this.keyboardMenu.setOptions(this.getSettings(resolve));
        }
      },
    ].filter(v => v);
  }

  //Settings, the same as in the pause menu: the language of the game (Lang.js) and the saved game as a file, out and in
  //(Progress.getBackupOptions). A saved game taken in here shows up as "Pokračovat" after going back.
  getSettings(resolve) {
    return [
      {
        label: Lang.label(),
        description: Lang.describe(),
        handler: () => {
          Lang.toggle();
          this.backupNote = null;
          this.keyboardMenu.setOptions(this.getSettings(resolve));
        }
      },
      ...this.progress.getBackupOptions({
        note: this.backupNote,
        show: note => {
          if (!this.element.isConnected) { return; } //the game was started in the meantime
          this.backupNote = note;
          this.keyboardMenu.setOptions(this.getSettings(resolve), note.index + 1);
        },
      }),
      {
        label: "Zpět",
        description: "Zpět na úvodní obrazovku",
        handler: () => {
          this.keyboardMenu.setOptions(this.getOptions(resolve));
        }
      },
    ];
  }

  createElement() {
    this.element = document.createElement("div");
    this.element.classList.add("TitleScreen");
    this.element.innerHTML = (`
      <img class="TitleScreen_logo" src="images/logo.png" alt="Ricky Quest" />
    `)

  }

  close() {
    this.keyboardMenu.end();
    this.element.remove();
  }

  init(container) {
    return new Promise(resolve => {
      this.createElement();
      container.appendChild(this.element);
      this.keyboardMenu = new KeyboardMenu();
      this.keyboardMenu.init(this.element);
      this.keyboardMenu.setOptions(this.getOptions(resolve))
    })
  }

}