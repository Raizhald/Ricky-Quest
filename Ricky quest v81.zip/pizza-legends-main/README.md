# pizza-legends

This is a demo project that works on desktops only.

Move your character using WASD or arrow keys.
Press E (or ENTER) when facing an opponent to battle. E also confirms in menus, W/S or arrow keys move through them.

Press ESC to save progress.
