class Overworld {
  constructor(config) {
    this.element = config.element;
    this.canvas = this.element.querySelector(".game-canvas");
    this.ctx = this.canvas.getContext("2d");
    this.map = null;
  }

  startGameLoop() {
    //Game logic runs at a fixed 60 steps per second whatever the refresh rate of the screen is
    //(on a 120 or 144 Hz monitor requestAnimationFrame fires more often, which used to speed everything up).
    //Drawing still happens on every screen frame.
    const STEP_MS = 1000 / 60;
    let lastTime = performance.now();
    let accumulated = 0;

    const step = (now) => {
      now = now || performance.now();
      accumulated += Math.min(now - lastTime, 250); //after a long pause (hidden tab) don't catch up for ages
      lastTime = now;

      //Clear off the canvas
      this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

      //Establish the camera person
      const cameraPerson = this.map.gameObjects.hero;

      //Update all objects, once per 1/60 s (1 ms of tolerance so a real 60 Hz screen never skips a step)
      while (accumulated >= STEP_MS - 1) {
        accumulated -= STEP_MS;
        Object.values(this.map.gameObjects).forEach(object => {
          object.update({
            arrow: this.directionInput.direction,
            map: this.map,
          })
          object.sprite.updateAnimationProgress?.();
        })
        //Somebody who keeps turning around may have just turned to face the hero
        this.map.checkForTrainerSight();
      }

      //Draw Lower layer
      this.map.drawLowerImage(this.ctx, cameraPerson);

      //Draw Game Objects
      Object.values(this.map.gameObjects).sort((a, b) => {
        return a.y - b.y;
      }).forEach(object => {
        object.sprite.draw(this.ctx, cameraPerson);
      })

      //Draw Upper layer
      this.map.drawUpperImage(this.ctx, cameraPerson);

      //Evening and night: a colour over everything drawn so far. Rooms have their lights on, so only a third of it.
      const [red, green, blue, alpha] = playerState.getDaylightTint();
      const strength = alpha * (this.map.isOutdoors ? 1 : 0.35);
      if (strength > 0.005) {
        this.ctx.save();
        this.ctx.globalCompositeOperation = "source-atop"; //only where the map is, not on the empty space around it
        this.ctx.fillStyle = `rgba(${Math.round(red)}, ${Math.round(green)}, ${Math.round(blue)}, ${strength.toFixed(3)})`;
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        this.ctx.restore();
      }

      if (!this.map.isPaused) {
        requestAnimationFrame(step)
      }
    }
    step();
  }

  bindActionInput() {
    new KeyPressListener(["KeyE", "Enter"], () => {
      //Is there a person here to talk to?
      this.map.checkForActionCutscene()
    })
    new KeyPressListener("Escape", () => {
      if (!this.map.isCutscenePlaying) {
        this.map.startCutscene([
          { type: "pause" }
        ])
      }
    })
  }

  bindHeroPositionCheck() {
    document.addEventListener("PersonWalkingComplete", e => {
      if (e.detail.whoId === "hero") {
        //Hero's position has changed
        this.map.checkForFootstepCutscene()
        this.map.checkForTrainerSight()
        this.map.checkForWildEncounter()
      }
    })
  }

  startMap(mapConfig, heroInitialState = null) {
    this.map = new OverworldMap(mapConfig);
    this.map.overworld = this;
    this.map.mountObjects();

    if (heroInitialState) {
      const { hero } = this.map.gameObjects;
      this.map.removeWall(hero.x, hero.y);
      //Keep the map's default spot if the requested one is inside a wall (e.g. an older save file)
      if (!this.map.walls[`${heroInitialState.x}, ${heroInitialState.y}`]) {
        hero.x = heroInitialState.x;
        hero.y = heroInitialState.y;
      }
      hero.direction = heroInitialState.direction;
      this.map.addWall(hero.x, hero.y);
    }

    this.progress.mapId = mapConfig.id;
    this.progress.startingHeroX = this.map.gameObjects.hero.x;
    this.progress.startingHeroY = this.map.gameObjects.hero.y;
    this.progress.startingHeroDirection = this.map.gameObjects.hero.direction;

    console.log(this.map.walls)

  }

  async init() {

    const container = document.querySelector(".game-container");

    //Create a new Progress tracker
    this.progress = new Progress();

    //Show the title screen
    this.titleScreen = new TitleScreen({
      progress: this.progress
    })
    const useSaveFile = await this.titleScreen.init(container);

    //Potentially load saved data
    let initialHeroState = null;
    if (useSaveFile) {
      this.progress.load();
      initialHeroState = {
        x: this.progress.startingHeroX,
        y: this.progress.startingHeroY,
        direction: this.progress.startingHeroDirection,
      }
    }

    //Load the HUD
    this.hud = new Hud();
    this.hud.init(container);

    //Start the first map
    this.startMap(window.OverworldMaps[this.progress.mapId], initialHeroState);

    //The clock in the corner; it also counts play time and game time
    this.gameClock = new GameClock({ overworld: this });
    this.gameClock.init(container);

    //Create controls
    this.bindActionInput();
    this.bindHeroPositionCheck();

    this.directionInput = new DirectionInput();
    this.directionInput.init();

    //Kick off the game!
    this.startGameLoop();


    //A new game opens in the DEMO house: the hero comes out of the door in the back wall, Beth walks over and blocks the front door
    if (!useSaveFile) {
      this.map.startCutscene([
        { type: "walkPath", who: "hero", path: ["down", "left", "left"] },
        { type: "textMessage", text: "Dobré ráno! Dneska to začíná: staneš se Pizza Legendou." },
        { type: "textMessage", text: "Pizza kámen je tady vlevo. Nejdřív si na něm upeč svou pizzu!" },
        { type: "walkPath", who: "npcA", path: ["left", "left"] },
        { type: "stand", who: "npcA", direction: "down", time: 300 },
        { type: "textMessage", text: "Hej! Ven se dostaneš jedině přese mě.", faceHero: "npcA" },
        { type: "textMessage", text: "Upeč si pizzu na kameni a pak se ukaž v souboji!", faceHero: "npcA" },
        { type: "addStoryFlag", flag: "DEMO_INTRO_DONE" },
      ])
    }

  }
}